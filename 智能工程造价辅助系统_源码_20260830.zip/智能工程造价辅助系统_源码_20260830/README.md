﻿# 大硕造价云库 开发环境

## 技术栈

- Python 3.12.10
- PySide6：桌面界面
- SQLite：本地数据库
- SQLAlchemy：数据库模型与应用内迁移
- openpyxl / xlrd：Excel 导入导出
- requests / BeautifulSoup / lxml：官方网页抓取与解析
- pdfplumber / PyMuPDF：PDF 信息价解析
- requests：DeepSeek OpenAI-compatible HTTP API 接入
- PyInstaller：打包 EXE

## 启动虚拟环境

```powershell
cd C:\Users\Thinkpad\Documents\Codex\2026-07-29\za\work\dashuo-cost-cloud
.\.venv\Scripts\Activate.ps1
```

## 验证依赖

```powershell
python --version
python -m pip list
pyinstaller --version
```

## 后续建议

1. 先搭 PySide6 主窗口和分组导航。
2. 再建 SQLite 数据库表。
3. 先做信息价订阅和价格库。
4. 再做项目报价联动。
5. 最后做打包 EXE。
