"""定额库下的企业参考定额表页面。"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView, QFileDialog, QFormLayout, QHBoxLayout, QHeaderView,
    QComboBox, QLabel, QLineEdit, QMessageBox, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from src.db import get_session
from src.models import ProjectListData
from src.project_list_data_service import HEADERS, import_project_list_data, search_project_list_data
from src.ui.widgets import ActionButton, SectionHeader, install_long_text_tooltip
from src.ui.quota_library import CellContentEditDialog


class ProjectListDataPage(QWidget):
    data_changed = Signal()
    DISPLAY_FIELDS = [
        "seq_no", "item_code", "item_name", "feature", "unit", "analysis",
        "comprehensive_price", "labor_cost", "material_cost", "machinery_cost",
        "management_cost", "profit", "note", "source_project", "source_sheet",
        "region", "period",
    ]
    DISPLAY_HEADERS = [
        "序号", "项目编码", "清单名称", "项目特征及工作内容", "单位",
        "单位价格组成", "除税综合单价", "人工费", "材料费", "机械费",
        "管理费", "利润", "备注", "来源项目", "来源工作表", "地区", "月份",
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self._rows = []
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 18, 22, 18)
        root.addWidget(SectionHeader("企业参考定额表"))
        intro = QLabel("导入企业参考定额总表、项目报价表或带组价明细的清单。系统自动识别清单名称、项目特征、单位和价格，并按每1个清单单位生成单位价格参考；原始工程量、总价和换算依据保存在记录中供追溯，不会改写正式定额库。")
        intro.setStyleSheet("color:#64748b; padding:4px 0 10px;")
        intro.setWordWrap(True)
        root.addWidget(intro)
        tools = QHBoxLayout()
        self._keyword = QLineEdit()
        self._keyword.setPlaceholderText("搜索项目名称、项目特征、企业编码、组成明细、地区或月份")
        self._keyword.textChanged.connect(self.refresh_data)
        tools.addWidget(self._keyword, 1)
        self._source_filter = QComboBox()
        self._source_filter.setMinimumWidth(180)
        self._source_filter.setToolTip("按表格中的来源项目筛选")
        self._source_filter.currentIndexChanged.connect(self.refresh_data)
        tools.addWidget(self._source_filter)
        self._region_filter = QComboBox()
        self._region_filter.setMinimumWidth(100)
        self._region_filter.setToolTip("按地区筛选")
        self._region_filter.currentIndexChanged.connect(self.refresh_data)
        tools.addWidget(self._region_filter)
        self._period_filter = QComboBox()
        self._period_filter.setMinimumWidth(100)
        self._period_filter.setToolTip("按价格月份筛选")
        self._period_filter.currentIndexChanged.connect(self.refresh_data)
        tools.addWidget(self._period_filter)
        import_button = ActionButton("导入企业参考定额表", "primary")
        import_button.clicked.connect(self._import)
        tools.addWidget(import_button)
        delete_button = ActionButton("删除选中", "warn")
        delete_button.setToolTip("删除选中的企业参考定额记录")
        delete_button.clicked.connect(self._delete_selected)
        tools.addWidget(delete_button)
        self._source_label = QLabel("支持：项目清单、报价清单、企业参考定额表")
        self._source_label.setStyleSheet("color:#64748b;")
        tools.addWidget(self._source_label)
        root.addLayout(tools)
        self._table = QTableWidget(0, len(self.DISPLAY_HEADERS))
        self._table.setHorizontalHeaderLabels(self.DISPLAY_HEADERS)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setWordWrap(False)
        self._table.setTextElideMode(Qt.ElideRight)
        self._table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self._table.setStyleSheet("QTableWidget{background:#fff;border:1px solid #e2e8f0;gridline-color:#e2e8f0;} QHeaderView::section{background:#f8fafc;padding:8px;font-weight:600;}")
        self._table.setFont(QFont("Microsoft YaHei", 10))
        install_long_text_tooltip(self._table)
        self._table.cellDoubleClicked.connect(self._edit_cell)
        root.addWidget(self._table, 1)
        self._summary = QLabel("尚未导入企业参考定额表")
        self._summary.setStyleSheet("color:#475569; padding-top:8px;")
        root.addWidget(self._summary)

    def show_route(self, route_key: str):
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            self._load_filter_options(session)
            self._rows = search_project_list_data(
                session, self._keyword.text().strip(), limit=None,
                source_project=self._source_filter.currentData() or "",
                region=self._region_filter.currentData() or "",
                period=self._period_filter.currentData() or "",
            )
        finally:
            session.close()
        self._render()

    def _load_filter_options(self, session):
        current_values = (self._source_filter.currentData(), self._region_filter.currentData(), self._period_filter.currentData())
        filter_specs = (
            (self._source_filter, "全部来源项目", ProjectListData.source_project),
            (self._region_filter, "全部地区", ProjectListData.region),
            (self._period_filter, "全部月份", ProjectListData.period),
        )
        for index, (combo, placeholder, column) in enumerate(filter_specs):
            values = [value[0] for value in session.query(column).filter(column.isnot(None), column != "").distinct().order_by(column.asc()).all()]
            combo.blockSignals(True)
            combo.clear()
            combo.addItem(placeholder, "")
            for value in values:
                combo.addItem(str(value), str(value))
            wanted_index = combo.findData(current_values[index])
            combo.setCurrentIndex(wanted_index if wanted_index >= 0 else 0)
            combo.blockSignals(False)

    def _render(self):
        self._table.setRowCount(len(self._rows))
        fields = self.DISPLAY_FIELDS
        for r, record in enumerate(self._rows):
            for c, field in enumerate(fields):
                value = getattr(record, field, "")
                if value is None:
                    value = ""
                item = QTableWidgetItem(str(value))
                item.setData(Qt.UserRole, record.id)
                item.setTextAlignment(Qt.AlignCenter)
                if field in {"feature", "analysis", "note"}:
                    item.setToolTip(str(value))
                self._table.setItem(r, c, item)
        widths = [55, 130, 220, 390, 65, 260, 110, 85, 85, 85, 85, 85, 180, 180, 120, 100, 90]
        for index, width in enumerate(widths):
            self._table.setColumnWidth(index, width)
        self._summary.setText(
            f"当前显示 {len(self._rows):,} 条单位价格参考；原工程量和总价保存在原始记录中，"
            "匹配按每1个清单单位计价；原始工程量和总价仅用于追溯。可按来源、工作表、地区和月份筛选，双击单元格可编辑。"
        )

    def _delete_selected(self):
        selected_rows = sorted({index.row() for index in self._table.selectionModel().selectedRows()})
        ids = [self._rows[row].id for row in selected_rows if 0 <= row < len(self._rows)]
        if not ids:
            QMessageBox.information(self, "未选择记录", "请先选择要删除的企业参考定额行。")
            return
        answer = QMessageBox.question(
            self, "确认删除",
            f"确定删除选中的 {len(ids):,} 条企业参考定额记录吗？\n\n只删除参考数据，不影响正式定额库。",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        session = get_session()
        try:
            deleted = session.query(ProjectListData).filter(ProjectListData.id.in_(ids)).delete(synchronize_session=False)
            session.commit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "删除失败", str(error))
            return
        finally:
            session.close()
        QMessageBox.information(self, "删除完成", f"已删除 {deleted:,} 条企业参考定额记录。")
        self.refresh_data()
        self.data_changed.emit()

    def _import(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入企业参考定额表", "", "Excel 文件 (*.xlsx *.xls)")
        if not path:
            return
        from PySide6.QtWidgets import QDialog, QDialogButtonBox
        wrapper = QDialog(self)
        wrapper.setWindowTitle("补充企业参考定额来源信息")
        wrapper.setMinimumWidth(420)
        layout = QVBoxLayout(wrapper)
        form = QFormLayout()
        project = QComboBox()
        project.setEditable(False)
        project.addItem("不关联已有来源（使用文件名）", "")
        project_session = get_session()
        try:
            source_projects = project_session.query(ProjectListData.source_project).filter(
                ProjectListData.source_project.isnot(None),
                ProjectListData.source_project != "",
            ).distinct().order_by(ProjectListData.source_project.asc()).all()
            for (source_name,) in source_projects:
                project.addItem(source_name, source_name)
        finally:
            project_session.close()
        manual_project = QLineEdit()
        manual_project.setPlaceholderText("选择“手动输入”时填写")
        project.addItem("手动输入其他来源项目", "__manual__")
        region = QLineEdit()
        period = QLineEdit()
        period.setPlaceholderText("例如 2026-07")
        for label, widget in (("来源项目（选择表中已有来源）", project), ("项目地区（可留空，自动识别）", region), ("价格月份（可留空，自动识别）", period)):
            form.addRow(label, widget)
        form.addRow("其他来源项目名称", manual_project)
        manual_project.setVisible(False)
        project.currentIndexChanged.connect(lambda index: manual_project.setVisible(project.itemData(index) == "__manual__"))
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(wrapper.accept)
        buttons.rejected.connect(wrapper.reject)
        layout.addWidget(buttons)
        if wrapper.exec() != QDialog.Accepted:
            return
        session = get_session()
        try:
            selected_project = project.currentData()
            source_project = manual_project.text().strip() if selected_project == "__manual__" else (selected_project or "")
            result = import_project_list_data(path, session, source_project=source_project, region=region.text().strip(), period=period.text().strip())
        finally:
            session.close()
        if not result.get("success"):
            QMessageBox.warning(self, "导入失败", result.get("error", "无法识别企业参考定额表"))
            return
        format_name = result.get("format", "普通项目清单")
        valid = int(result.get("valid") or result.get("imported", 0) or 0) + int(result.get("updated", 0) or 0) if "valid" not in result else int(result.get("valid") or 0)
        details = (
            f"格式：{format_name}\n"
            f"本次识别有效 {valid:,} 条\n"
            f"新增 {result.get('imported', 0):,} 条，更新 {result.get('updated', 0):,} 条，"
            f"跳过/拦截 {result.get('skipped', 0):,} 行。"
        )
        if result.get("component_count"):
            details += f"\n已关联定额子目组成 {result['component_count']:,} 条。"
        if result.get("region") or result.get("period"):
            details += f"\n地区：{result.get('region') or '未识别'}；价格月份：{result.get('period') or '未识别'}。"
        details += "\n参考数据不会改写正式定额库，后续匹配时仅作为同类案例和价格依据。"
        QMessageBox.information(self, "导入完成", details)
        self.refresh_data()
        self.data_changed.emit()

    def _edit_cell(self, row: int, column: int):
        record = self._rows[row] if 0 <= row < len(self._rows) else None
        if record is None or column >= len(self.DISPLAY_FIELDS):
            return
        field = self.DISPLAY_FIELDS[column]
        item = self._table.item(row, column)
        dialog = CellContentEditDialog(self._table.horizontalHeaderItem(column).text(), item.text() if item else "", parent=self)
        if dialog.exec() != dialog.Accepted:
            return
        value = dialog.value()
        if field in {"comprehensive_price", "labor_cost", "material_cost", "machinery_cost", "management_cost", "profit"}:
            try:
                value = float(value) if value else None
            except ValueError:
                QMessageBox.warning(self, "格式错误", "该字段必须填写数字。")
                return
        session = get_session()
        try:
            setattr(session.query(type(record)).filter(type(record).id == record.id).first(), field, value)
            session.commit()
        finally:
            session.close()
        self.refresh_data()
        self.data_changed.emit()
