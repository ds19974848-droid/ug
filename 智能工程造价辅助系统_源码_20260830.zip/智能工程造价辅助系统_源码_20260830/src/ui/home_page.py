"""首页造价数据驾驶舱。"""
from datetime import datetime

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QProgressBar,
    QScrollArea,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from sqlalchemy import func

from src.db import get_db_stats, get_session
from src.models import (
    CostItem,
    Material,
    MaterialPrice,
    OfficialSource,
    Project,
    ProjectItem,
    Region,
    SourceDocument,
    SubscriptionTask,
)
from src.ui.widgets import ActionButton, StatusBadge
from src.utils import is_official_domain


PANEL_STYLE = "background:#ffffff; border:1px solid #e1e7ef; border-radius:8px;"
TABLE_STYLE = (
    "QTableWidget { background:#fff; border:none; gridline-color:#edf1f6; }"
    "QTableWidget::item { padding:6px; border-bottom:1px solid #f0f3f7; }"
    "QHeaderView::section { background:#f8fafc; color:#64748b; font-weight:bold;"
    " border:none; border-bottom:1px solid #e5eaf0; padding:7px 6px; }"
)


class PriceTrendChart(QWidget):
    def __init__(self):
        super().__init__()
        self._title = "暂无价格趋势"
        self._points: list[tuple[str, float]] = []
        self.setMinimumHeight(205)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_series(self, title: str, points: list[tuple[str, float]]):
        self._title = title
        self._points = points[-12:]
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), QColor("#ffffff"))
        painter.setPen(QColor("#0f172a"))
        painter.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        painter.drawText(18, 25, self._title)
        if len(self._points) < 2:
            painter.setPen(QColor("#94a3b8"))
            painter.setFont(QFont("Microsoft YaHei", 9))
            painter.drawText(self.rect(), Qt.AlignCenter, "确认两期以上价格后显示趋势")
            return

        chart = QRectF(54, 43, max(80, self.width() - 76), max(80, self.height() - 78))
        values = [value for _, value in self._points]
        low = min(values)
        high = max(values)
        padding = max((high - low) * 0.2, max(high, 1) * 0.02)
        low -= padding
        high += padding

        painter.setFont(QFont("Microsoft YaHei", 8))
        for index in range(4):
            ratio = index / 3
            y = chart.bottom() - chart.height() * ratio
            painter.setPen(QPen(QColor("#e8edf3"), 1))
            painter.drawLine(QPointF(chart.left(), y), QPointF(chart.right(), y))
            painter.setPen(QColor("#94a3b8"))
            value = low + (high - low) * ratio
            painter.drawText(QRectF(0, y - 9, 48, 18), Qt.AlignRight | Qt.AlignVCenter, f"{value:,.0f}")

        plot_points = []
        for index, (_, value) in enumerate(self._points):
            x = chart.left() + chart.width() * index / (len(self._points) - 1)
            y = chart.bottom() - chart.height() * (value - low) / (high - low)
            plot_points.append(QPointF(x, y))

        area = QPainterPath(plot_points[0])
        for point in plot_points[1:]:
            area.lineTo(point)
        area.lineTo(chart.right(), chart.bottom())
        area.lineTo(chart.left(), chart.bottom())
        area.closeSubpath()
        painter.fillPath(area, QColor(14, 165, 164, 28))

        line = QPainterPath(plot_points[0])
        for point in plot_points[1:]:
            line.lineTo(point)
        painter.setPen(QPen(QColor("#0f9f9a"), 2.4))
        painter.drawPath(line)
        painter.setBrush(QColor("#ffffff"))
        for point in plot_points:
            painter.setPen(QPen(QColor("#0f9f9a"), 2))
            painter.drawEllipse(point, 3.5, 3.5)

        painter.setPen(QColor("#64748b"))
        first_period = self._points[0][0]
        last_period = self._points[-1][0]
        painter.drawText(QRectF(chart.left(), chart.bottom() + 8, 80, 18), Qt.AlignLeft, first_period)
        painter.drawText(QRectF(chart.right() - 80, chart.bottom() + 8, 80, 18), Qt.AlignRight, last_period)


class HomePage(QWidget):
    navigate_requested = Signal(str)

    def __init__(self):
        super().__init__()
        self._metric_values = {}
        self._pipeline_values = {}
        self._category_bars = []
        self._setup_ui()
        QTimer.singleShot(50, self._load_data)

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet("QScrollArea { background:#f3f6fa; border:none; }")
        content = QWidget()
        content.setStyleSheet("background:#f3f6fa;")
        layout = QVBoxLayout(content)
        layout.setContentsMargins(22, 18, 22, 22)
        layout.setSpacing(12)

        layout.addWidget(self._build_header())
        layout.addWidget(self._build_metric_strip())

        dashboard = QGridLayout()
        dashboard.setContentsMargins(0, 0, 0, 0)
        dashboard.setHorizontalSpacing(12)
        dashboard.setVerticalSpacing(12)
        dashboard.setColumnStretch(0, 7)
        dashboard.setColumnStretch(1, 4)
        dashboard.addWidget(self._build_trend_panel(), 0, 0)
        dashboard.addWidget(self._build_pipeline_panel(), 0, 1)
        dashboard.addWidget(self._build_category_panel(), 1, 0)
        dashboard.addWidget(self._build_activity_panel(), 1, 1)
        layout.addLayout(dashboard)
        layout.addStretch()

        scroll.setWidget(content)
        root.addWidget(scroll)

    def _build_header(self) -> QFrame:
        header = QFrame()
        header.setStyleSheet("background:#111827; border:none; border-radius:8px;")
        layout = QHBoxLayout(header)
        layout.setContentsMargins(20, 16, 18, 16)
        title_box = QVBoxLayout()
        title = QLabel("造价项目总览")
        title.setFont(QFont("Microsoft YaHei", 20, QFont.Bold))
        title.setStyleSheet("color:#ffffff; border:none;")
        title_box.addWidget(title)
        self._headline_status = QLabel("正在读取造价数据资产...")
        self._headline_status.setStyleSheet("color:#a7b0bf; font-size:12px; border:none;")
        title_box.addWidget(self._headline_status)
        layout.addLayout(title_box)
        layout.addStretch()
        projects = ActionButton("项目信息", "primary")
        projects.clicked.connect(lambda: self.navigate_requested.emit("project_info"))
        layout.addWidget(projects)
        project = ActionButton("匹配定额库", "default")
        project.setStyleSheet("background:#ffffff; color:#111827; border:none; border-radius:7px; padding:0 14px; font-weight:700;")
        project.clicked.connect(lambda: self.navigate_requested.emit("quota_match"))
        layout.addWidget(project)
        return header

    def _build_metric_strip(self) -> QFrame:
        strip = QFrame()
        strip.setStyleSheet(PANEL_STYLE)
        layout = QHBoxLayout(strip)
        layout.setContentsMargins(8, 10, 8, 10)
        metrics = [
            ("项目总数", "projects", "#172033"),
            ("进行中", "doing_projects", "#167d8d"),
            ("已锁定", "locked_projects", "#2563eb"),
            ("项目清单", "project_items", "#7c3aed"),
            ("项目总造价", "project_amount", "#b45309"),
            ("定额数据", "quota", "#0e7490"),
            ("信息价", "prices", "#0f766e"),
        ]
        for index, (label, key, color) in enumerate(metrics):
            metric = QWidget()
            box = QVBoxLayout(metric)
            box.setContentsMargins(12, 4, 12, 4)
            name = QLabel(label)
            name.setStyleSheet("color:#64748b; font-size:11px; border:none;")
            box.addWidget(name)
            value = QLabel("0")
            value.setFont(QFont("Microsoft YaHei", 18, QFont.Bold))
            value.setStyleSheet(f"color:{color}; border:none;")
            box.addWidget(value)
            self._metric_values[key] = value
            layout.addWidget(metric, 1)
            if index < len(metrics) - 1:
                divider = QFrame()
                divider.setFrameShape(QFrame.VLine)
                divider.setStyleSheet("color:#e5eaf0;")
                layout.addWidget(divider)
        return strip

    def _panel(self, title: str, action_text: str = "", route: str = "") -> tuple[QFrame, QVBoxLayout]:
        panel = QFrame()
        panel.setStyleSheet(PANEL_STYLE)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 13, 16, 14)
        layout.setSpacing(10)
        header = QHBoxLayout()
        label = QLabel(title)
        label.setFont(QFont("Microsoft YaHei", 11, QFont.Bold))
        label.setStyleSheet("color:#0f172a; border:none;")
        header.addWidget(label)
        header.addStretch()
        if action_text:
            action = ActionButton(action_text, "default")
            action.clicked.connect(lambda: self.navigate_requested.emit(route))
            header.addWidget(action)
        layout.addLayout(header)
        return panel, layout

    def _build_trend_panel(self) -> QFrame:
        panel, layout = self._panel("官方价格走势", "查看价格库", "price_library")
        self._trend_chart = PriceTrendChart()
        layout.addWidget(self._trend_chart, 1)
        self._trend_note = QLabel("价格曲线来自已确认的地方信息价")
        self._trend_note.setStyleSheet("color:#64748b; font-size:11px; border:none;")
        layout.addWidget(self._trend_note)
        return panel

    def _build_pipeline_panel(self) -> QFrame:
        panel, layout = self._panel("官方数据管线", "查看任务", "subscription")
        self._pipeline_status = QLabel("尚未执行官网抓取")
        self._pipeline_status.setWordWrap(True)
        self._pipeline_status.setStyleSheet("color:#475569; font-size:12px; border:none;")
        layout.addWidget(self._pipeline_status)
        stages = [
            ("可用官方源", "sources", "#2563eb"),
            ("已保存原文件", "documents", "#7c3aed"),
            ("待人工确认", "pending", "#d97706"),
            ("已确认价格", "confirmed", "#0f9f9a"),
        ]
        for label, key, color in stages:
            row = QHBoxLayout()
            name = QLabel(label)
            name.setStyleSheet("color:#64748b; font-size:11px; border:none;")
            row.addWidget(name)
            row.addStretch()
            value = QLabel("0")
            value.setFont(QFont("Microsoft YaHei", 12, QFont.Bold))
            value.setStyleSheet(f"color:{color}; border:none;")
            row.addWidget(value)
            self._pipeline_values[key] = value
            layout.addLayout(row)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(0)
            bar.setTextVisible(False)
            bar.setFixedHeight(6)
            bar.setStyleSheet(
                f"QProgressBar {{ background:#edf1f5; border:none; border-radius:3px; }}"
                f"QProgressBar::chunk {{ background:{color}; border-radius:3px; }}"
            )
            self._pipeline_values[f"{key}_bar"] = bar
            layout.addWidget(bar)
        layout.addStretch()
        return panel

    def _build_category_panel(self) -> QFrame:
        panel, layout = self._panel("固定清单专业分布", "打开固定库", "bq_library")
        self._category_layout = QVBoxLayout()
        self._category_layout.setSpacing(8)
        layout.addLayout(self._category_layout)
        self._category_empty = QLabel("正在统计清单分类...")
        self._category_empty.setStyleSheet("color:#94a3b8; border:none;")
        self._category_layout.addWidget(self._category_empty)
        layout.addStretch()
        return panel

    def _build_activity_panel(self) -> QFrame:
        panel, layout = self._panel("最近项目", "查看全部项目", "project_info")
        self._task_table = QTableWidget(0, 4)
        self._task_table.setHorizontalHeaderLabels(["项目", "状态", "清单", "总造价"])
        self._task_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self._task_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self._task_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self._task_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self._task_table.verticalHeader().setVisible(False)
        self._task_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._task_table.setSelectionMode(QTableWidget.NoSelection)
        self._task_table.setStyleSheet(TABLE_STYLE)
        self._task_table.setMinimumHeight(205)
        layout.addWidget(self._task_table, 1)
        self._portfolio_note = QLabel("暂无项目，请先建立项目档案。")
        self._portfolio_note.setStyleSheet("color:#64748b; font-size:11px; border:none;")
        layout.addWidget(self._portfolio_note)
        return panel

    def refresh_data(self):
        self._load_data()

    def _load_data(self):
        try:
            stats = get_db_stats()
            session = get_session()
            try:
                documents = session.query(func.count(SourceDocument.id)).scalar() or 0
                confirmed = session.query(func.count(MaterialPrice.id)).filter(
                    MaterialPrice.is_confirmed.is_(True),
                ).scalar() or 0
                pending = session.query(func.count(MaterialPrice.id)).filter(
                    MaterialPrice.is_confirmed.is_(False),
                ).scalar() or 0
                project_amount = session.query(func.sum(Project.total_amount)).scalar() or 0
                project_items = session.query(func.count(ProjectItem.id)).scalar() or 0
                doing_projects = session.query(func.count(Project.id)).filter(Project.status == "doing").scalar() or 0
                locked_projects = session.query(func.count(Project.id)).filter(Project.status == "locked").scalar() or 0
                official_sources = session.query(OfficialSource).filter(
                    OfficialSource.is_official.is_(True),
                    OfficialSource.is_active.is_(True),
                ).all()
                available_sources = sum(
                    1 for source in official_sources
                    if is_official_domain(source.url)
                    and source.last_result in {"connected", "success", "empty"}
                )

                self._metric_values["quota"].setText(f"{stats['quota_items']:,}")
                self._metric_values["prices"].setText(f"{stats['prices']:,}")
                self._metric_values["projects"].setText(f"{stats['projects']:,}")
                self._metric_values["doing_projects"].setText(f"{doing_projects:,}")
                self._metric_values["locked_projects"].setText(f"{locked_projects:,}")
                self._metric_values["project_items"].setText(f"{project_items:,}")
                self._metric_values["project_amount"].setText(f"¥{project_amount / 10000:,.1f}万")

                pipeline = {
                    "sources": available_sources,
                    "documents": documents,
                    "pending": pending,
                    "confirmed": confirmed,
                }
                maximum = max(pipeline.values(), default=1) or 1
                for key, value in pipeline.items():
                    self._pipeline_values[key].setText(f"{value:,}")
                    self._pipeline_values[f"{key}_bar"].setValue(max(4 if value else 0, int(value / maximum * 100)))

                latest_task = session.query(SubscriptionTask).order_by(
                    SubscriptionTask.created_at.desc(),
                ).first()
                if latest_task:
                    latest_text = latest_task.created_at.strftime("%Y-%m-%d %H:%M")
                    self._headline_status.setText(
                        f"{stats['cost_items']:,} 条固定清单 · {stats['quota_items']:,} 条定额 · "
                        f"{stats['prices']:,} 条动态价格 · 最近同步 {latest_text}"
                    )
                    self._pipeline_status.setText(
                        f"最近任务 {latest_text}，结果 {latest_task.result_count:,} 条；"
                        f"当前 {available_sources} 个可用官方来源。"
                    )
                else:
                    self._headline_status.setText(
                        f"{stats['cost_items']:,} 条固定清单 · {stats['quota_items']:,} 条定额已就绪 · "
                        "等待首次官方数据抓取"
                    )
                    self._pipeline_status.setText("尚未执行官网抓取，可从上海等地区的官方来源开始。")

                self._load_trend(session)
                self._load_categories(session)
                self._load_tasks(session)
                self._load_portfolio(session, project_amount)
            finally:
                session.close()
        except Exception as error:
            self._headline_status.setText(f"首页数据加载失败：{error}")

    def _load_trend(self, session):
        material = (
            session.query(Material)
            .join(MaterialPrice)
            .filter(MaterialPrice.is_confirmed.is_(True))
            .group_by(Material.id)
            .order_by(func.count(MaterialPrice.id).desc())
            .first()
        )
        if material is None:
            self._trend_chart.set_series("暂无已确认价格", [])
            return
        prices = (
            session.query(MaterialPrice)
            .filter(
                MaterialPrice.material_id == material.id,
                MaterialPrice.is_confirmed.is_(True),
            )
            .order_by(MaterialPrice.period.asc())
            .limit(12)
            .all()
        )
        points = [(price.period, price.price) for price in prices]
        region = prices[-1].region_obj.name if prices and prices[-1].region_obj else ""
        self._trend_chart.set_series(f"{material.name} · {region}", points)
        if len(points) >= 2 and points[-2][1]:
            change = (points[-1][1] - points[-2][1]) / points[-2][1]
            self._trend_note.setText(
                f"最新 {points[-1][0]}：¥{points[-1][1]:,.2f}，较上期 {change:+.1%}"
            )
        elif points:
            self._trend_note.setText(f"最新 {points[-1][0]}：¥{points[-1][1]:,.2f}")

    def _load_categories(self, session):
        while self._category_layout.count():
            item = self._category_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        rows = (
            session.query(CostItem.original_category, func.count(CostItem.id))
            .filter(CostItem.original_category != "")
            .group_by(CostItem.original_category)
            .order_by(func.count(CostItem.id).desc())
            .limit(6)
            .all()
        )
        if not rows:
            empty = QLabel("暂无清单分类")
            empty.setStyleSheet("color:#94a3b8; border:none;")
            self._category_layout.addWidget(empty)
            return
        maximum = max(count for _, count in rows) or 1
        colors = ["#2563eb", "#0f9f9a", "#7c3aed", "#d97706", "#dc2626", "#475569"]
        for index, (category, count) in enumerate(rows):
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            name = QLabel(category[:18])
            name.setMinimumWidth(150)
            name.setStyleSheet("color:#334155; font-size:11px; border:none;")
            row_layout.addWidget(name)
            bar = QProgressBar()
            bar.setRange(0, maximum)
            bar.setValue(count)
            bar.setFormat(f"{count:,} 条")
            bar.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            color = colors[index % len(colors)]
            bar.setStyleSheet(
                f"QProgressBar {{ background:#edf1f5; border:none; border-radius:4px;"
                " color:#334155; padding-right:6px; height:18px; }}"
                f"QProgressBar::chunk {{ background:{color}; border-radius:4px; }}"
            )
            row_layout.addWidget(bar, 1)
            self._category_layout.addWidget(row)

    def _load_tasks(self, session):
        projects = session.query(Project).order_by(Project.updated_at.desc()).limit(6).all()
        item_counts = dict(
            session.query(ProjectItem.project_id, func.count(ProjectItem.id))
            .group_by(ProjectItem.project_id).all()
        )
        self._task_table.clearSpans()
        self._task_table.setRowCount(len(projects))
        status_map = {
            "draft": ("未开始", "neutral"), "doing": ("进行中", "warn"),
            "locked": ("已锁定", "info"), "archived": ("已归档", "ok"),
        }
        for row, project in enumerate(projects):
            self._task_table.setItem(row, 0, QTableWidgetItem(project.name or ""))
            status_text, status_kind = status_map.get(project.status, (project.status, "neutral"))
            self._task_table.setCellWidget(row, 1, StatusBadge(status_text, status_kind))
            count_item = QTableWidgetItem(f"{item_counts.get(project.id, 0):,}")
            count_item.setTextAlignment(Qt.AlignCenter)
            self._task_table.setItem(row, 2, count_item)
            amount_item = QTableWidgetItem(f"¥{project.total_amount or 0:,.2f}")
            amount_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self._task_table.setItem(row, 3, amount_item)
        if not projects:
            self._task_table.setRowCount(1)
            item = QTableWidgetItem("暂无项目，请从“项目信息”新建项目")
            item.setTextAlignment(Qt.AlignCenter)
            self._task_table.setSpan(0, 0, 1, 4)
            self._task_table.setItem(0, 0, item)

    def _load_portfolio(self, session, project_amount: float):
        projects = session.query(Project).order_by(Project.updated_at.desc()).limit(3).all()
        if not projects:
            self._portfolio_note.setText("暂无项目，请先建立项目档案。")
            return
        names = "、".join(project.name for project in projects)
        self._portfolio_note.setText(
            f"项目总造价 ¥{project_amount:,.2f} · 最近项目：{names}"
        )
