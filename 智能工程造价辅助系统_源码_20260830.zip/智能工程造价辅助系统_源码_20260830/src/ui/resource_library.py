"""统一资源库入口：定额与基础资源分层展示，信息价保持独立。"""
from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QTabWidget, QVBoxLayout, QWidget

from src.ui.base_database import BaseDatabasePage
from src.ui.project_list_data import ProjectListDataPage
from src.ui.quota_library import QuotaLibraryPage
from src.ui.widgets import SectionHeader


class ResourceLibraryPage(QWidget):
    """统一管理定额、企业案例和基础资源，内部仍保持各自数据边界。"""

    data_changed = Signal()

    TAB_ROUTES = {
        "resource_library": 0,
        "quota_library": 0,
        "quota_data": 0,
        "project_list_data": 1,
        "enterprise_reference": 1,
        "bq_library": 2,
        "market_library": 3,
        "material_library": 4,
    }

    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(10)
        root.addWidget(SectionHeader("定额与基础资源库"))

        self._tabs = QTabWidget()
        self._tabs.setDocumentMode(True)
        self._tabs.setStyleSheet(
            "QTabWidget::pane { border:none; background:#f0f4f9; }"
            "QTabBar::tab { padding:10px 18px; font-weight:600; "
            "border:none; color:#667085; }"
            "QTabBar::tab:selected { color:#2563eb; "
            "border-bottom:3px solid #2563eb; }"
        )
        root.addWidget(self._tabs, 1)

        self._quota_page = QuotaLibraryPage()
        self._enterprise_page = ProjectListDataPage()
        base_page = BaseDatabasePage()
        self._base_page = base_page

        tabs = [
            (self._quota_page, "正式定额与工料机"),
            (self._enterprise_page, "企业参考定额"),
        ]
        # Detach the non-price resource tabs from the legacy container before
        # placing them here. The official information-price tab remains in
        # BaseDatabasePage and is intentionally outside this resource pool.
        for index in (3, 2, 1):
            base_page._tabs.removeTab(index)
        tabs.extend([
            (base_page._fixed_items, "固定工程清单"),
            (base_page._market_prices, "市场参考库"),
            (base_page._materials, "材料标准库"),
        ])
        # The official price tab intentionally remains in the separate
        # information-price module and is not moved into this resource pool.
        for page, label in tabs:
            self._tabs.addTab(page, label)
            if hasattr(page, "data_changed"):
                page.data_changed.connect(self.data_changed)

    def show_route(self, route_key: str):
        index = self.TAB_ROUTES.get(route_key, 0)
        self._tabs.setCurrentIndex(index)
        page = self._tabs.currentWidget()
        if hasattr(page, "show_route"):
            page.show_route(route_key)
        elif hasattr(page, "refresh_data"):
            page.refresh_data()

    def refresh_data(self):
        page = self._tabs.currentWidget()
        if hasattr(page, "refresh_data"):
            page.refresh_data()
