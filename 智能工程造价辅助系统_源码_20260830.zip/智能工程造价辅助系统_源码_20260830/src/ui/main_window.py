"""主窗口：分组导航、页面路由和自动任务。"""
from datetime import datetime, timedelta
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget,
    QSplitter, QLabel, QPushButton, QScrollArea, QFrame,
    QMessageBox, QApplication, QLineEdit,
)
from PySide6.QtCore import Qt, QTimer, QSize, QThread, Signal
from PySide6.QtGui import QFont, QIcon, QAction

from src.config import config
from src.db import (
    get_db_stats, init_db, backup_database, write_audit, get_session,
    get_setting, set_settings,
)
from src.models import OfficialSource
from src.ui.widgets import NavGroup, AIBadge

NAV_STRUCTURE = [
    ("首页", "⌂", []),
    ("项目信息", "▣", []),
    ("造价工作台", "▦", ["匹配定额库", "匹配信息价与基础信息库", "造价变化联动"]),
    ("AI智能", "✦", []),
    ("信息价管理", "↻", ["官方订阅", "来源配置", "原始文件"]),
    ("定额与基础资源库", "☷", ["定额数据", "企业参考定额表", "固定工程清单库", "市场参考库", "材料标准库"]),
    ("数据记录", "◴", ["历史记录", "操作日志", "备份恢复", "审计导出"]),
    ("系统设置", "⚙", ["使用说明", "DeepSeek 配置", "订阅规则", "异常阈值", "授权管理", "数据库管理"]),
]

PAGE_MAP = {
    "首页": "home",
    "项目信息": "project_info",
    "AI智能": "ai_chat",
    "使用说明": "system_settings",
    "官方订阅": "subscription",
    "来源配置": "source_config",
    "原始文件": "source_docs",
    "造价工作台": "quota_match",
    "匹配定额库": "quota_match",
    "匹配信息价与基础信息库": "project_quote",
    "造价变化联动": "price_linkage",
    "地方官方信息价库": "price_library",
    "固定工程清单库": "bq_library",
    "市场参考库": "market_library",
    "材料标准库": "material_library",
    "定额数据": "quota_library",
    "企业参考定额表": "project_list_data",
    "历史记录": "history",
    "操作日志": "audit_logs",
    "备份恢复": "backup_restore",
    "审计导出": "audit_export",
    "DeepSeek 配置": "deepseek_config",
    "授权管理": "license_management",
    "订阅规则": "sub_rules",
    "异常阈值": "anomaly_threshold",
    "数据库管理": "db_management",
}


class ScheduledSubscriptionWorker(QThread):
    completed = Signal(dict)

    def __init__(self, source_ids: list[int]):
        super().__init__()
        self.source_ids = source_ids

    def run(self):
        try:
            from src.subscription import SubscriptionEngine
            with SubscriptionEngine() as engine:
                self.completed.emit(engine.run_sources(self.source_ids))
        except Exception as error:
            self.completed.emit({"total": len(self.source_ids), "success": 0, "failed": len(self.source_ids), "new_prices": 0, "errors": [str(error)]})


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{config.APP_NAME} v{config.VERSION}")
        if config.APP_ICON.exists():
            self.setWindowIcon(QIcon(str(config.APP_ICON)))
        self.resize(1400, 900)
        self.setMinimumSize(1100, 700)
        self._nav_groups: list[NavGroup] = []
        self._data_signal_pages: set[int] = set()
        self._page_factories: dict[str, object] = {}
        self._data_refresh_scheduled = False
        self._current_page_key = ""
        self._scheduled_worker = None
        self._close_waiting = False
        self._label_by_page_key = {page_key: label for label, page_key in PAGE_MAP.items()}
        self._setup_ui()
        self._connect_signals()
        self._ai_status_timer = QTimer(self)
        self._ai_status_timer.timeout.connect(self._ai_badge.refresh)
        self._ai_status_timer.start(2000)
        QTimer.singleShot(100, self._auto_backup_check)
        QTimer.singleShot(3000, self._scheduled_subscription_check)
        self._subscription_timer = QTimer(self)
        self._subscription_timer.timeout.connect(self._scheduled_subscription_check)
        self._subscription_timer.start(60 * 60 * 1000)

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        sidebar = self._build_sidebar()
        root.addWidget(sidebar)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        top_bar = self._build_top_bar()
        right_layout.addWidget(top_bar)

        self.stack = QStackedWidget()
        self.stack.setStyleSheet("background: #f2f5f7;")
        right_layout.addWidget(self.stack, 1)

        self._status_bar = QLabel("  就绪")
        self._status_bar.setObjectName("status-bar")
        self._status_bar.setFixedHeight(28)
        self._status_bar.setStyleSheet("background: #1a2b39; color: #b1c1cc; font-size: 12px;")
        right_layout.addWidget(self._status_bar)

        root.addWidget(right, 1)

    def _build_sidebar(self) -> QWidget:
        container = QWidget()
        container.setObjectName("sidebar")
        container.setFixedWidth(238)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(12, 16, 12, 12)
        layout.setSpacing(5)

        brand = QWidget()
        bl = QHBoxLayout(brand)
        bl.setContentsMargins(4, 2, 4, 16)
        bl.setSpacing(8)
        logo = QLabel()
        logo.setFixedSize(38, 38)
        logo.setAlignment(Qt.AlignCenter)
        if config.APP_ICON.exists():
            logo.setPixmap(QIcon(str(config.APP_ICON)).pixmap(38, 38))
        else:
            logo.setText("智")
            logo.setStyleSheet("background:#1c4b65; border-radius:10px; color:#8ee5df; font-weight:900; font-size:18px;")
        bl.addWidget(logo)
        name = QLabel(config.APP_NAME)
        name.setStyleSheet("color:#f8fafc; font-size:14px; font-weight:900; background:transparent; border:none;")
        bl.addWidget(name)
        bl.addStretch()
        layout.addWidget(brand)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; } QScrollBar:vertical { width: 0; }")
        nav_widget = QWidget()
        nav_widget.setStyleSheet("background: transparent;")
        nav_layout = QVBoxLayout(nav_widget)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(8)

        for title, icon, children in NAV_STRUCTURE:
            group = NavGroup(title, icon, children)
            nav_layout.addWidget(group)
            self._nav_groups.append(group)

        nav_layout.addStretch()

        tip = QLabel("仅采信住建局、造价站等\n官方来源。第三方网站仅\n作为线索，不直接入库。")
        tip.setStyleSheet("background: #173a49; border: 1px solid #2b6170; border-radius: 7px; color: #b8d0da; padding: 10px; font-size: 11px;")
        tip.setWordWrap(True)
        nav_layout.addWidget(tip)

        scroll.setWidget(nav_widget)
        layout.addWidget(scroll)
        return container

    def _build_top_bar(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("top-bar")
        bar.setFixedHeight(44)
        bar.setStyleSheet("background: #ffffff; border-bottom: 1px solid #e2e8f0;")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(20, 0, 20, 0)
        bl.setSpacing(10)
        title = QLabel("造价工作台")
        title.setFont(QFont("Microsoft YaHei", 11, QFont.Bold))
        title.setStyleSheet("color:#0f172a; background:transparent; border:none;")
        bl.addWidget(title)
        subtitle = QLabel("工程清单、定额、信息价统一归集")
        subtitle.setStyleSheet("color:#64748b; background:transparent; border:none; font-size:12px;")
        bl.addWidget(subtitle)
        bl.addStretch()
        self._ai_badge = AIBadge()

        return bar

    def _connect_signals(self):
        for group in self._nav_groups:
            group.clicked.connect(self._on_nav_click)

    def _on_nav_click(self, label: str):
        page_key = PAGE_MAP.get(label)
        if page_key:
            self.show_page(page_key)
            self._status_bar.setText(f"  当前模块：{label}")
            self._log_audit("navigate", "page", detail=f"切换到: {label}")

    def register_page(self, page_key: str, page: QWidget):
        if self.stack.indexOf(page) == -1:
            self.stack.addWidget(page)
        if hasattr(page, "data_changed") and id(page) not in self._data_signal_pages:
            page.data_changed.connect(self._on_data_changed)
            self._data_signal_pages.add(id(page))
        setattr(self, f"_page_{page_key}", page)

    def register_page_factory(self, page_key: str, factory):
        """Register a page creator so expensive tables load only when opened."""
        self._page_factories[page_key] = factory

    def _page_for_key(self, page_key: str):
        page = getattr(self, f"_page_{page_key}", None)
        if page is not None:
            return page
        factory = self._page_factories.get(page_key)
        if factory is None:
            return None
        page = factory()
        if page is not None:
            self.register_page(page_key, page)
        return page

    def show_page(self, page_key: str):
        page = self._page_for_key(page_key)
        if page:
            same_route = (
                self.stack.currentWidget() is page
                and self._current_page_key == page_key
            )
            self.stack.setCurrentWidget(page)
            if not same_route:
                route_handler = getattr(page, "show_route", None)
                if callable(route_handler):
                    route_handler(page_key)
                else:
                    refresh = getattr(page, "refresh_data", None)
                    if callable(refresh):
                        refresh()
            self._current_page_key = page_key
            self._sync_nav_state(page_key)
            label = self._label_by_page_key.get(page_key)
            if label:
                self._status_bar.setText(f"  当前模块：{label}")

    def _sync_nav_state(self, page_key: str):
        label = self._label_by_page_key.get(page_key, "")
        for group in self._nav_groups:
            group.set_active_label(label)

    def _on_search_return(self):
        query = self._search.text().strip()
        if not query:
            return
        self.show_page("price_library")
        page = getattr(self, "_page_price_library", None)
        if page and hasattr(page, "set_search_query"):
            page.set_search_query(query)
        self._status_bar.setText(f"  价格搜索结果：{query}（基础数据库 > 地方官方信息价库）")

    def _on_data_changed(self):
        # Several widgets emit data_changed during one operation. Coalesce the
        # callbacks so a large table is rendered at most once per event-loop
        # turn, and never refresh hidden pages.
        if self._data_refresh_scheduled:
            return
        self._data_refresh_scheduled = True
        QTimer.singleShot(0, self._flush_data_changed)

    def _flush_data_changed(self):
        self._data_refresh_scheduled = False
        self._refresh_data()

    def _refresh_data(self):
        try:
            stats = get_db_stats()
            self._ai_badge.refresh()
            current_page = self.stack.currentWidget()
            refresh = getattr(current_page, "refresh_data", None) if current_page else None
            if callable(refresh):
                refresh()
            msg = (
                f"数据刷新完成。固定清单: {stats['cost_items']:,}, 材料: {stats['materials']:,}, "
                f"定额: {stats['quota_items']:,}, "
                f"动态价格: {stats['prices']:,}, 项目: {stats['projects']:,}"
            )
            self._status_bar.setText(f"  {msg}")
        except Exception as e:
            self._status_bar.setText(f"  刷新失败: {e}")

    def _auto_backup_check(self):
        if config.AUTO_BACKUP_ENABLED:
            result = backup_database("auto", "自动备份")
            if result:
                self._status_bar.setText(f"  自动备份完成: {result.name}")
            else:
                self._status_bar.setText(f"  自动备份跳过（数据库未变化或异常）")

    def _scheduled_subscription_check(self):
        if self._scheduled_worker and self._scheduled_worker.isRunning():
            return
        if get_setting("auto_subscription_enabled", "true") != "true":
            return
        interval_days = max(1, int(get_setting("subscription_interval_days", "7")))
        last_text = get_setting("last_auto_subscription_at", "")
        if last_text:
            try:
                if datetime.now() - datetime.fromisoformat(last_text) < timedelta(days=interval_days):
                    return
            except ValueError:
                pass
        official_only = get_setting("subscription_official_only", "true") == "true"
        session = get_session()
        try:
            query = session.query(OfficialSource).filter(OfficialSource.is_active.is_(True))
            if official_only:
                query = query.filter(OfficialSource.is_official.is_(True))
            sources = query.all()
            if official_only:
                from src.utils import is_official_domain
                sources = [source for source in sources if is_official_domain(source.url)]
            from src.api_fetcher import has_api_handler
            sources = [source for source in sources if has_api_handler(source.url)]
            source_ids = [source.id for source in sources]
        finally:
            session.close()
        if not source_ids:
            return
        self._status_bar.setText(f"  自动订阅正在后台检查 {len(source_ids)} 个来源...")
        self._scheduled_worker = ScheduledSubscriptionWorker(source_ids)
        self._scheduled_worker.completed.connect(self._on_scheduled_subscription_complete)
        self._scheduled_worker.start()

    def _on_scheduled_subscription_complete(self, result: dict):
        set_settings({"last_auto_subscription_at": datetime.now().isoformat(timespec="seconds")})
        self._status_bar.setText(
            f"  自动订阅完成：成功 {result.get('success', 0)} 个来源，"
            f"失败 {result.get('failed', 0)} 个，新增或更新 {result.get('new_prices', 0):,} 条。"
        )
        self._on_data_changed()

    def _manual_backup(self):
        result = backup_database("manual", "用户手动备份")
        if result:
            QMessageBox.information(self, "备份成功", f"数据库已备份到:\n{result}")
        else:
            QMessageBox.warning(self, "备份失败", "无法创建备份，请检查磁盘空间。")

    def _log_audit(self, action: str, entity_type: str, detail: str = ""):
        try:
            session = get_session()
            write_audit(session, action, entity_type, detail=detail)
            session.commit()
            session.close()
        except Exception:
            pass

    def closeEvent(self, event):
        running_workers = []
        widgets = [self]
        widgets.extend(self.findChildren(QWidget))
        for widget in widgets:
            for value in vars(widget).values():
                if isinstance(value, QThread) and value.isRunning() and value not in running_workers:
                    running_workers.append(value)
        if running_workers:
            event.ignore()
            self._ai_status_timer.stop()
            self._subscription_timer.stop()
            self._status_bar.setText(f"  正在等待 {len(running_workers)} 个后台任务安全结束，完成后自动关闭...")
            if not self._close_waiting:
                self._close_waiting = True
                for worker in running_workers:
                    worker.finished.connect(self._retry_close_after_workers)
            return
        for widget in [self, *self.findChildren(QWidget)]:
            persist = getattr(widget, "persist_state", None)
            if callable(persist):
                try:
                    persist()
                except Exception:
                    pass
        backup_database("auto", "关闭前自动备份")
        event.accept()

    def _retry_close_after_workers(self):
        for widget in [self, *self.findChildren(QWidget)]:
            if any(isinstance(value, QThread) and value.isRunning() for value in vars(widget).values()):
                return
        self._close_waiting = False
        QTimer.singleShot(0, self.close)
