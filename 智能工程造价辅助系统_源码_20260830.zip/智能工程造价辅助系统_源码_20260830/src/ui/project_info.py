"""项目档案管理：维护造价工作的项目主数据。"""
from datetime import datetime
import json

from sqlalchemy import func
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from src.db import get_session, get_setting, set_settings, write_audit
from src.models import Project, ProjectItem, ProjectPriceSnapshot, ProjectQuotaMatch, Region
from src.ui.widgets import ActionButton, install_long_text_tooltip


PROJECT_TYPES = [
    "房屋建筑", "住宅建筑", "公共建筑", "工业厂房", "园区建设",
    "市政道路", "桥梁隧道", "综合管廊", "给排水管网", "污水处理",
    "水利工程", "电力工程", "设备安装", "园林绿化", "装饰装修", "其他",
]
PROJECT_STAGES = ["概算", "预算", "招标控制价", "投标报价", "施工过程", "结算参考"]
FUNDING_SOURCES = ["财政资金", "国有资金", "自筹资金", "银行贷款", "政府专项债", "社会资本", "其他"]
CONTRACT_TYPES = ["总价合同", "单价合同", "成本加酬金合同", "框架合同", "其他"]
TAX_METHODS = ["一般计税（除税价）", "简易计税", "含税价", "暂未确定"]
PROJECT_SPECIALTIES = [
    "建筑与装饰工程", "安装工程", "市政工程", "园林绿化工程",
    "城市轨道交通工程", "公路工程", "桥梁与隧道工程", "水利水电工程",
]
STATUS_LABELS = {
    "draft": "未开始",
    "doing": "进行中",
    "locked": "已锁定",
    "archived": "已归档",
}


def _effective_status(project: Project, has_data: bool) -> str:
    if project.status in {"locked", "archived"}:
        return STATUS_LABELS.get(project.status, "已锁定")
    if project.status == "doing" or has_data:
        return "进行中"
    return STATUS_LABELS.get(project.status, "未开始")


def _combo(items: list[str], editable: bool = False) -> QComboBox:
    widget = QComboBox()
    widget.addItems(items)
    widget.setEditable(editable)
    widget.setMinimumHeight(36)
    return widget


class ProjectEditDialog(QDialog):
    """新增和编辑项目的统一表单。"""

    def __init__(self, project: Project | None = None, parent=None):
        super().__init__(parent)
        self._project = project
        self.setWindowTitle("编辑项目信息" if project else "新建项目")
        self.resize(820, 720)
        self.setMinimumSize(720, 620)
        self._setup_ui()
        if project:
            self._load_project(project)

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(12)

        heading = QLabel("项目档案")
        heading.setFont(QFont("Microsoft YaHei", 16, QFont.Bold))
        heading.setStyleSheet("color:#172033;")
        root.addWidget(heading)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(0, 0, 4, 0)
        layout.setSpacing(12)

        self._name = QLineEdit()
        self._name.setPlaceholderText("请输入完整项目名称")
        self._code = QLineEdit()
        self._code.setPlaceholderText("例如：DS-2026-001")
        self._client = QLineEdit()
        self._client.setPlaceholderText("建设单位或委托客户")
        self._type = _combo(PROJECT_TYPES, editable=True)
        self._status = _combo(list(STATUS_LABELS.values()))
        self._scale = _combo(["不分规模", "小型", "中型", "大型", "特大型"])
        layout.addWidget(self._group("基础信息", [
            ("项目名称 *", self._name), ("项目编号", self._code),
            ("建设单位 / 客户", self._client), ("项目类型", self._type),
            ("项目状态", self._status), ("规模等级", self._scale),
        ]))

        self._design_unit = QLineEdit()
        self._design_unit.setPlaceholderText("设计院或设计咨询单位")
        self._contractor = QLineEdit()
        self._contractor.setPlaceholderText("施工总承包或专业承包单位")
        self._supervision_unit = QLineEdit()
        self._supervision_unit.setPlaceholderText("监理单位")
        self._tender_agent = QLineEdit()
        self._tender_agent.setPlaceholderText("招标代理、造价咨询或全过程咨询单位")
        self._funding_source = _combo(FUNDING_SOURCES, editable=True)
        self._contract_type = _combo(CONTRACT_TYPES, editable=True)
        layout.addWidget(self._group("参建单位与合同信息", [
            ("设计单位", self._design_unit), ("施工单位", self._contractor),
            ("监理单位", self._supervision_unit), ("招标代理 / 咨询", self._tender_agent),
            ("资金来源", self._funding_source), ("合同类型", self._contract_type),
        ]))

        self._daily_capacity = QDoubleSpinBox()
        self._daily_capacity.setRange(0, 999999999)
        self._daily_capacity.setDecimals(2)
        self._daily_capacity.setSuffix(" 万m3/d")
        self._area = QDoubleSpinBox()
        self._area.setRange(0, 999999999999)
        self._area.setDecimals(2)
        self._area.setSuffix(" m2")
        self._structure = QLineEdit()
        self._structure.setPlaceholderText("例如：钢筋混凝土框架、钢结构")
        self._process = QLineEdit()
        self._process.setPlaceholderText("例如：装配式、MBR、顶管施工")
        layout.addWidget(self._group("规模与技术特征", [
            ("日处理量", self._daily_capacity), ("建筑面积", self._area),
            ("结构形式", self._structure), ("工艺类型", self._process),
        ]))

        self._location = QLineEdit()
        self._location.setPlaceholderText("项目实际所在地，例如：四川省成都市")
        self._address = QLineEdit()
        self._address.setPlaceholderText("具体到道路、园区、地块或厂区地址")
        self._province = QLineEdit()
        self._city = QLineEdit()
        self._district = QLineEdit()
        self._pricing_date = QLineEdit()
        self._pricing_date.setPlaceholderText("YYYY-MM-DD")
        self._price_year = QLineEdit(str(datetime.now().year))
        self._stage = _combo(PROJECT_STAGES)
        self._stage.setCurrentText("投标报价")
        self._specialty = _combo(PROJECT_SPECIALTIES, editable=True)
        self._currency = _combo(["CNY - 人民币", "USD - 美元", "EUR - 欧元"])
        layout.addWidget(self._group("计价口径", [
            ("项目所在地", self._location), ("详细地址", self._address),
            ("计价省份", self._province),
            ("计价城市", self._city), ("计价区县", self._district),
            ("计价日期", self._pricing_date), ("价格年份", self._price_year),
            ("计价阶段", self._stage), ("造价专业", self._specialty),
            ("项目本位币", self._currency),
        ]))

        self._pricing_basis = QLineEdit()
        self._pricing_basis.setPlaceholderText("例如：2024版地方计价依据、清单计价规范")
        self._boq_basis = QLineEdit()
        self._boq_basis.setPlaceholderText("例如：招标工程量清单、施工图预算清单")
        self._tax_method = _combo(TAX_METHODS, editable=True)
        layout.addWidget(self._group("编制依据与税价口径", [
            ("计价依据", self._pricing_basis), ("清单编制依据", self._boq_basis),
            ("税价口径", self._tax_method),
        ]))

        self._planned_start_date = QLineEdit()
        self._planned_start_date.setPlaceholderText("YYYY-MM-DD")
        self._planned_end_date = QLineEdit()
        self._planned_end_date.setPlaceholderText("YYYY-MM-DD")
        layout.addWidget(self._group("计划工期", [
            ("计划开工日期", self._planned_start_date), ("计划完工日期", self._planned_end_date),
        ]))

        notes_group = QGroupBox("备注")
        notes_layout = QVBoxLayout(notes_group)
        self._notes = QTextEdit()
        self._notes.setPlaceholderText("记录计价依据、范围边界、特殊说明等")
        self._notes.setMaximumHeight(100)
        notes_layout.addWidget(self._notes)
        layout.addWidget(notes_group)
        layout.addStretch()
        scroll.setWidget(content)
        root.addWidget(scroll, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("保存项目")
        buttons.button(QDialogButtonBox.Cancel).setText("取消")
        buttons.accepted.connect(self._validate)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self.setStyleSheet("""
            QDialog { background:#f4f6f8; }
            QGroupBox { background:#ffffff; border:1px solid #d9e0e8; border-radius:6px;
                        margin-top:12px; padding:14px 10px 10px 10px; font-weight:700; color:#273449; }
            QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 5px; }
            QLineEdit, QComboBox, QDoubleSpinBox, QTextEdit {
                background:#ffffff; border:1px solid #cfd8e3; border-radius:4px; padding:6px 8px; min-height:22px;
            }
            QLineEdit:focus, QComboBox:focus, QDoubleSpinBox:focus, QTextEdit:focus { border:1px solid #167d8d; }
            QDialogButtonBox QPushButton { min-width:88px; min-height:34px; border-radius:4px; padding:0 14px; }
        """)

    def _group(self, title: str, fields: list[tuple[str, QWidget]]) -> QGroupBox:
        group = QGroupBox(title)
        grid = QGridLayout(group)
        grid.setContentsMargins(12, 16, 12, 12)
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)
        for index, (label_text, widget) in enumerate(fields):
            row = index // 2
            side = index % 2
            label = QLabel(label_text)
            label.setStyleSheet("color:#5a6778; font-size:12px; font-weight:500;")
            grid.addWidget(label, row * 2, side)
            grid.addWidget(widget, row * 2 + 1, side)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        return group

    def _load_project(self, project: Project):
        self._name.setText(project.name or "")
        self._code.setText(project.code or "")
        self._client.setText(project.client or "")
        self._design_unit.setText(project.design_unit or "")
        self._contractor.setText(project.contractor or "")
        self._supervision_unit.setText(project.supervision_unit or "")
        self._tender_agent.setText(project.tender_agent or "")
        self._type.setCurrentText(project.project_type or "其他")
        self._funding_source.setCurrentText(project.funding_source or "")
        self._contract_type.setCurrentText(project.contract_type or "")
        self._status.setCurrentText(STATUS_LABELS.get(project.status, "未开始"))
        self._scale.setCurrentText(project.scale or "不分规模")
        self._daily_capacity.setValue(project.daily_capacity or 0)
        self._area.setValue(project.area or 0)
        self._structure.setText(project.structure_type or "")
        self._process.setText(project.process_type or "")
        self._location.setText(project.project_location or "")
        self._address.setText(project.project_address or "")
        self._province.setText(project.pricing_province or "")
        self._city.setText(project.pricing_city or "")
        self._district.setText(project.pricing_district or "")
        self._pricing_date.setText(project.pricing_date or "")
        self._price_year.setText(project.price_year or "")
        self._stage.setCurrentText(project.stage or "投标报价")
        self._pricing_basis.setText(project.pricing_basis or "")
        self._boq_basis.setText(project.boq_basis or "")
        self._tax_method.setCurrentText(project.tax_method or "")
        self._planned_start_date.setText(project.planned_start_date or "")
        self._planned_end_date.setText(project.planned_end_date or "")
        self._specialty.setCurrentText(project.specialty or "建筑与装饰工程")
        currency_index = {"CNY": 0, "USD": 1, "EUR": 2}.get(project.currency or "CNY", 0)
        self._currency.setCurrentIndex(currency_index)
        self._notes.setPlainText(project.notes or "")

    def _validate(self):
        if not self._name.text().strip():
            QMessageBox.warning(self, "信息不完整", "项目名称不能为空。")
            self._name.setFocus()
            return
        for label, widget in (
            ("计价日期", self._pricing_date),
            ("计划开工日期", self._planned_start_date),
            ("计划完工日期", self._planned_end_date),
        ):
            date_text = widget.text().strip()
            if date_text:
                try:
                    datetime.strptime(date_text, "%Y-%m-%d")
                except ValueError:
                    QMessageBox.warning(self, "日期格式错误", f"{label}请填写为 YYYY-MM-DD。")
                    widget.setFocus()
                    return
        if (
            self._planned_start_date.text().strip()
            and self._planned_end_date.text().strip()
            and self._planned_start_date.text().strip() > self._planned_end_date.text().strip()
        ):
            QMessageBox.warning(self, "工期日期错误", "计划完工日期不能早于计划开工日期。")
            self._planned_end_date.setFocus()
            return
        self.accept()

    def values(self) -> dict:
        reverse_status = {label: key for key, label in STATUS_LABELS.items()}
        return {
            "name": self._name.text().strip(),
            "code": self._code.text().strip(),
            "client": self._client.text().strip(),
            "design_unit": self._design_unit.text().strip(),
            "contractor": self._contractor.text().strip(),
            "supervision_unit": self._supervision_unit.text().strip(),
            "tender_agent": self._tender_agent.text().strip(),
            "project_type": self._type.currentText().strip(),
            "funding_source": self._funding_source.currentText().strip(),
            "contract_type": self._contract_type.currentText().strip(),
            "status": reverse_status.get(self._status.currentText(), "draft"),
            "scale": "" if self._scale.currentText() == "不分规模" else self._scale.currentText(),
            "daily_capacity": self._daily_capacity.value(),
            "area": self._area.value(),
            "structure_type": self._structure.text().strip(),
            "process_type": self._process.text().strip(),
            "project_location": self._location.text().strip(),
            "project_address": self._address.text().strip(),
            "pricing_province": self._province.text().strip(),
            "pricing_city": self._city.text().strip(),
            "pricing_district": self._district.text().strip(),
            "pricing_date": self._pricing_date.text().strip(),
            "price_year": self._price_year.text().strip(),
            "stage": self._stage.currentText().strip(),
            "pricing_basis": self._pricing_basis.text().strip(),
            "boq_basis": self._boq_basis.text().strip(),
            "tax_method": self._tax_method.currentText().strip(),
            "planned_start_date": self._planned_start_date.text().strip(),
            "planned_end_date": self._planned_end_date.text().strip(),
            "specialty": self._specialty.currentText().strip(),
            "currency": self._currency.currentText().split(" ", 1)[0],
            "notes": self._notes.toPlainText().strip(),
        }


class ProjectInfoPage(QWidget):
    data_changed = Signal()
    navigate_requested = Signal(str)

    HEADERS = [
        "当前", "状态", "项目名称", "项目编号", "项目类型",
        "项目所在地", "计价阶段", "造价专业", "总造价", "更新时间",
    ]

    def __init__(self):
        super().__init__()
        self._rows: list[int] = []
        self._metrics: dict[str, QLabel] = {}
        self._metric_names: dict[str, QLabel] = {}
        self._detail_labels: dict[str, QLabel] = {}
        self._detail_records: dict[int, dict] = {}
        self._setup_ui()
        self.refresh_data()

    def _setup_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(22, 18, 22, 18)
        root.setSpacing(12)

        header = QHBoxLayout()
        titles = QVBoxLayout()
        title = QLabel("项目信息")
        title.setFont(QFont("Microsoft YaHei", 18, QFont.Bold))
        title.setStyleSheet("color:#172033;")
        titles.addWidget(title)
        self._subtitle = QLabel("建立项目档案后，可将清单匹配、信息价和价格联动归集到同一项目。")
        self._subtitle.setStyleSheet("color:#6b7788; font-size:12px;")
        titles.addWidget(self._subtitle)
        header.addLayout(titles)
        header.addStretch()
        new_button = ActionButton("+  新建项目", "primary")
        new_button.clicked.connect(self._new_project)
        header.addWidget(new_button)
        root.addLayout(header)

        metrics = QFrame()
        metrics.setObjectName("project-metrics")
        metric_layout = QHBoxLayout(metrics)
        metric_layout.setContentsMargins(14, 11, 14, 11)
        for label, key, color in [
            ("项目总数", "total", "#172033"), ("进行中", "doing", "#167d8d"),
            ("已锁定", "locked", "#2563eb"), ("项目清单", "items", "#7c3aed"),
            ("项目总造价", "amount", "#b45309"),
        ]:
            box = QVBoxLayout()
            name = QLabel(label)
            name.setStyleSheet("color:#6b7788; font-size:11px;")
            value = QLabel("0")
            value.setFont(QFont("Microsoft YaHei", 17, QFont.Bold))
            value.setStyleSheet(f"color:{color};")
            box.addWidget(name)
            box.addWidget(value)
            metric_layout.addLayout(box, 1)
            self._metrics[key] = value
            self._metric_names[key] = name
        root.addWidget(metrics)

        controls = QHBoxLayout()
        self._search = QLineEdit()
        self._search.setPlaceholderText("搜索项目名称、编号、建设单位、类型或地区")
        self._search.setClearButtonEnabled(True)
        self._search.setMinimumWidth(360)
        self._search.textChanged.connect(self.refresh_data)
        controls.addWidget(self._search, 1)
        self._status_filter = _combo(["全部状态", *STATUS_LABELS.values()])
        self._status_filter.setFixedWidth(130)
        self._status_filter.currentIndexChanged.connect(self.refresh_data)
        controls.addWidget(self._status_filter)
        edit_button = ActionButton("编辑", "default")
        edit_button.clicked.connect(self._edit_selected)
        controls.addWidget(edit_button)
        delete_button = ActionButton("删除", "danger")
        delete_button.clicked.connect(self._delete_selected)
        controls.addWidget(delete_button)
        open_button = ActionButton("进入造价工作台", "primary")
        open_button.clicked.connect(self._open_selected)
        controls.addWidget(open_button)
        root.addLayout(controls)

        self._table = QTableWidget(0, len(self.HEADERS))
        self._table.setHorizontalHeaderLabels(self.HEADERS)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.verticalHeader().setVisible(False)
        self._table.verticalHeader().setDefaultSectionSize(38)
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        for column, width in enumerate([
            68, 78, 240, 130, 125, 170, 110, 150, 100, 150,
        ]):
            self._table.setColumnWidth(column, width)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(5, QHeaderView.Stretch)
        header.setSectionResizeMode(7, QHeaderView.Stretch)
        self._table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._table.doubleClicked.connect(self._edit_selected)
        self._table.itemSelectionChanged.connect(self._refresh_detail)
        install_long_text_tooltip(self._table)

        table_panel = QWidget()
        table_panel.setMinimumWidth(620)
        table_layout = QVBoxLayout(table_panel)
        table_layout.setContentsMargins(0, 0, 0, 0)
        table_layout.addWidget(self._table, 1)
        detail_panel = self._build_detail_panel()
        detail_panel.setMinimumWidth(460)
        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(table_panel)
        splitter.addWidget(detail_panel)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([780, 560])
        root.addWidget(splitter, 1)

        self.setStyleSheet("""
            QFrame#project-metrics { background:#ffffff; border:1px solid #dce3ea; border-radius:6px; }
            QFrame#project-detail { background:#ffffff; border:1px solid #dce3ea; border-radius:6px; }
            QLineEdit, QComboBox { background:#ffffff; border:1px solid #cfd8e3; border-radius:4px; padding:6px 9px; min-height:23px; }
            QTableWidget { background:#ffffff; border:1px solid #dce3ea; border-radius:4px; gridline-color:#e5e9ef; }
            QTableWidget::item { padding:5px 8px; color:#283548; }
            QTableWidget::item:selected { background:#dff1f3; color:#12343a; }
            QHeaderView::section { background:#eef2f5; color:#435166; border:none; border-right:1px solid #d9e0e8;
                                   border-bottom:1px solid #d9e0e8; padding:8px; font-weight:700; }
        """)

    def _build_detail_panel(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("project-detail")
        root = QVBoxLayout(panel)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(10)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 6, 0)
        content_layout.setSpacing(10)

        eyebrow = QLabel("项目档案概览")
        eyebrow.setStyleSheet("color:#167d8d; font-size:11px; font-weight:800;")
        content_layout.addWidget(eyebrow)
        self._detail_title = QLabel("请选择项目")
        self._detail_title.setWordWrap(True)
        self._detail_title.setFont(QFont("Microsoft YaHei", 16, QFont.Bold))
        self._detail_title.setStyleSheet("color:#172033;")
        content_layout.addWidget(self._detail_title)
        self._detail_subtitle = QLabel("项目的计价上下文、参建单位和工作量信息会在这里集中显示。")
        self._detail_subtitle.setWordWrap(True)
        self._detail_subtitle.setStyleSheet("color:#6b7788; font-size:12px;")
        content_layout.addWidget(self._detail_subtitle)

        summary = QGridLayout()
        summary.setHorizontalSpacing(18)
        summary.setVerticalSpacing(7)
        for index, (label, key, color) in enumerate([
            ("项目清单", "items", "#167d8d"),
            ("项目总造价", "amount", "#b45309"),
            ("价格快照", "snapshots", "#2563eb"),
            ("当前状态", "status", "#7c3aed"),
        ]):
            box = QVBoxLayout()
            caption = QLabel(label)
            caption.setStyleSheet("color:#7b8796; font-size:11px;")
            value = QLabel("-")
            value.setFont(QFont("Microsoft YaHei", 13, QFont.Bold))
            value.setStyleSheet(f"color:{color};")
            box.addWidget(caption)
            box.addWidget(value)
            summary.addLayout(box, index // 2, index % 2)
            self._detail_labels[key] = value
        content_layout.addLayout(summary)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color:#e5e9ef;")
        content_layout.addWidget(line)

        details = QGridLayout()
        details.setHorizontalSpacing(10)
        details.setVerticalSpacing(8)
        detail_fields = [
            ("项目编号", "code"), ("项目类型", "project_type"),
            ("建设单位", "client"), ("设计单位", "design_unit"),
            ("施工单位", "contractor"), ("监理单位", "supervision_unit"),
            ("所在地", "location"), ("详细地址", "address"),
            ("造价专业", "specialty"), ("计价阶段", "stage"),
            ("计价依据", "pricing_basis"), ("税价口径", "tax_method"),
            ("清单依据", "boq_basis"), ("合同类型", "contract_type"),
            ("规模/面积", "scale_area"), ("结构/工艺", "structure_process"),
            ("计划工期", "schedule"), ("价格年份", "price_year"),
        ]
        for index, (caption, key) in enumerate(detail_fields):
            row = index // 2
            side = index % 2
            label = QLabel(caption)
            label.setStyleSheet("color:#7b8796; font-size:11px;")
            value = QLabel("-")
            value.setWordWrap(True)
            value.setTextInteractionFlags(Qt.TextSelectableByMouse)
            value.setStyleSheet("color:#273449; font-size:12px; font-weight:600;")
            details.addWidget(label, row * 2, side)
            details.addWidget(value, row * 2 + 1, side)
            self._detail_labels[key] = value
        details.setColumnStretch(0, 1)
        details.setColumnStretch(1, 1)
        content_layout.addLayout(details)

        notes_caption = QLabel("项目范围与备注")
        notes_caption.setStyleSheet("color:#7b8796; font-size:11px;")
        content_layout.addWidget(notes_caption)
        self._detail_notes = QLabel("-")
        self._detail_notes.setWordWrap(True)
        self._detail_notes.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._detail_notes.setStyleSheet("color:#536174; background:#f8fafc; border:1px solid #e5e9ef; padding:8px;")
        content_layout.addWidget(self._detail_notes)
        content_layout.addStretch()
        scroll.setWidget(content)
        root.addWidget(scroll, 1)
        return panel

    def _selected_id(self) -> int | None:
        row = self._table.currentRow()
        return self._rows[row] if 0 <= row < len(self._rows) else None

    def _refresh_detail(self):
        project_id = self._selected_id()
        record = self._detail_records.get(project_id) if project_id else None
        if not record:
            self._detail_title.setText("请选择项目")
            self._detail_subtitle.setText("项目的计价上下文、参建单位和工作量信息会在这里集中显示。")
            for key, label in self._detail_labels.items():
                label.setText("-")
            self._detail_notes.setText("-")
            return
        self._detail_title.setText(record["name"] or "未命名项目")
        subtitle_parts = [value for value in (
            record.get("code"), record.get("stage"), record.get("specialty"),
        ) if value]
        self._detail_subtitle.setText(" · ".join(subtitle_parts) or "项目档案已建立，请继续补充计价依据和参建单位。")
        self._detail_labels["items"].setText(f"{record['items']:,} 条")
        self._detail_labels["amount"].setText(f"¥{record['amount']:,.2f}")
        self._detail_labels["snapshots"].setText(f"{record['snapshots']:,} 次")
        self._detail_labels["status"].setText(record["status"])
        values = {
            "code": record.get("code"),
            "project_type": record.get("project_type"),
            "client": record.get("client"),
            "design_unit": record.get("design_unit"),
            "contractor": record.get("contractor"),
            "supervision_unit": record.get("supervision_unit"),
            "location": record.get("location"),
            "address": record.get("address"),
            "specialty": record.get("specialty"),
            "stage": record.get("stage"),
            "pricing_basis": record.get("pricing_basis"),
            "tax_method": record.get("tax_method"),
            "boq_basis": record.get("boq_basis"),
            "contract_type": record.get("contract_type"),
            "scale_area": record.get("scale_area"),
            "structure_process": record.get("structure_process"),
            "schedule": record.get("schedule"),
            "price_year": record.get("price_year"),
        }
        for key, label in self._detail_labels.items():
            if key in values:
                label.setText(values[key] or "未填写")
        self._detail_notes.setText(record.get("notes") or "未填写")

    def show_route(self, route_key: str):
        """兼容主窗口的页面路由接口。"""
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            projects = session.query(Project).order_by(Project.updated_at.desc(), Project.id.desc()).all()
            item_counts = dict(session.query(ProjectItem.project_id, func.count(ProjectItem.id)).group_by(ProjectItem.project_id).all())
            version_counts = dict(session.query(ProjectPriceSnapshot.project_id, func.count(ProjectPriceSnapshot.id)).group_by(ProjectPriceSnapshot.project_id).all())
            quota_counts = {}
            quota_amounts = {}
            for project_id, total_rows, data_json in session.query(
                ProjectQuotaMatch.project_id,
                ProjectQuotaMatch.total_rows,
                ProjectQuotaMatch.data_json,
            ).order_by(
                ProjectQuotaMatch.project_id,
                ProjectQuotaMatch.updated_at.desc(),
                ProjectQuotaMatch.id.desc(),
            ).all():
                if project_id in quota_counts:
                    continue
                quota_counts.setdefault(project_id, int(total_rows or 0))
                amount = 0.0
                try:
                    payload = json.loads(data_json or "{}")
                    for row in payload.get("rows") or []:
                        if row.get("quota_ids") or row.get("generated_quota"):
                            try:
                                amount += float(row.get("comprehensive_price") or 0) * float(row.get("quantity") or 0)
                            except (TypeError, ValueError):
                                pass
                except (TypeError, ValueError, json.JSONDecodeError):
                    amount = 0.0
                quota_amounts[project_id] = amount
            regions = {region.id: region for region in session.query(Region).all()}
            active_id = int(get_setting("active_project_id", "0") or 0)
            keyword = self._search.text().strip().lower()
            selected_status = self._status_filter.currentText()
            filtered = []
            for project in projects:
                region = regions.get(project.region_id)
                location = project.project_location or (region.name if region else "")
                haystack = " ".join([
                    project.name or "", project.code or "", project.client or "",
                    project.project_type or "", location, project.specialty or "",
                ]).lower()
                if keyword and keyword not in haystack:
                    continue
                if selected_status != "全部状态" and STATUS_LABELS.get(project.status, "未开始") != selected_status:
                    continue
                filtered.append((project, location))

            filtered_projects = [project for project, _ in filtered]
            filtered_ids = {project.id for project in filtered_projects}
            filtered_item_count = 0
            filtered_doing = 0
            filtered_locked = 0
            for project in filtered_projects:
                has_data = bool(
                    item_counts.get(project.id, 0)
                    or quota_counts.get(project.id, 0)
                    or version_counts.get(project.id, 0)
                )
                filtered_item_count += max(
                    int(item_counts.get(project.id, 0)),
                    int(quota_counts.get(project.id, 0)),
                )
                status = _effective_status(project, has_data)
                if status == "进行中":
                    filtered_doing += 1
                elif status == "已锁定":
                    filtered_locked += 1
            filtered_amount = sum(
                max(project.total_amount or 0, quota_amounts.get(project.id, 0))
                for project in filtered_projects
            )
            filtering_active = bool(keyword or selected_status != "全部状态")
            self._metric_names["total"].setText("当前显示" if filtering_active else "项目总数")
            self._metrics["total"].setText(f"{len(filtered):,}")
            self._metrics["doing"].setText(f"{filtered_doing:,}")
            self._metrics["locked"].setText(f"{filtered_locked:,}")
            self._metrics["items"].setText(f"{filtered_item_count:,}")
            total_amount = filtered_amount
            self._metrics["amount"].setText(f"¥{total_amount / 10000:,.1f}万")
            self._subtitle.setText(
                f"数据库共 {len(projects)} 个项目，当前显示 {len(filtered)} 个；"
                "点击项目查看档案，双击可编辑。"
            )

            self._rows = [project.id for project, _ in filtered]
            self._detail_records = {}
            for project, location in filtered:
                has_data = bool(
                    item_counts.get(project.id, 0)
                    or quota_counts.get(project.id, 0)
                    or version_counts.get(project.id, 0)
                )
                effective_items = max(
                    int(item_counts.get(project.id, 0)),
                    int(quota_counts.get(project.id, 0)),
                )
                effective_status = _effective_status(project, has_data)
                scale_parts = [part for part in (
                    project.scale,
                    f"建筑面积 {project.area:,.2f} m²" if project.area else "",
                    f"日处理量 {project.daily_capacity:,.2f} 万m³/d" if project.daily_capacity else "",
                ) if part]
                structure_parts = [part for part in (project.structure_type, project.process_type) if part]
                schedule_parts = [part for part in (
                    project.planned_start_date,
                    project.planned_end_date,
                ) if part]
                self._detail_records[project.id] = {
                    "name": project.name or "",
                    "code": project.code or "",
                    "client": project.client or "",
                    "design_unit": project.design_unit or "",
                    "contractor": project.contractor or "",
                    "supervision_unit": project.supervision_unit or "",
                    "project_type": project.project_type or "",
                    "location": location or "",
                    "address": project.project_address or "",
                    "stage": project.stage or "",
                    "specialty": project.specialty or "",
                    "pricing_basis": project.pricing_basis or "",
                    "boq_basis": project.boq_basis or "",
                    "tax_method": project.tax_method or "",
                    "contract_type": project.contract_type or "",
                    "scale_area": " · ".join(scale_parts),
                    "structure_process": " · ".join(structure_parts),
                    "schedule": " 至 ".join(schedule_parts),
                    "price_year": project.price_year or project.pricing_date or "",
                    "status": STATUS_LABELS.get(project.status, "未开始"),
                    "amount": max(
                        float(project.total_amount or 0),
                        float(quota_amounts.get(project.id, 0)),
                    ),
                    "items": effective_items,
                    "snapshots": int(version_counts.get(project.id, 0)),
                    "quota_rows": int(quota_counts.get(project.id, 0)),
                    "notes": project.notes or "",
                    "status": effective_status,
                }
            self._table.setRowCount(len(filtered))
            for row, (project, location) in enumerate(filtered):
                values = [
                    "当前" if project.id == active_id else "",
                    _effective_status(project, has_data),
                    project.name or "", project.code or "", project.project_type or "",
                    location, project.stage or "",
                    project.specialty or "",
                    f"¥{max(project.total_amount or 0, quota_amounts.get(project.id, 0)):,.2f}",
                    project.updated_at.strftime("%Y-%m-%d %H:%M") if project.updated_at else "",
                ]
                for column, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    if column in {0, 1, 8}:
                        item.setTextAlignment(Qt.AlignCenter)
                    if project.id == active_id:
                        item.setBackground(QColor("#e6f4f4"))
                    self._table.setItem(row, column, item)
            if filtered:
                selected_row = next((index for index, (project, _) in enumerate(filtered) if project.id == active_id), 0)
                self._table.selectRow(selected_row)
            else:
                self._refresh_detail()
        finally:
            session.close()

    def _new_project(self):
        dialog = ProjectEditDialog(parent=self)
        if dialog.exec() != QDialog.Accepted:
            return
        self._save_project(None, dialog.values())

    def _edit_selected(self, *_):
        project_id = self._selected_id()
        if not project_id:
            QMessageBox.information(self, "请选择项目", "请先在表格中选择一个项目。")
            return
        session = get_session()
        try:
            project = session.query(Project).filter(Project.id == project_id).first()
            if not project:
                return
            dialog = ProjectEditDialog(project, self)
            if dialog.exec() != QDialog.Accepted:
                return
            values = dialog.values()
        finally:
            session.close()
        self._save_project(project_id, values)

    def _save_project(self, project_id: int | None, values: dict):
        session = get_session()
        try:
            project = session.query(Project).filter(Project.id == project_id).first() if project_id else Project()
            if project is None:
                raise ValueError("项目不存在或已被删除。")
            for key, value in values.items():
                setattr(project, key, value)
            region_name = values.get("pricing_city") or values.get("project_location")
            if region_name:
                region = session.query(Region).filter(Region.name == region_name).first()
                if region:
                    project.region_id = region.id
            should_activate = project_id is None and not get_setting("active_project_id", "")
            if project_id is None:
                session.add(project)
                session.flush()
            write_audit(
                session, "update" if project_id else "create", "project", project.id,
                detail=f"{'更新' if project_id else '新建'}项目: {project.name}",
            )
            session.commit()
            if should_activate:
                set_settings({"active_project_id": str(project.id)})
            self.data_changed.emit()
            self.refresh_data()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _delete_selected(self):
        project_id = self._selected_id()
        if not project_id:
            QMessageBox.information(self, "请选择项目", "请先在表格中选择一个项目。")
            return
        session = get_session()
        try:
            project = session.query(Project).filter(Project.id == project_id).first()
            if not project:
                return
            if QMessageBox.question(
                self, "删除项目", f"确定删除项目“{project.name}”及其清单和价格快照吗？",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
            ) != QMessageBox.Yes:
                return
            name = project.name
            session.delete(project)
            write_audit(session, "delete", "project", project_id, detail=f"删除项目: {name}")
            session.commit()
            if get_setting("active_project_id", "") == str(project_id):
                set_settings({"active_project_id": ""})
            self.data_changed.emit()
            self.refresh_data()
        finally:
            session.close()

    def _open_selected(self):
        project_id = self._selected_id()
        if not project_id:
            QMessageBox.information(self, "请选择项目", "请先选择要进入造价工作台的项目。")
            return
        set_settings({"active_project_id": str(project_id)})
        self.data_changed.emit()
        self.navigate_requested.emit("quota_match")
