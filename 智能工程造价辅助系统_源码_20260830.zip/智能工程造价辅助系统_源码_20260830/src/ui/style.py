﻿"""全局 QSS 样式表 — 大硕造价云库 (使用 Qt 属性选择器)"""
GLOBAL_QSS = """
/* === 全局 === */
QMainWindow { background: #f2f5f7; }
QWidget { font-family: "Microsoft YaHei", "PingFang SC", sans-serif; font-size: 13px; }

/* === 侧栏 === */
QWidget#sidebar { background: #102b3d; border-right: 1px solid #24495a; }
QWidget#sidebar QLabel { color: #c8d5df; background: transparent; border: none; }
QScrollArea { border: none; background: transparent; }

/* === 侧栏图标与导航层级 === */
QWidget#nav-title-row { background: transparent; }
QLabel#nav-icon-badge {
    background: #1b4052; color: #8ee5df; border: 1px solid #2b6170;
    border-radius: 8px; font-size: 14px; font-weight: bold;
}
QLabel#nav-icon-badge[navIconStyle="active"] {
    background: #49d7d0; color: #102b3d; border-color: #8ee5df;
}

/* === 侧栏导航 — 通过动态属性选择 === */
QPushButton[navStyle="title"] {
    background: transparent; color: #c8d8df; border: none;
    border-radius: 7px; text-align: left; padding-left: 8px;
    font-size: 13px; font-weight: bold;
}
QPushButton[navStyle="title"]:hover { background: #1b4052; color: #ffffff; }
QPushButton[navStyle="titleActive"] {
    background: #1f5260; color: #ffffff; border: none; border-radius: 7px; text-align: left; padding-left: 8px;
    font-size: 13px; font-weight: bold;
}

QPushButton[navStyle="child"] {
    background: transparent; color: #91aab6; border: none;
    border-left: 2px solid #284c5c; border-radius: 4px; text-align: left; padding-left: 12px;
    font-size: 12px;
}
QPushButton[navStyle="child"]:hover { background: #1b4052; color: #d4f2f2; border-left-color: #49d7d0; }
QPushButton[navStyle="childActive"] {
    background: #173a49; color: #8ee5df;
    font-weight: bold; border-left: 3px solid #ffca70; border-radius: 4px; text-align: left; padding-left: 11px;
}

/* === 顶栏 === */
QWidget#top-bar { background: #ffffff; border-bottom: 1px solid #e2e8f0; }

/* === 按钮 === */
QPushButton[btnStyle="primary"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563eb, stop:1 #06b6d4);
    color: #fff; border: none; border-radius: 11px; padding: 0 14px; font-weight: bold;
}
QPushButton[btnStyle="default"] {
    background: #fff; color: #475569; border: 1px solid #e2e8f0;
    border-radius: 11px; padding: 0 14px; font-weight: bold;
}
QPushButton[btnStyle="warn"] {
    background: #fff7ed; color: #c2410c; border: 1px solid #fed7aa;
    border-radius: 11px; padding: 0 14px; font-weight: bold;
}

/* === 表格 === */
QTableWidget {
    background: #fff; border: 1px solid #edf1f6; border-radius: 14px;
    gridline-color: #edf1f6;
}
QTableWidget::item { padding: 8px; }
QHeaderView::section {
    background: #f8fafc; color: #667085; font-weight: bold;
    border: none; border-bottom: 1px solid #edf1f6; padding: 10px 8px;
}

/* === 标签页 === */
QTabWidget::pane { border: none; background: transparent; }
QTabBar::tab {
    padding: 10px 20px; font-weight: bold; border: none; color: #667085;
    background: transparent;
}
QTabBar::tab:selected { color: #2563eb; border-bottom: 3px solid #2563eb; }

/* === 状态栏 === */
QWidget#status-bar { background: #1a2b39; color: #b1c1cc; font-size: 12px; padding: 4px 12px; }
"""
