﻿"""项目工作台 - 匹配定额库页签：导入清单并按定额库逐行匹配。"""
from __future__ import annotations

import json
import hashlib
import time
from difflib import SequenceMatcher
from itertools import islice
from pathlib import Path
import re

from PySide6.QtCore import QItemSelectionModel, QRect, Qt, Signal, QThread
from PySide6.QtGui import QColor, QCursor, QFont, QFontMetrics
from PySide6.QtWidgets import (
    QAbstractItemView,
    QAbstractSpinBox,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from src.db import get_session, get_setting, set_settings, write_audit
from src.config import config
from src.models import Project, ProjectQuotaMatch
from src.quota_service import (
    build_base_data_fallback,
    build_quota_match_index,
    apply_official_prices_to_compositions,
    apply_explicit_unit_conversion,
    apply_specification_quantity_conversion,
    build_ai_quota_context,
    build_quota_audit_report,
    cost_category_coverage,
    deduplicate_quota_components,
    composition_cost_breakdown,
    find_quota_composition_matches,
    labor_coordination_evidence,
    LOW_CONFIDENCE_THRESHOLD,
    latest_price_period,
    get_quota_item,
    list_quota_majors,
    material_coverage_gaps,
    normalize_quota_row_matches,
    preserve_imported_cost_references,
    quota_composition_category_counts,
    quota_reference_dict,
    required_cost_categories,
    validate_ai_generated_quota,
    save_ai_generated_quota,
    quota_reference_scope_errors,
    search_quota_items,
    uncovered_cost_clauses,
    QUOTA_MATCH_ALGORITHM_VERSION,
)
from src.source_display import redact_research_evidence
from src.project_list_data_service import find_project_list_references
from src.excel_compat import read_excel_sheets
from src.ui.quota_library import CellContentEditDialog
from src.ui.widgets import ActionButton, SectionHeader, install_long_text_tooltip


TABLE_STYLE = (
    "QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:8px; "
    "gridline-color:#edf1f6; font-size:10pt; } "
    "QTableWidget::item { padding:4px 7px; } "
    "QHeaderView::section { background:#f8fafc; color:#475569; font-size:10pt; "
    "font-weight:600; border:none; border-bottom:1px solid #e2e8f0; padding:8px 7px; }"
)
INPUT_STYLE = "border:1px solid #dbe3ef; border-radius:8px; padding:6px 10px; font-size:10pt;"
FEE_DIALOG_STYLE = (
    "QDialog { background:#f8fafc; font-family:'Microsoft YaHei'; font-size:10pt; } "
    "QLabel { font-family:'Microsoft YaHei'; font-size:10pt; color:#334155; } "
    "QTableWidget { font-family:'Microsoft YaHei'; font-size:10pt; } "
    "QComboBox, QDoubleSpinBox { font-family:'Microsoft YaHei'; font-size:10pt; "
    "min-height:30px; border:1px solid #dbe3ef; border-radius:6px; padding:0 8px; }"
)
FEE_BASE_OPTIONS = (
    ("人工费+材料费+机械费", "direct"),
    ("人工费+材料费", "labor_material"),
    ("人工费+机械费", "labor_machine"),
    ("仅人工费", "labor"),
    ("人材机+管理费", "direct_management"),
    ("人工费+机械费+管理费", "labor_machine_management"),
)
FEE_BASE_LABELS = {key: label for label, key in FEE_BASE_OPTIONS}


def _numeric(value, default=0.0) -> float:
    if value in (None, ""):
        return default
    try:
        return float(str(value).replace(",", "").replace("%", ""))
    except (TypeError, ValueError):
        return default


def _text(value) -> str:
    return "" if value is None else str(value).strip()


def _percent(value, default=0.0) -> float:
    number = _numeric(value, default)
    if number == default:
        return default
    return number / 100 if "%" in str(value or "") else number


class QuotaSelectionDialog(QDialog):
    """从当前定额库中人工选择一条定额加入清单组价。"""

    def __init__(self, major: str = "", parent=None):
        super().__init__(parent)
        self._major = major
        self._items = []
        self.setWindowTitle("添加定额")
        self.resize(920, 560)
        root = QVBoxLayout(self)
        tools = QHBoxLayout()
        tools.addWidget(QLabel("搜索:"))
        self._keyword = QLineEdit()
        self._keyword.setPlaceholderText("定额名称、编码或工作内容")
        self._keyword.returnPressed.connect(self._search)
        tools.addWidget(self._keyword, 1)
        search_button = ActionButton("查询", "primary")
        search_button.clicked.connect(self._search)
        tools.addWidget(search_button)
        root.addLayout(tools)
        self._table = QTableWidget(0, 6)
        self._table.setHorizontalHeaderLabels(["专业", "定额编码", "定额名称", "工作内容", "单位", "组成数"])
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(TABLE_STYLE)
        self._table.setFont(QFont("Microsoft YaHei", 10))
        install_long_text_tooltip(self._table)
        self._table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        for column, width in enumerate([80, 120, 220, 330, 65, 70]):
            self._table.setColumnWidth(column, width)
        self._table.cellDoubleClicked.connect(lambda *_: self.accept())
        root.addWidget(self._table, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        self._search()

    def _search(self):
        session = get_session()
        try:
            self._items = search_quota_items(
                session,
                major=self._major,
                keyword=self._keyword.text().strip(),
                limit=500,
            )
            for item in self._items:
                _ = len(item.compositions)
        finally:
            session.close()
        self._table.setRowCount(len(self._items))
        for row, item in enumerate(self._items):
            values = [item.major, item.code, item.name, item.feature, item.unit, len(item.compositions)]
            for column, value in enumerate(values):
                self._table.setItem(row, column, QTableWidgetItem(str(value or "")))
        if self._items:
            self._table.selectRow(0)

    def selected_quota_id(self) -> int | None:
        row = self._table.currentRow()
        return self._items[row].id if 0 <= row < len(self._items) else None

    def accept(self):
        if self.selected_quota_id() is None:
            QMessageBox.information(self, "未选择定额", "请先选择一条定额。")
            return
        super().accept()


class CompositionAdjustmentDialog(QDialog):
    """调整清单下单个工料机分量，原始含量只读以保留换算依据。"""

    CATEGORIES = ["人工费", "材料费", "辅材费", "主材费", "机械费", "专业分包", "其他"]

    def __init__(self, detail: dict | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("编辑组价分量")
        self.resize(660, 620)
        detail = dict(detail or {})
        form = QFormLayout(self)
        self._included = QCheckBox("计入清单组价")
        self._included.setChecked(bool(detail.get("included", True)))
        self._category = QComboBox()
        self._category.setEditable(True)
        self._category.addItems(self.CATEGORIES)
        self._category.setCurrentText(str(detail.get("cat") or "主材费"))
        self._code = QLineEdit(str(detail.get("code") or ""))
        self._name = QLineEdit(str(detail.get("name") or ""))
        self._feature = QTextEdit()
        self._feature.setPlainText(str(detail.get("feature") or ""))
        self._feature.setMaximumHeight(70)
        self._unit = QLineEdit(str(detail.get("unit") or ""))
        self._unit_conversion = QLineEdit(str(detail.get("unitConversion") or detail.get("unit_conversion") or ""))
        self._source_qty = QLabel(f"{_numeric(detail.get('sourceQty', detail.get('qty'))):g}")
        # Missing consumption must remain visible as zero until a reviewer
        # supplies a defensible per-BOQ-unit quantity. Never display a made-up
        # 1 merely because the old record had no quantity.
        self._qty = self._spin(_numeric(detail.get("qty")))
        self._quota_factor = self._spin(_numeric(detail.get("quotaFactor"), 1.0))
        self._loss = self._spin(_numeric(detail.get("loss")))
        self._no_tax_price = self._spin(_numeric(detail.get("noTaxPrice")))
        self._tax_rate = self._spin(_numeric(detail.get("taxRate")))
        self._tax_price = self._spin(_numeric(detail.get("taxPrice")))
        self._note = QLineEdit(str(detail.get("note") or ""))
        rows = [
            ("状态", self._included), ("费用类别", self._category), ("编码", self._code),
            ("名称", self._name), ("工作内容", self._feature), ("单位", self._unit),
            ("单位换算公式", self._unit_conversion),
            ("定额原含量", self._source_qty), ("调整后含量", self._qty),
            ("定额系数", self._quota_factor), ("损耗率%", self._loss),
            ("除税单价", self._no_tax_price), ("税率%", self._tax_rate),
            ("含税单价", self._tax_price), ("调整说明", self._note),
        ]
        for label, widget in rows:
            form.addRow(label, widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept_values)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def _accept_values(self):
        if self._included.isChecked() and self._qty.value() <= 0:
            QMessageBox.warning(
                self,
                "含量不能为空",
                "计入清单组价的分量必须填写大于0的单位含量；"
                "如果暂时无法确定，请取消计入并在调整说明中记录原因。",
            )
            self._qty.setFocus()
            return
        if not self._unit.text().strip():
            QMessageBox.warning(self, "单位不能为空", "请先填写人材机分量单位。")
            self._unit.setFocus()
            return
        self.accept()

    @staticmethod
    def _spin(value: float) -> QDoubleSpinBox:
        spin = QDoubleSpinBox()
        spin.setRange(0, 1_000_000_000)
        spin.setDecimals(6)
        spin.setButtonSymbols(QAbstractSpinBox.NoButtons)
        spin.setValue(value)
        return spin

    def values(self, original: dict | None = None) -> dict:
        result = dict(original or {})
        result.update({
            "included": self._included.isChecked(),
            "forceFormula": True,
            "cat": self._category.currentText().strip(),
            "code": self._code.text().strip(),
            "name": self._name.text().strip(),
            "feature": self._feature.toPlainText().strip(),
            "unit": self._unit.text().strip(),
            "unitConversion": self._unit_conversion.text().strip(),
            "qty": self._qty.value(),
            "quotaFactor": self._quota_factor.value(),
            "loss": self._loss.value(),
            "noTaxPrice": self._no_tax_price.value(),
            "taxRate": self._tax_rate.value(),
            "taxPrice": self._tax_price.value(),
            "note": self._note.text().strip(),
        })
        result.setdefault("sourceQty", _numeric(self._source_qty.text()))
        return result


def _ai_price_source_guidance(context: dict, result: dict) -> dict:
    """Describe the next official-price action for an AI market estimate."""
    if result.get("decision") != "generate":
        return {}
    generated = result.get("generated_quota") or {}
    components = generated.get("components") or []
    if not components:
        return {}
    estimated = any(
        not (value.get("sourceEvidenceIds") or value.get("source_evidence_ids"))
        for value in components
        if isinstance(value, dict)
    )
    if not estimated:
        return {}

    # build_ai_quota_context stores the normalized project fields in
    # project_context. Keep the fallback for older result payloads.
    project = (
        context.get("project_context")
        or context.get("project")
        or context
        or {}
    )
    # Only the information-price selector controls the source region. Project
    # city/province are construction background and must never trigger a
    # different price source after the row has been matched.
    region = _text(project.get("source_region"))
    # The source-region selector is the authoritative UI input for this
    # workflow. Older/partial worker payloads may omit it from context, so
    # recover the persisted selection before showing any post-match prompt.
    if not region:
        from src.db import get_setting

        region = _text(get_setting("quota_source_region", ""))
    if not region:
        return {
            "kind": "missing_region",
            "region": "",
            "city_query": "",
            "route": "subscription",
            "message": "未选择信息来源地区，将使用信息价库最新期；也可在匹配页面指定城市。",
        }

    # The same effective region is used by local price lookup, AI context,
    # official-source guidance, and historical project references.
    city_query = region.rstrip("市")
    from src.official_sources_config import CITY_AUDIT_STATUS, get_city_audit_status

    known_city = next(
        (city for city in CITY_AUDIT_STATUS if city and city in region),
        "",
    )
    if known_city:
        city_query = known_city
    elif region.rstrip("省") == "四川":
        city_query = "成都"

    audit = get_city_audit_status(city_query)
    status = _text(audit.get("status")) or "pending_adapter"
    login_statuses = {
        "login_required", "membership_required", "browser_dynamic", "waf_blocked",
    }
    if status in login_statuses:
        message = (
            f"{city_query} 官方信息价需要登录、会员或浏览器验证。"
            "请进入“信息价管理 → 官方订阅”，选择城市并打开官网完成登录；"
            "需要保存登录状态时，再到“来源配置”选择该来源并点击“浏览器登录”，"
            "抓取入库后重新匹配当前清单。"
        )
        kind = "login_required"
    elif status == "working":
        message = (
            f"当前AI组成仍有市场估算价格。请进入“信息价管理 → 官方订阅”更新"
            f"{city_query} 最新信息价，入库后重新匹配可提高价格准确度。"
        )
        kind = "official_refresh"
    else:
        message = (
            f"{city_query} 暂无可直接抓取来源。请进入“信息价管理 → 官方订阅”，"
            "输入本人有权访问的官方信息价网址，按页面提示登录、验证并抓取入库，"
            "然后重新匹配当前清单。"
        )
        kind = "custom_url"
    period = _text(
        context.get("effective_pricing_period")
        or project.get("effective_pricing_period")
        or (context.get("project_context") or {}).get("effective_pricing_period")
        or project.get("pricing_date")
        or project.get("price_year")
    )
    if period:
        message = f"当前有效计价期：{period}。" + message
    return {
        "kind": kind,
        "region": region,
        "city_query": city_query,
        "route": "subscription",
        "status": status,
        "period": period,
        "message": message,
        "note": _text(audit.get("note")),
    }


def _filter_ai_existing_matches(
    session,
    boq: dict,
    result: dict,
    candidates: list[dict],
) -> tuple[list[dict], list[str]]:
    """Apply the same hard gate to the first AI answer and every retry.

    The provider is untrusted input. An ID allow-list alone is insufficient:
    the selected quota must still pass the current candidate safety flag and
    the full quota/component scope validation immediately before it can be
    applied to a row.
    """
    allowed_ids = {
        int(candidate.get("quota_id"))
        for candidate in candidates
        if candidate.get("logic_allowed", True)
        and str(candidate.get("quota_id") or "").lstrip("-").isdigit()
    }
    valid_matches = []
    rejected_reasons = []
    seen_ids = set()
    raw_matches = result.get("matches") or []
    if not isinstance(raw_matches, list):
        raw_matches = []
    # Do not trust the provider's order. Validate all returned candidates and
    # keep only the best valid one; otherwise an invalid first candidate could
    # hide a valid second candidate and make AI appear to have no result.
    for raw_match in raw_matches:
        if not isinstance(raw_match, dict):
            continue
        raw_id = raw_match.get("quota_id")
        if not str(raw_id or "").lstrip("-").isdigit():
            rejected_reasons.append(f"AI返回了无效定额ID：{raw_id}")
            continue
        quota_id = int(raw_id)
        if quota_id in seen_ids:
            continue
        seen_ids.add(quota_id)
        if quota_id not in allowed_ids:
            rejected_reasons.append(f"AI选择了已禁用或不存在的本地定额ID：{quota_id}")
            continue
        try:
            confidence = min(max(float(raw_match.get("confidence") or 0), 0.0), 1.0)
        except (TypeError, ValueError):
            confidence = 0.0
        if confidence < 0.40:
            rejected_reasons.append(f"定额ID {quota_id} 的AI置信度低于40%，不得写入")
            continue
        item = get_quota_item(session, quota_id)
        if item is None:
            rejected_reasons.append(f"本地定额ID {quota_id} 已不存在")
            continue
        reference = quota_reference_dict(item)
        scope_errors = quota_reference_scope_errors(
            boq.get("name", ""), boq.get("feature", ""), reference,
        )
        if scope_errors:
            rejected_reasons.extend(scope_errors)
            continue
        valid_matches.append({
            **raw_match,
            "quota_id": quota_id,
            "confidence": confidence,
            "reason": str(raw_match.get("reason") or "AI 复核").strip(),
            "source_clause": str(raw_match.get("source_clause") or "AI 复核").strip(),
        })
    valid_matches.sort(
        key=lambda value: (
            float(value.get("confidence") or 0),
            float(value.get("local_score") or value.get("score") or 0),
        ),
        reverse=True,
    )
    if valid_matches:
        valid_matches = [{
            **valid_matches[0],
            "role": "主体",
        }]
    return valid_matches, list(dict.fromkeys(rejected_reasons))


def _resolve_ai_fallback(
    session,
    project_id: int,
    boq: dict,
    major: str,
    status_callback=None,
    repair_hints: list[str] | None = None,
    excluded_quota_ids: set[int] | None = None,
    force_research: bool = False,
    allow_research: bool = True,
    current_composition: dict | None = None,
    region_override: str = "",
) -> tuple[dict, dict]:
    """Resolve one BOQ row through base data, local AI, and web research."""
    context = build_ai_quota_context(
        session,
        project_id,
        boq,
        major=major,
        candidate_limit=20,
        source_costs=boq.get("source_costs") or {},
        region_override=region_override,
    )
    excluded = {
        int(value)
        for value in (excluded_quota_ids or set())
        if str(value).lstrip("-").isdigit()
    }
    working_context = {
        **context,
        "current_composition": current_composition or {},
        "candidates": [
            {
                **candidate,
                "logic_allowed": (
                    candidate.get("logic_allowed", True)
                    and int(candidate.get("quota_id") or -1) not in excluded
                ),
            }
            for candidate in context.get("candidates") or []
        ],
    }
    base = build_base_data_fallback(
        session,
        boq,
        project_id,
        major=major,
        minimum_score=45,
        include_unconfirmed=False,
        region_override=region_override,
    )
    if base and base.get("auto_apply") and not repair_hints:
        generated = base.get("generated_quota") or {}
        base_validation = validate_ai_generated_quota(
            boq, generated, context.get("market_prices") or [],
        )
        if base_validation.get("errors"):
            # A rejected local candidate is evidence of what not to use, not a
            # terminal result.  Keep it excluded and continue through AI
            # generation so a generic composition can replace an over-specific
            # quota such as ``隧道无纺土工布``.
            rejected_id = base.get("quota_id") or generated.get("quota_id")
            if rejected_id is not None and str(rejected_id).lstrip("-").isdigit():
                excluded.add(int(rejected_id))
            working_context["candidates"] = [
                {
                    **candidate,
                    "logic_allowed": (
                        candidate.get("logic_allowed", True)
                        and int(candidate.get("quota_id") or -1) not in excluded
                    ),
                }
                for candidate in working_context.get("candidates") or []
            ]
            repair_hints = [
                *(repair_hints or []),
                "基础库候选已被安全校验拒绝，请生成符合原清单对象、部位和规格的通用人材机组成",
                *list(base_validation.get("errors") or []),
            ]
        else:
            return context, {
                "decision": "generate",
                "source_type": base.get("source_type"),
                "generated_quota": generated,
                "evidence_level": base.get("evidence_level") or generated.get("evidence_level") or "red",
                "valid": bool(base.get("actionable")),
                "actionable": bool(base.get("actionable")),
                "summary": str(base.get("summary") or "已调用基础库与已确认信息价"),
                "errors": list(base.get("errors") or []),
                "warnings": list(base.get("warnings") or []),
            }

    from src.ai_service import ai

    result = ai.match_or_generate_quota(
        boq,
        working_context,
        repair_hints=repair_hints,
    )
    if not result.get("success", True):
        # A failed provider call (for example HTTP 402 balance exhaustion or
        # a timeout) cannot be improved by another web-search round. Preserve
        # the provider's exact message so the row explains the real blocker.
        result["valid"] = False
        result["actionable"] = False
        result["web_research_attempted"] = False
        result["context"] = context
        return context, result
    if result.get("decision") == "existing":
        valid_matches, rejected_reasons = _filter_ai_existing_matches(
            session,
            boq,
            result,
            working_context.get("candidates") or [],
        )
        result["matches"] = valid_matches
        if not valid_matches:
            retry_result = ai.match_or_generate_quota(
                boq,
                working_context,
                repair_hints=[
                    *(repair_hints or []),
                    *rejected_reasons,
                    "禁止再次选择上述本地候选；请按原清单对象生成通用人材机组成并给出可复核单位含量",
                ],
            )
            if retry_result.get("decision") == "existing":
                retry_matches, retry_reasons = _filter_ai_existing_matches(
                    session,
                    boq,
                    retry_result,
                    working_context.get("candidates") or [],
                )
                retry_result["matches"] = retry_matches
                rejected_reasons.extend(retry_reasons)
                if not retry_matches:
                    # Do not let an invalid second answer reach the UI apply
                    # path. It may proceed to the explicit research fallback,
                    # but it is never a payable existing match.
                    retry_result["decision"] = "none"
                    retry_result["errors"] = list(dict.fromkeys(
                        [*(retry_result.get("errors") or []), *rejected_reasons]
                    ))
            result = retry_result

    # The fallback contract is: a recognizable BOQ must receive either one
    # validated local quota or one calculable project-only estimate. Models
    # sometimes answer "none" because they over-apply the strict local-match
    # rule. Give that case one bounded, explicit generation retry. It still
    # cannot invent a local quota ID, and the normal validator below remains
    # the final safety gate.
    if (
        result.get("decision") == "none"
        and _text(boq.get("name"))
        and _text(boq.get("unit"))
    ):
        forced_hints = [
            *(repair_hints or []),
            *(result.get("errors") or []),
            "本条清单工程名称和单位可识别，禁止返回none。",
            "如果本地候选不适用，必须生成一个项目级AI补充定额，名称和工作内容保留原清单核心对象。",
            "必须输出至少人工、主材/材料、辅材或机械中与该工序实际相关的正数组成，并给出每1个清单单位的qty、单位、除税单价、税率和计算依据。",
            "不能为了凑类别添加无关人材机；不确定规格写入assumptions，不能把不同对象或不同工艺硬套进来。",
        ]
        forced = ai.match_or_generate_quota(
            boq,
            working_context,
            repair_hints=list(dict.fromkeys(str(value) for value in forced_hints if str(value).strip())),
        )
        if forced.get("success", True):
            result = forced
    validation = None
    if result.get("decision") == "generate" and result.get("generated_quota"):
        validation = validate_ai_generated_quota(
            boq,
            result.get("generated_quota") or {},
            context.get("market_prices") or [],
        )
        if validation.get("errors"):
            repaired = ai.match_or_generate_quota(
                boq,
                working_context,
                repair_hints=[*(repair_hints or []), *list(validation["errors"])],
            )
            if repaired.get("generated_quota"):
                result = repaired
                validation = validate_ai_generated_quota(
                    boq,
                    result.get("generated_quota") or {},
                    context.get("market_prices") or [],
                )
            # A repair answer can still be an empty/structurally unusable
            # response. One final forced-generation request recovers the
            # normal case without weakening object, process or specification
            # conflict checks.
            if validation.get("errors"):
                salvage = ai.match_or_generate_quota(
                    boq,
                    working_context,
                    repair_hints=[
                        *(repair_hints or []),
                        *list(validation.get("errors") or []),
                        "请重新生成可计算的项目级补充定额，不要返回none。",
                        "保留原清单名称、项目特征及工作内容；删除任何与原清单对象、施工部位或工艺冲突的组成。",
                        "缺少文字换算说明时按每1清单单位的正数单位消耗量输出并在calculation_basis写明估算依据，不要因为缺少说明而放弃结果。",
                    ],
                )
                if salvage.get("generated_quota"):
                    result = salvage
                    validation = validate_ai_generated_quota(
                        boq,
                        salvage.get("generated_quota") or {},
                        context.get("market_prices") or [],
                    )
        remaining_errors = set(validation.get("errors") or [])
        specification_errors = set(validation.get("specification_errors") or [])
        if remaining_errors and remaining_errors.issubset(specification_errors):
            adjusted_quota = dict(result.get("generated_quota") or {})
            adjusted_quota["allow_specification_adjustment"] = True
            validation = validate_ai_generated_quota(
                boq,
                adjusted_quota,
                context.get("market_prices") or [],
            )
            result["generated_quota"] = adjusted_quota
        result.update(validation)
        result["generated_quota"] = validation["quota"]
    elif result.get("decision") == "existing":
        confidence = max(
            (float(value.get("confidence") or 0) for value in result.get("matches") or []),
            default=0.0,
        )
        result["valid"] = bool(result.get("matches"))
        result["evidence_level"] = "green" if confidence >= 0.75 else "yellow"

    # A structurally complete generated result is repaired once above. Web
    # search cannot fix a remaining object/specification/formula violation and
    # repeatedly hitting blocked public sites made every row take much longer.
    # Research is reserved for cases where the model formed no usable local
    # candidate at all, or when the caller explicitly requests it.
    needs_research = allow_research and (force_research or (
        result.get("decision") == "none"
        or (result.get("decision") == "existing" and not result.get("matches"))
        or (result.get("decision") == "generate" and not result.get("actionable"))
        or (
            result.get("decision") == "generate"
            and result.get("actionable")
            and result.get("evidence_level") == "red"
            and not any(
                component.get("sourceEvidenceIds") or component.get("source_evidence_ids")
                for component in (
                    (result.get("generated_quota") or {}).get("components") or []
                )
                if isinstance(component, dict)
            )
        )
    ))
    if needs_research:
        if status_callback is not None:
            status_callback("本地定额未形成可靠结果，正在联网检索人材机与造价信息...")
        from src.ai_research import research_boq_evidence

        evidence = research_boq_evidence(boq, context)
        if evidence:
            if status_callback is not None:
                status_callback(f"已获取 {len(evidence)} 条公开检索证据，AI 正在提取人材机组成...")
            researched = ai.research_quota(boq, context, evidence)
            if researched.get("decision") == "generate" and researched.get("generated_quota"):
                research_validation = validate_ai_generated_quota(
                    boq,
                    researched.get("generated_quota") or {},
                    context.get("market_prices") or [],
                )
                if not research_validation.get("errors"):
                    result = researched
                    result.update(research_validation)
                    result["generated_quota"] = research_validation["quota"]
                    result["source_type"] = (
                        research_validation["quota"].get("source_type")
                        or "ai_web_research"
                    )
                    result["research_sources"] = redact_research_evidence(evidence)
                    if (
                        result.get("evidence_level") == "red"
                        and any(value.get("excerpt") or value.get("official") for value in evidence)
                    ):
                        result["evidence_level"] = "yellow"
        elif status_callback is not None:
            status_callback("联网检索未获得可用资料，继续保留本地 AI 复核结果。")
    result["context"] = context
    result["web_research_attempted"] = needs_research
    guidance = _ai_price_source_guidance(context, result)
    if guidance:
        result["price_source_guidance"] = guidance
    return context, result


class QuotaAIWorker(QThread):
    """在后台为一条清单复核定额，必要时联网检索人材机证据。"""

    finished = Signal(dict)
    error = Signal(str)
    status = Signal(str)

    def __init__(
        self,
        project_id: int,
        boq: dict,
        major: str,
        region_override: str = "",
        generation: int = 0,
    ):
        super().__init__()
        self.project_id = project_id
        self.boq = dict(boq)
        self.major = major
        self.region_override = region_override
        self.generation = int(generation or 0)

    def run(self):
        session = get_session()
        try:
            context, result = _resolve_ai_fallback(
                session,
                self.project_id,
                self.boq,
                major=self.major,
                status_callback=self.status.emit,
                region_override=self.region_override,
            )
            result["context"] = context
            result["_match_generation"] = self.generation
            result["_row_input_key"] = QuotaMatchTab._row_input_key(self.boq)
            result["_project_id"] = self.project_id
            self.finished.emit(result)
        except Exception as error:
            self.error.emit(str(error))
        finally:
            session.close()


class QuotaAIFallbackBatchWorker(QThread):
    """Process selected rows through the same AI fallback pipeline."""

    finished = Signal(dict)
    error = Signal(str)
    status = Signal(str)
    row_finished = Signal(dict)

    def __init__(
        self,
        project_id: int,
        items: list[tuple[int, dict]],
        major: str,
        region_override: str = "",
        generation: int = 0,
    ):
        super().__init__()
        self.project_id = project_id
        self.items = [(int(index), dict(boq)) for index, boq in items]
        self.major = major
        self.region_override = region_override
        self.generation = int(generation or 0)

    def run(self):
        session = get_session()
        results = []
        try:
            total = len(self.items)
            for position, (row_index, boq) in enumerate(self.items, start=1):
                self.status.emit(f"AI兜底匹配：正在处理第 {position}/{total} 条...")
                try:
                    _, result = _resolve_ai_fallback(
                        session,
                        self.project_id,
                        boq,
                        # A batch may contain rows from different imported
                        # sheets/profession labels. Never reuse the first
                        # row's major for every later row.
                        _text(boq.get("major") or self.major),
                        status_callback=self.status.emit,
                        region_override=self.region_override,
                    )
                    item_result = {
                        "row_index": row_index,
                        "boq": boq,
                        "result": result,
                        "error": "",
                        "match_generation": self.generation,
                        "row_input_key": QuotaMatchTab._row_input_key(boq),
                        "project_id": self.project_id,
                    }
                    results.append(item_result)
                    self.row_finished.emit(dict(item_result))
                except Exception as error:
                    item_result = {
                        "row_index": row_index,
                        "boq": boq,
                        "result": None,
                        "error": str(error),
                        "match_generation": self.generation,
                        "row_input_key": QuotaMatchTab._row_input_key(boq),
                        "project_id": self.project_id,
                    }
                    results.append(item_result)
                    self.row_finished.emit(dict(item_result))
            self.finished.emit({"results": results})
        except Exception as error:
            self.error.emit(str(error))
        finally:
            session.close()


class QuotaAuditWorker(QThread):
    """Review existing matched rows and correct logical problems through AI fallback."""

    finished = Signal(dict)
    error = Signal(str)
    status = Signal(str)
    row_finished = Signal(dict)

    def __init__(
        self,
        project_id: int,
        items: list[tuple[int, dict, dict]],
        major: str,
        region_override: str = "",
        generation: int = 0,
    ):
        super().__init__()
        self.project_id = project_id
        self.items = [
            (int(index), dict(boq), dict(current))
            for index, boq, current in items
        ]
        self.major = major
        self.region_override = region_override
        self.generation = int(generation or 0)

    @staticmethod
    def _requires_deep_correction(audit: dict) -> bool:
        """Only spend a second AI request on actionable high-risk errors."""
        severe_categories = {
            "人材机遗漏", "人材机管利遗漏", "重复匹配", "乱匹配",
            "计算错误", "单位换算", "纠正失败",
        }
        for finding in audit.get("findings") or []:
            if not isinstance(finding, dict):
                continue
            if str(finding.get("severity") or "").lower() == "high":
                return True
            if str(finding.get("category") or "") in severe_categories:
                return True
        return False

    @staticmethod
    def _pattern_key(boq: dict, current: dict) -> str:
        matches = []
        for value in current.get("quota_matches") or []:
            matches.append({
                "quota_id": value.get("quota_id"),
                "quota_code": _text(value.get("quota_code")),
                "quota_name": _text(value.get("quota_name")),
                "role": _text(value.get("role")),
                "score": round(_numeric(value.get("score")), 4),
                "source_type": _text(value.get("source_type")),
            })
        matches.sort(key=lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True))
        components = []
        for value in current.get("compositions") or []:
            components.append({
                "cat": _text(value.get("cat") or value.get("category")),
                "code": _text(value.get("code")),
                "name": _text(value.get("name")),
                "unit": _text(value.get("unit")),
                "qty": round(_numeric(value.get("qty")), 8),
                "loss": round(_percent(value.get("loss") if "loss" in value else value.get("loss_rate")), 8),
                "noTaxPrice": round(_numeric(value.get("noTaxPrice") if "noTaxPrice" in value else value.get("no_tax_price")), 8),
                "taxRate": round(_percent(value.get("taxRate") if "taxRate" in value else value.get("tax_rate")), 8),
                "taxPrice": round(_numeric(value.get("taxPrice") if "taxPrice" in value else value.get("tax_price")), 8),
            })
        components.sort(key=lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True))
        return json.dumps({
            "name": _text(boq.get("name")),
            "feature": _text(boq.get("feature")),
            "unit": _text(boq.get("unit")),
            "matches": matches,
            "components": components,
        }, ensure_ascii=False, sort_keys=True)

    def run(self):
        session = get_session()
        results = []
        try:
            groups = {}
            for row_index, boq, current in self.items:
                key = self._pattern_key(boq, current)
                groups.setdefault(key, []).append((row_index, boq, current))
            total_groups = len(groups)
            processed_rows = 0
            for group_position, group in enumerate(groups.values(), start=1):
                self.status.emit(
                    f"AI核查与纠正：正在处理模式 {group_position}/{total_groups}，"
                    f"覆盖 {len(group)} 行..."
                )
                context = build_ai_quota_context(
                    session,
                    self.project_id,
                    group[0][1],
                    major=_text(group[0][1].get("major") or self.major),
                    candidate_limit=24,
                    source_costs=(group[0][2].get("source_costs") or {}),
                    region_override=self.region_override,
                )
                from src.ai_service import ai

                audit = ai.audit_quota_composition(group[0][1], context, group[0][2])
                local_report = group[0][2].get("local_audit_report") or {}
                local_issues = local_report.get("issues") or []
                merged_findings = list(audit.get("findings") or [])
                seen_messages = {
                    str(value.get("message") or "")
                    for value in merged_findings
                    if isinstance(value, dict)
                }
                for value in local_issues:
                    if not isinstance(value, dict) or not value.get("message"):
                        continue
                    if str(value["message"]) in seen_messages:
                        continue
                    seen_messages.add(str(value["message"]))
                    merged_findings.append(dict(value))
                audit["findings"] = merged_findings
                audit["needs_correction"] = bool(
                    audit.get("needs_correction")
                    or local_report.get("needs_correction")
                )
                correction = None
                if audit.get("needs_correction") and self._requires_deep_correction(audit):
                    self.status.emit(f"模式 {group_position} 发现高风险问题，正在二次纠正...")
                    try:
                        repair_hints = [
                            f"审计问题：{finding.get('message') or finding.get('type') or '需要纠正'}"
                            for finding in audit.get("findings") or []
                            if isinstance(finding, dict)
                        ]
                        findings_text = " ".join(
                            str(finding.get("message") or "")
                            for finding in audit.get("findings") or []
                            if isinstance(finding, dict)
                        )
                        excluded_quota_ids = set()
                        for value in group[0][2].get("quota_matches") or []:
                            raw_id = value.get("quota_id")
                            if not str(raw_id or "").lstrip("-").isdigit():
                                continue
                            quota_name = str(value.get("quota_name") or "")
                            score = float(value.get("score") or 0)
                            clearly_bad = score < 0.55 or any(
                                marker in findings_text
                                for marker in ("乱匹配", "重复匹配", "规格冲突", "计算错误")
                            ) and quota_name and quota_name in findings_text
                            if clearly_bad:
                                excluded_quota_ids.add(int(raw_id))
                        if excluded_quota_ids:
                            repair_hints.append(
                                "禁止再次选择当前问题定额ID："
                                + ", ".join(str(value) for value in sorted(excluded_quota_ids))
                            )
                        _, correction = _resolve_ai_fallback(
                            session,
                            self.project_id,
                            group[0][1],
                            _text(group[0][1].get("major") or self.major),
                            status_callback=self.status.emit,
                            repair_hints=repair_hints,
                            excluded_quota_ids=excluded_quota_ids,
                            current_composition=group[0][2],
                            region_override=self.region_override,
                            # The first AI audit already has local evidence.
                            # Network research is reserved for an explicit
                            # unresolved fallback, keeping routine audits fast.
                            allow_research=False,
                        )
                    except Exception as error:
                        correction = None
                        audit["findings"].append({
                            "severity": "high",
                            "category": "其他",
                            "type": "纠正失败",
                            "message": str(error),
                            "affected_component": "",
                        })
                elif audit.get("needs_correction"):
                    audit["summary"] = (
                        str(audit.get("summary") or "AI 已完成复核。")
                        + "；发现中低风险提示，暂不重复调用AI重套，已标记人工复核"
                    )
                for row_index, boq, current in group:
                    item_result = {
                        "row_index": row_index,
                        "boq": boq,
                        "current": current,
                        "audit": dict(audit),
                        "correction": dict(correction) if correction else None,
                        "match_generation": self.generation,
                        "row_input_key": QuotaMatchTab._row_input_key(boq),
                        "project_id": self.project_id,
                    }
                    results.append(item_result)
                    self.row_finished.emit(dict(item_result))
                    processed_rows += 1
                self.status.emit(
                    f"模式 {group_position}/{total_groups} 核查完成，"
                    f"当前共处理 {processed_rows} 行"
                )
            self.finished.emit({"results": results})
        except Exception as error:
            self.error.emit(str(error))
        finally:
            session.close()


class QuotaAIReviewDialog(QDialog):
    """AI 结果复核窗，明确区分本地定额和市场补充估算。"""

    def __init__(self, boq: dict, result: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("定额/基础库复核")
        self.resize(1060, 700)
        self._boq = dict(boq or {})
        self._result = result
        self._confirm = QCheckBox("我已核对工程名称、工作内容、单位和组成明细，同意应用到当前清单")
        self._confirm.toggled.connect(self._update_buttons)
        root = QVBoxLayout(self)
        title = QLabel(f"清单：{boq.get('name', '')}    单位：{boq.get('unit', '')}")
        title.setStyleSheet("font-weight:bold; font-size:14px; color:#0f172a;")
        root.addWidget(title)
        feature = QLabel(f"项目特征及工作内容：{boq.get('feature', '') or '（空）'}")
        feature.setWordWrap(True)
        feature.setStyleSheet("color:#475569;")
        root.addWidget(feature)
        decision = str(result.get("decision") or "none")
        source_type = str(result.get("source_type") or "")
        labels = {
            "existing": "AI 推荐本地定额",
            "generate": (
                "AI 联网检索人材机"
                if source_type == "ai_web_research"
                else ("基础库换算" if source_type.startswith("base_") else "AI 补充定额/市场估算")
            ),
            "none": "未形成可采用结果",
        }
        level = str(result.get("evidence_level") or "yellow")
        level_text = {"green": "绿色：证据较可靠", "yellow": "黄色：部分证据，需复核", "red": "红色：证据不足，不建议直接采用"}.get(level, "待复核")
        badge = QLabel(f"{labels.get(decision, decision)}    {level_text}")
        badge.setStyleSheet({
            "green": "color:#15803d; font-weight:bold;",
            "yellow": "color:#a16207; font-weight:bold;",
            "red": "color:#b91c1c; font-weight:bold;",
        }.get(level, "color:#475569; font-weight:bold;"))
        root.addWidget(badge)
        summary = QLabel(str(result.get("summary") or ""))
        summary.setWordWrap(True)
        root.addWidget(summary)

        issues = [*(result.get("errors") or []), *(result.get("warnings") or [])]
        if issues:
            issue_text = "\n".join(f"{'错误' if index < len(result.get('errors') or []) else '提示'}：{value}" for index, value in enumerate(issues))
            issue_label = QLabel(issue_text)
            issue_label.setWordWrap(True)
            issue_label.setStyleSheet("color:#b45309; background:#fffbeb; padding:8px;")
            root.addWidget(issue_label)

        table = QTableWidget(0, 14)
        table.setHorizontalHeaderLabels([
            "费用类别", "编码", "名称", "工作内容", "单位", "含量", "损耗率%",
            "除税单价", "税率%", "含税单价", "除税合价", "含税合价", "备注", "价格依据/来源",
        ])
        table.setWordWrap(False)
        table.setTextElideMode(Qt.ElideRight)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        for column, width in enumerate([90, 110, 180, 260, 65, 80, 80, 100, 75, 100, 100, 100, 180, 320]):
            table.setColumnWidth(column, width)
        generated = result.get("generated_quota") or {}
        rows = []
        if decision == "existing":
            candidate_map = {
                int(value["quota_id"]): value
                for value in (result.get("context") or {}).get("candidates") or []
                if value.get("quota_id") is not None
            }
            for match in result.get("matches") or []:
                candidate = candidate_map.get(int(match.get("quota_id") or 0), {})
                for component in candidate.get("components") or []:
                    rows.append({
                        "level": level,
                        "values": [
                            component.get("category", ""), component.get("code", ""),
                            component.get("name", ""), component.get("feature", ""),
                            component.get("unit", ""), component.get("qty", ""),
                            component.get("loss_rate", ""), component.get("no_tax_price", ""),
                            component.get("tax_rate", ""), component.get("tax_price", ""),
                            "", "", match.get("role", ""),
                            f"本地定额 {candidate.get('code', '')} {candidate.get('name', '')}；"
                            f"置信度 {float(match.get('confidence') or 0):.0%}；{match.get('reason', '')}",
                        ],
                    })
        elif decision == "generate":
            for component in generated.get("components") or []:
                source_ids = component.get("sourceEvidenceIds") or component.get("source_evidence_ids") or []
                source_text = component.get("calculationBasis") or component.get("calculation_basis") or ""
                if source_ids:
                    source_text += f"；本地已确认价格ID：{','.join(str(value) for value in source_ids)}"
                rows.append({
                    "level": component.get("evidenceLevel") or level,
                    "values": [
                        component.get("cat") or component.get("category", ""),
                        component.get("code", ""), component.get("name", ""),
                        component.get("feature", ""), component.get("unit", ""),
                        component.get("qty", ""), component.get("loss") or component.get("loss_rate", ""),
                        component.get("noTaxPrice") or component.get("no_tax_price", ""),
                        component.get("taxRate") or component.get("tax_rate", ""),
                        component.get("taxPrice") or component.get("tax_price", ""),
                        component.get("noTaxTotal") or component.get("no_tax_total", ""),
                        component.get("taxTotal") or component.get("tax_total", ""),
                        component.get("note", ""), source_text,
                    ],
                })
        table.setRowCount(len(rows))
        for row_index, row_data in enumerate(rows):
            values = row_data["values"]
            row_level = row_data["level"]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value or ""))
                item.setToolTip(str(value or ""))
                if row_level == "green":
                    item.setBackground(QColor("#f0fdf4"))
                elif row_level == "yellow":
                    item.setBackground(QColor("#fffbeb"))
                else:
                    item.setBackground(QColor("#fef2f2"))
                table.setItem(row_index, column, item)
        install_long_text_tooltip(table)
        root.addWidget(table, 1)
        if decision == "generate":
            info = QLabel(
                f"补充定额名称：{generated.get('name', '')}；编码：{generated.get('code', '')}；"
                f"单位：{generated.get('unit', '')}；除税单价：{generated.get('no_tax_price', '')}；"
                f"含税单价：{generated.get('tax_price', '')}"
            )
            info.setWordWrap(True)
            info.setStyleSheet("color:#334155;")
            root.addWidget(info)
        root.addWidget(self._confirm)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self._save_library_button = None
        if decision == "generate" and generated:
            self._save_library_button = buttons.addButton(
                "保存为AI定额库",
                QDialogButtonBox.ActionRole,
            )
            self._save_library_button.setToolTip(
                "保存为可复用的AI定额数据；保留地区、计价期、价格来源和人工复核标记，不写入正式定额"
            )
            self._save_library_button.clicked.connect(self._save_generated_to_library)
        self._ok_button = buttons.button(QDialogButtonBox.Ok)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        self._update_buttons()

    def _update_buttons(self):
        valid = bool(self._result.get("actionable", self._result.get("valid", False)))
        self._ok_button.setEnabled(valid and self._confirm.isChecked())
        if self._save_library_button is not None:
            can_save = bool(self._result.get("generated_quota")) and not bool(
                self._result.get("errors")
            )
            self._save_library_button.setEnabled(can_save and self._confirm.isChecked())

    def _save_generated_to_library(self):
        generated = self._result.get("generated_quota") or {}
        if not generated:
            return
        session = get_session()
        try:
            item = save_ai_generated_quota(
                session,
                generated,
                boq=self._boq,
                project=(self._result.get("context") or {}).get("project") or {},
            )
            session.commit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
            return
        finally:
            session.close()
        self._save_library_button.setEnabled(False)
        self._save_library_button.setText("已保存到AI定额库")
        QMessageBox.information(
            self,
            "保存成功",
            f"已保存“{item.name}”到 AI 定额数据。地区、计价期、来源和复核状态已保留。",
        )


class QuotaAIBatchReviewDialog(QDialog):
    """One confirmation point for multiple AI fallback results."""

    def __init__(self, items: list[dict], parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI兜底匹配复核")
        self.resize(1120, 680)
        self._items = items
        root = QVBoxLayout(self)
        valid_count = sum(
            1
            for value in items
            if value.get("result") and value["result"].get(
                "valid",
                value["result"].get("actionable", False),
            )
        )
        title = QLabel(
            f"共处理 {len(items)} 条，可应用结果 {valid_count} 条。"
            "双击任意行可查看该行的完整 AI 组成和证据。"
        )
        title.setStyleSheet("font-weight:bold; color:#0f172a;")
        title.setWordWrap(True)
        root.addWidget(title)

        table = QTableWidget(0, 5)
        table.setHorizontalHeaderLabels(["序号", "工程名称", "AI结果", "证据", "说明"])
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setAlternatingRowColors(True)
        table.setStyleSheet(TABLE_STYLE)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        for column, width in enumerate([55, 190, 180, 90, 420]):
            table.setColumnWidth(column, width)
        for row_index, value in enumerate(items):
            boq = value.get("boq") or {}
            result = value.get("result") or {}
            table.insertRow(row_index)
            valid = bool(result.get("valid", result.get("actionable", False)))
            decision = str(result.get("decision") or "none")
            source_type = str(result.get("source_type") or result.get("generated_quota", {}).get("source_type") or "")
            if decision == "existing":
                decision_label = "AI本地定额"
            elif source_type.startswith("base_"):
                decision_label = "基础库/信息价"
            elif source_type == "ai_web_research":
                decision_label = "AI联网检索"
            elif decision == "generate":
                decision_label = "AI补充定额"
            else:
                decision_label = "无可采用结果"
            evidence = str(result.get("evidence_level") or "red")
            issues = [
                *(result.get("errors") or []),
                *(result.get("warnings") or []),
            ]
            if not valid:
                issues.insert(
                    0,
                    value.get("error")
                    or result.get("summary")
                    or "AI未形成可计算结果",
                )
            values = [
                str(boq.get("seq") or row_index + 1),
                str(boq.get("name") or ""),
                decision_label,
                evidence,
                "；".join(issues[:4]),
            ]
            for column, text in enumerate(values):
                item = QTableWidgetItem(str(text or ""))
                item.setToolTip(str(text or ""))
                if evidence == "green":
                    item.setBackground(QColor("#f0fdf4"))
                elif evidence == "yellow":
                    item.setBackground(QColor("#fffbeb"))
                else:
                    item.setBackground(QColor("#fef2f2"))
                table.setItem(row_index, column, item)
        table.cellDoubleClicked.connect(self._show_detail)
        root.addWidget(table, 1)

        self._confirm = QCheckBox("我已逐条核对工程名称、工作内容、单位、人材机组成和来源，同意应用上述 AI 结果")
        self._confirm.toggled.connect(self._update_buttons)
        root.addWidget(self._confirm)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self._ok_button = buttons.button(QDialogButtonBox.Ok)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        self._update_buttons()

    def _show_detail(self, row: int, _column: int):
        if not (0 <= row < len(self._items)):
            return
        value = self._items[row]
        result = value.get("result")
        if result:
            QuotaAIReviewDialog(value.get("boq") or {}, result, self).exec()

    def _update_buttons(self):
        self._ok_button.setEnabled(self._confirm.isChecked())


class QuotaAuditReviewDialog(QDialog):
    """Batch review for AI audit findings and corrected results."""

    def __init__(self, items: list[dict], parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI核查与纠正复核")
        self.resize(1120, 680)
        self._items = items
        root = QVBoxLayout(self)
        correction_count = sum(
            1
            for value in items
            if value.get("correction")
            and value["correction"].get("valid", value["correction"].get("actionable", False))
        )
        issue_count = sum(
            1
            for value in items
            if value.get("audit", {}).get("findings")
        )
        title = QLabel(
            f"已核查 {len(items)} 条，发现问题 {issue_count} 条，形成纠正结果 {correction_count} 条。"
            "所有 AI 核查和纠正结果仅用于人工复核，双击行可查看明细。"
        )
        title.setWordWrap(True)
        title.setStyleSheet("font-weight:bold; color:#0f172a;")
        root.addWidget(title)

        table = QTableWidget(0, 5)
        table.setHorizontalHeaderLabels(["序号", "工程名称", "核查结论", "证据", "问题说明"])
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setAlternatingRowColors(True)
        table.setStyleSheet(TABLE_STYLE)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        for column, width in enumerate([55, 190, 130, 90, 480]):
            table.setColumnWidth(column, width)

        for row_index, value in enumerate(items):
            table.insertRow(row_index)
            boq = value.get("boq") or {}
            audit = value.get("audit") or {}
            correction = value.get("correction") or {}
            findings = audit.get("findings") or []
            conclusion = (
                "已形成纠正结果"
                if correction.get("valid", correction.get("actionable", False))
                else ("发现问题，未能自动纠正" if findings else "AI核查通过")
            )
            evidence = str(
                correction.get("evidence_level")
                or value.get("current", {}).get("evidence_level")
                or "yellow"
            )
            messages = [
                f"[{finding.get('severity', 'low')}/{finding.get('category', '其他')}] "
                f"{finding.get('message', '')}"
                for finding in findings[:6]
                if isinstance(finding, dict)
            ]
            values = [
                str(boq.get("seq") or row_index + 1),
                str(boq.get("name") or ""),
                conclusion,
                evidence,
                "；".join(messages) or "AI核查后仍建议人工确认",
            ]
            for column, text in enumerate(values):
                item = QTableWidgetItem(str(text or ""))
                item.setToolTip(str(text or ""))
                if evidence == "green":
                    item.setBackground(QColor("#f0fdf4"))
                elif evidence == "yellow":
                    item.setBackground(QColor("#fffbeb"))
                else:
                    item.setBackground(QColor("#fef2f2"))
                table.setItem(row_index, column, item)
        table.cellDoubleClicked.connect(self._show_detail)
        root.addWidget(table, 1)

        self._confirm = QCheckBox("我已逐条核对核查结论、问题说明和纠正后的组价，同意应用到当前项目")
        self._confirm.toggled.connect(self._update_buttons)
        root.addWidget(self._confirm)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self._ok_button = buttons.button(QDialogButtonBox.Ok)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)
        self._update_buttons()

    def _show_detail(self, row: int, _column: int):
        if not (0 <= row < len(self._items)):
            return
        value = self._items[row]
        correction = value.get("correction") or {}
        if correction.get("valid", correction.get("actionable", False)):
            QuotaAIReviewDialog(value.get("boq") or {}, correction, self).exec()
            return
        audit = value.get("audit") or {}
        findings = audit.get("findings") or []
        detail = "\n".join(
            f"[{finding.get('severity', 'low')}/{finding.get('category', '其他')}] "
            f"{finding.get('type', '')}: "
            f"{finding.get('message', '')}"
            for finding in findings
            if isinstance(finding, dict)
        )
        QMessageBox.information(
            self,
            "AI核查明细",
            detail or audit.get("summary") or "AI核查通过，仍建议人工复核。",
        )

    def _update_buttons(self):
        self._ok_button.setEnabled(self._confirm.isChecked())


class FeeSettingsDialog(QDialog):
    """按分部维护管理费/利润的取费基数与费率。"""

    def __init__(self, settings: dict | None, group_names: list[str], parent=None):
        super().__init__(parent)
        self._settings = {
            "default": dict((settings or {}).get("default") or {}),
            "groups": {
                str(key): dict(value or {})
                for key, value in ((settings or {}).get("groups") or {}).items()
                if key and key != "default"
            },
        }
        self._group_names = list(dict.fromkeys(str(name) for name in group_names if name))
        self._default_settings = {
            "management_base": self._settings["default"].get("management_base", "direct"),
            "management_rate": float(self._settings["default"].get("management_rate", 5)),
            "profit_base": self._settings["default"].get("profit_base", "direct_management"),
            "profit_rate": float(self._settings["default"].get("profit_rate", 7)),
        }
        self.setWindowTitle("取费设置（按分部）")
        self.resize(1040, 560)
        self.setStyleSheet(FEE_DIALOG_STYLE)
        self._content_font = QFont("Microsoft YaHei", 10)
        self._header_font = QFont("Microsoft YaHei", 10, QFont.Bold)
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(10)

        title = QLabel("取费设置（按分部）")
        title.setFont(QFont("Microsoft YaHei", 14, QFont.Bold))
        title.setStyleSheet("color:#172033;")
        title.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        root.addWidget(title)
        hint = QLabel(
            "每个分部独立设置管理费/利润的取费基数与费率，未设置的分部使用默认配置"
        )
        hint.setFont(self._content_font)
        hint.setStyleSheet("color:#64748b;")
        hint.setWordWrap(True)
        root.addWidget(hint)

        self._table = QTableWidget(0, 5)
        self._table.setHorizontalHeaderLabels(
            ["分部工程", "管理费基数", "管理费率%", "利润基数", "利润率%"]
        )
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(TABLE_STYLE)
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setDefaultAlignment(Qt.AlignCenter)
        header.setHighlightSections(False)
        header.setFont(self._header_font)
        self._table.verticalHeader().setDefaultSectionSize(42)
        self._table.verticalHeader().setMinimumSectionSize(38)
        self._table.verticalHeader().setVisible(False)
        for column, width in enumerate([230, 220, 120, 220, 120]):
            self._table.setColumnWidth(column, width)
        root.addWidget(self._table, 1)

        self._populate_rows()

        buttons = QHBoxLayout()
        buttons.addStretch()
        restore_button = ActionButton("恢复默认", "default")
        restore_button.setToolTip("恢复默认配置，并清除所有分部的独立设置")
        restore_button.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        restore_button.clicked.connect(self._restore_defaults)
        buttons.addWidget(restore_button)
        cancel_button = ActionButton("取消", "default")
        cancel_button.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(cancel_button)
        save_button = ActionButton("保存并重算", "primary")
        save_button.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        save_button.clicked.connect(self._save_and_close)
        buttons.addWidget(save_button)
        root.addLayout(buttons)

    def _populate_rows(self):
        self._table.setRowCount(1 + len(self._group_names))
        self._set_row_values(0, "default", self._default_settings, is_default=True)
        for row, group_name in enumerate(self._group_names, start=1):
            config = self._settings["groups"].get(group_name) or self._default_settings
            self._set_row_values(row, group_name, config, is_default=False)

    def _set_row_values(self, row: int, group_name: str, config: dict, is_default: bool):
        label_item = QTableWidgetItem(group_name if not is_default else "默认配置")
        label_item.setFlags(label_item.flags() & ~Qt.ItemIsEditable)
        label_item.setFont(self._content_font)
        label_item.setTextAlignment(Qt.AlignCenter)
        if is_default:
            label_item.setBackground(QColor("#f8fafc"))
        self._table.setItem(row, 0, label_item)
        self._table.setRowHeight(row, 42)

        management_base = self._base_combo(
            str(config.get("management_base") or "direct"),
        )
        profit_base = self._base_combo(
            str(config.get("profit_base") or "direct_management"),
        )
        management_rate = self._rate_spin(float(config.get("management_rate", 5)))
        profit_rate = self._rate_spin(float(config.get("profit_rate", 7)))
        self._table.setCellWidget(row, 1, management_base)
        self._table.setCellWidget(row, 2, management_rate)
        self._table.setCellWidget(row, 3, profit_base)
        self._table.setCellWidget(row, 4, profit_rate)

    @staticmethod
    def _base_combo(value: str) -> QComboBox:
        combo = QComboBox()
        for label, key in FEE_BASE_OPTIONS:
            combo.addItem(label, key)
        index = combo.findData(value)
        combo.setCurrentIndex(max(0, index))
        combo.setMinimumWidth(205)
        combo.setFixedHeight(30)
        combo.setEditable(True)
        combo.lineEdit().setReadOnly(True)
        combo.lineEdit().setAlignment(Qt.AlignCenter)
        combo.lineEdit().setFont(QFont("Microsoft YaHei", 10))
        combo.setInsertPolicy(QComboBox.NoInsert)
        combo.setStyleSheet(INPUT_STYLE)
        return combo

    @staticmethod
    def _rate_spin(value: float) -> QDoubleSpinBox:
        spin = QDoubleSpinBox()
        spin.setRange(0, 100)
        spin.setDecimals(2)
        spin.setSuffix(" %")
        spin.setMinimumWidth(100)
        spin.setFixedHeight(30)
        spin.setAlignment(Qt.AlignCenter)
        spin.setFont(QFont("Microsoft YaHei", 10))
        spin.setValue(max(0.0, min(100.0, value)))
        return spin

    def _row_config(self, row: int) -> dict:
        return {
            "management_base": self._table.cellWidget(row, 1).currentData() or "direct",
            "management_rate": self._table.cellWidget(row, 2).value(),
            "profit_base": self._table.cellWidget(row, 3).currentData() or "direct_management",
            "profit_rate": self._table.cellWidget(row, 4).value(),
        }

    def _restore_defaults(self):
        self._settings["groups"].clear()
        self._populate_rows()

    def values(self) -> dict:
        default = self._row_config(0)
        groups = {}
        for row, group_name in enumerate(self._group_names, start=1):
            config = self._row_config(row)
            if config != default:
                groups[group_name] = config
        return {"default": default, "groups": groups}

    def _save_and_close(self):
        self._default_settings = self._row_config(0)
        self.accept()


class QuotaMatchTab(QWidget):
    # These versions are part of the persisted-data contract. Any change to
    # matching, AI prompts, validation, or quantity calculation must bump the
    # value so old results cannot silently become current results.
    RESULT_SCHEMA = "quota-result-v2"
    ROW_RESULT_SCHEMA = "quota-row-result-v1"
    AI_CACHE_SCHEMA = "ai-cache-v3"
    AI_PROMPT_VERSION = "ai-prompt-20260830-02"
    MATCHING_ALGORITHM_VERSION = QUOTA_MATCH_ALGORITHM_VERSION
    AI_CACHE_MAX_ENTRIES_PER_PURPOSE = 6
    AI_CACHE_MAX_BYTES_PER_ROW = 96 * 1024
    _last_generic_rejections: dict[str, int] = {}
    data_changed = Signal()
    navigate_requested = Signal(str)

    HEADERS = [
        "序号", "工程名称", "项目特征及工作内容", "单位", "工程量", "综合单价分析",
        "综合单价", "人工费", "材料费", "机械费", "管理费", "利润", "备注",
    ]
    WIDTHS = [55, 190, 360, 65, 95, 260, 95, 85, 85, 85, 85, 85, 230]
    NUMERIC_COLUMNS = {4, 6, 7, 8, 9, 10, 11}
    DETAIL_HEADERS = [
        "计入", "定额角色", "来源定额", "费用类别", "编码", "名称", "工作内容", "单位",
        "原含量", "调整含量", "定额系数", "损耗率%", "损耗后含量", "清单单位",
        "总用量", "换算说明", "除税单价", "除税单位合价", "清单工程量", "除税工程合价",
        "税率%", "含税单价", "含税单位合价", "含税工程合价", "计算式", "备注",
    ]
    DETAIL_WIDTHS = [52, 78, 210, 85, 110, 180, 300, 60, 75, 80, 75, 75, 90, 75, 90, 260, 90, 110, 90, 70, 90, 105, 110, 300, 160]
    EXPENSE_CATEGORIES = ["材料费", "辅材费", "人工费", "主材费", "机械费", "专业分包"]
    PRICE_PRIORITY_OPTIONS = (
        ("定额库优先", "quota"),
        ("官方信息价优先", "official"),
    )
    TOOLTIP_DURATION_MS = 30000
    KEY_SPECIFICATION_TERMS = (
        "桩长", "空桩长度", "有效桩长", "桩径", "管径", "管道规格",
        "厚度", "宽度", "高度", "长度", "强度等级", "混凝土等级", "材质",
        "规格型号", "型号", "压力等级", "粒径", "级配", "含水率", "密实度",
        "配筋", "钢筋规格", "电缆规格", "电压等级", "容量", "尺寸",
    )
    VAGUE_SPECIFICATION_PHRASES = (
        "按设计深度", "按设计要求", "按设计确定", "按图纸确定", "按实际确定",
        "按现场确定", "由设计确定", "由现场确定", "待设计确定", "待定",
        "暂定", "现场确定", "另行确定", "按实际发生", "按实际计取",
    )
    HEADER_ALIASES = {
        "seq": ("序号", "序列号", "顺序号"),
        "code": ("清单编码", "清单编号", "项目编码", "项目编号", "编码", "定额编号", "定额编码"),
        "name": ("工程名称", "工程或费用名称", "清单名称", "清单项目名称", "项目名称", "单项名称", "材料名称"),
        "feature": ("项目特征及工作内容", "项目特征描述", "项目特征", "特征及工作内容", "规格型号", "工作内容", "规格", "型号"),
        "unit": ("单位", "计量单位"),
        "quantity": ("工程量", "清单工程量", "工程数量", "数量", "清单数量"),
        "analysis": ("综合单价分析", "单价分析"),
        "comprehensive_price": ("综合单价",),
        "total_price": ("合价", "清单合价", "工程合价"),
        "labor": ("人工费",),
        "material": ("材料费",),
        "machinery": ("机械费",),
        "management": ("管理费",),
        "profit": ("利润",),
        "note": ("备注", "说明"),
    }

    def __init__(self):
        super().__init__()
        self._rows: list[dict] = []
        self._source_file = ""
        self._source_format = ""
        self._loaded_saved_result = False
        self._current_project_id = 0
        # Async AI results are accepted only for the exact project/input
        # generation that created them. This prevents a late worker callback
        # from writing an old result into a newly imported row.
        self._match_generation = 0
        self._pending_ai_results: dict[int, dict] = {}
        self._ai_fallback_indexes: list[int] = []
        self._ai_fallback_total = 0
        self._ai_fallback_completed = 0
        self._ai_fallback_applied = 0
        self._ai_fallback_failed = 0
        self._ai_fallback_stage_done = False
        self._ai_audit_indexes: list[int] = []
        self._ai_audit_total = 0
        self._ai_audit_completed = 0
        self._ai_audit_stage_done = False
        self._pipeline_local_total = 0
        self._pipeline_local_completed = 0
        self._pipeline_status = ""
        self._pipeline_active = False
        self._pipeline_finished = False
        self._fee_settings = self._normalize_fee_settings(None)
        self._source_region = ""
        self._setup_ui()

    def _setup_ui(self):
        self.setFont(QFont("Microsoft YaHei", 10))
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("匹配定额库"))
        tools.addStretch()
        for text, callback, kind in [
            ("Excel导入", self._import_excel, "primary"),
            ("批量匹配定额库", self._batch_match, "default"),
            ("匹配选中行", self._batch_match_selected, "primary"),
            ("AI兜底匹配", self._ai_fallback_selected, "primary"),
            ("AI核查与纠正", self._ai_audit_correct, "primary"),
            ("保存组价", self._save_results_clicked, "default"),
            ("导出结果", self._export_excel, "default"),
            ("清空结果", self._clear, "warn"),
            ("刷新", self.refresh_data, "default"),
        ]:
            button = ActionButton(text, kind)
            button.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
            if text == "Excel导入":
                button.setToolTip(
                    "支持工程量清单、投标文件、投标报价清单、结算文件等，"
                    "系统会自动提取需要套定额的清单。"
                )
            elif text == "AI兜底匹配":
                button.setToolTip(
                    "对选中行依次使用固定工程清单库、已确认信息价、地区标准和 AI 联网检索。"
                    "未选择行时处理当前行。"
                )
            elif text == "AI核查与纠正":
                button.setToolTip(
                    "核查已有定额组价是否合乎逻辑、是否存在遗漏或低置信结果；"
                    "问题行自动重新使用 AI 兜底匹配。"
                )
            button.clicked.connect(callback)
            tools.addWidget(button)
        layout.addLayout(tools)

        filters = QHBoxLayout()
        self._major = QComboBox()
        self._major.addItem("全部专业", "")
        self._major.setEditable(True)
        self._major.setToolTip("优先从该专业的定额库匹配；导入清单时也可以为本批次指定专业。")
        filters.addWidget(QLabel("定额专业:"))
        filters.addWidget(self._major)
        self._add_major_btn = ActionButton("新增专业", "default")
        self._add_major_btn.setToolTip("新增一个匹配方向标签；不会自动生成定额数据。")
        self._add_major_btn.clicked.connect(self._add_custom_major)
        filters.addWidget(self._add_major_btn)
        filters.addSpacing(4)
        filters.addWidget(QLabel("匹配挡位:"))
        self._match_level = QComboBox()
        self._match_level.setStyleSheet(INPUT_STYLE)
        for label, threshold in (
            ("宽松（40%）", 40),
            ("较宽松（50%）", 50),
            ("标准（60%）", 60),
            ("谨慎（70%）", 70),
        ):
            self._match_level.addItem(label, threshold)
        # New matching sessions use the standard 60% level. Saved project
        # selections are restored by _apply_saved_payload.
        self._match_level.setCurrentIndex(2)
        filters.addWidget(self._match_level)
        filters.addSpacing(10)
        filters.addWidget(QLabel("信息来源地区:"))
        self._source_region_input = QComboBox()
        self._source_region_input.setEditable(True)
        self._source_region_input.setStyleSheet(INPUT_STYLE)
        self._source_region_input.setMinimumWidth(150)
        self._source_region_input.addItem("未选择，按信息价库最新期", "")
        self._source_region_input.addItems([
            "北京", "上海", "广州", "深圳", "杭州", "苏州", "成都", "重庆",
            "西安", "武汉", "南京", "郑州", "合肥", "昆明", "拉萨",
        ])
        self._source_region_input.setToolTip(
            "只控制信息价、市场参考价和AI价格来源；留空时使用信息价库最新期，不读取项目地区。"
        )
        self._source_region_input.currentTextChanged.connect(self._on_source_region_changed)
        saved_region = get_setting("quota_source_region", "")
        if saved_region:
            self._source_region_input.setCurrentText(saved_region)
        filters.addWidget(self._source_region_input)
        filters.addSpacing(10)
        filters.addWidget(QLabel("单价来源:"))
        self._price_priority = QComboBox()
        self._price_priority.setStyleSheet(INPUT_STYLE)
        self._price_priority.setToolTip(
            "定额库决定定额、含量、损耗和系数；官方信息价优先时，仅替换规格、单位、地区和计价期均匹配的已确认人材机单价。"
        )
        saved_priority = get_setting("quota_price_priority", "quota")
        for label, key in self.PRICE_PRIORITY_OPTIONS:
            self._price_priority.addItem(label, key)
        priority_index = self._price_priority.findData(saved_priority)
        self._price_priority.setCurrentIndex(max(0, priority_index))
        self._price_priority.currentIndexChanged.connect(self._on_price_priority_changed)
        filters.addWidget(self._price_priority)
        # Keep the default rate controls as internal state. User-facing rate
        # editing is consolidated in the fee settings dialog.
        self._management_rate = QDoubleSpinBox(self)
        self._management_rate.setRange(0, 100)
        self._management_rate.setDecimals(2)
        self._management_rate.setSuffix(" %")
        self._management_rate.setValue(float(self._fee_settings["default"].get("management_rate", 5)))
        self._management_rate.hide()
        self._profit_rate = QDoubleSpinBox(self)
        self._profit_rate.setRange(0, 100)
        self._profit_rate.setDecimals(2)
        self._profit_rate.setSuffix(" %")
        self._profit_rate.setValue(float(self._fee_settings["default"].get("profit_rate", 7)))
        self._profit_rate.hide()
        filters.addSpacing(12)
        self._fee_settings_btn = ActionButton("取费设置", "default")
        self._fee_settings_btn.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        self._fee_settings_btn.setToolTip(
            "按分部配置管理费/利润的取费基数与费率，未设置的分部使用默认配置"
        )
        self._fee_settings_btn.clicked.connect(self._open_fee_settings)
        filters.addWidget(self._fee_settings_btn)
        filters.addStretch()
        self._stats_label = QLabel("尚未导入清单")
        self._stats_label.setStyleSheet("color:#64748b; font-weight:bold;")
        filters.addWidget(self._stats_label)
        layout.addLayout(filters)

        category_bar = QHBoxLayout()
        category_bar.addWidget(QLabel("清单状态:"))
        self._status_filter = QComboBox()
        self._status_filter.setStyleSheet(INPUT_STYLE)
        self._status_filter.setMinimumWidth(110)
        self._status_filter.setToolTip("按清单匹配状态筛选表格")
        for label, status in (
            ("全部", "all"),
            ("未匹配", "unmatched"),
            ("已匹配", "matched"),
            ("候选匹配", "candidate"),
            ("AI补充", "ai"),
            ("需人工确认", "review"),
            ("禁止计价", "blocked"),
        ):
            self._status_filter.addItem(label, status)
        category_bar.addWidget(self._status_filter)
        self._select_unmatched_button = ActionButton("选中未匹配", "default")
        self._select_unmatched_button.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        self._select_unmatched_button.setToolTip("选择当前筛选中尚未匹配的清单行")
        self._select_unmatched_button.clicked.connect(self._select_unmatched)
        category_bar.addWidget(self._select_unmatched_button)
        category_bar.addSpacing(12)
        category_bar.addWidget(QLabel("低置信自动AI复核:"))
        self._auto_ai_audit = QCheckBox()
        self._auto_ai_audit.setChecked(get_setting("quota_auto_ai_audit", "true").lower() != "false")
        self._auto_ai_audit.setToolTip(
            "匹配完成后，AI会自动复核低置信、信息不足、单位换算、含量计算、人材机遗漏、重复匹配和乱匹配；"
            "完全没有结果的清单则生成补充定额。AI结果会标注来源并保留人工复核状态。"
        )
        self._auto_ai_audit.toggled.connect(
            lambda checked: set_settings({"quota_auto_ai_audit": "true" if checked else "false"})
        )
        category_bar.addWidget(self._auto_ai_audit)
        category_bar.addSpacing(12)
        category_bar.addWidget(QLabel("计价组成:"))
        self._category_checks = {}
        for category in self.EXPENSE_CATEGORIES:
            checkbox = QCheckBox(category)
            checkbox.setChecked(True)
            checkbox.setToolTip(f"控制匹配后是否将“{category}”组成计入清单价格")
            checkbox.toggled.connect(self._recalculate_matched_rows)
            category_bar.addWidget(checkbox)
            self._category_checks[category] = checkbox
        category_bar.addStretch()
        self._match_rule_label = QLabel()
        self._match_rule_label.setStyleSheet("color:#64748b;")
        category_bar.addWidget(self._match_rule_label)
        category_bar.addSpacing(14)
        legend_title = QLabel("证据等级:")
        legend_title.setStyleSheet("color:#64748b;")
        category_bar.addWidget(legend_title)
        for label, color, tip in (
            ("可靠", "#15803d", "本地确认价格与名称、规格、单位、地区、计价期和税价口径相容"),
            ("需复核", "#a16207", "部分证据或跨地区/跨期/口径不完整，必须人工复核"),
            ("不足", "#b91c1c", "无可靠本地价格来源或存在逻辑风险，不建议直接采用"),
        ):
            badge = QLabel(label)
            badge.setStyleSheet(f"color:{color}; font-weight:bold;")
            badge.setToolTip(tip)
            category_bar.addWidget(badge)
        layout.addLayout(category_bar)

        ai_progress_row = QHBoxLayout()
        ai_progress_row.setSpacing(8)
        ai_progress_row.addWidget(QLabel("匹配总进度:"))
        self._ai_progress = QProgressBar()
        self._ai_progress.setRange(0, 100)
        self._ai_progress.setValue(0)
        self._ai_progress.setTextVisible(True)
        self._ai_progress.setFormat("未运行")
        self._ai_progress.setMinimumWidth(380)
        self._ai_progress.setMaximumWidth(620)
        self._ai_progress.setFixedHeight(22)
        self._ai_progress.setStyleSheet(
            "QProgressBar { border:1px solid #dbe3ef; border-radius:5px; "
            "background:#f8fafc; text-align:center; color:#334155; } "
            "QProgressBar::chunk { background:#2563eb; border-radius:4px; }"
        )
        self._ai_progress.setToolTip(
            "统一显示本地定额、企业参考/基础库、AI兜底和AI复核的总进度；结果会逐行保存。"
        )
        ai_progress_row.addWidget(self._ai_progress, 1)
        self._ai_progress_detail = QLabel("无正在运行的匹配任务")
        self._ai_progress_detail.setStyleSheet("color:#64748b;")
        ai_progress_row.addWidget(self._ai_progress_detail)
        ai_progress_row.addStretch()
        layout.addLayout(ai_progress_row)
        self._match_level.currentIndexChanged.connect(self._update_match_rule_label)
        self._status_filter.currentIndexChanged.connect(self._on_status_filter_changed)
        self._update_match_rule_label()

        self._table = QTableWidget(0, len(self.HEADERS))
        self._table.setHorizontalHeaderLabels(self.HEADERS)
        self._table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._table.setWordWrap(False)
        self._table.setTextElideMode(Qt.ElideRight)
        self._table.setMouseTracking(True)
        self._table.setSortingEnabled(False)
        header = self._table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setDefaultSectionSize(100)
        header.setDefaultAlignment(Qt.AlignCenter)
        header.setHighlightSections(False)
        header.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        self._table.verticalHeader().setVisible(True)
        self._table.verticalHeader().setDefaultSectionSize(32)
        self._table.verticalHeader().setMinimumSectionSize(30)
        self._table.verticalHeader().setMinimumWidth(48)
        for column, width in enumerate(self.WIDTHS):
            self._table.setColumnWidth(column, width)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(TABLE_STYLE)
        install_long_text_tooltip(self._table)
        self._table.itemSelectionChanged.connect(self._on_main_selection_changed)
        self._table.cellEntered.connect(self._on_cell_entered)
        self._table.cellDoubleClicked.connect(self._show_main_cell_content)

        detail_container = QWidget()
        detail_layout = QVBoxLayout(detail_container)
        detail_layout.setContentsMargins(0, 4, 0, 0)
        detail_layout.setSpacing(6)
        detail_tools = QHBoxLayout()
        self._detail_label = QLabel("组价明细：请选择一条清单")
        self._detail_label.setStyleSheet("color:#334155; font-weight:bold;")
        detail_tools.addWidget(self._detail_label, 1)
        detail_actions = QHBoxLayout()
        detail_actions.setSpacing(6)
        for text, callback, kind in [
            ("调整取费归属", self._adjust_row_fee_group, "default"),
            ("写入清单行", self._write_pending_ai_to_row, "primary"),
            ("选择现有定额", self._add_quota_to_row, "primary"),
            ("新增补充分量", self._add_main_material, "default"),
            ("补充主材", self._add_main_material, "default"),
            ("确认计入", self._confirm_detail_included, "primary"),
            ("确认不计入", self._confirm_detail_excluded, "default"),
            ("编辑分量", self._edit_detail, "default"),
            ("删除分量", self._remove_detail, "warn"),
            ("移除定额", self._remove_quota_from_row, "warn"),
        ]:
            button = ActionButton(text, kind)
            button.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
            if text == "确认计入":
                button.setToolTip("将当前选中的组价分量纳入清单计算，并保留人工确认记录")
            elif text == "确认不计入":
                button.setToolTip("明确当前分量不纳入清单计算，并保留人工确认记录")
            button.clicked.connect(callback)
            if text in {"确认计入", "确认不计入"}:
                detail_tools.addWidget(button)
            else:
                detail_actions.addWidget(button)
        detail_tools.addSpacing(8)
        detail_tools.addStretch()
        detail_layout.addLayout(detail_tools)
        detail_actions.addStretch()
        detail_layout.addLayout(detail_actions)
        self._detail_table = QTableWidget(0, len(self.DETAIL_HEADERS))
        self._detail_table.setHorizontalHeaderLabels(self.DETAIL_HEADERS)
        self._detail_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._detail_table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._detail_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._detail_table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._detail_table.setWordWrap(False)
        self._detail_table.setTextElideMode(Qt.ElideRight)
        self._detail_table.setMouseTracking(True)
        self._detail_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._detail_table.setSelectionBehavior(QTableWidget.SelectRows)
        self._detail_table.setAlternatingRowColors(True)
        self._detail_table.setStyleSheet(TABLE_STYLE)
        self._detail_table.setFont(QFont("Microsoft YaHei", 10))
        install_long_text_tooltip(self._detail_table)
        self._detail_table.cellDoubleClicked.connect(self._edit_detail)
        self._detail_table.cellEntered.connect(self._on_cell_entered)
        detail_header = self._detail_table.horizontalHeader()
        detail_header.setSectionResizeMode(QHeaderView.Interactive)
        detail_header.setDefaultAlignment(Qt.AlignCenter)
        detail_header.setHighlightSections(False)
        detail_header.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        self._detail_table.verticalHeader().setDefaultSectionSize(30)
        self._detail_table.verticalHeader().setMinimumSectionSize(28)
        for column, width in enumerate(self.DETAIL_WIDTHS):
            self._detail_table.setColumnWidth(column, width)
        detail_layout.addWidget(self._detail_table, 1)

        splitter = QSplitter(Qt.Vertical)
        splitter.setChildrenCollapsible(False)
        splitter.addWidget(self._table)
        splitter.addWidget(detail_container)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        layout.addWidget(splitter, 1)

        self._management_rate.valueChanged.connect(self._on_default_fee_rate_changed)
        self._profit_rate.valueChanged.connect(self._on_default_fee_rate_changed)

        self._load_majors()
        self._render_table()

    @classmethod
    def _normalize_fee_settings(cls, raw: dict | None) -> dict:
        raw = raw or {}
        raw_default = raw.get("default") or {}
        allowed_bases = {value for _, value in FEE_BASE_OPTIONS}
        defaults = {
            "management_base": str(
                raw_default.get("management_base")
                or get_setting("quote_management_base", "direct")
            ),
            "management_rate": cls._fee_rate_value(
                raw_default.get("management_rate"),
                get_setting("quote_management_rate", "5"),
            ),
            "profit_base": str(
                raw_default.get("profit_base")
                or get_setting("quote_profit_base", "direct_management")
            ),
            "profit_rate": cls._fee_rate_value(
                raw_default.get("profit_rate"),
                get_setting("quote_profit_rate", "7"),
            ),
        }
        defaults["management_base"] = (
            defaults["management_base"]
            if defaults["management_base"] in allowed_bases
            else "direct"
        )
        defaults["profit_base"] = (
            defaults["profit_base"]
            if defaults["profit_base"] in allowed_bases
            else "direct_management"
        )

        groups = {}
        for key, value in (raw.get("groups") or {}).items():
            if not key or key == "default" or not isinstance(value, dict):
                continue
            management_base = str(
                value.get("management_base") or defaults["management_base"]
            )
            profit_base = str(value.get("profit_base") or defaults["profit_base"])
            if management_base not in allowed_bases:
                management_base = "direct"
            if profit_base not in allowed_bases:
                profit_base = "direct_management"
            groups[str(key)] = {
                "management_base": management_base,
                "management_rate": cls._fee_rate_value(
                    value.get("management_rate"),
                    defaults["management_rate"],
                ),
                "profit_base": profit_base,
                "profit_rate": cls._fee_rate_value(
                    value.get("profit_rate"),
                    defaults["profit_rate"],
                ),
            }
        return {"default": defaults, "groups": groups}

    @staticmethod
    def _fee_rate_value(value, fallback) -> float:
        if value in (None, ""):
            return float(fallback)
        try:
            return max(0.0, min(100.0, float(value)))
        except (TypeError, ValueError):
            return float(fallback)

    def _serialized_fee_settings(self) -> dict:
        return {
            "default": dict(self._fee_settings.get("default") or {}),
            "groups": {
                key: dict(value)
                for key, value in self._fee_settings.get("groups", {}).items()
            },
        }

    def _sync_fee_controls_from_settings(self):
        default = self._fee_settings.get("default") or {}
        self._management_rate.blockSignals(True)
        self._profit_rate.blockSignals(True)
        try:
            self._management_rate.setValue(float(default.get("management_rate", 5)))
            self._profit_rate.setValue(float(default.get("profit_rate", 7)))
        finally:
            self._management_rate.blockSignals(False)
            self._profit_rate.blockSignals(False)

    def _on_default_fee_rate_changed(self, *_):
        default = self._fee_settings.setdefault("default", {})
        default["management_rate"] = self._management_rate.value()
        default["profit_rate"] = self._profit_rate.value()
        self._recalculate_matched_rows()

    def _persist_fee_settings(self) -> bool:
        default = self._fee_settings.get("default") or {}
        try:
            set_settings({
                "quota_fee_settings": json.dumps(
                    self._serialized_fee_settings(), ensure_ascii=False
                ),
                "quote_management_rate": str(default.get("management_rate", 5)),
                "quote_profit_rate": str(default.get("profit_rate", 7)),
                "quote_management_base": str(default.get("management_base", "direct")),
                "quote_profit_base": str(default.get("profit_base", "direct_management")),
            })
            return True
        except Exception:
            return False

    @staticmethod
    def _row_fee_group(row: dict) -> str:
        raw = str(row.get("fee_group") or row.get("source_tab") or "").strip()
        if not raw:
            return "未分项清单"
        raw = re.sub(r"^[\d_]+\s*", "", raw)
        raw = re.sub(r"^(F\.?\d*\s*|表[\d\.\-]+\s*)", "", raw, flags=re.I)
        raw = raw.replace("表10_2_2-16", "").strip(" _-")
        if "施工技术措施" in raw:
            return "施工技术措施项目"
        if "分部分项" in raw:
            return "分部分项工程"
        if "单价措施" in raw:
            return "单价措施项目"
        if "措施项目" in raw:
            return "措施项目"
        raw = re.sub(r"(清单与计价表|清单和计价表|项目清单|计价表)$", "", raw).strip(" _-")
        return raw or "未分项清单"

    def _fee_group_names(self) -> list[str]:
        names = []
        for row in self._rows:
            group = self._row_fee_group(row)
            if group not in names:
                names.append(group)
        return names

    def _fee_settings_for_row(self, row: dict) -> dict:
        group = self._row_fee_group(row)
        settings = dict(self._fee_settings.get("default") or {})
        settings.update(self._fee_settings.get("groups", {}).get(group) or {})
        return settings

    def _adjust_row_fee_group(self):
        row = self._current_boq_row()
        if row is None:
            QMessageBox.information(
                self,
                "未选择清单",
                "请先在上方选择一条需要调整取费归属的清单。",
            )
            return
        auto_label = "自动识别（按来源表）"
        current_group = self._row_fee_group(row)
        group_names = self._fee_group_names()
        options = [auto_label, *group_names]
        current_index = 0 if not row.get("fee_group") else options.index(current_group)
        selected, ok = QInputDialog.getItem(
            self,
            "调整取费归属",
            "选择该清单所属的取费分部，或输入新的分部：",
            options,
            current_index,
            True,
        )
        if not ok or not selected.strip():
            return
        selected = selected.strip()
        if selected == auto_label:
            row.pop("fee_group", None)
            assigned = self._row_fee_group(row)
            message = "已恢复自动识别"
        else:
            row["fee_group"] = selected
            assigned = selected
            message = f"已调整到“{assigned}”"
        if row.get("compositions"):
            self._calculate_row_from_compositions(row)
        self._render_table()
        if self._rows and not self._save_results(show_message=False):
            self._save_pending_draft()
        self._stats_label.setText(f"{row.get('seq', '')} {message}")
        self.data_changed.emit()
        QMessageBox.information(
            self,
            "取费归属",
            f"{row.get('seq', '')} {message}。",
        )

    @staticmethod
    def _fee_base_amount(
        code: str, labor: float, material: float, machinery: float, management: float = 0.0
    ) -> float:
        direct = labor + material + machinery
        bases = {
            "labor": labor,
            "labor_material": labor + material,
            "labor_machine": labor + machinery,
            "direct": direct,
            "labor_machine_management": labor + machinery + management,
            "direct_management": direct + management,
        }
        return bases.get(code or "direct", direct)

    @staticmethod
    def _fee_base_label(code: str) -> str:
        return FEE_BASE_LABELS.get(code, "人工费+材料费+机械费")

    def _open_fee_settings(self):
        dialog = FeeSettingsDialog(
            self._serialized_fee_settings(),
            self._fee_group_names(),
            self,
        )
        if dialog.exec() != QDialog.Accepted:
            return
        self._fee_settings = self._normalize_fee_settings(dialog.values())
        self._sync_fee_controls_from_settings()
        persisted = self._persist_fee_settings()
        self._recalculate_matched_rows()
        if self._rows and not self._save_results(show_message=False):
            self._save_pending_draft()
        self._render_table()
        if not persisted:
            QMessageBox.warning(
                self,
                "取费设置保存失败",
                "当前设置已在本次计算中生效，但未能写入本地配置。",
            )
            return
        QMessageBox.information(
            self,
            "取费设置",
            "取费设置已保存"
            + ("，并已按当前清单重新计算。" if self._rows else "。"),
        )

    def show_route(self, route_key: str):
        self.refresh_data()

    def refresh_data(self):
        self._load_majors()
        active_project_id = self._active_project_id()
        if active_project_id != self._current_project_id:
            self._invalidate_async_generation()
            self._rows = []
            self._source_file = ""
            self._source_format = ""
            self._loaded_saved_result = False
            self._current_project_id = active_project_id
            self._fee_settings = self._normalize_fee_settings(None)
            self._sync_fee_controls_from_settings()
        if not self._rows and not self._loaded_saved_result:
            self._load_saved_results()
        if not self._rows and not self._loaded_saved_result:
            self._load_pending_draft()
        # Backfill the BOQ unit for legacy saved compositions and re-run the
        # guarded calculation so incompatible units cannot remain priced as 1.
        for row in self._rows:
            if not row.get("compositions"):
                continue
            for detail in row.get("compositions") or []:
                detail.setdefault("boqUnit", row.get("unit", ""))
            self._calculate_row_from_compositions(row)
        self._render_table()

    def _active_project_id(self) -> int:
        try:
            return int(get_setting("active_project_id", "0") or 0)
        except (TypeError, ValueError):
            return 0

    def _prompt_select_project(self, action: str):
        dialog = QMessageBox(self)
        dialog.setIcon(QMessageBox.Information)
        dialog.setWindowTitle("未选择项目")
        dialog.setText(f"使用{action}前，需要先选择当前项目。")
        dialog.setInformativeText("项目地区、计价日期和专业会作为匹配及市场估算依据。")
        go_button = dialog.addButton("前往项目信息", QMessageBox.AcceptRole)
        dialog.addButton("取消", QMessageBox.RejectRole)
        dialog.exec()
        if dialog.clickedButton() is go_button:
            self.navigate_requested.emit("project_info")

    @staticmethod
    def _row_quota_count(row: dict) -> int:
        formal_ids = list(dict.fromkeys(row.get("quota_ids") or []))
        # The persisted contract is one formal winner or one generated result.
        # Cap this display/counting helper as well, so a legacy row cannot show
        # or export a misleading multi-quota count before it is normalized.
        return min(len(formal_ids), 1) + (1 if row.get("generated_quota") and not formal_ids else 0)

    @classmethod
    def _row_has_result_payload(cls, row: dict) -> bool:
        """Return whether a row contains a result that can affect pricing."""
        return bool(
            row.get("quota_id")
            or row.get("quota_ids")
            or row.get("generated_quota")
            or row.get("compositions")
            or row.get("ai_generated")
        )

    @classmethod
    def _row_result_is_current(cls, row: dict) -> bool:
        """Check the row-level result contract, independent of payload version."""
        if not cls._row_has_result_payload(row):
            return True
        return bool(
            _text(row.get("row_result_algorithm_version"))
            == cls.MATCHING_ALGORITHM_VERSION
            and _text(row.get("row_result_schema")) == cls.ROW_RESULT_SCHEMA
        )

    @classmethod
    def _row_input_key(cls, row: dict) -> str:
        """Stable identity for the BOQ inputs used by an async operation."""
        payload = {
            "code": _text(row.get("code")),
            "name": _text(row.get("name")),
            "feature": _text(row.get("feature")),
            "unit": _text(row.get("unit")),
            "quantity": _text(row.get("quantity")),
            "major": _text(row.get("major")),
        }
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _mark_row_result_current(self, row: dict, pipeline: str = "") -> None:
        """Stamp a calculated row so only current-process results are payable."""
        row["row_result_algorithm_version"] = self.MATCHING_ALGORITHM_VERSION
        row["row_result_schema"] = self.ROW_RESULT_SCHEMA
        row["row_result_pipeline"] = _text(pipeline or row.get("row_result_pipeline") or "calculation")
        row["row_result_at"] = time.time()
        row.pop("needs_rematch", None)

    def _invalidate_async_generation(self) -> int:
        self._match_generation += 1
        self._pending_ai_results.clear()
        self._ai_cache_key_pending = ""
        self._ai_fallback_indexes = []
        return self._match_generation

    def _async_result_is_current(self, item: dict, row_index: int, boq: dict | None = None) -> bool:
        """Reject late AI callbacks after project/import/row context changes."""
        if not isinstance(item, dict):
            return False
        if item.get("project_id") not in (None, "", self._active_project_id()):
            try:
                if int(item.get("project_id") or 0) != self._active_project_id():
                    return False
            except (TypeError, ValueError):
                return False
        generation = item.get("match_generation", item.get("_match_generation"))
        if generation not in (None, ""):
            try:
                if int(generation) != self._match_generation:
                    return False
            except (TypeError, ValueError):
                return False
        if not (0 <= row_index < len(self._rows)):
            return False
        expected = _text(item.get("row_input_key") or item.get("_row_input_key"))
        source = boq or item.get("boq") or {}
        if expected and expected != self._row_input_key(self._rows[row_index]):
            return False
        if source and expected and expected != self._row_input_key(source):
            return False
        return True

    @classmethod
    def _row_is_matched(cls, row: dict) -> bool:
        if row.get("needs_rematch"):
            return False
        # Rows loaded from disk are checked in _apply_saved_payload. Keep the
        # fallback for hand-built in-memory rows used by imports/tests.
        if any(row.get(key) for key in ("row_result_algorithm_version", "row_result_schema")) and not cls._row_result_is_current(row):
            return False
        coverage = row.get("category_coverage") or {}
        if coverage and (coverage.get("missing") or coverage.get("reference_only")):
            return False
        return cls._row_quota_count(row) > 0 or bool(row.get("quota_id"))

    @classmethod
    def _source_items_for_backfill(cls, source_file: str) -> list[dict]:
        """Read source BOQ prices for legacy saved rows without changing import behavior."""
        path = Path(source_file)
        if not path.exists():
            return []
        try:
            if path.suffix.lower() != ".xls":
                from src.bill_list_extractor import extract_specialized_bill_list

                extracted = extract_specialized_bill_list(str(path))
                if extracted is not None:
                    return list(extracted.get("items") or [])
            sheets = read_excel_sheets(path)
            return cls._extract_generic_items(sheets, lambda sheet: sheet[1])
        except Exception:
            # Saved rows may refer to a deleted, renamed, or invalid legacy
            # workbook. Backfill is optional and must never block reopening a
            # project or make the whole matching page fail.
            return []

    @classmethod
    def _backfill_saved_source_prices(cls, rows: list[dict], source_file: str) -> bool:
        """Fill only missing source fields from the original workbook."""
        items = cls._source_items_for_backfill(source_file)
        if not items:
            return False
        by_code = {}
        by_name_unit = {}
        by_code_name_unit = {}
        for item in items:
            code = cls._cell_text([item.get("code")], 0)
            name = cls._cell_text([item.get("name")], 0)
            unit = cls._cell_text([item.get("unit")], 0)
            if code:
                by_code.setdefault(code, []).append(item)
            if name:
                by_name_unit.setdefault((name, unit), []).append(item)
            if code and name:
                by_code_name_unit.setdefault((code, name, unit), []).append(item)
        changed = False
        source_fields = ("comprehensive_price", "total_price", "labor", "material", "machinery", "management", "profit")
        for row in rows:
            code = cls._cell_text([row.get("code")], 0)
            name = cls._cell_text([row.get("name")], 0)
            unit = cls._cell_text([row.get("unit")], 0)
            candidates = by_code_name_unit.get((code, name, unit), []) if code else []
            if len(candidates) != 1 and code:
                candidates = by_code.get(code, [])
            if len(candidates) != 1:
                candidates = by_name_unit.get((name, unit), [])
            if len(candidates) != 1:
                continue
            item = candidates[0]
            for field in source_fields:
                value = cls._cell_text([item.get(field)], 0)
                if not value:
                    continue
                source_key = {
                    "comprehensive_price": "source_comprehensive_price",
                    "total_price": "source_total_price",
                }.get(field, field)
                imported_key = f"imported_{field}"
                if not row.get(source_key):
                    row[source_key] = value
                    changed = True
                if not row.get(imported_key):
                    row[imported_key] = value
                    changed = True
                legacy_result = (
                    cls._row_has_result_payload(row)
                    and not cls._row_result_is_current(row)
                )
                if (not cls._row_is_matched(row) or legacy_result) and not row.get(field):
                    row[field] = value
                    changed = True
            if not row.get("source_tab") and item.get("source_tab"):
                row["source_tab"] = str(item["source_tab"])
                changed = True
        return changed

    def _apply_saved_payload(self, payload: dict, project_id: int = 0):
        # Replacing the table invalidates every callback tied to the previous
        # payload, even when the project id itself did not change.
        self._invalidate_async_generation()
        loaded_rows = payload.get("rows") or []
        from src.bill_list_extractor import boq_item_rejection_reason, normalized_boq_feature
        self._rows = []
        self._last_generic_rejections = {}
        for row in loaded_rows:
            if not isinstance(row, dict):
                continue
            reason = boq_item_rejection_reason(
                name=row.get("name"), feature=row.get("feature"), unit=row.get("unit"),
                quantity=row.get("quantity"), code=row.get("code"), require_quantity=True,
            )
            if reason:
                self._last_generic_rejections[reason] = self._last_generic_rejections.get(reason, 0) + 1
                continue
            row["feature"] = normalized_boq_feature(
                row.get("name"), row.get("feature"), row.get("code"),
            )
            self._rows.append(row)
        self._source_file = payload.get("source_file") or ""
        self._source_format = payload.get("source_format") or ""
        self._import_major = _text(payload.get("import_major") or "")
        # Recover source-price evidence before clearing an old result. The
        # subsequent reset keeps that evidence in source_* fields and removes
        # it from the current calculated columns.
        backfilled = self._backfill_saved_source_prices(self._rows, self._source_file)
        saved_algorithm_version = _text(payload.get("matching_algorithm_version"))
        saved_result_schema = _text(payload.get("result_schema"))
        stale_result = (
            saved_algorithm_version != self.MATCHING_ALGORITHM_VERSION
            or saved_result_schema != self.RESULT_SCHEMA
        )
        for row in self._rows:
            if isinstance(row, dict):
                self._normalize_import_unit_quantity(row)
                row_result_stale = (
                    self._row_has_result_payload(row)
                    and not self._row_result_is_current(row)
                )
                if stale_result or row_result_stale:
                    # Keep the imported BOQ and source-price evidence, but do
                    # not let an older matcher remain payable after reopening.
                    self._reset_row_match(row)
                    row["ai_result_cache"] = {}
                    row["matching_algorithm_version"] = self.MATCHING_ALGORITHM_VERSION
                    row["result_schema"] = self.RESULT_SCHEMA
                    row["needs_rematch"] = True
                    invalidation_reason = (
                        "检测到旧版本匹配结果，已失效；请按当前算法重新匹配"
                        if stale_result
                        else "检测到清单行缺少当前结果版本标记，旧匹配结果已失效；请重新匹配"
                    )
                    row["note"] = "；".join(
                        value for value in (
                            row.get("imported_note"),
                            invalidation_reason,
                        ) if value
                    )
                else:
                    self._purge_stale_ai_cache(row)
                    row.setdefault(
                        "matching_algorithm_version",
                        self.MATCHING_ALGORITHM_VERSION,
                    )
                    row.setdefault("result_schema", self.RESULT_SCHEMA)
        if self._import_major:
            index = self._major.findData(self._import_major)
            if index >= 0:
                self._major.setCurrentIndex(index)
        worker = getattr(self, "_ai_fallback_worker", None)
        has_live_fallback_worker = bool(worker is not None and worker.isRunning())
        stale_pending_cleared = False
        if not has_live_fallback_worker:
            self._ai_fallback_indexes = []
            self._ai_fallback_total = 0
            self._ai_fallback_completed = 0
            self._ai_fallback_applied = 0
            self._ai_fallback_failed = 0
            self._update_ai_fallback_progress()
            # A process can close after saving a row while the remaining rows
            # still carry the old pending flag. Do not resurrect that flag on
            # the next launch when there is no worker able to finish it.
            for row in self._rows:
                if not row.get("ai_fallback_pending"):
                    continue
                row["ai_fallback_pending"] = False
                stale_pending_cleared = True
                if _text(row.get("note")) == "本地定额未找到，已排队后台AI兜底匹配":
                    row["note"] = "上次AI兜底任务未完成，当前仍未匹配；可重新发起AI兜底匹配"
        management_rate = payload.get("management_rate")
        profit_rate = payload.get("profit_rate")
        match_threshold = payload.get("match_threshold")
        if payload.get("fee_settings"):
            self._fee_settings = self._normalize_fee_settings(payload.get("fee_settings"))
        else:
            self._fee_settings = self._normalize_fee_settings(None)
            if management_rate is not None:
                self._fee_settings["default"]["management_rate"] = float(management_rate)
            if profit_rate is not None:
                self._fee_settings["default"]["profit_rate"] = float(profit_rate)
        self._sync_fee_controls_from_settings()
        saved_priority = payload.get("price_priority")
        if saved_priority:
            priority_index = self._price_priority.findData(str(saved_priority))
            if priority_index >= 0:
                self._price_priority.blockSignals(True)
                self._price_priority.setCurrentIndex(priority_index)
                self._price_priority.blockSignals(False)
        for row in self._rows:
            normalize_quota_row_matches(row)
            if row.get("compositions"):
                self._calculate_row_from_compositions(row)
        if match_threshold is not None:
            index = self._match_level.findData(int(match_threshold))
            if index >= 0:
                self._match_level.setCurrentIndex(index)
        selected = set(payload.get("selected_categories") or self.EXPENSE_CATEGORIES)
        for category, checkbox in self._category_checks.items():
            checkbox.setChecked(category in selected)
        self._loaded_saved_result = bool(self._rows)
        self._stale_result_invalidated = stale_result
        if project_id:
            self._current_project_id = project_id
        if (backfilled or stale_pending_cleared or stale_result) and project_id:
            self._save_results(show_message=False)

    def _load_saved_results(self):
        project_id = self._active_project_id()
        if not project_id:
            return
        session = get_session()
        try:
            saved = (
                session.query(ProjectQuotaMatch)
                .filter(ProjectQuotaMatch.project_id == project_id)
                .order_by(ProjectQuotaMatch.updated_at.desc(), ProjectQuotaMatch.id.desc())
                .first()
            )
            if saved is None or not saved.data_json:
                return
            payload = json.loads(saved.data_json)
            if isinstance(payload, dict):
                payload.setdefault("source_file", saved.source_file or "")
                self._apply_saved_payload(payload, project_id)
        except (TypeError, ValueError, json.JSONDecodeError):
            return
        finally:
            session.close()

    def _payload(self) -> dict:
        return {
            "matching_algorithm_version": self.MATCHING_ALGORITHM_VERSION,
            "result_schema": self.RESULT_SCHEMA,
            "rows": self._rows,
            "source_file": self._source_file,
            "source_format": self._source_format,
            "management_rate": self._management_rate.value(),
            "profit_rate": self._profit_rate.value(),
            "fee_settings": self._serialized_fee_settings(),
            "price_priority": self._price_priority.currentData() or "quota",
            "match_threshold": int(self._match_level.currentData() or 60),
            "selected_categories": sorted(self._selected_categories()),
            "import_major": getattr(self, "_import_major", ""),
        }

    def _save_pending_draft(self):
        if not self._rows:
            return False
        try:
            set_settings({
                "quota_match_pending_draft": json.dumps(
                    self._payload(), ensure_ascii=False
                ),
            })
            return True
        except Exception:
            return False

    @staticmethod
    def _clear_pending_draft():
        try:
            set_settings({"quota_match_pending_draft": ""})
        except Exception:
            pass

    def _load_pending_draft(self):
        raw = get_setting("quota_match_pending_draft", "")
        if not raw:
            return
        try:
            payload = json.loads(raw)
            if not isinstance(payload, dict) or not payload.get("rows"):
                return
            project_id = self._active_project_id()
            self._apply_saved_payload(payload, project_id)
            if project_id and self._save_results(show_message=False):
                self._clear_pending_draft()
        except (TypeError, ValueError, json.JSONDecodeError):
            return

    def _persist_after_import(self) -> bool:
        """Save imported rows immediately so closing the app cannot discard them."""
        if self._save_results(show_message=False):
            return True
        return self._save_pending_draft()

    def persist_state(self):
        """Called by the main window during shutdown."""
        if not self._rows:
            return
        if not self._save_results(show_message=False):
            self._save_pending_draft()

    def _save_results(self, show_message: bool = True):
        if not self._rows:
            if show_message:
                QMessageBox.information(self, "没有组价结果", "请先导入清单并完成匹配。")
            return False
        project_id = self._active_project_id()
        if not project_id:
            if show_message:
                self._prompt_select_project("保存组价")
            return False
        session = get_session()
        try:
            project = session.query(Project).filter(Project.id == project_id).first()
            if project is None:
                if show_message:
                    QMessageBox.warning(self, "保存失败", "当前项目不存在，请重新选择项目。")
                return False
            # Normalize and recalculate immediately before persistence. This is
            # the final boundary for results restored from an old snapshot,
            # manually edited rows, or late AI callbacks: one row can never
            # save multiple formal quotas or stale losing components.
            for row in self._rows:
                normalize_quota_row_matches(row)
                if row.get("compositions"):
                    self._calculate_row_from_compositions(row)
            matched_rows = sum(1 for row in self._rows if self._row_is_matched(row))
            quota_count = sum(self._row_quota_count(row) for row in self._rows)
            saved = (
                session.query(ProjectQuotaMatch)
                .filter(ProjectQuotaMatch.project_id == project_id)
                .order_by(ProjectQuotaMatch.id.desc())
                .first()
            )
            if saved is None:
                saved = ProjectQuotaMatch(project_id=project_id)
                session.add(saved)
            saved.source_file = self._source_file
            saved.data_json = json.dumps(self._payload(), ensure_ascii=False)
            saved.total_rows = len(self._rows)
            saved.matched_rows = matched_rows
            saved.quota_count = quota_count
            project.total_amount = sum(
                _numeric(row.get("comprehensive_price"))
                * _numeric(row.get("quantity"))
                for row in self._rows
                if self._row_is_matched(row)
            )
            if project.status == "draft" and self._rows:
                project.status = "doing"
            session.flush()
            write_audit(session, "update", "project_quota_match", saved.id, f"保存项目定额匹配: {project.name}")
            session.commit()
            self._clear_pending_draft()
            self._loaded_saved_result = True
            if show_message:
                QMessageBox.information(self, "保存完成", f"已保存“{project.name}”的 {len(self._rows)} 条清单组价结果。")
            return True
        except Exception as error:
            session.rollback()
            if show_message:
                QMessageBox.warning(self, "保存失败", str(error))
            return False
        finally:
            session.close()

    def _save_results_clicked(self):
        self._save_results(show_message=True)

    def _load_majors(self):
        selected = self._major.currentData() if self._major.count() else ""
        session = get_session()
        try:
            majors = list_quota_majors(session)
            counts = quota_composition_category_counts(session, selected or "")
        finally:
            session.close()
        custom_majors = []
        try:
            raw_custom = json.loads(get_setting("quota_custom_majors", "[]") or "[]")
            if isinstance(raw_custom, list):
                custom_majors = [str(value).strip() for value in raw_custom if str(value).strip()]
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
        majors = list(dict.fromkeys([*majors, *custom_majors]))
        self._major.blockSignals(True)
        self._major.clear()
        self._major.addItem("全部专业", "")
        for major in majors:
            self._major.addItem(major, major)
        index = self._major.findData(selected)
        self._major.setCurrentIndex(max(index, 0))
        self._major.blockSignals(False)
        for category, checkbox in self._category_checks.items():
            checkbox.setText(f"{category} ({counts.get(category, 0):,})")

    def _add_custom_major(self):
        value, ok = QInputDialog.getText(self, "新增定额专业", "专业名称:")
        value = _text(value)
        if not ok or not value:
            return
        try:
            raw = json.loads(get_setting("quota_custom_majors", "[]") or "[]")
            majors = [str(item).strip() for item in raw] if isinstance(raw, list) else []
        except (TypeError, ValueError, json.JSONDecodeError):
            majors = []
        if value not in majors:
            majors.append(value)
            set_settings({"quota_custom_majors": json.dumps(majors, ensure_ascii=False)})
        self._load_majors()
        index = self._major.findData(value)
        if index >= 0:
            self._major.setCurrentIndex(index)

    def _choose_import_major(self):
        session = get_session()
        try:
            majors = list_quota_majors(session)
        finally:
            session.close()
        try:
            raw = json.loads(get_setting("quota_custom_majors", "[]") or "[]")
            if isinstance(raw, list):
                majors.extend(str(item).strip() for item in raw if str(item).strip())
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
        majors = list(dict.fromkeys(majors))
        choices = ["全部专业（不限定方向）", *majors]
        current = self._major.currentData() or ""
        current_index = majors.index(current) + 1 if current in majors else 0
        selected, ok = QInputDialog.getItem(
            self, "选择清单匹配专业", "本次导入清单的定额匹配方向：",
            choices, current_index, True,
        )
        if not ok:
            return None
        selected = _text(selected)
        if not selected or selected.startswith("全部专业"):
            return ""
        if selected not in majors:
            try:
                raw = json.loads(get_setting("quota_custom_majors", "[]") or "[]")
                custom = [str(item).strip() for item in raw] if isinstance(raw, list) else []
            except (TypeError, ValueError, json.JSONDecodeError):
                custom = []
            if selected not in custom:
                custom.append(selected)
                set_settings({"quota_custom_majors": json.dumps(custom, ensure_ascii=False)})
        return selected

    def _update_match_rule_label(self):
        threshold = int(self._match_level.currentData() or 60)
        self._match_rule_label.setText(
            f"主体≥{threshold}%，补充工序≥{threshold + 8}%；低置信度需复核"
        )

    def _on_source_region_changed(self, value: str):
        self._source_region = (
            ""
            if getattr(self, "_source_region_input", None) is not None
            and self._source_region_input.currentIndex() == 0
            else _text(value)
        )
        set_settings({"quota_source_region": self._source_region})

    def _selected_source_region(self) -> str:
        if not hasattr(self, "_source_region_input"):
            return ""
        if self._source_region_input.currentIndex() == 0:
            return ""
        return _text(self._source_region_input.currentText())

    @staticmethod
    def _local_match_rejection_reason(matches: list[dict]) -> str:
        """Reject only when the *primary* local quota is unsafe.

        Each BOQ row may contain several independently matched work clauses.
        A weak supplemental material/process must not invalidate an otherwise
        usable primary quota. The previous implementation inspected every
        result and cleared the complete row when any supplemental result was
        red, which made the 60% matching level behave like "match nothing".
        """
        values = list(matches or [])
        if not values:
            # An empty local result is a normal path to the base-data/AI
            # fallback. It is not itself a rejection of a candidate.
            return ""

        primary = next(
            (
                match for match in values
                if str(match.get("role") or "").strip().startswith("主体")
            ),
            None,
        )
        if primary is None:
            primary = values[0]

        evidence = str(primary.get("evidence_level") or "").lower()
        reason_text = " ".join(str(value or "") for value in (
            *(primary.get("reasons") or []),
            primary.get("role"),
        ))
        weak_reasons = []
        if primary.get("component_only"):
            weak_reasons.append("本地主体结果仅命中材料组成，未命中完整工程对象")
        if evidence == "red":
            weak_reasons.append("本地主体结果为低证据替补")
        if any(token in reason_text for token in ("低相似度", "低相似", "替补")):
            weak_reasons.append("本地主体结果包含低相似度替补")
        return "；".join(dict.fromkeys(weak_reasons))

    @staticmethod
    def _local_match_supplement_warning(matches: list[dict]) -> str:
        """Describe weak supplemental matches without discarding the primary."""
        values = list(matches or [])
        primary = next(
            (
                match for match in values
                if str(match.get("role") or "").strip().startswith("主体")
            ),
            values[0] if values else None,
        )
        warnings = []
        for match in values:
            if match is primary:
                continue
            evidence = str(match.get("evidence_level") or "").lower()
            reason_text = " ".join(str(value or "") for value in (
                *(match.get("reasons") or []),
                match.get("role"),
            ))
            if match.get("component_only") or evidence == "red" or any(
                token in reason_text for token in ("低相似度", "低相似", "替补", "材料组成")
            ):
                warnings.append(
                    f"{match.get('source_clause') or match.get('role') or '补充项'}需AI核对"
                )
        if not warnings:
            return ""
        return "本地主体已按当前挡位保留；" + "、".join(dict.fromkeys(warnings))

    def _should_ai_review_batch(self, row: dict, matches: list[dict]) -> tuple[bool, list[str]]:
        """Trigger AI only for materially risky local matches.

        A good local result remains fast. AI is required when the row has
        multiple work clauses, explicit specifications, unit conversion,
        missing cost categories, competing candidates, low evidence, or a
        material price deviation. This makes AI a fixed quality gate instead
        of an arbitrary percentage switch.
        """
        reasons = []
        score = float(row.get("score") or 0)
        if score < 0.75:
            reasons.append(f"本地匹配置信度{score:.0%}低于75%")
        if len(matches) > 1:
            reasons.append("存在多个主体/补充工序候选")
        feature = _text(row.get("feature"))
        if len(re.findall(r"(?:^|\n|[；;。])\s*(?:\d+[、.．]|[一二三四五六七八九十]+[、.．])", feature)) >= 2:
            reasons.append("项目特征包含多个工作内容条款")
        if any(_text(term) in f"{row.get('name', '')}{feature}" for term in self.KEY_SPECIFICATION_TERMS):
            reasons.append("清单含明确规格/参数，需要AI核对")
        if any(detail.get("conversionRequired") for detail in row.get("compositions") or [] if detail.get("included", True)):
            reasons.append("存在单位换算或含量计算")
        coverage = cost_category_coverage(
            row.get("name", ""), feature, row.get("compositions") or [],
            source_costs=self._source_costs(row), fee_details=row.get("fee_details") or [],
        )
        if coverage.get("missing"):
            reasons.append("人材机或管利类别存在缺失")
        if material_coverage_gaps(row.get("name", ""), feature, row.get("compositions") or []):
            reasons.append("清单明确材料未被组成覆盖")
        if row.get("audit_issues") or row.get("ai_validation_failed"):
            reasons.append("本地规则发现待复核问题")
        if row.get("evidence_level") in {"red", "yellow"}:
            reasons.append("价格或来源证据不足")
        if row.get("price_deviation_rate") not in (None, "") and _numeric(row.get("price_deviation_rate")) >= 0.20:
            reasons.append("套定额计算价与原表价格偏差较大")
        return bool(reasons), list(dict.fromkeys(reasons))

    @staticmethod
    def _machine_labor_review_issue(row: dict) -> str:
        """Detect machine work whose manual coordination is not represented.

        A machine shift may include its driver, but that does not cover manual
        trimming, bottom cleaning, signalling, spreading, or backfill support.
        This check never invents a labor quantity; it blocks a false "complete"
        result and sends the row to the normal review/AI completion flow.
        """
        machine_details = []
        has_labor = False
        for detail in row.get("compositions") or []:
            if not detail.get("included", True):
                continue
            category = str(detail.get("cat") or detail.get("category") or "")
            if category == "人工费":
                has_labor = True
            elif category == "机械费":
                machine_details.append(detail)
        if not machine_details or has_labor:
            return ""
        evidence = []
        for detail in machine_details:
            evidence.extend(labor_coordination_evidence(
                detail.get("name", ""), detail.get("feature", ""),
            ))
        row_text = f"{row.get('name', '')} {row.get('feature', '')}"
        if not evidence and any(term in row_text for term in (
            "土方开挖", "土方回填", "沟槽开挖", "基坑开挖", "路床整形", "压实碾压",
        )):
            evidence.append("土方/路基机械施工配合")
        if not evidence:
            return ""
        terms = "、".join(dict.fromkeys(evidence))
        return (
            f"机械定额工作内容明确包含{terms}，但当前组价未发现人工费；"
            "请核对台班单价是否已含司机，并补齐清底、修坡、指挥或回填配合等必要人工，"
            "未完成核查前不得标记为可靠报价"
        )

    def _row_status(self, row: dict) -> str:
        if self._row_has_hard_block(row):
            return "blocked"
        if row.get("audit_issues"):
            return "review"
        if row.get("ai_generated"):
            return "ai"
        if self._row_is_matched(row) and str(row.get("evidence_level") or "").lower() in {"yellow", "red"}:
            return "candidate"
        if self._row_is_matched(row):
            return "matched"
        return "unmatched"

    @staticmethod
    def _row_has_hard_block(row: dict) -> bool:
        """Return true when a result must not be treated as a payable quote."""
        if any(row.get(field) for field in (
            "ai_validation_failed",
            "blocked_by_logic",
            "blocked_by_major",
            "blocked_by_unit_conversion",
        )):
            return True
        for detail in row.get("compositions") or []:
            if any(detail.get(field) for field in (
                "blockedByLogic",
                "blockedByUnitConversion",
                "blockedByQuantity",
            )):
                return True
        return False

    def _on_status_filter_changed(self):
        self._apply_status_filter(clear_selection=True)

    def _apply_status_filter(self, clear_selection: bool = True):
        status = self._status_filter.currentData() or "all"
        if self._table.rowCount() != len(self._rows):
            return
        if clear_selection:
            self._table.clearSelection()
        for row_index, row in enumerate(self._rows):
            row_status = self._row_status(row)
            visible = status == "all" or row_status == status
            self._table.setRowHidden(row_index, not visible)

    def _visible_row_indexes(self) -> list[int]:
        return [
            row_index
            for row_index in range(self._table.rowCount())
            if not self._table.isRowHidden(row_index)
        ]

    def _select_unmatched(self):
        self._table.clearSelection()
        selected = 0
        selection = self._table.selectionModel()
        for row_index in self._visible_row_indexes():
            if self._row_status(self._rows[row_index]) == "unmatched":
                index = self._table.model().index(row_index, 0)
                selection.select(
                    index,
                    QItemSelectionModel.Select | QItemSelectionModel.Rows,
                )
                selected += 1
        if not selected:
            QMessageBox.information(self, "没有未匹配清单", "当前筛选范围内没有未匹配的清单。")
        self._stats_label.setText(f"已选择 {selected} 条未匹配清单")

    @classmethod
    def _row_from_import_item(cls, item: dict, position: int, major: str = "") -> dict:
        costs = list(item.get("costs") or ())
        costs.extend([None] * (5 - len(costs)))
        for cost_index, field in enumerate(("labor", "material", "machinery", "management", "profit")):
            if costs[cost_index] in (None, "") and item.get(field) not in (None, ""):
                costs[cost_index] = item.get(field)
        name = cls._cell_text([item.get("name")], 0)
        source_feature = cls._cell_text([item.get("feature")], 0)
        feature = source_feature or name
        imported_note = cls._cell_text([item.get("note")], 0)
        if not source_feature and name:
            imported_note = "；".join(
                value for value in (imported_note, "原表未提供项目特征/工作内容，已使用工程名称作为匹配依据")
                if value
            )
        row = {
            "seq": cls._cell_text([item.get("seq") or position], 0),
            "major": cls._cell_text([item.get("major") or major], 0),
            "code": cls._cell_text([item.get("code")], 0),
            "name": name,
            "feature": feature,
            "unit": cls._cell_text([item.get("unit")], 0),
            "quantity": cls._cell_text([item.get("quantity")], 0),
            "analysis": cls._cell_text([item.get("analysis")], 0),
            "comprehensive_price": cls._cell_text([item.get("comprehensive_price")], 0),
            "total_price": cls._cell_text([item.get("total_price")], 0),
            "labor": cls._cell_text([costs[0]], 0),
            "material": cls._cell_text([costs[1]], 0),
            "machinery": cls._cell_text([costs[2]], 0),
            "management": cls._cell_text([costs[3]], 0),
            "profit": cls._cell_text([costs[4]], 0),
            "note": imported_note,
            "quota_id": None,
            "quota_ids": [],
            "quota_matches": [],
            "score": 0.0,
            "match_reasons": [],
            "compositions": [],
            "source_comprehensive_price": cls._cell_text([item.get("comprehensive_price")], 0),
            "source_total_price": cls._cell_text([item.get("total_price")], 0),
            "calculated_comprehensive_price": "",
            "price_difference": "",
            "price_difference_rate": "",
            "price_deviation_level": "",
            "price_deviation_reason": "",
            "matching_algorithm_version": cls.MATCHING_ALGORITHM_VERSION,
            "result_schema": cls.RESULT_SCHEMA,
        }
        if item.get("source_tab"):
            row["source_tab"] = str(item["source_tab"])
        cls._normalize_import_unit_quantity(row)
        for field in (
            "analysis", "comprehensive_price", "total_price", "labor", "material",
            "machinery", "management", "profit", "note",
        ):
            row[f"imported_{field}"] = row[field]
        return row

    @classmethod
    def _extract_generic_items(cls, worksheets, worksheet_rows) -> list[dict]:
        """Extract BOQ rows from varied Excel layouts without fixed sheet names."""
        from src.bill_list_extractor import (
            boq_item_rejection_reason, normalized_boq_feature,
        )

        imported = {}
        ordered = []
        rejected: dict[str, int] = {}
        cls._last_generic_rejections = rejected
        for worksheet in worksheets:
            rows = [tuple(row) for row in worksheet_rows(worksheet)]
            best = None
            for header_row, values in enumerate(rows[:80]):
                header_block = cls._header_block(rows, header_row)
                indexes = cls._header_indexes_from_rows(header_block)
                if indexes["name"] is None or (indexes["unit"] is None and indexes["quantity"] is None):
                    continue
                score = (
                    2 + (1 if indexes["seq"] is not None else 0)
                    + (2 if indexes["code"] is not None else 0)
                    + (3 if indexes["feature"] is not None else 0)
                    + (2 if indexes["unit"] is not None else 0)
                    + (2 if indexes["quantity"] is not None else 0)
                )
                candidate = (score, -header_row, header_row, indexes)
                if best is None or candidate[:2] > best[:2]:
                    best = candidate
            if best is None:
                continue
            _, _, header_row, indexes = best
            header_block = cls._header_block(rows, header_row)
            feature_indexes = [
                index for index, value in enumerate(cls._header_columns(header_block))
                if any(token in cls._normalized_header(value) for token in ("项目特征", "工作内容", "规格型号"))
            ]
            previous = None
            for values in rows[header_row + 1:]:
                if not any(value not in (None, "") for value in values):
                    continue
                name = cls._cell_text(values, indexes["name"])
                code = cls._cell_text(values, indexes["code"])
                feature_values = [cls._cell_text(values, index) for index in feature_indexes]
                feature = "\n".join(dict.fromkeys(value for value in feature_values if value))
                if not feature:
                    feature = cls._cell_text(values, indexes["feature"])
                unit = cls._cell_text(values, indexes["unit"])
                quantity = cls._cell_text(values, indexes["quantity"])
                if not name and not code and not unit and not quantity and feature and previous:
                    previous["feature"] = "\n".join(
                        value for value in (previous.get("feature", ""), feature) if value
                    )
                    continue
                reason = boq_item_rejection_reason(
                    name=name, feature=feature, unit=unit, quantity=quantity,
                    code=code, require_quantity=True,
                )
                if reason:
                    rejected[reason] = rejected.get(reason, 0) + 1
                    continue
                feature = normalized_boq_feature(name, feature, code)
                item = {
                    "seq": cls._cell_text(values, indexes["seq"]),
                    "code": code, "name": name, "feature": feature,
                    "unit": unit, "quantity": quantity,
                    "analysis": cls._cell_text(values, indexes["analysis"]),
                    "comprehensive_price": cls._cell_text(values, indexes["comprehensive_price"]),
                    "total_price": cls._cell_text(values, indexes["total_price"]),
                    "labor": cls._cell_text(values, indexes["labor"]),
                    "material": cls._cell_text(values, indexes["material"]),
                    "machinery": cls._cell_text(values, indexes["machinery"]),
                    "management": cls._cell_text(values, indexes["management"]),
                    "profit": cls._cell_text(values, indexes["profit"]),
                    "note": cls._cell_text(values, indexes["note"]),
                    "source_tab": getattr(worksheet, "name", "") or "工作表",
                }
                key = (code, name, unit) if code else ("", name, unit)
                old = imported.get(key)
                if old is None and code:
                    old = imported.get(("", name, unit))
                    if old is not None:
                        imported.pop(("", name, unit), None)
                        imported[key] = old
                        old["code"] = code
                if old is None:
                    old = next(
                        (candidate for candidate in ordered
                         if candidate.get("name") == name and candidate.get("unit") == unit),
                        None,
                    )
                if old is not None and code and not old.get("code"):
                    old["code"] = code
                if old is None:
                    imported[key] = item
                    ordered.append(item)
                    previous = item
                else:
                    for field in ("feature", "unit", "quantity", "analysis", "comprehensive_price", "total_price", "labor", "material", "machinery", "management", "profit", "note"):
                        if len(str(item.get(field) or "")) > len(str(old.get(field) or "")):
                            old[field] = item[field]
                    previous = old
        return ordered

    def _import_excel(self):
        QMessageBox.information(
            self,
            "清单 Excel 导入",
            "支持导入工程量清单、招标工程量清单、投标文件、投标报价清单、结算文件、竣工结算清单。\n\n"
            "系统会识别清单表、综合单价分析表或通用清单表头，并自动生成需要套定额的清单。",
        )
        path, _ = QFileDialog.getOpenFileName(
            self,
            "导入清单 Excel",
            "",
            "Excel 文件 (*.xlsx *.xls)",
        )
        if not path:
            return
        import_major = self._choose_import_major()
        if import_major is None:
            return
        # Any worker still processing the previous workbook must become
        # harmless before the new rows replace the table.
        self._invalidate_async_generation()
        self._import_major = import_major
        major_index = self._major.findData(import_major)
        if major_index >= 0:
            self._major.setCurrentIndex(major_index)
        self._source_file = path
        self._loaded_saved_result = True
        try:
            is_xls = Path(path).suffix.lower() == ".xls"
            if not is_xls:
                from src.bill_list_extractor import extract_specialized_bill_list

                extracted = extract_specialized_bill_list(path)
                if extracted is not None:
                    self._source_format = extracted["format"]
                    self._rows = [
                        self._row_from_import_item(item, index, import_major)
                        for index, item in enumerate(extracted["items"], 1)
                    ]
                    if not self._rows:
                        raise ValueError(
                            f"已识别为{self._source_format}，但没有找到有效清单行。"
                            "请确认序号、项目编码和工程名称位于同一行。"
                        )
                    source_reference = self._preserve_imported_costs()
                    self._render_table()
                    self._table.selectRow(0)
                    persisted = self._persist_after_import()
                    missing_features = sum(not row.get("feature") for row in self._rows)
                    QMessageBox.information(
                        self,
                        "导入完成",
                        f"识别格式：{self._source_format}\n"
                        f"已导入 {len(self._rows)} 条清单，已保留项目特征、工程量和定额编码，"
                        f"可点击“批量匹配定额”。"
                        + (f"\n已拦截 {int(extracted.get('rejected') or 0)} 条编码行、汇总行或无有效工程量行。" if extracted.get("rejected") else "")
                        + (f"\n其中 {missing_features} 条来源表未提供项目特征/工作内容，请人工补充。" if missing_features else "")
                        + self._source_reference_message(source_reference)
                        + "\n"
                        f"{'已自动保存到当前项目。' if self._active_project_id() and persisted else '已保存为临时草稿，选择项目后会自动归档。'}",
                    )
                    return
            self._source_format = "通用 Excel 表格"
            sheets = read_excel_sheets(path)
            worksheets = sheets

            def worksheet_rows(worksheet):
                return worksheet[1]

            generic_items = self._extract_generic_items(worksheets, worksheet_rows)
            if generic_items:
                self._rows = [
                    self._row_from_import_item(item, index, import_major)
                    for index, item in enumerate(generic_items, 1)
                ]
                source_reference = self._preserve_imported_costs()
                self._render_table()
                self._table.selectRow(0)
                persisted = self._persist_after_import()
                missing_features = sum(not row.get("feature") for row in self._rows)
                QMessageBox.information(
                    self,
                    "导入完成",
                    f"通用语义识别已导入 {len(self._rows)} 条清单，已合并多行项目特征并保留工程量。\n"
                    f"来源工作表：{len({item.get('source_tab') for item in generic_items})} 个，"
                    f"可继续批量匹配定额。"
                    + (f"\n已拦截 {sum(self._last_generic_rejections.values())} 条编码行、汇总行或无效清单行。" if self._last_generic_rejections else "")
                    + (f"\n其中 {missing_features} 条来源表未提供项目特征/工作内容，请人工补充。" if missing_features else "")
                    + self._source_reference_message(source_reference)
                )
                return

            best_header = None
            for worksheet in worksheets:
                for header_row, values in enumerate(islice(worksheet_rows(worksheet), 50)):
                    indexes = self._header_indexes(values)
                    if indexes["name"] is None:
                        continue
                    score = (
                        1
                        + (1 if indexes["seq"] is not None else 0)
                        + (1 if indexes["code"] is not None else 0)
                        + (2 if indexes["feature"] is not None else 0)
                        + (2 if indexes["unit"] is not None else 0)
                        + (1 if indexes["quantity"] is not None else 0)
                    )
                    data_rows = max(
                        (worksheet.nrows if is_xls else worksheet.max_row) - header_row - 1,
                        0,
                    )
                    candidate = (score, data_rows, worksheet, header_row, indexes)
                    if best_header is None or candidate[:2] > best_header[:2]:
                        best_header = candidate
            if best_header is None:
                QMessageBox.warning(self, "导入失败", "未找到“工程名称”或“项目名称”列。")
                return
            if best_header[4]["quantity"] is None:
                QMessageBox.warning(
                    self,
                    "导入失败",
                    "当前工作表没有可识别的工程量列，只有名称/单位的目录行不会进入定额匹配。",
                )
                return

            _, _, worksheet, header_row, indexes = best_header
            rows = islice(worksheet_rows(worksheet), header_row + 1, None)

            self._rows = []
            rejected_rows: dict[str, int] = {}
            from src.bill_list_extractor import boq_item_rejection_reason, normalized_boq_feature
            for row in rows:
                values = list(row)
                if not any(value not in (None, "") for value in values):
                    continue
                name = self._cell_text(values, indexes["name"])
                code = self._cell_text(values, indexes["code"])
                feature = self._cell_text(values, indexes["feature"])
                unit = self._cell_text(values, indexes["unit"])
                quantity = self._cell_text(values, indexes["quantity"])
                reason = boq_item_rejection_reason(
                    name=name, feature=feature, unit=unit, quantity=quantity,
                    code=code, require_quantity=True,
                )
                if reason:
                    rejected_rows[reason] = rejected_rows.get(reason, 0) + 1
                    continue
                self._rows.append({
                    "seq": self._cell_text(values, indexes["seq"]),
                    "major": import_major,
                    "code": code,
                    "name": name,
                    "feature": normalized_boq_feature(name, feature, code),
                    "unit": unit,
                    "quantity": quantity,
                    "analysis": self._cell_text(values, indexes["analysis"]),
                    "comprehensive_price": self._cell_text(values, indexes["comprehensive_price"]),
                    "total_price": self._cell_text(values, indexes["total_price"]),
                    "labor": self._cell_text(values, indexes["labor"]),
                    "material": self._cell_text(values, indexes["material"]),
                    "machinery": self._cell_text(values, indexes["machinery"]),
                    "management": self._cell_text(values, indexes["management"]),
                    "profit": self._cell_text(values, indexes["profit"]),
                    "note": self._cell_text(values, indexes["note"]),
                    "quota_id": None,
                    "quota_ids": [],
                    "quota_matches": [],
                    "score": 0.0,
                    "match_reasons": [],
                    "compositions": [],
                    "source_comprehensive_price": self._cell_text(values, indexes["comprehensive_price"]),
                    "source_total_price": self._cell_text(values, indexes["total_price"]),
                    "calculated_comprehensive_price": "",
                    "price_difference": "",
                    "price_difference_rate": "",
                    "price_deviation_level": "",
                    "price_deviation_reason": "",
                })
                self._normalize_import_unit_quantity(self._rows[-1])
                for field in (
                    "analysis", "comprehensive_price", "total_price", "labor", "material",
                    "machinery", "management", "profit", "note",
                ):
                    self._rows[-1][f"imported_{field}"] = self._rows[-1][field]
            source_reference = self._preserve_imported_costs()
            self._render_table()
            if self._rows:
                self._table.selectRow(0)
            persisted = self._persist_after_import() if self._rows else False
            QMessageBox.information(
                self,
                "导入完成",
                (
                    f"识别格式：{self._source_format}\n"
                    f"已导入 {len(self._rows)} 条清单，可点击“批量匹配定额”。\n"
                    + (f"已拦截 {sum(rejected_rows.values())} 条编码行、汇总行或无效清单行。\n" if rejected_rows else "")
                    + self._source_reference_message(source_reference)
                    + ("已自动保存到当前项目。" if self._active_project_id() and persisted else "已保存为临时草稿，选择项目后会自动归档。")
                ),
            )
        except Exception as error:
            QMessageBox.warning(self, "导入失败", str(error))
    def _preserve_imported_costs(self) -> dict:
        """Extract source human/material/machine prices into the quota library."""
        if not self._rows:
            return {"total": 0, "components": 0, "categories": {}}
        session = get_session()
        try:
            result = preserve_imported_cost_references(
                session,
                self._rows,
                source_file=self._source_file,
            )
            session.commit()
            return result
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    @staticmethod
    def _source_reference_message(result: dict | None) -> str:
        result = result or {}
        total = int(result.get("total") or 0)
        components = int(result.get("components") or 0)
        if not total:
            return ""
        categories = result.get("categories") or {}
        summary = "、".join(
            f"{category}{int(count)}条"
            for category, count in categories.items()
            if count
        )
        return (
            f"\n已从导入表筛选并保留 {total} 条人材机参考，组成 {components} 条"
            f"（{summary}），可在定额库按“导入表人材机”专业筛选。"
        )

    @classmethod
    def _header_block(cls, rows, header_row: int) -> list[tuple]:
        """Collect adjacent header rows used by merged, multi-level Excel headers."""
        block = [tuple(rows[header_row])]
        header_markers = (
            "项目编码", "项目名称", "项目特征", "工作内容", "规格型号", "计量", "工程量",
            "金额", "综合单价", "合价", "其中", "人工费", "材料费", "机械费", "管理费",
            "利润", "暂估价", "备注", "说明",
        )
        for candidate in rows[header_row + 1:header_row + 4]:
            values = tuple(candidate)
            labels = [cls._normalized_header(value) for value in values if cls._normalized_header(value)]
            if not labels:
                break
            joined = "".join(labels)
            candidate_indexes = cls._header_indexes(values)
            looks_like_header = any(marker in joined for marker in header_markers)
            contains_item_row = (
                candidate_indexes["name"] is not None
                and candidate_indexes["quantity"] is not None
            )
            if not looks_like_header or contains_item_row:
                break
            block.append(values)
        return block

    @classmethod
    def _header_columns(cls, header_rows) -> list[str]:
        """Return one normalized label per column for multi-level headers."""
        column_count = max((len(row) for row in header_rows), default=0)
        columns = []
        for column in range(column_count):
            labels = []
            for row in header_rows:
                if column >= len(row):
                    continue
                label = cls._normalized_header(row[column])
                if label and label not in labels:
                    labels.append(label)
            columns.append("".join(labels))
        return columns

    @classmethod
    def _header_indexes_from_rows(cls, header_rows) -> dict[str, int | None]:
        """Resolve fields from either a single header row or a merged header block."""
        columns = cls._header_columns(header_rows)
        result = {}
        for field, aliases in cls.HEADER_ALIASES.items():
            result[field] = None
            normalized_aliases = [cls._normalized_header(alias) for alias in aliases]
            for column, label in enumerate(columns):
                if not label:
                    continue
                if any(alias and (alias == label or alias in label) for alias in normalized_aliases):
                    result[field] = column
                    break
            if result[field] is not None:
                continue
            if field == "feature":
                result[field] = next(
                    (column for column, label in enumerate(columns)
                     if any(token in label for token in ("项目特征", "工作内容", "规格型号"))),
                    None,
                )
            elif field == "quantity":
                result[field] = next(
                    (column for column, label in enumerate(columns)
                     if "工程量" in label or label == "数量"),
                    None,
                )
            elif field == "name":
                result[field] = next(
                    (column for column, label in enumerate(columns)
                     if "项目名称" in label or "清单名称" in label),
                    None,
                )
        return result

    @classmethod
    def _header_indexes(cls, headers) -> dict[str, int | None]:
        return cls._header_indexes_from_rows([tuple(headers)])

    @staticmethod
    def _normalized_header(value) -> str:
        return re.sub(r"\s+", "", str(value or "")).strip()

    @staticmethod
    def _cell_text(row, index: int | None) -> str:
        if index is None or index >= len(row) or row[index] is None:
            return ""
        value = row[index]
        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        return re.sub(r"(?i)_?x000d_?", "\n", str(value)).strip()

    @classmethod
    def _normalize_import_unit_quantity(cls, row: dict) -> dict:
        """Split scaled BOQ units such as 100m2 or 10套.

        Chinese cost exports often encode the measurement basis in the unit
        cell. The application keeps a plain unit and converts the engineering
        quantity to that plain unit before matching or pricing.
        """
        unit = cls._cell_text([row.get("unit")], 0)
        if not unit:
            return row
        compact = re.sub(r"\s+", "", unit).lower()
        aliases = {
            "m2": "m2", "m²": "m2", "m^2": "m2", "m平方": "m2", "平方米": "m2",
            "m3": "m3", "m³": "m3", "m^3": "m3", "m立方": "m3", "立方米": "m3",
            "㎡": "m2", "立方": "m3", "m": "m", "米": "m", "延米": "m",
            "个": "个", "件": "件", "套": "套", "台": "台", "组": "组",
        }
        unit_pattern = "|".join(sorted((re.escape(value) for value in aliases), key=len, reverse=True))
        match = re.fullmatch(rf"(\d+(?:\.\d+)?)({unit_pattern})", compact)
        if not match:
            return row
        scale = float(match.group(1))
        plain_unit = aliases[match.group(2)]
        raw_quantity = row.get("quantity")
        quantity_text = cls._cell_text([raw_quantity], 0).replace(",", "")
        try:
            quantity = float(quantity_text) if quantity_text else None
        except (TypeError, ValueError):
            quantity = None
        row.setdefault("source_unit", unit)
        row.setdefault("source_quantity", quantity_text)
        row.setdefault("unit_scale", scale)
        row["unit"] = plain_unit
        if quantity is not None:
            converted = quantity * scale
            row["quantity"] = str(int(converted)) if converted.is_integer() else f"{converted:.8f}".rstrip("0").rstrip(".")
        elif scale > 0:
            row["quantity"] = str(int(scale)) if scale.is_integer() else str(scale)
        note = f"原表组合单位 {unit} 已换算为 {plain_unit}，工程量按 {scale:g} 倍换算"
        row["note"] = "；".join(value for value in (row.get("note"), note) if value)
        return row

    def _begin_matching_pipeline(self, local_total: int = 0, status: str = ""):
        """Start one progress lifecycle shared by local matching and AI stages."""
        self._pipeline_active = True
        self._pipeline_finished = False
        self._pipeline_local_total = max(int(local_total or 0), 0)
        self._pipeline_local_completed = 0
        self._pipeline_status = status
        self._ai_fallback_total = 0
        self._ai_fallback_completed = 0
        self._ai_fallback_applied = 0
        self._ai_fallback_failed = 0
        self._ai_fallback_stage_done = False
        self._ai_audit_total = 0
        self._ai_audit_completed = 0
        self._ai_audit_stage_done = False
        self._update_matching_progress()

    def _update_matching_progress(self):
        """Render local, AI fallback, and audit work as one cumulative bar."""
        local_total = max(int(self._pipeline_local_total or 0), 0)
        local_completed = min(max(int(self._pipeline_local_completed or 0), 0), local_total)
        fallback_total = max(int(self._ai_fallback_total or 0), 0)
        fallback_completed = min(max(int(self._ai_fallback_completed or 0), 0), fallback_total)
        audit_total = max(int(self._ai_audit_total or 0), 0)
        audit_completed = min(max(int(self._ai_audit_completed or 0), 0), audit_total)
        total = local_total + fallback_total + audit_total
        completed = local_completed + fallback_completed + audit_completed
        if total <= 0:
            self._ai_progress.setValue(0)
            self._ai_progress.setFormat("未运行")
            self._ai_progress_detail.setText("无正在运行的匹配任务")
            return
        percent = min(max(round(completed * 100 / total), 0), 100)
        self._ai_progress.setValue(percent)
        applied = max(int(self._ai_fallback_applied or 0), 0)
        failed = max(int(self._ai_fallback_failed or 0), 0)
        self._ai_progress.setFormat(f"{completed}/{total} ({percent}%) · 已写入 {applied}")
        status = _text(self._pipeline_status)
        self._ai_progress_detail.setText(
            (f"{status} · " if status else "")
            + f"本地 {local_completed}/{local_total} · AI兜底 {fallback_completed}/{fallback_total} · "
            f"AI复核 {audit_completed}/{audit_total} · 未写入/待复核 {failed}"
        )

    def _maybe_finish_matching_pipeline(self):
        if not self._pipeline_active:
            return
        fallback_worker = getattr(self, "_ai_fallback_worker", None)
        audit_worker = getattr(self, "_ai_audit_worker", None)
        fallback_running = bool(
            fallback_worker is not None
            and fallback_worker.isRunning()
            and not self._ai_fallback_stage_done
        )
        audit_running = bool(
            audit_worker is not None
            and audit_worker.isRunning()
            and not self._ai_audit_stage_done
        )
        total = (
            max(int(self._pipeline_local_total or 0), 0)
            + max(int(self._ai_fallback_total or 0), 0)
            + max(int(self._ai_audit_total or 0), 0)
        )
        completed = (
            max(int(self._pipeline_local_completed or 0), 0)
            + max(int(self._ai_fallback_completed or 0), 0)
            + max(int(self._ai_audit_completed or 0), 0)
        )
        if total and completed >= total and not fallback_running and not audit_running:
            self._pipeline_active = False
            self._pipeline_finished = True
            self._pipeline_status = "匹配流程完成"
            self._update_matching_progress()

    def _batch_match(self):
        self._batch_match_indexes(list(range(len(self._rows))))

    def _batch_match_filtered(self):
        row_indexes = self._visible_row_indexes()
        if not row_indexes:
            QMessageBox.information(self, "没有筛选结果", "当前状态筛选下没有清单行。")
            return
        self._batch_match_indexes(row_indexes)

    def _selected_row_indexes(self) -> list[int]:
        return sorted({
            index.row()
            for index in self._table.selectionModel().selectedRows()
            if not self._table.isRowHidden(index.row())
        })

    def _batch_match_selected(self):
        row_indexes = self._selected_row_indexes()
        if not row_indexes:
            current = self._table.currentRow()
            if 0 <= current < len(self._rows) and not self._table.isRowHidden(current):
                row_indexes = [current]
        self._batch_match_indexes(row_indexes)

    def _batch_match_indexes(self, row_indexes: list[int]):
        if not self._rows:
            QMessageBox.information(self, "没有清单", "请先导入一份清单。")
            return
        if not row_indexes:
            QMessageBox.information(self, "没有选择清单", "请先筛选或选择需要匹配的清单。")
            return
        major = self._major.currentData() or ""
        minimum_score = int(self._match_level.currentData() or 40)
        project_id = self._active_project_id()
        session = get_session()
        self._begin_matching_pipeline(
            len(row_indexes),
            "正在按单位、部位、工艺和组成明细匹配定额...",
        )
        try:
            matched = 0
            base_fallback_matched = 0
            ai_generated_matched = 0
            ai_review_pending = []
            ai_fallback_pending = []
            candidate_indexes = {}
            def index_for(current_major: str):
                key = _text(current_major)
                if key not in candidate_indexes:
                    candidate_indexes[key] = build_quota_match_index(session, key)
                return candidate_indexes[key]
            candidate_index = index_for(major)
            project = session.query(Project).filter(Project.id == project_id).first() if project_id else None
            # Information-price region is an independent pricing input. An
            # empty selector means the newest period in the information-price
            # library, never the project's city or address.
            reference_region = self._selected_source_region()
            reference_period, _ = latest_price_period(
                session, None, reference_region,
            )
            for position, row_index in enumerate(row_indexes):
                if not (0 <= row_index < len(self._rows)):
                    continue
                row = self._rows[row_index]
                row_major = _text(row.get("major") or major)
                row["major"] = row_major
                candidate_index = index_for(row_major)
                self._reset_row_match(row)
                historical = find_project_list_references(
                    session, row.get("name", ""), row.get("feature", ""), row.get("unit", ""),
                    region=reference_region, period=reference_period, limit=1
                )
                if historical and historical[0][0] >= 72:
                    _, historical_row, name_score, context_score = historical[0]
                    row["historical_reference"] = {
                        "id": historical_row.id,
                        "source_project": historical_row.source_project,
                        "source_file": historical_row.source_file,
                        "region": historical_row.region,
                        "period": historical_row.period,
                        "score": round(historical[0][0] / 100, 4),
                        "comprehensive_price": historical_row.comprehensive_price,
                        "labor": historical_row.labor_cost,
                        "material": historical_row.material_cost,
                        "machinery": historical_row.machinery_cost,
                        "management": historical_row.management_cost,
                        "profit": historical_row.profit,
                    }
                else:
                    row.pop("historical_reference", None)
                matches = find_quota_composition_matches(
                    session,
                    row["name"],
                    row["feature"],
                    row["unit"],
                    major=row_major,
                    candidate_index=candidate_index,
                    item_code=row.get("code", ""),
                    minimum_score=minimum_score,
                    supplemental_minimum_score=minimum_score + 8,
                    reference_price=self._reference_price(row),
                    source_costs=self._source_costs(row),
                    fallback_candidate_index=candidate_index,
                )
                if matches:
                    valid_matches = []
                    blocked_reasons = []
                    # The matcher may return a ranked candidate list, but a
                    # persisted row is intentionally single-select. The
                    # service normalizer also enforces this after each append.
                    for match in matches[:1]:
                        reference = quota_reference_dict(match["item"])
                        scope_errors = quota_reference_scope_errors(
                            row.get("name", ""), row.get("feature", ""), reference,
                        )
                        if scope_errors:
                            blocked_reasons.extend(scope_errors)
                            continue
                        valid_matches.append((match, reference))
                    if blocked_reasons:
                        row["note"] = "；".join(dict.fromkeys(blocked_reasons))
                    matches = [value[0] for value in valid_matches]
                    if matches:
                        matches = [max(
                            matches,
                            key=lambda value: (
                                float(value.get("score") or 0),
                                1 if str(value.get("role") or "").startswith("主体") else 0,
                            ),
                        )]
                # Controlled cross-major rescue: only run after the selected
                # major has no logically valid result. It uses a higher
                # threshold and keeps the warning visible in the row.
                if not matches and row_major:
                    cross_index = index_for("")
                    cross_threshold = max(float(minimum_score) + 8.0, 50.0)
                    cross_matches = find_quota_composition_matches(
                        session,
                        row["name"], row["feature"], row["unit"],
                        major="",
                        candidate_index=cross_index,
                        item_code=row.get("code", ""),
                        minimum_score=cross_threshold,
                        supplemental_minimum_score=cross_threshold + 8,
                        reference_price=self._reference_price(row),
                        source_costs=self._source_costs(row),
                        fallback_candidate_index=cross_index,
                    )
                    if cross_matches:
                        row["cross_major_candidates"] = [
                            {
                                "quota_id": value["item"].id,
                                "quota_code": value["item"].code,
                                "quota_name": value["item"].name,
                                "score": value.get("score", 0),
                                "reasons": list(value.get("reasons") or []),
                            }
                            for value in cross_matches[:5]
                        ]
                        row["cross_major_match"] = True
                        row["cross_major_source"] = row_major
                        row["blocked_by_major"] = True
                        matches = []
                        row["note"] = "；".join(dict.fromkeys([
                            value for value in (
                                row.get("note"),
                                f"本专业（{row_major}）无合格候选，已发现跨专业候选但未计入综合单价",
                                "跨专业候选仅供复核，必须确认专业、施工工艺和含量后才能人工选择",
                            ) if value
                        ]))
                local_rejection = self._local_match_rejection_reason(matches)
                if local_rejection:
                    row["local_match_rejection_reason"] = local_rejection
                    row["note"] = local_rejection + "；已转入AI匹配"
                    matches = []
                if matches:
                    local_warning = self._local_match_supplement_warning(matches)
                    if local_warning:
                        row["local_match_warning"] = local_warning
                        row["note"] = "；".join(
                            value for value in (row.get("note"), local_warning) if value
                        )
                    row["score"] = matches[0]["score"]
                    row["quota_id"] = matches[0]["item"].id
                    row["match_reasons"] = list(matches[0]["reasons"])
                    row["evidence_level"] = (
                        "red"
                        if any(str(value.get("evidence_level") or "") == "red" for value in matches)
                        else ("green" if matches[0]["score"] >= 0.75 else "yellow")
                    )
                    for match in matches[:1]:
                        item = match["item"]
                        reference = quota_reference_dict(item)
                        self._append_quota_reference(
                            row,
                            reference,
                            role=match["role"],
                            score=match["score"],
                            reasons=match["reasons"],
                            source_clause=match["source_clause"],
                            components_override=match.get("components"),
                            matched_source_clauses=match.get("matched_source_clauses"),
                        )
                    normalize_quota_row_matches(row)
                    self._ensure_source_cost_components(row)
                    self._apply_price_priority(session, row)
                    self._calculate_row_from_compositions(row, reference)
                    if reference_region:
                        row["match_reasons"] = list(dict.fromkeys([
                            *(row.get("match_reasons") or []),
                            f"信息来源地区：{reference_region}",
                        ]))
                    matched += 1
                    should_review, review_reasons = self._should_ai_review_batch(row, matches)
                    if should_review:
                        row["ai_review_trigger"] = "；".join(review_reasons)
                        row["ai_reviewed"] = False
                        row["ai_review_pending"] = True
                        ai_review_pending.append(row_index)
                else:
                    fallback = None
                    if not row.get("local_match_rejection_reason"):
                        fallback = build_base_data_fallback(
                            session,
                            row,
                            project_id,
                            major=row_major,
                            minimum_score=minimum_score,
                            include_unconfirmed=False,
                            region_override=reference_region,
                        )
                    if fallback and fallback.get("auto_apply"):
                        self._apply_ai_result(
                            row,
                            self._base_fallback_as_ai_result(fallback),
                        )
                        base_fallback_matched += 1
                    else:
                        row["evidence_level"] = "red"
                        if project_id:
                            row["note"] = "本地定额未找到，已排队后台AI兜底匹配"
                            row["ai_fallback_pending"] = True
                            ai_fallback_pending.append(row_index)
                        else:
                            row["note"] = "本地定额未找到，请先选择项目后使用AI兜底匹配"
                self._pipeline_local_completed = position + 1
                self._pipeline_status = "本地定额、企业参考和基础库匹配中..."
                self._update_matching_progress()
                if position % 5 == 0:
                    QApplication.processEvents()
            self._render_table()
            self._save_results(show_message=False)
            fallback_started = self._start_ai_fallback_for_indexes(
                ai_fallback_pending,
                reference_region=reference_region,
            )
            auto_audit_started = self._auto_audit_rows(row_indexes)
            if not auto_audit_started:
                for pending_index in ai_review_pending:
                    if 0 <= pending_index < len(self._rows):
                        self._rows[pending_index]["ai_review_pending"] = False
            ai_review_count = len(ai_review_pending) if auto_audit_started else 0
            self._pipeline_status = (
                "AI兜底和AI复核正在继续..."
                if fallback_started or auto_audit_started
                else "匹配流程完成"
            )
            self._update_matching_progress()
            self._maybe_finish_matching_pipeline()
            self._stats_label.setText(
                f"本次本地匹配完成 {len(row_indexes)} 条，定额匹配 {matched} 条，"
                f"基础库兜底 {base_fallback_matched} 条，"
                f"AI 自动生成 {ai_generated_matched} 条，"
                f"后台AI复核 {ai_review_count} 条，"
                f"未匹配 {len(row_indexes) - matched - base_fallback_matched - ai_generated_matched} 条"
                + ("；AI兜底已后台启动" if fallback_started else "")
                + ("；低置信AI核查已后台启动" if auto_audit_started else "")
            )
        except Exception as error:
            QMessageBox.warning(self, "匹配失败", str(error))
        finally:
            session.close()

    def _reset_row_match(self, row: dict):
        """Clear only the current row's matching result, preserving imported BOQ fields."""
        for field in (
            "analysis", "comprehensive_price", "total_price", "labor", "material", "machinery",
            "management", "profit", "note",
        ):
            # Imported source costs remain in imported_* / source_* fields. The
            # visible calculated columns must not present source totals as a
            # newly matched unit composition while the row is unmatched.
            row[field] = ""
        row["note"] = row.get("imported_note", "")
        row["quota_id"] = None
        row["quota_ids"] = []
        row["quota_matches"] = []
        row["score"] = 0.0
        row["match_reasons"] = []
        row["compositions"] = []
        row["fee_details"] = []
        row.pop("generated_quota", None)
        row.pop("ai_audited", None)
        row.pop("ai_audit_summary", None)
        row.pop("ai_audit_findings", None)
        row.pop("local_audit_report", None)
        row.pop("audit_issues", None)
        row.pop("category_coverage", None)
        row.pop("applied_fee_settings", None)
        row.pop("ai_review_trigger", None)
        row.pop("ai_validation_failed", None)
        row.pop("ai_candidate_quota", None)
        row.pop("rejected_quota_matches", None)
        row.pop("local_match_rejection_reason", None)
        row.pop("local_match_warning", None)
        row.pop("cross_major_match", None)
        row.pop("cross_major_source", None)
        row.pop("cross_major_candidates", None)
        row.pop("blocked_by_logic", None)
        row.pop("blocked_by_major", None)
        row.pop("needs_rematch", None)
        row["ai_review_pending"] = False
        row["ai_fallback_pending"] = False
        row["ai_generated"] = False
        row["evidence_level"] = "red"
        row["matching_algorithm_version"] = self.MATCHING_ALGORITHM_VERSION
        row["result_schema"] = self.RESULT_SCHEMA
        row.pop("row_result_algorithm_version", None)
        row.pop("row_result_schema", None)
        row.pop("row_result_pipeline", None)
        row.pop("row_result_at", None)
        for field in (
            "calculated_comprehensive_price", "price_difference",
            "price_difference_rate", "price_deviation_level",
            "price_deviation_reason",
        ):
            row[field] = ""

    @staticmethod
    def _reference_price(row: dict) -> float | None:
        """Return a usable imported unit price; blank source cells stay blank."""
        raw = row.get("source_comprehensive_price")
        if raw in (None, ""):
            raw = row.get("imported_comprehensive_price")
        value = _numeric(raw)
        if value > 0:
            return value
        historical = row.get("historical_reference") or {}
        value = _numeric(historical.get("comprehensive_price"))
        return value if value > 0 else None

    @staticmethod
    def _ai_cache_key(row: dict, purpose: str, project_id: int = 0,
                      region_override: str = "", current: dict | None = None) -> str:
        """Build a stable key for one AI operation on one BOQ row."""
        payload = {
            "schema": QuotaMatchTab.AI_CACHE_SCHEMA,
            "algorithm_version": QuotaMatchTab.MATCHING_ALGORITHM_VERSION,
            "prompt_version": QuotaMatchTab.AI_PROMPT_VERSION,
            "model": _text(getattr(config, "DEEPSEEK_MODEL", "")),
            "purpose": purpose,
            "project_id": int(project_id or 0),
            "region": _text(region_override),
            "code": _text(row.get("code")),
            "name": _text(row.get("name")),
            "feature": _text(row.get("feature")),
            "unit": _text(row.get("unit")),
            "quantity": _text(row.get("quantity")),
            "major": _text(row.get("major")),
        }
        if current is not None:
            payload["current"] = current
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    @classmethod
    def _is_current_ai_cache_entry(cls, entry: dict) -> bool:
        return bool(
            isinstance(entry, dict)
            and entry.get("schema") == cls.AI_CACHE_SCHEMA
            and entry.get("algorithm_version") == cls.MATCHING_ALGORITHM_VERSION
            and entry.get("prompt_version") == cls.AI_PROMPT_VERSION
            and isinstance(entry.get("result"), dict)
        )

    @classmethod
    def _purge_stale_ai_cache(cls, row: dict) -> None:
        cache = row.get("ai_result_cache")
        if not isinstance(cache, dict):
            row.pop("ai_result_cache", None)
            return
        for purpose, bucket in list(cache.items()):
            if not isinstance(bucket, dict):
                cache.pop(purpose, None)
                continue
            for key, entry in list(bucket.items()):
                if not cls._is_current_ai_cache_entry(entry):
                    bucket.pop(key, None)
            if not bucket:
                cache.pop(purpose, None)

    @classmethod
    def _cached_ai_result(cls, row: dict, purpose: str, key: str) -> dict | None:
        cache = row.get("ai_result_cache") or {}
        entry = (cache.get(purpose) or {}).get(key)
        if not cls._is_current_ai_cache_entry(entry):
            return None
        result = entry.get("result")
        if not isinstance(result, dict):
            return None
        reusable = dict(result)
        for transient_key in ("_match_generation", "_row_input_key", "_project_id"):
            reusable.pop(transient_key, None)
        return reusable

    @staticmethod
    def _save_cached_ai_result(row: dict, purpose: str, key: str, result: dict) -> None:
        if not isinstance(result, dict) or result.get("errors"):
            return
        if purpose == "fallback" and not result.get("valid", result.get("actionable", False)):
            return
        cache = row.setdefault("ai_result_cache", {})
        # Remove entries written by an older matcher before adding the new
        # result. This prevents stale payloads from accumulating forever and
        # makes a cache migration deterministic even when the key format is
        # unchanged by a future maintenance edit.
        for purpose_name, purpose_bucket in list(cache.items()):
            if not isinstance(purpose_bucket, dict):
                cache.pop(purpose_name, None)
                continue
            for old_key, old_entry in list(purpose_bucket.items()):
                if not QuotaMatchTab._is_current_ai_cache_entry(old_entry):
                    purpose_bucket.pop(old_key, None)
            if not purpose_bucket:
                cache.pop(purpose_name, None)
        bucket = cache.setdefault(purpose, {})
        # Context contains the full candidate list and is not needed to apply
        # an already validated result. Excluding it keeps project files small.
        compact = dict(result)
        compact.pop("context", None)
        compact.pop("research_evidence", None)
        # These fields protect live worker callbacks only. They are not part
        # of the reusable answer and would make a valid cache look stale
        # after the application restarts with a new in-memory generation.
        for transient_key in ("_match_generation", "_row_input_key", "_project_id"):
            compact.pop(transient_key, None)
        bucket[key] = {
            "schema": QuotaMatchTab.AI_CACHE_SCHEMA,
            "algorithm_version": QuotaMatchTab.MATCHING_ALGORITHM_VERSION,
            "prompt_version": QuotaMatchTab.AI_PROMPT_VERSION,
            "result": compact,
            "saved_at": time.time(),
        }
        # Keep project payloads bounded when users repeatedly edit and retry
        # the same row. The newest six results per operation are sufficient
        # for reuse; old alternatives are removed automatically.
        ordered = sorted(
            bucket.items(),
            key=lambda item: float((item[1] or {}).get("saved_at") or 0),
            reverse=True,
        )
        for old_key, _ in ordered[QuotaMatchTab.AI_CACHE_MAX_ENTRIES_PER_PURPOSE:]:
            bucket.pop(old_key, None)
        if not bucket:
            cache.pop(purpose, None)
            return
        cache_size = len(json.dumps(cache, ensure_ascii=False, default=str).encode("utf-8"))
        if cache_size > QuotaMatchTab.AI_CACHE_MAX_BYTES_PER_ROW:
            all_entries = [
                (purpose_name, entry_key, entry)
                for purpose_name, purpose_bucket in cache.items()
                if isinstance(purpose_bucket, dict)
                for entry_key, entry in purpose_bucket.items()
                if isinstance(entry, dict)
            ]
            all_entries.sort(
                key=lambda value: float((value[2] or {}).get("saved_at") or 0),
            )
            for purpose_name, entry_key, _ in all_entries:
                purpose_bucket = cache.get(purpose_name) or {}
                purpose_bucket.pop(entry_key, None)
                if not purpose_bucket:
                    cache.pop(purpose_name, None)
                cache_size = len(json.dumps(cache, ensure_ascii=False, default=str).encode("utf-8"))
                if cache_size <= QuotaMatchTab.AI_CACHE_MAX_BYTES_PER_ROW:
                    break

    @staticmethod
    def _source_costs(row: dict) -> dict:
        """Return imported cost evidence in the same unit basis as the BOQ.

        Tender/control-price exports may store cost columns as either unit
        amounts or engineering-quantity totals. Use the relationship between
        the explicit unit price, row total, and component sum before dividing;
        this also handles quantities below one.
        """
        values = {
            "labor": _numeric(row.get("imported_labor")),
            "material": _numeric(row.get("imported_material")),
            "machinery": _numeric(row.get("imported_machinery")),
            "management": _numeric(row.get("imported_management")),
            "profit": _numeric(row.get("imported_profit")),
        }
        historical = row.get("historical_reference") or {}
        for key in values:
            if values[key] <= 0 and _numeric(historical.get(key)) > 0:
                values[key] = _numeric(historical.get(key))
        total_basis, quantity = QuotaMatchTab._source_cost_basis(row)
        if total_basis and quantity > 0:
            values = {
                key: value / quantity if value > 0 else value
                for key, value in values.items()
            }
        return values

    @staticmethod
    def _source_cost_basis(row: dict) -> tuple[bool, float]:
        """Return whether imported component prices are quantity totals.

        A quantity alone is not enough: a row with already-unitized component
        prices must not be divided just because its engineering quantity is
        large. Conversion requires agreement with the row total or the
        explicit unit comprehensive price.
        """
        quantity = _numeric(row.get("quantity"))
        if quantity <= 0 or abs(quantity - 1.0) <= 0.000001:
            return False, quantity
        values = {
            key: _numeric(row.get(f"imported_{key}"))
            for key in ("labor", "material", "machinery", "management", "profit")
        }
        component_sum = sum(value for value in values.values() if value > 0)
        if component_sum <= 0:
            return False, quantity
        source_total = _numeric(
            row.get("imported_total_price") or row.get("total_price")
        )
        source_unit = _numeric(
            row.get("imported_comprehensive_price")
            or row.get("comprehensive_price")
        )
        if source_total > 0:
            denominator = max(component_sum, source_total, 0.000001)
            if abs(component_sum - source_total) / denominator <= 0.25:
                return True, quantity
        if source_unit > 0:
            denominator = max(component_sum / quantity, source_unit, 0.000001)
            if abs(component_sum / quantity - source_unit) / denominator <= 0.35:
                return True, quantity
        return False, quantity

    def _ensure_source_cost_components(self, row: dict) -> list[str]:
        """Preserve source-only cost categories when no logical local quota exists.

        An exported BOQ can contain a reliable labor/material/machine amount
        even when the local quota library has no matching composition. Keeping
        that amount as an explicitly red, source-evidence component prevents a
        category from disappearing and prevents an unrelated quota from being
        forced in just to make the row look complete.
        """
        source_fields = (
            ("人工费", "imported_labor"),
            ("材料费", "imported_material"),
            ("机械费", "imported_machinery"),
        )
        basis_is_total, quantity = self._source_cost_basis(row)
        source_costs = self._source_costs(row)
        existing_categories = {
            str(detail.get("cat") or detail.get("category") or "")
            for detail in row.get("compositions") or []
            if detail.get("included", True)
        }
        reference_categories = {
            str(detail.get("sourceCostReferenceCategory") or "")
            for detail in row.get("compositions") or []
            if detail.get("sourceCostReferenceCategory")
        }
        machine_labor_terms = []
        for detail in row.get("compositions") or []:
            if not detail.get("included", True):
                continue
            if str(detail.get("cat") or detail.get("category") or "") != "机械费":
                continue
            machine_labor_terms.extend(labor_coordination_evidence(
                detail.get("name", ""), detail.get("feature", ""),
            ))
        machine_labor_terms = list(dict.fromkeys(machine_labor_terms))
        added = []
        for category, source_field in source_fields:
            raw_amount = _numeric(row.get(source_field))
            if raw_amount <= 0 or category in existing_categories or category in reference_categories:
                continue
            unit_price = _numeric(source_costs.get({
                "人工费": "labor",
                "材料费": "material",
                "机械费": "machinery",
            }[category]))
            if unit_price <= 0:
                continue
            basis_text = (
                f"原表{category}合价 {raw_amount:.4f} ÷ 工程量 {quantity:g}"
                if basis_is_total and quantity > 0
                else f"原表{category}单位金额 {unit_price:.4f}"
            )
            is_machine_coordination_labor = (
                category == "人工费" and bool(machine_labor_terms)
            )
            reference_name = (
                "原表人工配合费参考（主体机械定额已含人工配合）"
                if is_machine_coordination_labor
                else f"原表{category}参考（本地定额未找到合适组成）"
            )
            reference_role = (
                "原表人工配合费参考"
                if is_machine_coordination_labor else "原表费用参考"
            )
            source_clause = (
                "原表人工费列（主体机械定额已含人工配合）"
                if is_machine_coordination_labor else "原表费用列"
            )
            coordination_text = "、".join(machine_labor_terms)
            calculation_basis = (
                f"{basis_text} = 单位{unit_price:.4f}；"
                f"主体机械定额已明确包括{coordination_text}，未重复套用完整人工挖土方；"
                "保留原表人工费作为人工配合费用依据，需人工复核"
                if is_machine_coordination_labor else (
                    f"{basis_text} = 单位{unit_price:.4f}；"
                    "本地定额库未找到同时满足对象、工艺、规格和单位的合适组成，需人工复核"
                )
            )
            detail = {
                "included": True,
                "cat": category,
                "code": f"SOURCE-{category}",
                "name": reference_name,
                "feature": f"来源：工程量清单原表；{basis_text}",
                "unit": row.get("unit", ""),
                "qty": 1.0,
                "sourceQty": 1.0,
                "quotaFactor": 1.0,
                "loss": 0.0,
                "noTaxPrice": unit_price,
                "taxPrice": unit_price,
                "taxRate": 0.0,
                "forceFormula": True,
                "quotaRole": reference_role,
                "quotaCode": f"SOURCE-{category}",
                "quotaName": reference_name,
                "sourceClause": source_clause,
                "sourceCostReferenceCategory": category,
                "evidenceLevel": "red",
                "calculationBasis": calculation_basis,
                "note": (
                    "主体机械定额已含人工配合，原表人工费单列保留；未重复套用完整人工挖土方，请复核人工配合范围和计量口径"
                    if is_machine_coordination_labor else (
                    "保留原表费用证据，未伪造定额库匹配；请核对含税口径、工程量和机械施工方案"
                    if category == "机械费"
                    else "保留原表费用证据，未伪造定额库匹配；请人工复核组成和计量口径")
                ),
            }
            detail = apply_explicit_unit_conversion(
                detail,
                f"{row.get('name', '')} {row.get('feature', '')}",
                row.get("unit", ""),
                strict=False,
            )
            detail.update(composition_cost_breakdown(detail, row.get("quantity")))
            row.setdefault("compositions", []).append(detail)
            row.setdefault("quota_matches", []).append({
                "quota_id": None,
                "quota_code": f"SOURCE-{category}",
                "quota_name": reference_name,
                "role": reference_role,
                "quota_factor": 1.0,
                "score": 0.50,
                "evidence_level": "red",
                "source_type": "imported_cost_reference",
                "reasons": [detail["calculationBasis"]],
                "source_clause": source_clause,
                "matched_source_clauses": ["原表费用列"],
                "component_only": True,
            })
            added.append(category)
            existing_categories.add(category)
        if added:
            row["evidence_level"] = "red"
            row["match_reasons"] = list(dict.fromkeys([
                *(row.get("match_reasons") or []),
                "原表费用列已保留为缺少本地合适定额时的待复核参考",
                *(
                    [
                        "主体机械定额已含人工清底/修坡/配合，未重复套用完整人工挖土方；"
                        "人工费按原表人工费折算保留",
                    ]
                    if "人工费" in added and machine_labor_terms else []
                ),
            ]))
            normalize_quota_row_matches(row)
        return added

    def _update_price_deviation(self, row: dict, calculated_price) -> None:
        source = self._reference_price(row)
        calculated = _numeric(calculated_price)
        row["calculated_comprehensive_price"] = calculated if calculated > 0 else ""
        row["price_difference"] = ""
        row["price_difference_rate"] = ""
        row["price_deviation_level"] = ""
        row["price_deviation_reason"] = ""
        if source is None or calculated <= 0:
            return
        difference = calculated - source
        rate = abs(difference) / source
        row["price_difference"] = round(difference, 4)
        row["price_difference_rate"] = round(rate, 6)
        if rate <= 0.10:
            level = "价格接近"
        elif rate <= 0.20:
            level = "价格需关注"
        else:
            level = "价格偏差较大"
        row["price_deviation_level"] = level
        row["price_deviation_reason"] = (
            f"原表综合单价 {_numeric(source):.4f}；套定额计算价 {calculated:.4f}；"
            f"差额 {difference:+.4f}，偏差率 {rate:.1%}。"
            "仅作同口径价格比较，需核对含税/除税、地区和计价期。"
        )

    @classmethod
    def _find_incomplete_specifications(cls, row: dict) -> list[str]:
        """Find key specifications deferred to design or site decisions."""
        name = _text(row.get("name"))
        feature = _text(row.get("feature"))
        source = "；".join(value for value in (name, feature) if value)
        if not source:
            return []
        issues = []
        for phrase in cls.VAGUE_SPECIFICATION_PHRASES:
            phrase_start = source.find(phrase)
            if phrase_start < 0:
                continue
            context = source[max(0, phrase_start - 48):phrase_start]
            terms = [term for term in cls.KEY_SPECIFICATION_TERMS if term in context]
            if len(terms) > 1:
                terms = [
                    term for term in terms
                    if term not in ("长度", "尺寸", "型号")
                    or not any(
                        other != term and other in terms
                        and other in ("桩长", "空桩长度", "管道规格", "规格型号")
                        for other in terms
                    )
                ]
            if not terms:
                continue
            term_label = "、".join(dict.fromkeys(terms[:3]))
            issues.append(
                f"{term_label}未给出明确数值（{phrase}），请手动补充设计参数或确认采用值"
            )
        return list(dict.fromkeys(issues))

    @classmethod
    def _specification_review_message(cls, row: dict) -> str:
        issues = cls._find_incomplete_specifications(row)
        if not issues:
            return ""
        return "本行存在影响定额选择、含量换算或价格计算的规格信息待确认：" + "；".join(issues)

    def _match_current_row(self):
        row = self._current_boq_row()
        if row is None:
            QMessageBox.information(self, "未选择清单", "请先在上方选择一条清单。")
            return
        specification_message = self._specification_review_message(row)
        if specification_message:
            QMessageBox.warning(
                self,
                "规格信息待确认",
                specification_message + "。仍可继续匹配，但匹配结果必须人工复核。",
            )
        row_index = self._table.currentRow()
        session = get_session()
        project_id = self._active_project_id()
        base_fallback_applied = False
        try:
            self._reset_row_match(row)
            minimum_score = int(self._match_level.currentData() or 40)
            major = _text(row.get("major") or self._major.currentData() or "")
            row["major"] = major
            index = build_quota_match_index(session, major)
            fallback_index = index
            matches = find_quota_composition_matches(
                session,
                row.get("name", ""),
                row.get("feature", ""),
                row.get("unit", ""),
                major=major,
                candidate_index=index,
                item_code=row.get("code", ""),
                minimum_score=minimum_score,
                supplemental_minimum_score=minimum_score + 8,
                reference_price=self._reference_price(row),
                source_costs=self._source_costs(row),
                fallback_candidate_index=fallback_index,
            )
            if matches:
                valid_matches = []
                blocked_reasons = []
                for match in matches[:1]:
                    scope_errors = quota_reference_scope_errors(
                        row.get("name", ""), row.get("feature", ""),
                        quota_reference_dict(match["item"]),
                    )
                    if scope_errors:
                        blocked_reasons.extend(scope_errors)
                    else:
                        valid_matches.append(match)
                matches = valid_matches
                if matches:
                    matches = [max(
                        matches,
                        key=lambda value: (
                            float(value.get("score") or 0),
                            1 if str(value.get("role") or "").startswith("主体") else 0,
                        ),
                    )]
                if blocked_reasons:
                    row["note"] = "；".join(dict.fromkeys(blocked_reasons))
            if not matches and major:
                cross_index = build_quota_match_index(session, "")
                cross_threshold = max(float(minimum_score) + 8.0, 50.0)
                matches = find_quota_composition_matches(
                    session,
                    row.get("name", ""), row.get("feature", ""), row.get("unit", ""),
                    major="", candidate_index=cross_index,
                    item_code=row.get("code", ""),
                    minimum_score=cross_threshold,
                    supplemental_minimum_score=cross_threshold + 8,
                    reference_price=self._reference_price(row),
                    source_costs=self._source_costs(row),
                    fallback_candidate_index=cross_index,
                )
                if matches:
                    row["cross_major_candidates"] = [
                        {
                            "quota_id": value["item"].id,
                            "quota_code": value["item"].code,
                            "quota_name": value["item"].name,
                            "score": value.get("score", 0),
                            "reasons": list(value.get("reasons") or []),
                        }
                        for value in matches[:5]
                    ]
                    row["cross_major_match"] = True
                    row["cross_major_source"] = major
                    row["blocked_by_major"] = True
                    matches = []
                    row["note"] = "；".join(dict.fromkeys([
                        value for value in (
                            row.get("note"),
                            f"本专业（{major}）无合格候选，已发现跨专业候选但未计入综合单价",
                            "跨专业候选仅供复核，必须确认专业、施工工艺和含量后才能人工选择",
                        ) if value
                    ]))
            if matches:
                row["score"] = matches[0]["score"]
                row["quota_id"] = matches[0]["item"].id
                row["match_reasons"] = list(matches[0]["reasons"])
                row["evidence_level"] = (
                    "red"
                    if any(str(value.get("evidence_level") or "") == "red" for value in matches)
                    else ("green" if matches[0]["score"] >= 0.75 else "yellow")
                )
            # Keep only the best local candidate in the row. The remaining
            # candidates are useful for internal ranking only.
            for match in matches[:1]:
                self._append_quota_reference(
                    row,
                    quota_reference_dict(match["item"]),
                    role=match["role"], score=match["score"],
                    reasons=match["reasons"], source_clause=match["source_clause"],
                    components_override=match.get("components"),
                    matched_source_clauses=match.get("matched_source_clauses"),
                )
            normalize_quota_row_matches(row)
            if matches:
                self._ensure_source_cost_components(row)
                self._apply_price_priority(session, row)
                self._calculate_row_from_compositions(row)
            else:
                fallback = build_base_data_fallback(
                    session,
                    row,
                    project_id,
                    major=major,
                    minimum_score=minimum_score,
                    include_unconfirmed=False,
                    region_override=self._selected_source_region(),
                )
                if fallback and fallback.get("auto_apply"):
                    self._apply_ai_result(
                        row,
                        self._base_fallback_as_ai_result(fallback),
                    )
                    base_fallback_applied = True
        finally:
            session.close()
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()
        auto_audit_started = self._auto_audit_rows([row_index])
        if not row.get("quota_ids") and not row.get("generated_quota"):
            QMessageBox.information(
                self,
                "本行未匹配",
                "本地定额库没有通过造价逻辑校验的结果，可使用“AI匹配/生成本行”或“基础库兜底本行”复核。",
            )
        elif base_fallback_applied:
            QMessageBox.information(
                self,
                "基础库兜底完成",
                "定额库无匹配，已调用固定工程清单库或已确认信息价形成项目级补充定额，请在下方明细中复核。",
            )
        elif auto_audit_started:
            QMessageBox.information(
                self,
                "已启动AI核查",
                "本地匹配已完成，低置信结果正在自动进行AI核查，核查结论会再次要求人工确认。",
            )

    def _ai_match_row(self):
        row = self._current_boq_row()
        if row is None:
            QMessageBox.information(self, "未选择清单", "请先在上方选择一条清单。")
            return
        if not row.get("name") or not row.get("unit"):
            QMessageBox.warning(self, "信息不足", "本行至少需要工程名称和单位，才能进行 AI 匹配、市场估算或联网检索。")
            return
        specification_message = self._specification_review_message(row)
        if specification_message:
            QMessageBox.warning(
                self,
                "AI匹配前请确认规格",
                specification_message + "。AI不会擅自猜测缺失规格，建议先双击项目特征进行编辑。",
            )
        if getattr(self, "_ai_worker", None) is not None and self._ai_worker.isRunning():
            QMessageBox.information(self, "AI 正在处理", "请等待当前 AI 匹配完成。")
            return
        project_id = self._active_project_id()
        if not project_id:
            self._prompt_select_project("AI匹配和市场估算")
            return
        from src.ai_service import ai
        if not ai.is_available:
            QMessageBox.information(self, "AI 未配置", "请先在系统设置中配置并测试 DeepSeek；本地定额匹配不受影响。")
            return
        self._ai_row_index = self._table.currentRow()
        selected_major = _text(row.get("major") or self._major.currentData() or "")
        row["major"] = selected_major
        cache_key = self._ai_cache_key(
            row,
            "fallback",
            project_id,
            self._selected_source_region(),
        )
        cached = self._cached_ai_result(row, "fallback", cache_key)
        if cached is not None:
            self._stats_label.setText("已读取本条清单的AI缓存结果，未重复调用AI")
            self._on_ai_match_result(cached)
            return
        self._ai_cache_key_pending = cache_key
        self._ai_worker = QuotaAIWorker(
            project_id,
            {
                "code": row.get("code", ""),
                "name": row.get("name", ""),
                "feature": row.get("feature", ""),
                "unit": row.get("unit", ""),
                "quantity": row.get("quantity", ""),
                "major": _text(row.get("major") or self._major.currentData() or ""),
            },
            selected_major,
            region_override=self._selected_source_region(),
            generation=self._match_generation,
        )
        self._ai_worker.finished.connect(self._on_ai_match_result)
        self._ai_worker.error.connect(self._on_ai_match_error)
        self._ai_worker.status.connect(self._stats_label.setText)
        self._ai_worker.start()
        self._stats_label.setText(
            f"正在 AI 复核第 {self._ai_row_index + 1} 行；无可靠本地结果时将自动联网检索人材机…"
        )

    def _on_ai_match_error(self, message: str):
        QMessageBox.warning(self, "AI 匹配失败", message)
        self._stats_label.setText("AI 匹配失败，请检查网络、API Key 或项目资料")

    def _on_ai_match_result(self, result: dict):
        row_index = getattr(self, "_ai_row_index", -1)
        if not self._async_result_is_current(result, row_index):
            self._stats_label.setText("已忽略过期AI结果：当前清单或项目已发生变化")
            return
        row = self._rows[row_index]
        self._ai_result = result
        cache_key = getattr(self, "_ai_cache_key_pending", "")
        if cache_key:
            self._save_cached_ai_result(row, "fallback", cache_key, result)
            self._ai_cache_key_pending = ""
        if result.get("errors"):
            result["valid"] = False
            result["actionable"] = False
            result["decision"] = "none"
            row["note"] = "AI结果未写入：" + "；".join(str(value) for value in result["errors"][:5])
            row["evidence_level"] = "red"
            self._pending_ai_results.pop(row_index, None)
            self._render_table()
            self._save_results(show_message=False)
            guidance = result.get("price_source_guidance") or {}
            if guidance:
                self._show_price_source_guidance(
                    guidance,
                    heading="AI结果需要补充价格依据",
                    summary=row["note"],
                )
            else:
                QMessageBox.warning(self, "AI结果未写入", row["note"])
            return
        if result.get("decision") == "generate" and result.get("generated_quota"):
            generated = result["generated_quota"]
            result["evidence_level"] = result.get("evidence_level") or "red"
            result["valid"] = bool(result.get("valid"))
        elif result.get("decision") == "existing":
            result["valid"] = bool(result.get("matches"))
        else:
            result["valid"] = False

        # A result that passed the structural, object, specification, unit and
        # calculation gates is already actionable. Apply it immediately; the
        # review dialog is not a second approval gate. Warnings remain attached
        # to the row for post-match review and export.
        can_auto_apply = bool(
            (result.get("decision") == "existing" and result.get("matches"))
            or (
                result.get("decision") == "generate"
                and (result.get("generated_quota") or {}).get("components")
                and result.get("actionable", result.get("valid", False))
            )
        )
        if can_auto_apply:
            applied = self._apply_ai_result(row, result)
            if applied:
                warning_values = [
                    str(value).strip()
                    for value in (result.get("warnings") or [])
                    if str(value).strip()
                ]
                if warning_values:
                    row["audit_issues"] = list(dict.fromkeys([
                        *(row.get("audit_issues") or []),
                        *warning_values,
                    ]))
                    row["note"] = "；".join(dict.fromkeys([
                        str(row.get("note") or "").strip(),
                        "AI已自动应用结果，以下为事后复核提示：" + "；".join(warning_values[:4]),
                    ]))
                self._pending_ai_results.pop(row_index, None)
                self._render_table()
                self._save_results(show_message=False)
                self.data_changed.emit()
                self._stats_label.setText("AI结果已自动确认并写入；风险提示已保留在当前清单")
                guidance = result.get("price_source_guidance") or {}
                if guidance:
                    self._show_price_source_guidance(
                        guidance,
                        heading="AI结果已写入，建议补充官方信息价",
                        summary="当前行已完成计算；价格来源提示已保留。")
                return
        self._pending_ai_results[row_index] = dict(result)
        dialog = QuotaAIReviewDialog(row, result, self)
        if dialog.exec() != QDialog.Accepted:
            self._stats_label.setText("AI 结果未应用，当前清单保持原结果")
            return
        self._apply_ai_result(row, result)
        self._pending_ai_results.pop(row_index, None)

    @staticmethod
    def _base_fallback_as_ai_result(fallback: dict) -> dict:
        generated = dict(fallback.get("generated_quota") or {})
        return {
            "decision": "generate",
            "source_type": str(fallback.get("source_type") or "base_fallback"),
            "generated_quota": generated,
            "evidence_level": str(fallback.get("evidence_level") or generated.get("evidence_level") or "red"),
            "valid": bool(fallback.get("actionable")),
            "actionable": bool(fallback.get("actionable")),
            "summary": str(fallback.get("summary") or "定额库无匹配，已调用基础库数据"),
            "errors": list(fallback.get("errors") or []),
            "warnings": list(fallback.get("warnings") or []),
        }

    def _base_fallback_current_row(self):
        row_index = self._table.currentRow()
        row = self._current_boq_row()
        if row is None:
            QMessageBox.information(self, "未选择清单", "请先在上方选择一条清单。")
            return
        if not row.get("name") or not row.get("unit"):
            QMessageBox.warning(self, "信息不足", "基础库换算至少需要工程名称和单位。")
            return
        project_id = self._active_project_id()
        session = get_session()
        try:
            fallback = build_base_data_fallback(
                session,
                row,
                project_id,
                major=_text(row.get("major") or self._major.currentData() or ""),
                minimum_score=45,
                include_unconfirmed=True,
                region_override=self._selected_source_region(),
            )
        finally:
            session.close()
        if not fallback:
            QMessageBox.information(
                self,
                "基础库没有可用数据",
                "本地固定工程清单库、已确认信息价和地区标准中没有能用于本条清单的换算证据。",
            )
            return
        result = self._base_fallback_as_ai_result(fallback)
        self._pending_ai_results[row_index] = dict(result)
        dialog = QuotaAIReviewDialog(row, result, self)
        if dialog.exec() != QDialog.Accepted:
            self._stats_label.setText("基础库结果未应用，当前清单保持原结果")
            return
        self._apply_ai_result(row, result)
        self._pending_ai_results.pop(row_index, None)
        if result.get("price_source_guidance"):
            self._show_price_source_guidance(
                result["price_source_guidance"],
                heading="AI结果已写入，建议补充官方信息价",
                summary="当前行已按AI市场估算写入并标记人工复核。",
            )

    def _update_ai_fallback_progress(self):
        # Kept as a compatibility wrapper for single-row AI actions. The page
        # now has one cumulative progress bar for every matching stage.
        self._update_matching_progress()

    def _start_ai_fallback_for_indexes(
        self,
        row_indexes: list[int],
        *,
        reference_region: str = "",
    ) -> bool:
        row_indexes = list(dict.fromkeys(
            int(index)
            for index in row_indexes
            if 0 <= int(index) < len(self._rows)
        ))
        if not row_indexes:
            return False
        if not self._pipeline_active:
            self._begin_matching_pipeline(0, "AI兜底匹配中...")
        if getattr(self, "_ai_fallback_worker", None) is not None and self._ai_fallback_worker.isRunning():
            self._stats_label.setText("已有AI兜底任务在后台运行，当前结果会继续写入")
            return False
        project_id = self._active_project_id()
        if not project_id:
            return False
        from src.ai_service import ai
        if not ai.is_available:
            self._ai_fallback_total = len(row_indexes)
            self._ai_fallback_completed = len(row_indexes)
            self._ai_fallback_failed = len(row_indexes)
            self._ai_fallback_stage_done = True
            for index in row_indexes:
                row = self._rows[index]
                row["ai_fallback_pending"] = False
                row["note"] = "本地定额未找到，AI未配置，需人工复核"
                row["evidence_level"] = "red"
            self._render_table()
            self._save_results(show_message=False)
            return False
        items = []
        cached_items = []
        for index in row_indexes:
            selected_major = _text(
                self._rows[index].get("major") or self._major.currentData() or ""
            )
            self._rows[index]["major"] = selected_major
            item = {
                "code": self._rows[index].get("code", ""),
                "name": self._rows[index].get("name", ""),
                "feature": self._rows[index].get("feature", ""),
                "unit": self._rows[index].get("unit", ""),
                "quantity": self._rows[index].get("quantity", ""),
                "major": selected_major,
                "seq": self._rows[index].get("seq", index + 1),
                "similar_project_results": self._similar_project_results(index),
            }
            key = self._ai_cache_key(
                item, "fallback", project_id, reference_region,
            )
            cached = self._cached_ai_result(self._rows[index], "fallback", key)
            if cached is not None:
                cached_items.append({
                    "row_index": index,
                    "boq": item,
                    "result": cached,
                    "error": "",
                    "cache_hit": True,
                    "match_generation": self._match_generation,
                    "row_input_key": self._row_input_key(item),
                    "project_id": project_id,
                })
            else:
                items.append((index, item))
        # Cached rows are part of the same visible work total: they finish
        # immediately, but must not make the progress jump backwards.
        self._ai_fallback_total = len(items) + len(cached_items)
        self._ai_fallback_completed = 0
        self._ai_fallback_applied = 0
        self._ai_fallback_failed = 0
        self._ai_fallback_stage_done = not items
        self._update_ai_fallback_progress()
        for cached_item in cached_items:
            self._on_ai_fallback_row_result(cached_item)
        if not items:
            self._stats_label.setText(
                f"AI兜底已读取缓存结果 {len(cached_items)} 条，未重复调用AI"
            )
            return bool(cached_items)
        self._ai_fallback_worker = QuotaAIFallbackBatchWorker(
            project_id,
            items,
            _text(self._rows[row_indexes[0]].get("major") or self._major.currentData() or ""),
            reference_region,
            generation=self._match_generation,
        )
        self._ai_fallback_indexes = list(row_indexes)
        self._ai_fallback_worker.finished.connect(self._on_ai_fallback_batch_result)
        self._ai_fallback_worker.error.connect(self._on_ai_fallback_batch_error)
        self._ai_fallback_worker.status.connect(self._stats_label.setText)
        self._ai_fallback_worker.row_finished.connect(self._on_ai_fallback_row_result)
        self._ai_fallback_worker.start()
        self._pipeline_status = f"AI兜底匹配中（{len(items)} 条联网/模型任务）..."
        self._update_matching_progress()
        self._stats_label.setText(f"AI兜底匹配已转后台，正在处理 {len(items)} 行...")
        return True

    def _similar_project_results(self, target_index: int) -> list[dict]:
        """Return nearby priced siblings for structure comparison, never direct copying."""
        if not (0 <= target_index < len(self._rows)):
            return []
        target = self._rows[target_index]

        def normalized(row: dict) -> str:
            text = f"{row.get('name', '')} {row.get('feature', '')}"
            text = re.sub(r"(?i)_?x000d_?", "", text)
            text = re.sub(r"[（(][^）)]{0,30}[）)]", "", text)
            return re.sub(r"\s+", "", text)

        def headline(row: dict) -> str:
            text = str(row.get("name", "")).splitlines()[0]
            text = re.sub(r"(?i)_?x000d_?", "", text)
            text = re.sub(r"[（(][^）)]{0,30}[）)]", "", text)
            return re.sub(r"\s+", "", text)

        target_text = normalized(target)
        target_headline = headline(target)
        ranked = []
        for index, row in enumerate(self._rows):
            if index == target_index or row.get("unit") != target.get("unit"):
                continue
            generated = row.get("generated_quota") or {}
            source_components = generated.get("components") or row.get("compositions") or []
            source_components = [
                value for value in source_components
                if value.get("included", True)
                and _numeric(value.get("qty")) > 0
                and _numeric(value.get("noTaxPrice")) > 0
            ]
            if not source_components:
                continue
            headline_score = SequenceMatcher(None, target_headline, headline(row)).ratio()
            detail_score = SequenceMatcher(None, target_text, normalized(row)).ratio()
            score = headline_score * 0.55 + detail_score * 0.45
            # A similar block of boilerplate must not make a different work
            # item eligible. The item headline remains the primary gate.
            if headline_score < 0.55 or score < 0.64:
                continue
            ranked.append((score, headline_score, detail_score, row, source_components))
        ranked.sort(key=lambda value: (value[0], value[1], value[2]), reverse=True)
        references = []
        for score, headline_score, detail_score, row, source_components in ranked[:3]:
            components = []
            for value in source_components[:15]:
                components.append({
                    key: value.get(key)
                    for key in (
                        "cat", "code", "name", "feature", "unit", "qty", "loss",
                        "unitConversion", "noTaxPrice", "taxRate", "taxPrice",
                        "calculationBasis", "note",
                    )
                })
            references.append({
                "similarity": round(score, 4),
                "headline_similarity": round(headline_score, 4),
                "detail_similarity": round(detail_score, 4),
                "source_name": row.get("name", ""),
                "source_feature": row.get("feature", ""),
                "source_unit": row.get("unit", ""),
                "structure_only": True,
                "must_compare": [
                    "工程对象和铺装/安装工艺是否相同",
                    "主材名称、材质、规格、厚度、颜色是否不同",
                    "基层、找平层、结合层及配合比是否不同",
                    "单位含量是否需按当前尺寸重新换算",
                    "损耗是否与理论含量重复计算",
                    "价格是否符合当前信息来源地区和最新计价期",
                ],
                "warning": "仅借鉴共同组成；差异分量必须按当前清单重算，禁止照抄综合单价、含量或价格",
                "components": components,
            })
        return references

    def _ai_fallback_selected(self):
        row_indexes = self._selected_row_indexes()
        if not row_indexes:
            current = self._table.currentRow()
            if 0 <= current < len(self._rows) and not self._table.isRowHidden(current):
                row_indexes = [current]
        if not row_indexes:
            QMessageBox.information(self, "没有选择清单", "请选择1行或按住Ctrl/Shift选择多行。")
            return
        if not self._active_project_id():
            self._prompt_select_project("AI兜底匹配")
            return
        session = get_session()
        try:
            project = session.query(Project).filter(Project.id == self._active_project_id()).first()
        finally:
            session.close()
        # The selected information-price region is independent of project
        # identity. An empty selector intentionally means latest library data.
        region = self._selected_source_region()
        if not self._start_ai_fallback_for_indexes(row_indexes, reference_region=region):
            if getattr(self, "_ai_fallback_worker", None) is None:
                QMessageBox.information(self, "AI未配置或任务未启动", "请先配置AI服务，或等待当前AI任务完成。")

    def _on_ai_fallback_batch_error(self, message: str):
        worker = getattr(self, "_ai_fallback_worker", None)
        if worker is not None and int(getattr(worker, "generation", self._match_generation)) != self._match_generation:
            self._stats_label.setText("已忽略过期AI任务：当前清单或项目已发生变化")
            return
        total = int(self._ai_fallback_total or 0)
        self._ai_fallback_completed = total
        self._ai_fallback_failed = max(total - int(self._ai_fallback_applied or 0), 0)
        for row_index in getattr(self, "_ai_fallback_indexes", []) or []:
            if 0 <= row_index < len(self._rows):
                row = self._rows[row_index]
                row["ai_fallback_pending"] = False
                row["note"] = "AI兜底任务失败：" + str(message)
                row["evidence_level"] = "red"
        self._ai_fallback_indexes = []
        self._ai_fallback_stage_done = True
        self._update_ai_fallback_progress()
        self._render_table()
        self._save_results(show_message=False)
        QMessageBox.warning(self, "AI兜底匹配失败", message)
        self._stats_label.setText("AI兜底匹配失败，请检查网络、API Key或项目资料")

    def _on_ai_fallback_row_result(self, item: dict):
        row_index = int(item.get("row_index") or -1)
        if not self._async_result_is_current(item, row_index):
            return
        if not (0 <= row_index < len(self._rows)):
            return
        row = self._rows[row_index]
        result = item.get("result")
        row["ai_fallback_pending"] = False
        if result and not item.get("cache_hit"):
            cache_key = self._ai_cache_key(
                item.get("boq") or row,
                "fallback",
                self._active_project_id(),
                self._selected_source_region(),
            )
            self._save_cached_ai_result(row, "fallback", cache_key, result)
        if result is not None:
            self._ai_result = result
            self._ai_row_index = row_index
        if result and result.get("valid", result.get("actionable", False)):
            applied = self._apply_ai_result(row, result)
            if applied:
                self._ai_fallback_applied += 1
                self._pending_ai_results.pop(row_index, None)
            else:
                self._ai_fallback_failed += 1
                self._pending_ai_results[row_index] = result
        else:
            result = result or {}
            reasons = [
                item.get("error"),
                result.get("summary"),
                *(result.get("errors") or []),
                *(result.get("warnings") or []),
            ]
            reasons = list(dict.fromkeys(
                str(value).strip() for value in reasons if str(value or "").strip()
            ))
            generated = result.get("generated_quota") or {}
            generated_but_invalid = bool(
                result.get("decision") == "generate" and generated.get("components")
            )
            row["ai_validation_failed"] = generated_but_invalid
            if generated_but_invalid:
                row["ai_candidate_quota"] = generated
            else:
                row.pop("ai_candidate_quota", None)
            row["note"] = (
                ("AI已生成但校验未通过：" if generated_but_invalid else "AI兜底未写入：")
                + "；".join(reasons[:3])
                if reasons
                else "AI兜底未形成可计算结果，需人工复核"
            )
            row["evidence_level"] = "red"
            self._ai_fallback_failed += 1
            self._pending_ai_results.pop(row_index, None)
        self._ai_fallback_completed = min(
            self._ai_fallback_completed + 1,
            self._ai_fallback_total or self._ai_fallback_completed + 1,
        )
        self._update_ai_fallback_progress()
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()
        self._maybe_finish_matching_pipeline()

    def _on_ai_fallback_batch_result(self, payload: dict):
        items = payload.get("results") or []
        for item in items:
            row_index = int(item.get("row_index") or -1)
            if self._async_result_is_current(item, row_index) and 0 <= row_index < len(self._rows):
                self._rows[row_index]["ai_fallback_pending"] = False
        self._ai_fallback_indexes = []
        self._ai_fallback_stage_done = True
        # row_finished 已经逐行完成最终校验和写入；这里仅汇总真实结果，
        # 不再依据 AI 第一次 validation 的 valid 字段虚报写入数。
        applied = int(self._ai_fallback_applied or 0)
        self._ai_fallback_total = max(int(self._ai_fallback_total or 0), len(items))
        # Every row_finished callback has already advanced the cumulative
        # counter, including cached rows. Do not reset it to the worker-only
        # count here.
        self._ai_fallback_completed = min(
            max(int(self._ai_fallback_completed or 0), 0),
            int(self._ai_fallback_total or 0),
        )
        self._ai_fallback_applied = applied
        self._ai_fallback_failed = max(len(items) - applied, 0)
        self._update_ai_fallback_progress()
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()
        self._stats_label.setText(
            f"AI兜底匹配完成：处理 {len(items)} 行，应用 {applied} 行；AI结果已标注，请人工复核"
        )
        self._pipeline_status = "AI兜底匹配完成，等待AI复核..." if self._ai_audit_total else "匹配流程完成"
        self._update_matching_progress()
        self._maybe_finish_matching_pipeline()
        guidance_values = [
            item["result"].get("price_source_guidance")
            for item in items
            if item.get("result") and item["result"].get("price_source_guidance")
        ]
        guidance = next(
            (value for value in guidance_values if value.get("kind") == "login_required"),
            guidance_values[0] if guidance_values else None,
        )
        selected_region = self._selected_source_region()
        if guidance and guidance.get("kind") == "missing_region" and selected_region:
            # A worker may finish with an older/incomplete context while the
            # user has already selected a source region in the page.
            guidance = None
        summary = (
            f"已逐行处理 {len(items)} 条，直接写入 {applied} 条。\n"
            "所有AI结果已标注，仍需人工复核。"
        )
        if guidance:
            self._show_price_source_guidance(
                guidance,
                heading="AI兜底匹配完成",
                summary=summary,
            )
        else:
            QMessageBox.information(self, "AI兜底匹配完成", summary)

    def _show_price_source_guidance(
        self,
        guidance: dict,
        *,
        heading: str,
        summary: str,
    ):
        """Give one explicit next step without interrupting every batch row."""
        if guidance.get("kind") == "missing_region" and self._selected_source_region():
            return
        route = _text(guidance.get("route")) or "subscription"
        city_query = _text(guidance.get("city_query"))
        box = QMessageBox(self)
        box.setWindowTitle(heading)
        box.setIcon(QMessageBox.Information)
        box.setText(summary)
        detail = _text(guidance.get("message"))
        note = _text(guidance.get("note"))
        box.setInformativeText("\n".join(value for value in (detail, note) if value))
        action_label = "前往信息价官方订阅"
        action_button = box.addButton(action_label, QMessageBox.AcceptRole)
        box.addButton("稍后处理", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is not action_button:
            return
        if city_query:
            set_settings({
                "price_info_pending_city_query": city_query,
                "price_info_pending_period": _text(guidance.get("period")),
            })
        self.navigate_requested.emit(route)

    def _write_pending_ai_to_row(self):
        row_index = self._table.currentRow()
        row = self._current_boq_row()
        if row is None:
            QMessageBox.information(self, "未选择清单", "请先选择需要写入 AI 组价的清单行。")
            return
        result = self._pending_ai_results.get(row_index)
        if not result:
            if row.get("ai_generated") or row.get("generated_quota"):
                QMessageBox.information(
                    self,
                    "AI结果已经写入",
                    "当前行的 AI 组价已经计算并写入清单，无需重复操作。",
                )
            else:
                QMessageBox.information(
                    self,
                    "没有待写入AI结果",
                    "当前行没有尚未写入的 AI 组价，请先使用“AI兜底匹配”。",
                )
            return
        generated = result.get("generated_quota") or {}
        if not (
            result.get("valid", result.get("actionable", False))
            and generated.get("components")
            and generated.get("no_tax_price") is not None
        ):
            QMessageBox.information(
                self,
                "AI结果未通过计算校验",
                "当前 AI 结果缺少有效人材机或计算价格，不能写入清单。",
            )
            return
        self._apply_ai_result(row, result)
        self._pending_ai_results.pop(row_index, None)
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()
        self._stats_label.setText("AI组价已写入当前清单，请人工复核")

    @staticmethod
    def _should_auto_audit(row: dict) -> bool:
        if not row.get("quota_ids") and not row.get("generated_quota"):
            return False
        if row.get("ai_review_trigger"):
            return True
        if any(
            bool(composition_cost_breakdown(
                {**detail, "boqUnit": detail.get("boqUnit") or row.get("unit", "")},
                row.get("quantity"),
            ).get("conversionRequired"))
            for detail in row.get("compositions") or []
            if detail.get("included", True)
        ):
            return True
        score = float(row.get("score") or 0)
        if score < 0.50:
            return True
        report = build_quota_audit_report(
            {
                "code": row.get("code", ""),
                "name": row.get("name", ""),
                "feature": row.get("feature", ""),
                "unit": row.get("unit", ""),
                "quantity": row.get("quantity", ""),
                "major": row.get("major", ""),
            },
            {
                "quota_matches": row.get("quota_matches") or [],
                "compositions": row.get("compositions") or [],
                "audit_issues": row.get("audit_issues") or [],
                "evidence_level": row.get("evidence_level") or "red",
                "score": row.get("score") or 0,
                "generated_quota": row.get("generated_quota") or {},
                "labor": row.get("labor") or 0,
                "material": row.get("material") or 0,
                "machinery": row.get("machinery") or 0,
                "management": row.get("management") or 0,
                "profit": row.get("profit") or 0,
                "source_costs": QuotaMatchTab._source_costs(row),
                "fee_details": row.get("fee_details") or [],
                "comprehensive_price": row.get("comprehensive_price") or 0,
                "total_price": row.get("total_price") or 0,
                "source_comprehensive_price": row.get("source_comprehensive_price") or 0,
                "imported_comprehensive_price": row.get("imported_comprehensive_price") or 0,
                "historical_reference": row.get("historical_reference") or {},
            },
        )
        meaningful_issues = [
            issue for issue in report.get("issues") or []
            if isinstance(issue, dict)
            and issue.get("category") in {
                "人材机遗漏", "人材机管利遗漏", "重复匹配", "乱匹配",
                "计算错误", "信息不足", "单位换算", "匹配置信度",
                "综合价合理性",
            }
        ]
        return bool(
            report.get("needs_correction")
            or meaningful_issues
            or row.get("audit_issues")
            or row.get("evidence_level") in {"red", "yellow"}
        )

    def _start_ai_audit(self, row_indexes: list[int]):
        row_indexes = list(dict.fromkeys(
            int(index)
            for index in row_indexes
            if 0 <= int(index) < len(self._rows)
        ))
        if not row_indexes:
            return False
        project_id = self._active_project_id()
        if not project_id:
            return False
        from src.ai_service import ai
        if not ai.is_available:
            return False
        if not self._pipeline_active:
            self._begin_matching_pipeline(0, "AI复核中...")
        if getattr(self, "_ai_audit_worker", None) is not None and self._ai_audit_worker.isRunning():
            return False

        items = []
        cached_audit_count = 0
        self._ai_audit_skipped = False
        for row_index in row_indexes:
            row = self._rows[row_index]
            if row.get("compositions"):
                self._calculate_row_from_compositions(row)
            if not self._should_auto_audit(row):
                continue
            audit_major = _text(row.get("major") or self._major.currentData() or "")
            row["major"] = audit_major
            boq = {
                "code": row.get("code", ""),
                "name": row.get("name", ""),
                "feature": row.get("feature", ""),
                "unit": row.get("unit", ""),
                "quantity": row.get("quantity", ""),
                "major": audit_major,
                "seq": row.get("seq", row_index + 1),
            }
            current = {
                "quota_matches": row.get("quota_matches") or [],
                "compositions": row.get("compositions") or [],
                "audit_issues": row.get("audit_issues") or [],
                "evidence_level": row.get("evidence_level") or "red",
                "score": row.get("score") or 0,
                "generated_quota": row.get("generated_quota") or {},
                "analysis": row.get("analysis") or "",
                "note": row.get("note") or "",
                "labor": row.get("labor") or 0,
                "material": row.get("material") or 0,
                "machinery": row.get("machinery") or 0,
                "management": row.get("management") or 0,
                "profit": row.get("profit") or 0,
                "source_costs": self._source_costs(row),
                "fee_details": row.get("fee_details") or [],
                "comprehensive_price": row.get("comprehensive_price") or 0,
                "total_price": row.get("total_price") or 0,
                "source_comprehensive_price": row.get("source_comprehensive_price") or 0,
                "imported_comprehensive_price": row.get("imported_comprehensive_price") or 0,
                "historical_reference": row.get("historical_reference") or {},
            }
            report = build_quota_audit_report(boq, current)
            current["local_audit_report"] = report
            current["audit_issues"] = list(dict.fromkeys([
                *(current.get("audit_issues") or []),
                *(str(value.get("message") or "") for value in report.get("issues") or []),
            ]))
            cache_key = self._ai_cache_key(
                boq,
                "audit",
                project_id,
                self._selected_source_region(),
                current=current,
            )
            cached = self._cached_ai_result(row, "audit", cache_key)
            if cached is not None:
                self._apply_ai_audit_item({
                    "row_index": row_index,
                    "boq": boq,
                    "current": current,
                    "audit": cached.get("audit") or {},
                    "correction": cached.get("correction"),
                })
                cached_audit_count += 1
            else:
                items.append((row_index, boq, current))
        self._ai_audit_indexes = list(dict.fromkeys(int(index) for index in row_indexes))
        self._ai_audit_total = len(items) + cached_audit_count
        self._ai_audit_completed = cached_audit_count
        self._ai_audit_stage_done = not items
        self._pipeline_status = "AI复核中..."
        self._update_matching_progress()
        if not items:
            if cached_audit_count:
                self._render_table()
                self._save_results(show_message=False)
                self.data_changed.emit()
                self._stats_label.setText(
                    f"AI核查已读取缓存结果 {cached_audit_count} 条，未重复调用AI"
                )
                self._pipeline_status = "匹配流程完成"
                self._update_matching_progress()
                self._maybe_finish_matching_pipeline()
                return True
            self._ai_audit_skipped = True
            self._stats_label.setText("本地规则预检通过，未发现需要AI核查与纠正的行")
            return False
        self._ai_audit_worker = QuotaAuditWorker(
            project_id,
            items,
            self._major.currentData() or "",
            region_override=self._selected_source_region(),
            generation=self._match_generation,
        )
        self._ai_audit_worker.finished.connect(self._on_ai_audit_result)
        self._ai_audit_worker.error.connect(self._on_ai_audit_error)
        self._ai_audit_worker.status.connect(self._stats_label.setText)
        self._ai_audit_worker.row_finished.connect(self._on_ai_audit_row_result)
        self._ai_audit_worker.start()
        self._update_matching_progress()
        self._stats_label.setText(
            f"AI正在核查与纠正 {len(items)} 行已匹配组价..."
            + (f"；已读取缓存 {cached_audit_count} 条" if cached_audit_count else "")
        )
        return True

    def _auto_audit_rows(self, row_indexes: list[int]) -> bool:
        if not self._auto_ai_audit.isChecked():
            return False
        candidates = [
            int(index)
            for index in row_indexes
            if 0 <= int(index) < len(self._rows)
            and self._should_auto_audit(self._rows[int(index)])
        ]
        return self._start_ai_audit(candidates)

    def _ai_audit_correct(self):
        selected = self._selected_row_indexes()
        row_indexes = selected or [
            index
            for index, row in enumerate(self._rows)
            if self._row_is_matched(row)
        ]
        row_indexes = [
            index
            for index in row_indexes
            if 0 <= index < len(self._rows) and self._row_is_matched(self._rows[index])
        ]
        if not row_indexes:
            QMessageBox.information(self, "没有可核查组价", "请先匹配定额或选择已匹配的清单行。")
            return
        if not self._start_ai_audit(row_indexes):
            if getattr(self, "_ai_audit_skipped", False):
                QMessageBox.information(
                    self,
                    "本地核查通过",
                    "当前选择行已通过本地人材机、重复和计算规则预检，无需调用 AI。",
                )
            else:
                QMessageBox.information(self, "无法启动AI核查", "请检查项目、AI配置或当前AI任务状态。")

    def _on_ai_audit_error(self, message: str):
        self._ai_audit_completed = self._ai_audit_total
        self._ai_audit_indexes = []
        self._ai_audit_stage_done = True
        self._pipeline_status = "AI复核失败，匹配流程结束"
        self._update_matching_progress()
        self._maybe_finish_matching_pipeline()
        QMessageBox.warning(self, "AI核查失败", message)
        self._stats_label.setText("AI核查失败，请检查网络、API Key或项目资料")

    def _apply_ai_audit_item(self, item: dict) -> bool:
        row_index = int(item.get("row_index") or -1)
        if not (0 <= row_index < len(self._rows)):
            return False
        row = self._rows[row_index]
        audit = item.get("audit") or {}
        correction = item.get("correction") or {}
        row["ai_review_pending"] = False
        corrected = bool(
            correction
            and correction.get("valid", correction.get("actionable", False))
        )
        if corrected:
            self._apply_ai_result(row, correction)

        findings = audit.get("findings") or []
        audit_label = (
            "AI核查发现问题：" + "；".join(
                str(finding.get("message") or "")
                for finding in findings[:5]
                if isinstance(finding, dict)
            )
            if findings
            else "AI核查通过，仍需人工复核"
        )
        row["ai_audited"] = True
        row["ai_audit_summary"] = str(audit.get("summary") or audit_label)
        row["ai_audit_findings"] = [
            dict(finding) for finding in findings if isinstance(finding, dict)
        ]
        row["local_audit_report"] = {
            "issues": list(row["ai_audit_findings"]),
            "needs_correction": bool(audit.get("needs_correction")),
        }
        existing_note = str(row.get("note") or "").strip()
        row["note"] = "；".join(
            value for value in (audit_label, existing_note) if value
        )
        if row.get("evidence_level") == "red":
            row["evidence_level"] = "yellow"
        row["match_reasons"] = [
            *(row.get("match_reasons") or []),
            f"AI核查：{audit_label}",
        ]
        return corrected

    def _on_ai_audit_row_result(self, item: dict):
        row_index = int(item.get("row_index") or -1)
        if self._async_result_is_current(item, row_index) and 0 <= row_index < len(self._rows):
            cache_key = self._ai_cache_key(
                item.get("boq") or self._rows[row_index],
                "audit",
                self._active_project_id(),
                self._selected_source_region(),
                current=item.get("current") or {},
            )
            self._save_cached_ai_result(
                self._rows[row_index],
                "audit",
                cache_key,
                {
                    "audit": item.get("audit") or {},
                    "correction": item.get("correction"),
                },
            )
        self._apply_ai_audit_item(item)
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()
        if self._pipeline_active and self._ai_audit_total:
            self._ai_audit_completed = min(
                self._ai_audit_completed + 1,
                self._ai_audit_total,
            )
            self._update_matching_progress()
            self._maybe_finish_matching_pipeline()

    def _on_ai_audit_result(self, payload: dict):
        items = payload.get("results") or []
        corrected = sum(
            1
            for item in items
            if item.get("correction")
            and item["correction"].get(
                "valid",
                item["correction"].get("actionable", False),
            )
        )
        # row_finished has counted each accepted row already. The final
        # signal only closes the worker stage and must not reset progress.
        self._ai_audit_completed = min(
            max(int(self._ai_audit_completed or 0), 0),
            int(self._ai_audit_total or 0),
        )
        self._ai_audit_indexes = []
        self._ai_audit_stage_done = True
        self._pipeline_status = "匹配流程完成"
        self._update_matching_progress()
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()
        self._maybe_finish_matching_pipeline()
        self._stats_label.setText(
            f"AI核查完成：核查 {len(items)} 行，自动纠正 {corrected} 行；所有AI结论已标注，请人工复核"
        )
        QMessageBox.information(
            self,
            "AI核查完成",
            f"已逐行核查 {len(items)} 条，自动纠正 {corrected} 条。\n"
            "所有AI结论已标注，仍需人工复核。",
        )

    def _apply_ai_result(self, row: dict, result: dict) -> bool:
        applied = False
        session = get_session()
        try:
            self._reset_row_match(row)
            decision = result.get("decision")
            if decision == "existing":
                # AI may return a legacy list, but a persisted row has one
                # formal quota only. Validate every returned candidate first,
                # then apply the best valid one; rejected candidates remain
                # audit evidence and never enter costing.
                valid_matches = []
                rejected_reasons = []
                for raw_match in result.get("matches") or []:
                    if not isinstance(raw_match, dict):
                        continue
                    try:
                        quota_id = int(raw_match.get("quota_id"))
                    except (TypeError, ValueError):
                        continue
                    item = get_quota_item(session, quota_id)
                    if item is None:
                        rejected_reasons.append(f"AI选择的本地定额不存在：{quota_id}")
                        continue
                    reference = quota_reference_dict(item)
                    scope_errors = quota_reference_scope_errors(
                        row.get("name", ""), row.get("feature", ""), reference,
                    )
                    if scope_errors:
                        rejected_reasons.extend(scope_errors)
                        continue
                    valid_matches.append((raw_match, item, reference))
                if rejected_reasons:
                    row["note"] = "；".join(dict.fromkeys(rejected_reasons))
                    row["evidence_level"] = "yellow"
                valid_matches.sort(
                    key=lambda value: float(value[0].get("confidence") or 0),
                    reverse=True,
                )
                if valid_matches:
                    match, item, reference = valid_matches[0]
                    score = min(max(float(match.get("confidence") or 0), 0.0), 1.0)
                    self._append_quota_reference(
                        row, reference,
                        role=match.get("role") or "主体",
                        score=score,
                        reasons=[match.get("reason") or "AI 复核"],
                        source_clause=match.get("source_clause") or "AI 复核",
                    )
                    row["match_reasons"].append(match.get("reason") or "AI 复核")
                    row["rejected_quota_matches"] = [
                        {
                            **other_match,
                            "rejected_reason": "AI返回多个候选，已按有效性和置信度只保留一条最佳定额",
                        }
                        for other_match, _item, _reference in valid_matches[1:]
                    ]
                normalize_quota_row_matches(row)
                if row.get("quota_ids"):
                    row["quota_id"] = row["quota_ids"][0]
                    row["score"] = min(max(float(row.get("score") or 0), 0.0), 1.0)
                    row["evidence_level"] = (
                        "yellow"
                        if rejected_reasons
                        else result.get("evidence_level") or "yellow"
                    )
                    self._apply_price_priority(session, row)
                    self._calculate_row_from_compositions(row)
                    applied = True
            elif decision == "generate":
                generated = dict(result.get("generated_quota") or {})
                generated["components"] = [dict(value) for value in generated.get("components") or []]
                final_validation = validate_ai_generated_quota(
                    {
                        "name": row.get("name", ""),
                        "feature": row.get("feature", ""),
                        "unit": row.get("unit", ""),
                    },
                    generated,
                    (result.get("context") or {}).get("market_prices") or [],
                )
                # Accept legacy AI payloads that were rejected only because
                # an ordinary labour/machine consumption lacked a prose basis.
                # The quantity and price checks below remain strict.
                legacy_basis_errors = [
                    value for value in final_validation.get("errors") or []
                    if "单位含量" in str(value)
                    and ("依据" in str(value) or "清单单位" in str(value))
                ]
                if legacy_basis_errors:
                    final_validation.setdefault("warnings", []).extend(
                        f"已兼容旧版校验：{value}；按清单单位计取，需人工复核"
                        for value in legacy_basis_errors
                    )
                    final_validation["errors"] = [
                        value for value in final_validation.get("errors") or []
                        if value not in legacy_basis_errors
                    ]
                if final_validation.get("errors"):
                    candidate = final_validation.get("quota") or generated
                    row["ai_candidate_quota"] = candidate
                    row["ai_validation_failed"] = True
                    row["note"] = "AI结果未写入：" + "；".join(
                        str(value) for value in final_validation["errors"][:6]
                    )
                    row["evidence_level"] = "red"
                    row["ai_generated"] = False
                    self._render_table()
                    self._save_results(show_message=False)
                    self.data_changed.emit()
                    self._stats_label.setText("AI结果未写入：规格或单位换算未通过强制校验")
                    return False
                generated = final_validation.get("quota") or generated
                generated["evidence_level"] = result.get("evidence_level") or generated.get("evidence_level") or "red"
                row["generated_quota"] = generated
                row["ai_generated"] = True
                row["score"] = float(generated.get("confidence") or 0)
                row["evidence_level"] = generated["evidence_level"]
                source_type = str(generated.get("source_type") or "")
                is_base = source_type.startswith("base_")
                is_web = source_type == "ai_web_research"
                row["match_reasons"] = [
                    (
                        "依据固定工程清单库、已确认信息价和基础数据库换算"
                        if is_base
                        else (
                            "AI根据清单工程名称、项目特征及工作内容联网检索人材机证据"
                            if is_web
                            else "AI依据清单工程名称、项目特征及工作内容生成"
                        )
                    ),
                    str(result.get("summary") or "AI 市场估算"),
                    str(generated.get("evidence_summary") or ""),
                ]
                reference = {
                    "quota_id": None,
                    "quota_code": generated.get("code", "AI补充定额"),
                    "quota_name": generated.get("name") or row.get("name", ""),
                    "compositions": generated.get("components") or [],
                }
                self._append_generated_reference(row, reference, generated)
                self._apply_price_priority(session, row)
                self._calculate_row_from_compositions(row)
                applied = True
            else:
                return False
        finally:
            session.close()
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()
        self._stats_label.setText("AI 结果已确认并应用；补充定额仅保存在本项目匹配结果中")
        return applied

    @staticmethod
    def _append_generated_reference(row: dict, reference: dict, generated: dict):
        source_type = str(generated.get("source_type") or "ai_generated_market_estimate")
        is_base = source_type.startswith("base_")
        is_web = source_type == "ai_web_research"
        role = (
            "基础库换算"
            if is_base
            else ("AI联网检索人材机" if is_web else "AI补充定额")
        )
        match = {
            "quota_id": None,
            "quota_code": reference.get("quota_code", ""),
            "quota_name": reference.get("quota_name", ""),
            "quota_feature": reference.get("quota_feature", ""),
            "quota_unit": reference.get("unit", ""),
            "role": role,
            "quota_factor": 1.0,
            "score": float(generated.get("confidence") or 0),
            "evidence_level": generated.get("evidence_level", "red"),
            "source_type": source_type,
            "reasons": [generated.get(
                "evidence_summary",
                "基础库换算" if is_base else ("AI联网检索人材机" if is_web else "AI市场估算"),
            )],
            "source_clause": "清单工程名称及项目特征/工作内容",
        }
        row.setdefault("quota_matches", []).append(match)
        for source_detail in reference.get("compositions") or []:
            detail = dict(source_detail)
            detail.update({
                "sourceQty": _numeric(detail.get("qty")),
                "quotaFactor": 1.0,
                "boqUnit": row.get("unit", ""),
                "forceFormula": True,
                "included": True,
                "quotaRole": role,
                "quotaId": None,
                "quotaCode": reference.get("quota_code", ""),
                "quotaName": reference.get("quota_name", ""),
                "matchScore": float(generated.get("confidence") or 0),
                "sourceClause": "清单工程名称及项目特征/工作内容",
                "evidenceLevel": detail.get("evidenceLevel") or generated.get("evidence_level", "red"),
                # The generated quota has already passed the unified full-row
                # object/craft/specification validator.  Do not run the older
                # component-only scope rule again during costing; it cannot see
                # valid materials inferred from the complete work process.
                "logicValidated": True,
                "logicValidationVersion": QuotaMatchTab.MATCHING_ALGORITHM_VERSION,
                "note": detail.get("note") or (
                    "基础库换算，确认后仅用于当前项目"
                    if is_base
                    else (
                        "AI联网检索证据，确认后仅用于当前项目"
                        if is_web
                        else "AI补充定额/市场估算，确认后仅用于当前项目"
                    )
                ),
            })
            detail = apply_explicit_unit_conversion(
                detail,
                f"{row.get('name', '')} {row.get('feature', '')}",
                row.get("unit", ""),
                strict=False,
            )
            detail.update(composition_cost_breakdown(detail, row.get("quantity")))
            row.setdefault("compositions", []).append(detail)
        normalize_quota_row_matches(row)

    @staticmethod
    def _append_quota_reference(
        row: dict,
        reference: dict,
        *,
        role: str,
        score: float,
        reasons: list[str],
        source_clause: str,
        quota_factor: float = 1.0,
        components_override: list[dict] | None = None,
        matched_source_clauses: list[str] | None = None,
    ):
        quota_id = reference.get("quota_id")
        row.setdefault("quota_ids", []).append(quota_id)
        row.setdefault("quota_matches", []).append({
            "quota_id": quota_id,
            "quota_code": reference.get("quota_code", ""),
            "quota_name": reference.get("quota_name", ""),
            "quota_feature": reference.get("quota_feature", ""),
            "role": role,
            "quota_factor": quota_factor,
            "score": score,
            "reasons": list(reasons),
            "source_clause": source_clause,
            "matched_source_clauses": list(matched_source_clauses or [source_clause]),
            "component_only": components_override is not None,
        })
        source_details = (
            components_override
            if components_override is not None
            else reference.get("compositions") or []
        )
        for source_detail in source_details:
            detail = dict(source_detail)
            low_similarity_supplement = (
                "低相似度" in str(role)
                or any("低相似度" in str(reason) for reason in reasons)
            )
            source_qty = _numeric(detail.get("sourceQty"), _numeric(detail.get("qty")))
            target_text = f"{row.get('name', '')} {row.get('feature', '')}"
            candidate_text = " ".join(
                _text(value)
                for value in (
                    reference.get("quota_code"),
                    reference.get("quota_name"),
                    reference.get("quota_feature"),
                    detail.get("name"),
                    detail.get("feature"),
                )
                if _text(value)
            )
            detail = apply_explicit_unit_conversion(
                detail,
                target_text,
                row.get("unit", ""),
                strict=False,
            )
            # For m3/m2 or kg/t materials, the explicit BOQ-unit conversion
            # already determines the quantity. Applying the separate quota
            # thickness factor again would double-count the adjustment.
            if not detail.get("physicalUnitConversionRequired"):
                detail = apply_specification_quantity_conversion(
                    detail,
                    target_text,
                    candidate_text,
                )
            if _numeric(detail.get("specConversionFactor"), 1.0) != 1.0:
                row.setdefault("match_reasons", []).append(
                    f"规格差异已换算材料含量：{detail.get('specConversionBasis') or detail.get('specConversionFactor')}"
                )
            if detail.get("specConversionWarning"):
                row.setdefault("match_reasons", []).append(detail["specConversionWarning"])
            if detail.get("unitQuantityCorrection"):
                row.setdefault("match_reasons", []).append(detail["unitQuantityCorrection"])
            if detail.get("unitConversionReview"):
                row.setdefault("match_reasons", []).append(detail["unitConversionReview"])
            detail.update({
                "sourceQty": source_qty,
                "quotaFactor": quota_factor,
                "boqUnit": row.get("unit", ""),
                "forceFormula": False,
                # A low-similarity substitute is evidence for review only. It
                # must never silently enter the comprehensive price.
                "included": not low_similarity_supplement,
                "excludedByEvidence": low_similarity_supplement,
                "quotaRole": role,
                "matchScore": score,
                "sourceClause": source_clause,
            })
            if low_similarity_supplement:
                detail["note"] = "；".join(filter(None, (
                    _text(detail.get("note")),
                    "低相似度补充，仅作候选证据，未计入综合单价；需人工确认后启用",
                )))
            detail.update(composition_cost_breakdown(detail, row.get("quantity")))
            row.setdefault("compositions", []).append(detail)
        normalize_quota_row_matches(row)

    def _selected_categories(self) -> set[str]:
        return {
            category
            for category, checkbox in self._category_checks.items()
            if checkbox.isChecked()
        }

    def _calculate_row_from_compositions(self, row: dict, reference: dict | None = None):
        # Enforce the single-winning-quota contract before every recalculation,
        # including rows restored from older project snapshots.
        normalize_quota_row_matches(row)
        source_reference_categories = self._ensure_source_cost_components(row)
        selected = self._selected_categories()
        totals = {category: 0.0 for category in [*self.EXPENSE_CATEGORIES, "管理费", "利润"]}
        other = 0.0
        audit_issues = []
        score = float(row.get("score") or 0)
        if 0 < score < LOW_CONFIDENCE_THRESHOLD / 100:
            audit_issues.append(f"匹配置信度仅{score:.0%}，请人工复核定额名称、工作内容和组成明细")
        audit_issues.extend(self._find_incomplete_specifications(row))
        machine_labor_issue = self._machine_labor_review_issue(row)
        if machine_labor_issue:
            audit_issues.append(machine_labor_issue)
        if source_reference_categories:
            audit_issues.append(
                "以下费用仅保留原表证据，未找到本地合适定额组成，必须人工复核："
                + "、".join(source_reference_categories)
            )
        if row.get("ai_generated") and row.get("evidence_level") == "red":
            audit_issues.append("AI补充定额缺少可靠的本地同期市场价格佐证，必须人工复核价格、含量和适用范围")
        for detail_index, detail in enumerate(row.get("compositions") or []):
            validated_current = bool(
                detail.get("logicValidated")
                and detail.get("logicValidationVersion") == self.MATCHING_ALGORITHM_VERSION
            )
            scope_errors = [] if validated_current else quota_reference_scope_errors(
                row.get("name", ""),
                row.get("feature", ""),
                {"compositions": [detail]},
            )
            if scope_errors:
                detail["included"] = False
                detail["blockedByLogic"] = True
                detail["logicValidationErrors"] = list(scope_errors)
                audit_issues.extend(scope_errors)
                continue
            # Compatibility repair for results saved by the old validator.
            # Non-material components such as 工日/m2 and 台班/m3 do not need
            # a physical dimension formula; stale conversion blocks must not
            # keep their comprehensive price at zero after an upgrade.
            detail_category = str(detail.get("cat") or detail.get("category") or "")
            if detail_category in {"材料费", "辅材费", "主材费"}:
                detail = apply_explicit_unit_conversion(
                    detail,
                    f"{row.get('name', '')} {row.get('feature', '')}",
                    row.get("unit", ""),
                    strict=False,
                )
                row["compositions"][detail_index] = detail
            if detail_category not in {"材料费", "辅材费", "主材费"}:
                if _numeric(detail.get("qty")) > 0 and _numeric(detail.get("noTaxPrice")) > 0:
                    detail["blockedByUnitConversion"] = False
                    detail["conversionRequired"] = False
                    detail["requiresUnitConversion"] = False
                    detail["unitConversionReview"] = ""
            detail.update(composition_cost_breakdown(detail, row.get("quantity")))
            if detail.get("specConversionFactor") not in (None, "", 1, 1.0):
                audit_issues.append(
                    f"{detail.get('name') or detail.get('code') or '未命名分量'}已按规格差异换算含量："
                    f"{detail.get('specConversionBasis') or detail.get('specConversionFactor')}"
                )
            if detail.get("specConversionWarning"):
                audit_issues.append(detail["specConversionWarning"])
            if detail.get("unitConversionReview"):
                audit_issues.append(detail["unitConversionReview"])
            component_unit = _text(detail.get("unit") or detail.get("componentUnit"))
            component_qty = _numeric(detail.get("qty"))
            boq_unit = _text(row.get("unit"))
            if (
                detail_category == "机械费"
                and component_unit in {"台班", "台", "班"}
                and boq_unit in {"m2", "m²", "m", "个"}
                and component_qty > 0.2
            ):
                audit_issues.append(
                    f"{detail.get('name') or detail.get('code') or '机械费'}单位含量{component_qty:g}{component_unit}/{boq_unit}偏高，"
                    "需按设备生产率和施工组织复核，未取得可靠依据前不得视为准确组价"
                )
            if (
                detail_category == "人工费"
                and component_unit in {"工日", "工日/"}
                and boq_unit in {"m2", "m²", "m", "个"}
                and component_qty > 0.5
            ):
                audit_issues.append(
                    f"{detail.get('name') or detail.get('code') or '人工费'}单位含量{component_qty:g}{component_unit}/{boq_unit}偏高，"
                    "需按施工工艺和劳动生产率复核"
                )
            if detail.get("blockedByQuantity") or not detail.get("quantityValid", True):
                audit_issues.append(
                    f"{detail.get('name') or detail.get('code') or '未命名分量'}的单位含量缺失或不大于0，"
                    "禁止计价，必须按清单单位和施工做法补齐含量"
                )
            if detail.get("blockedByLossRate"):
                audit_issues.append(
                    f"{detail.get('name') or detail.get('code') or '未命名分量'}损耗率为"
                    f"{_numeric(detail.get('loss')):g}%，禁止计价，必须复核损耗率"
                )
            if detail.get("conversionRequired"):
                audit_issues.append(
                    f"{detail.get('name') or detail.get('code') or '未命名分量'}的单位"
                    f"{detail.get('componentUnit') or detail.get('unit')}与清单单位"
                    f"{detail.get('engineeringUnit') or row.get('unit')}不一致，缺少换算公式"
                )
            category = str(detail.get("cat") or "")
            if not detail.get("included", True):
                continue
            if category in self.EXPENSE_CATEGORIES and category not in selected:
                continue
            value = float(detail.get("unitNoTaxTotal") or 0)
            if detail.get("blockedByUnitConversion"):
                # A raw incompatible-unit amount must never enter the row total.
                value = 0.0
                detail["calculatedNoTaxTotal"] = ""
                detail["calculatedTaxTotal"] = ""
                continue
            if detail.get("blockedByQuantity"):
                # Missing consumption is different from a zero-priced item:
                # keep the row visible, but never manufacture a quantity or
                # reuse a stale source total.
                value = 0.0
                detail["calculatedNoTaxTotal"] = ""
                detail["calculatedTaxTotal"] = ""
                continue
            if detail.get("included", True) and not _numeric(detail.get("noTaxPrice")):
                audit_issues.append(f"{detail.get('name') or detail.get('code') or '未命名分量'}缺少除税单价")
            if detail.get("included", True) and category in self.EXPENSE_CATEGORIES and not _numeric(detail.get("qty")):
                audit_issues.append(f"{detail.get('name') or detail.get('code') or '未命名分量'}缺少含量")
            detail["calculatedNoTaxTotal"] = round(value, 4)
            detail["calculatedTaxTotal"] = round(float(detail.get("unitTaxTotal") or 0), 4)
            # Management and profit are derived fee items, not ordinary
            # consumption components. Never reuse a stale imported/AI amount
            # after labor, material, or machine quantities have changed.
            if category in {"管理费", "利润"}:
                continue
            if category in totals:
                totals[category] += value
            else:
                other += value

        labor = totals["人工费"]
        material = totals["材料费"] + totals["辅材费"] + totals["主材费"]
        machinery = totals["机械费"]
        subcontract = totals["专业分包"]
        fee_settings = self._fee_settings_for_row(row)
        management_base = self._fee_base_amount(
            fee_settings.get("management_base", "direct"),
            labor,
            material,
            machinery,
        )
        management = management_base * fee_settings.get("management_rate", 0) / 100
        profit_base = self._fee_base_amount(
            fee_settings.get("profit_base", "direct_management"),
            labor,
            material,
            machinery,
            management,
        )
        profit = profit_base * fee_settings.get("profit_rate", 0) / 100
        comprehensive = labor + material + machinery + subcontract + other + management + profit
        row["fee_group"] = self._row_fee_group(row)
        row["applied_fee_settings"] = dict(fee_settings)

        row["labor"] = labor if labor else ""
        row["material"] = material if material else ""
        row["machinery"] = machinery if machinery else ""
        row["management"] = management if management else ""
        row["profit"] = profit if profit else ""
        row["comprehensive_price"] = comprehensive if comprehensive else ""
        self._update_price_deviation(row, row["comprehensive_price"])
        matched_clauses = [
            str(value)
            for match in row.get("quota_matches") or []
            for value in (match.get("matched_source_clauses") or [match.get("source_clause")])
            if value and str(value) != "主体工序"
        ]
        for clause in uncovered_cost_clauses(
            row.get("name", ""),
            row.get("feature", ""),
            row.get("compositions") or [],
            matched_clauses,
        ):
            audit_issues.append(f"工作内容未覆盖:{clause}，请复核是否补套定额或换算含量")
        for material in material_coverage_gaps(
            row.get("name", ""),
            row.get("feature", ""),
            row.get("compositions") or [],
        ):
            audit_issues.append(f"清单明确材料未进入组成:{material}，请复核或补充主材")
        imported_machinery = _numeric(row.get("imported_machinery"))
        if imported_machinery > 0 and machinery <= 0:
            quantity = _numeric(row.get("quantity"))
            source_machine_unit = imported_machinery / quantity if quantity > 0 else 0
            audit_issues.append(
                f"原表含定额机械费 {imported_machinery:.2f}（约 {source_machine_unit:.4f}/{row.get('unit') or '单位'}），"
                "当前套用组成未包含机械费，禁止直接采用当前综合单价"
            )
        row["audit_issues"] = list(dict.fromkeys(audit_issues))
        engineering_quantity = row.get("quantity") if row.get("quantity") not in (None, "") else None
        row["fee_details"] = [
            self._fee_detail(
                row,
                "管理费",
                management,
                (
                    "定额管理费分量合计"
                    if totals["管理费"]
                    else (
                        f"{self._fee_base_label(fee_settings.get('management_base', 'direct'))} "
                        f"{management_base:.4f} × {fee_settings.get('management_rate', 0):g}%"
                    )
                ),
                engineering_quantity,
            ),
            self._fee_detail(
                row,
                "利润",
                profit,
                (
                    "定额利润分量合计"
                    if totals["利润"]
                    else (
                        f"{self._fee_base_label(fee_settings.get('profit_base', 'direct_management'))} "
                        f"{profit_base:.4f} × {fee_settings.get('profit_rate', 0):g}%"
                    )
                ),
                engineering_quantity,
            ),
        ]

        coverage = cost_category_coverage(
            row.get("name", ""),
            row.get("feature", ""),
            row.get("compositions") or [],
            source_costs=self._source_costs(row),
            fee_details=row.get("fee_details") or [],
        )
        row["category_coverage"] = coverage
        for category in coverage.get("missing") or []:
            reason = coverage.get("reasons", {}).get(category) or "未找到明确依据"
            audit_issues.append(
                f"费用类别未形成完整组成：{category}（{reason}），不得按已完成组价通过"
            )
        row["audit_issues"] = list(dict.fromkeys(audit_issues))

        quota_matches = row.get("quota_matches") or []
        # Put the actual cost composition first. The previous order started
        # with the AI quota label, which hid the useful analysis below the
        # fixed-height table row and made the column appear empty.
        analysis_lines = []
        analysis_lines.append(
            "综合单价分析："
            + "；".join(
                f"{label} {_numeric(value):.4f}"
                for label, value in (
                    ("人工费", labor),
                    ("材料费", totals["材料费"]),
                    ("辅材费", totals["辅材费"]),
                    ("主材费", totals["主材费"]),
                    ("机械费", machinery),
                    ("专业分包", subcontract),
                )
                if _numeric(value) > 0
            )
            or "尚未形成有效人材机组成"
        )
        for match in quota_matches:
            # Imported prices are evidence only, not a second formal quota.
            # Keep them in the detail/source fields, but do not present them
            # as another quota in the main composition summary.
            if match.get("source_type") == "imported_cost_reference":
                continue
            quota_label = " ".join(
                value for value in (match.get("quota_code"), match.get("quota_name")) if value
            )
            analysis_lines.append(
                f"{match.get('role', '定额')}：{quota_label} × {float(match.get('quota_factor') or 1):g}"
            )
        official_price_count = sum(
            1 for detail in row.get("compositions") or []
            if detail.get("priceSourceMode") in {"official", "market_reference", "database"}
        )
        if official_price_count:
            analysis_lines.append(
                f"单价来源：已确认价格库优先，已更新 {official_price_count} 个通过名称、规格、单位、地区和期数校验的人材机分量；来源证据已写入分量记录"
            )
        elif self._price_priority.currentData() == "official":
            analysis_lines.append("单价来源：官方信息价优先，但本行没有同时满足规格、单位、地区和计价期的已确认官方价，保留定额库单价")
        if row.get("match_reasons"):
            analysis_lines.append(
                f"匹配依据：{'；'.join(row['match_reasons'])}；置信度 {row.get('score', 0):.0%}"
            )
        historical = row.get("historical_reference") or {}
        if historical:
            source_label = " / ".join(
                value for value in (historical.get("source_project"), historical.get("region"), historical.get("period"))
                if value
            ) or "来源信息不完整"
            analysis_lines.append(
                f"历史项目参考：{source_label}；案例相似度 {float(historical.get('score') or 0):.0%}"
            )
            if _numeric(historical.get("comprehensive_price")) > 0:
                analysis_lines.append(
                    f"历史案例综合单价：{_numeric(historical.get('comprehensive_price')):.4f}（仅作价格和组价参考，需人工复核）"
                )
        analysis_lines.append(f"管理费：{management:.4f}")
        analysis_lines.append(f"利润：{profit:.4f}")
        if coverage.get("missing"):
            analysis_lines.append(
                "类别核查：缺少 " + "、".join(coverage["missing"]) + "，已标记待复核"
            )
        if coverage.get("reference_only"):
            analysis_lines.append(
                "类别核查："
                + "、".join(coverage["reference_only"])
                + "仅保留原表费用参考，未找到可确认的本地定额组成，已标红待人工复核"
            )
        if row["audit_issues"]:
            analysis_lines.append(f"待复核：{'；'.join(row['audit_issues'][:5])}")
        if row.get("price_deviation_reason"):
            analysis_lines.append(f"价格偏差：{row['price_deviation_reason']}")
        row["analysis"] = "\n".join(analysis_lines)
        self._mark_row_result_current(row)

    @staticmethod
    def _fee_detail(row: dict, category: str, value: float, formula: str, engineering_quantity) -> dict:
        quantity = _numeric(engineering_quantity) if engineering_quantity not in (None, "") else None
        return {
            "included": True,
            "calculatedFee": True,
            "quotaRole": "取费",
            "quotaCode": "计价参数",
            "quotaName": category,
            "cat": category,
            "name": category,
            "unit": row.get("unit", ""),
            "sourceQty": 1.0,
            "qty": 1.0,
            "quotaFactor": 1.0,
            "loss": 0.0,
            "effectiveQty": 1.0,
            "noTaxPrice": value,
            "unitNoTaxTotal": value,
            "engineeringQuantity": quantity,
            "engineeringNoTaxTotal": value * quantity if quantity is not None else None,
            "taxRate": 0.0,
            "taxPrice": value,
            "unitTaxTotal": value,
            "engineeringTaxTotal": value * quantity if quantity is not None else None,
            "calcFormula": formula,
            "note": "按当前计价参数计算",
        }

    def _recalculate_matched_rows(self, *_):
        session = get_session()
        try:
            for row in self._rows:
                if row.get("compositions"):
                    self._apply_price_priority(session, row)
                    self._calculate_row_from_compositions(row)
        finally:
            session.close()
        self._render_table()

    def _on_price_priority_changed(self, *_):
        priority = self._price_priority.currentData() or "quota"
        set_settings({"quota_price_priority": str(priority)})
        self._recalculate_matched_rows()
        if self._rows and not self._save_results(show_message=False):
            self._save_pending_draft()
        self._stats_label.setText(
            "已切换为官方信息价优先：仅更新匹配到可靠官方价的人材机单价；"
            if priority == "official"
            else "已切换为定额库优先：使用定额库人材机单价。"
        )

    def _apply_price_priority(self, session, row: dict) -> dict:
        priority = self._price_priority.currentData() or "quota"
        if priority == "official":
            return apply_official_prices_to_compositions(
                session,
                self._active_project_id(),
                {
                    "name": row.get("name", ""),
                    "feature": row.get("feature", ""),
                    "unit": row.get("unit", ""),
                },
                row.get("compositions") or [],
                self._selected_source_region(),
            )
        restored = 0
        for detail in row.get("compositions") or []:
            if detail.get("priceSourceMode") not in {"official", "market_reference", "database"}:
                continue
            if "quotaNoTaxPrice" in detail and detail.get("quotaNoTaxPrice") not in (None, ""):
                detail["noTaxPrice"] = detail["quotaNoTaxPrice"]
            if "quotaTaxPrice" in detail and detail.get("quotaTaxPrice") not in (None, ""):
                detail["taxPrice"] = detail["quotaTaxPrice"]
            detail["priceSourceMode"] = "quota"
            detail.pop("officialPriceId", None)
            detail.pop("priceEvidence", None)
            detail.pop("calculationBasis", None)
            detail.pop("sourceEvidence", None)
            detail.pop("evidenceLevel", None)
            restored += 1
        return {"applied": 0, "restored": restored, "skipped": 0, "details": []}

    def _current_boq_row(self) -> dict | None:
        row_index = self._table.currentRow()
        return self._rows[row_index] if 0 <= row_index < len(self._rows) else None

    def _add_quota_to_row(self):
        row = self._current_boq_row()
        if row is None:
            QMessageBox.information(self, "未选择清单", "请先在上方选择一条清单。")
            return
        dialog = QuotaSelectionDialog(self._major.currentData() or "", self)
        dialog._keyword.setText(row.get("name", ""))
        dialog._search()
        if dialog.exec() != QDialog.Accepted:
            return
        quota_id = dialog.selected_quota_id()
        if quota_id in (row.get("quota_ids") or []):
            QMessageBox.information(self, "定额已存在", "该清单已经套用了这条定额。")
            return
        if self._row_quota_count(row) > 0:
            QMessageBox.information(
                self,
                "当前清单已有定额",
                "每条清单只保留一个最佳定额。请先移除当前定额，再选择新的定额。",
            )
            return
        session = get_session()
        try:
            item = get_quota_item(session, quota_id)
            if item is None:
                return
            reference = quota_reference_dict(item)
        finally:
            session.close()
        role = "主体" if not self._row_is_matched(row) else "人工补充"
        self._append_quota_reference(
            row,
            reference,
            role=role,
            score=1.0,
            reasons=["造价人员人工选择"],
            source_clause="人工选择",
        )
        row["quota_id"] = (row.get("quota_ids") or [None])[0]
        row["score"] = max(float(row.get("score") or 0), 1.0)
        self._calculate_row_from_compositions(row)
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()

    def _add_main_material(self):
        row = self._current_boq_row()
        if row is None:
            QMessageBox.information(self, "未选择清单", "请先在上方选择一条清单。")
            return
        detail = {
            "included": True,
            "cat": "主材费",
            "name": row.get("name", ""),
            "feature": row.get("feature", ""),
            "unit": row.get("unit", ""),
            "qty": 1.0,
            "sourceQty": 1.0,
            "quotaFactor": 1.0,
            "quotaRole": "补充主材",
            "quotaCode": "补充主材",
            "quotaName": "人工补充主材",
            "sourceClause": "造价人员人工补充",
            "note": "待核对主材规格、含量和除税价格",
        }
        dialog = CompositionAdjustmentDialog(detail, self)
        if dialog.exec() != QDialog.Accepted:
            return
        detail = dialog.values(detail)
        detail.update(composition_cost_breakdown(detail, row.get("quantity")))
        row.setdefault("compositions", []).append(detail)
        self._calculate_row_from_compositions(row)
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()

    def _edit_detail(self, *_):
        row = self._current_boq_row()
        detail_index = self._detail_table.currentRow()
        details = row.get("compositions") if row else None
        if row and detail_index >= len(details or []) and detail_index < self._detail_table.rowCount():
            QMessageBox.information(self, "自动取费项", "管理费和利润由上方费率及计取基础自动计算，请调整对应费率。")
            return
        if not details or not (0 <= detail_index < len(details)):
            QMessageBox.information(self, "未选择分量", "请先选择一条组价分量。")
            return
        original = details[detail_index]
        original_factor = _numeric(original.get("quotaFactor"), 1.0)
        dialog = CompositionAdjustmentDialog(original, self)
        if dialog.exec() != QDialog.Accepted:
            return
        updated = dialog.values(original)
        if original.get("evidenceLevel"):
            updated["evidenceLevel"] = "yellow"
            updated["note"] = "; ".join(
                value for value in (
                    updated.get("note", ""),
                    "人工编辑后原价格证据需重新复核",
                ) if value
            )
        # Editing the inclusion checkbox is an explicit human decision. Mark
        # the current logic check as reviewed so the next recalculation does
        # not silently restore an earlier automatic exclusion.
        updated["manualConfirmed"] = True
        updated["confirmationStatus"] = (
            "人工确认计入" if updated.get("included", True) else "人工确认不计入"
        )
        updated["logicValidated"] = True
        updated["logicValidationVersion"] = self.MATCHING_ALGORITHM_VERSION
        updated["blockedByLogic"] = False
        updated_factor = _numeric(updated.get("quotaFactor"), 1.0)
        quota_id = original.get("quotaId")
        if quota_id and updated_factor != original_factor:
            for detail in details:
                if detail.get("quotaId") == quota_id:
                    detail["quotaFactor"] = updated_factor
            for match in row.get("quota_matches") or []:
                if match.get("quota_id") == quota_id:
                    match["quota_factor"] = updated_factor
        details[detail_index] = updated
        self._calculate_row_from_compositions(row)
        self._render_table()
        self._detail_table.selectRow(min(detail_index, self._detail_table.rowCount() - 1))
        self._save_results(show_message=False)
        self.data_changed.emit()

    def _set_detail_inclusion(self, included: bool):
        """Apply an explicit human inclusion decision to the selected detail."""
        row = self._current_boq_row()
        detail_index = self._detail_table.currentRow()
        if row is None or not (0 <= detail_index < self._detail_table.rowCount()):
            QMessageBox.information(self, "未选择分量", "请先在组价明细中选择需要确认的分量。")
            return
        all_details = [*(row.get("compositions") or []), *(row.get("fee_details") or [])]
        if not (0 <= detail_index < len(all_details)):
            return
        detail = all_details[detail_index]
        if detail.get("calculatedFee"):
            QMessageBox.information(
                self,
                "自动取费项",
                "管理费和利润由上方取费设置自动计算，不需要单独确认；请调整取费设置。",
            )
            return

        if included:
            missing = []
            if not _text(detail.get("unit")):
                missing.append("单位")
            if _numeric(detail.get("qty")) <= 0:
                missing.append("调整后含量")
            if _numeric(detail.get("noTaxPrice")) <= 0:
                missing.append("除税单价")
            if missing:
                QMessageBox.information(
                    self,
                    "暂不能计入",
                    "当前分量还缺少：" + "、".join(missing)
                    + "。请先点击“编辑分量”补齐后，再确认计入。",
                )
                return

        previous_logic_errors = list(detail.get("logicValidationErrors") or [])
        detail["included"] = bool(included)
        detail["manualConfirmed"] = True
        detail["confirmationStatus"] = (
            "人工确认计入" if included else "人工确认不计入"
        )
        if included:
            detail["logicValidated"] = True
            detail["logicValidationVersion"] = self.MATCHING_ALGORITHM_VERSION
            detail["blockedByLogic"] = False
            detail["excludedByEvidence"] = False
            if previous_logic_errors:
                detail["manualOverrideReason"] = "；".join(previous_logic_errors)
        else:
            detail["manualOverrideReason"] = "人工明确确认不计入本清单组价"
            detail["logicValidated"] = True
            detail["logicValidationVersion"] = self.MATCHING_ALGORITHM_VERSION
            detail["blockedByLogic"] = False
        detail["note"] = "; ".join(
            value for value in (
                _text(detail.get("note")),
                detail["confirmationStatus"],
            ) if value
        )
        self._calculate_row_from_compositions(row)
        self._render_table()
        self._table.selectRow(self._rows.index(row))
        self._detail_table.selectRow(detail_index)
        self._save_results(show_message=False)
        self.data_changed.emit()
        self._stats_label.setText(
            f"已确认：{detail.get('name') or detail.get('code') or '当前分量'}"
            + (" 已计入清单计算" if included else " 已排除出清单计算")
        )

    def _confirm_detail_included(self):
        self._set_detail_inclusion(True)

    def _confirm_detail_excluded(self):
        self._set_detail_inclusion(False)

    def _remove_detail(self):
        row = self._current_boq_row()
        detail_index = self._detail_table.currentRow()
        details = row.get("compositions") if row else None
        if row and detail_index >= len(details or []) and detail_index < self._detail_table.rowCount():
            QMessageBox.information(self, "自动取费项", "管理费和利润不能作为普通分量删除，请将对应费率设为 0。")
            return
        if not details or not (0 <= detail_index < len(details)):
            QMessageBox.information(self, "未选择分量", "请先选择一条组价分量。")
            return
        details.pop(detail_index)
        self._calculate_row_from_compositions(row)
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()

    def _remove_quota_from_row(self):
        row = self._current_boq_row()
        detail_index = self._detail_table.currentRow()
        details = row.get("compositions") if row else None
        if row and detail_index >= len(details or []) and detail_index < self._detail_table.rowCount():
            QMessageBox.information(self, "自动取费项", "当前行不是来源定额，请选择该定额下的工料机分量。")
            return
        if not details or not (0 <= detail_index < len(details)):
            QMessageBox.information(self, "未选择定额", "请先选择该定额下的一条组价分量。")
            return
        quota_id = details[detail_index].get("quotaId")
        quota_code = details[detail_index].get("quotaCode")
        quota_name = details[detail_index].get("quotaName")
        if not quota_id:
            if details[detail_index].get("quotaRole") == "AI补充定额":
                answer = QMessageBox.question(
                    self,
                    "移除 AI 补充定额",
                    f"确定移除“{quota_code} {quota_name}”及其全部市场估算分量吗？",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if answer != QMessageBox.Yes:
                    return
                row["compositions"] = [
                    detail for detail in details
                    if detail.get("quotaRole") != "AI补充定额"
                ]
                row["quota_matches"] = [
                    match for match in row.get("quota_matches") or []
                    if match.get("source_type") != "ai_generated_market_estimate"
                ]
                row.pop("generated_quota", None)
                row["ai_generated"] = False
                row["evidence_level"] = "yellow" if row.get("quota_ids") else "red"
                self._calculate_row_from_compositions(row)
                self._render_table()
                self._save_results(show_message=False)
                self.data_changed.emit()
                return
            QMessageBox.information(self, "不是定额分量", "该行是人工补充项，请使用“删除分量”。")
            return
        label = " ".join(value for value in (quota_code, quota_name) if value)
        answer = QMessageBox.question(
            self,
            "移除整条定额",
            f"确定从当前清单移除定额“{label}”及其全部分量吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        row["compositions"] = [detail for detail in details if detail.get("quotaId") != quota_id]
        row["quota_ids"] = [value for value in row.get("quota_ids") or [] if value != quota_id]
        row["quota_matches"] = [
            match for match in row.get("quota_matches") or [] if match.get("quota_id") != quota_id
        ]
        row["quota_id"] = (row.get("quota_ids") or [None])[0]
        self._calculate_row_from_compositions(row)
        self._render_table()
        self._save_results(show_message=False)
        self.data_changed.emit()

    def _on_main_selection_changed(self):
        row_index = self._table.currentRow()
        if not (0 <= row_index < len(self._rows)):
            self._detail_table.setRowCount(0)
            self._detail_label.setText("组价明细：请选择一条清单")
            return
        row = self._rows[row_index]
        self._render_detail_table(row)

    def _render_detail_table(self, row: dict):
        details = [*(row.get("compositions") or []), *(row.get("fee_details") or [])]
        self._detail_label.setText(
            f"组价明细：{row.get('seq', '')} {row.get('name', '')}（{self._row_quota_count(row)} 条定额 / {len(details)} 个分量）"
            "；选中分量后可点击“确认计入/确认不计入”，双击可编辑"
        )
        self._detail_table.setRowCount(len(details))
        for row_index, detail in enumerate(details):
            detail.setdefault("boqUnit", row.get("unit", ""))
            if not detail.get("calculatedFee"):
                detail.update(composition_cost_breakdown(detail, row.get("quantity")))
            category = str(detail.get("cat") or "")
            included = bool(detail.get("included", True)) and (
                category not in self.EXPENSE_CATEGORIES or category in self._selected_categories()
            )
            quota_label = " ".join(
                value for value in (detail.get("quotaCode"), detail.get("quotaName")) if value
            )
            if detail.get("manualConfirmed"):
                inclusion_label = "已确认" if detail.get("included", True) else "已排除"
            elif detail.get("included", True):
                inclusion_label = "是"
            else:
                inclusion_label = "待确认"
            formula = detail.get("calcFormula") or (
                f"{self._display_value(detail.get('qty'))} × {self._display_value(detail.get('quotaFactor'))}"
                f" × (1+{_numeric(detail.get('loss')):g}%) × {self._display_value(detail.get('noTaxPrice'))}"
                f" = {self._display_value(detail.get('unitNoTaxTotal'))}"
            )
            values = [
                inclusion_label, detail.get("quotaRole", ""),
                quota_label, detail.get("cat", ""), detail.get("code", ""), detail.get("name", ""),
                detail.get("feature", ""), detail.get("unit", ""), self._display_value(detail.get("sourceQty")),
                self._display_value(detail.get("qty")), self._display_value(detail.get("quotaFactor")),
                f"{_numeric(detail.get('loss')):g}", self._display_value(detail.get("effectiveQty")),
                detail.get("engineeringUnit") or row.get("unit", ""),
                self._display_value(detail.get("totalQty")), detail.get("unitConversion", ""),
                self._display_value(detail.get("noTaxPrice")), self._display_value(detail.get("unitNoTaxTotal")),
                self._display_value(detail.get("engineeringQuantity")),
                self._display_value(detail.get("engineeringNoTaxTotal")), f"{_numeric(detail.get('taxRate')):g}",
                self._display_value(detail.get("taxPrice")), self._display_value(detail.get("unitTaxTotal")),
                self._display_value(detail.get("engineeringTaxTotal")), formula, detail.get("note", ""),
            ]
            for column, value in enumerate(values):
                table_item = QTableWidgetItem(str(value))
                evidence_level = str(detail.get("evidenceLevel") or "")
                if evidence_level == "green":
                    table_item.setBackground(QColor("#f0fdf4"))
                elif evidence_level == "yellow":
                    table_item.setBackground(QColor("#fffbeb"))
                elif evidence_level == "red":
                    table_item.setBackground(QColor("#fef2f2"))
                source_tip = "；".join(str(value) for value in detail.get("sourceEvidence") or [])
                basis_tip = str(detail.get("calculationBasis") or "")
                if column == 0:
                    if detail.get("manualConfirmed"):
                        basis_tip = "；".join(
                            value for value in (
                                basis_tip,
                                str(detail.get("confirmationStatus") or "人工已确认"),
                                str(detail.get("manualOverrideReason") or ""),
                            ) if value
                        )
                    elif not detail.get("included", True):
                        basis_tip = "；".join(
                            value for value in (
                                basis_tip,
                                "当前未计入清单计算；选中后点击“确认计入”即可人工确认",
                            ) if value
                        )
                if source_tip or basis_tip:
                    table_item.setToolTip("\n".join(value for value in (basis_tip, source_tip) if value))
                table_item.setTextAlignment(Qt.AlignCenter)
                if not included:
                    table_item.setForeground(Qt.gray)
                self._detail_table.setItem(row_index, column, table_item)

    def _on_cell_entered(self, row: int, column: int):
        table = self.sender()
        if table not in (self._table, self._detail_table):
            return
        item = table.item(row, column)
        if item is None or not item.text():
            QToolTip.hideText()
            return
        text = item.text()
        metrics = QFontMetrics(table.font())
        longest_width = max(
            (metrics.horizontalAdvance(line) for line in text.splitlines()),
            default=0,
        )
        available_width = max(table.columnWidth(column) - 14, 0)
        has_custom_tip = bool(item.toolTip() and item.toolTip() != text)
        if "\n" in text or longest_width > available_width or has_custom_tip:
            tip = text
            if has_custom_tip:
                tip = f"{text}\n\n{item.toolTip()}"
            QToolTip.showText(
                QCursor.pos(), tip, table, QRect(), self.TOOLTIP_DURATION_MS
            )
        else:
            QToolTip.hideText()

    def _show_main_cell_content(self, row: int, column: int):
        item = self._table.item(row, column)
        if item is None or not item.text():
            return
        header = self._table.horizontalHeaderItem(column)
        title = header.text() if header is not None else "单元格内容"
        dialog = CellContentEditDialog(
            f"{title} - 查看完整内容",
            item.text(),
            editable=False,
            parent=self,
        )
        dialog.exec()

    def _render_table(self):
        self._table.setRowCount(len(self._rows))
        for row_index, row in enumerate(self._rows):
            matched = self._row_is_matched(row)
            evidence_level = str(row.get("evidence_level") or "")
            values = [
                row.get("seq", ""),
                row.get("name", ""),
                row.get("feature", ""),
                row.get("unit", ""),
                self._display_value(row.get("quantity")),
                row.get("analysis", ""),
                self._display_value(row.get("comprehensive_price")),
                self._display_value(row.get("labor")),
                self._display_value(row.get("material")),
                self._display_value(row.get("machinery")),
                self._display_value(row.get("management")),
                self._display_value(row.get("profit")),
                row.get("note", ""),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(Qt.AlignCenter)
                if evidence_level == "green":
                    item.setBackground(QColor("#f0fdf4"))
                elif evidence_level == "yellow":
                    item.setBackground(QColor("#fffbeb"))
                elif evidence_level == "red" and row.get("ai_generated"):
                    item.setBackground(QColor("#fef2f2"))
                if column == 6 and row.get("price_deviation_level"):
                    deviation_level = row["price_deviation_level"]
                    item.setBackground(QColor(
                        "#f0fdf4" if deviation_level == "价格接近"
                        else "#fffbeb" if deviation_level == "价格需关注"
                        else "#fef2f2"
                    ))
                    item.setToolTip(
                        str(row.get("price_deviation_reason") or "")
                    )
                if column == 5 and matched:
                    if evidence_level == "red":
                        item.setForeground(QColor("#b91c1c"))
                    elif evidence_level == "yellow" or row.get("audit_issues"):
                        item.setForeground(QColor("#a16207"))
                    else:
                        item.setForeground(QColor("#15803d"))
                if row.get("ai_generated"):
                    item.setToolTip(
                        "AI补充定额/市场估算，仅用于当前项目；"
                        + str((row.get("generated_quota") or {}).get("evidence_summary") or "需人工复核")
                    )
                self._table.setItem(row_index, column, item)
        status_counts = {
            "all": len(self._rows),
            "unmatched": sum(1 for row in self._rows if self._row_status(row) == "unmatched"),
            "matched": sum(1 for row in self._rows if self._row_status(row) == "matched"),
            "candidate": sum(1 for row in self._rows if self._row_status(row) == "candidate"),
            "ai": sum(1 for row in self._rows if self._row_status(row) == "ai"),
            "review": sum(1 for row in self._rows if self._row_status(row) == "review"),
            "blocked": sum(1 for row in self._rows if self._row_status(row) == "blocked"),
        }
        status_labels = {
            "all": "全部",
            "unmatched": "未匹配",
            "matched": "已匹配",
            "candidate": "候选匹配",
            "ai": "AI补充",
            "review": "需人工确认",
            "blocked": "禁止计价",
        }
        for index in range(self._status_filter.count()):
            status = self._status_filter.itemData(index)
            self._status_filter.setItemText(
                index,
                f"{status_labels.get(status, status)} ({status_counts.get(status, 0)})",
            )
        self._apply_status_filter(clear_selection=False)
        if not self._rows:
            self._stats_label.setText("尚未导入清单")
        else:
            reliable = sum(1 for row in self._rows if self._row_status(row) == "matched")
            candidate = sum(1 for row in self._rows if self._row_status(row) == "candidate")
            review = sum(1 for row in self._rows if self._row_status(row) == "review")
            blocked = sum(1 for row in self._rows if self._row_status(row) == "blocked")
            unmatched = sum(1 for row in self._rows if self._row_status(row) == "unmatched")
            quota_count = sum(self._row_quota_count(row) for row in self._rows)
            visible_count = len(self._visible_row_indexes())
            source_label = f"{self._source_format} | " if self._source_format else ""
            self._stats_label.setText(
                f"{source_label}显示 {visible_count}/{len(self._rows)} 条，"
                f"可靠 {reliable} 条，候选 {candidate} 条，需复核 {review} 条，"
                f"禁止计价 {blocked} 条，未匹配 {unmatched} 条，套用 {quota_count} 条定额"
            )
        self._on_main_selection_changed()

    @staticmethod
    def _display_value(value) -> str:
        if value in (None, ""):
            return ""
        if isinstance(value, (int, float)):
            return f"{float(value):,.4f}".rstrip("0").rstrip(".")
        return str(value)

    def _export_excel(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "导出匹配结果",
            "定额匹配结果.xlsx",
            "Excel 文件 (*.xlsx)",
        )
        if not path:
            return
        try:
            # Export is another persistence boundary. Re-normalize first so a
            # legacy or late-arriving result cannot put a losing quota's
            # composition into the exported workbook.
            for row in self._rows:
                normalize_quota_row_matches(row)
                if row.get("compositions"):
                    self._calculate_row_from_compositions(row)
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Font, PatternFill

            workbook = Workbook()
            worksheet = workbook.active
            worksheet.title = "定额匹配结果"
            has_source_price = any(
                self._reference_price(row) is not None
                for row in self._rows
            )
            hierarchy_headers = [
                "类别", "定额编码", "定额名称", "工作内容", "单位", "单位含量",
                "清单工程量", "损耗率", "除税单价", "税率", "含税单价",
                "除税单位合价", "含税单位合价", "除税工程合价", "含税工程合价",
            ]
            if has_source_price:
                hierarchy_headers.extend([
                    "原表综合单价", "套定额计算价", "价格差额", "价格偏差率", "偏差说明",
                ])
            worksheet.append(hierarchy_headers)
            fill = PatternFill(start_color="2563EB", end_color="2563EB", fill_type="solid")
            parent_fill = PatternFill(start_color="DBEAFE", end_color="DBEAFE", fill_type="solid")
            for cell in worksheet[1]:
                cell.fill = fill
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center")
            selected_categories = self._selected_categories()
            project_no_tax_total = 0.0
            project_tax_total = 0.0
            for row in self._rows:
                details = []
                for detail in [*(row.get("compositions") or []), *(row.get("fee_details") or [])]:
                    if not detail.get("calculatedFee"):
                        detail.update(composition_cost_breakdown(detail, row.get("quantity")))
                    details.append(detail)

                has_quantity = row.get("quantity") not in (None, "")
                quantity = _numeric(row.get("quantity"))
                parent_price = _numeric(row.get("comprehensive_price"))
                parent_no_tax_total = round(parent_price * quantity, 4) if has_quantity else ""
                parent_tax_total_value = 0.0
                for detail in details:
                    category = str(detail.get("cat") or "")
                    included = bool(detail.get("included", True)) and (
                        category not in self.EXPENSE_CATEGORIES or category in selected_categories
                    )
                    if included:
                        parent_tax_total_value += _numeric(detail.get("engineeringTaxTotal"))
                if has_quantity and details:
                    parent_tax_total_value = round(parent_tax_total_value, 4)
                    parent_tax_total = parent_tax_total_value
                    parent_tax_unit = (
                        round(parent_tax_total_value / quantity, 4)
                        if quantity
                        else ""
                    )
                else:
                    parent_tax_total = ""
                    parent_tax_unit = ""
                if has_quantity:
                    project_no_tax_total += _numeric(parent_no_tax_total)
                    project_tax_total += _numeric(parent_tax_total)

                parent_values = [
                    "清单", row.get("code", ""), row.get("name", ""), row.get("feature", ""),
                    row.get("unit", ""), "", row.get("quantity", ""), "",
                    row.get("comprehensive_price", ""), "", parent_tax_unit,
                    row.get("comprehensive_price", ""), parent_tax_unit,
                    parent_no_tax_total, parent_tax_total,
                ]
                if has_source_price:
                    parent_values.extend([
                        row.get("source_comprehensive_price", ""),
                        row.get("calculated_comprehensive_price", ""),
                        row.get("price_difference", ""),
                        row.get("price_difference_rate", ""),
                        row.get("price_deviation_reason", ""),
                    ])
                worksheet.append(parent_values)
                parent_row = worksheet.max_row
                for cell in worksheet[parent_row]:
                    cell.fill = parent_fill
                    cell.font = Font(bold=True)
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
                for detail in details:
                    category = str(detail.get("cat") or "")
                    quota_code = detail.get("quotaCode") or detail.get("code") or ""
                    quota_name = detail.get("quotaName") or ""
                    worksheet.append([
                        category, quota_code, quota_name, detail.get("feature", ""),
                        detail.get("unit", ""), detail.get("qty", ""),
                        detail.get("engineeringQuantity", ""), _numeric(detail.get("loss")),
                        detail.get("noTaxPrice", ""), _numeric(detail.get("taxRate")),
                        detail.get("taxPrice", ""), detail.get("unitNoTaxTotal", ""),
                        detail.get("unitTaxTotal", ""), detail.get("engineeringNoTaxTotal", ""),
                        detail.get("engineeringTaxTotal", ""),
                    ])
            total_values = [
                "项目合计", "", "", "", "", "", "", "", "", "", "", "", "",
                round(project_no_tax_total, 4), round(project_tax_total, 4),
            ]
            if has_source_price:
                total_values.extend(["", "", "", "", ""])
            worksheet.append(total_values)
            total_row = worksheet.max_row
            for cell in worksheet[total_row]:
                cell.font = Font(bold=True)
                cell.fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
            for column in worksheet.columns:
                letter = column[0].column_letter
                worksheet.column_dimensions[letter].width = 18
            worksheet.column_dimensions["C"].width = 42
            worksheet.column_dimensions["D"].width = 42
            worksheet.freeze_panes = "A2"

            summary_sheet = workbook.create_sheet("费用分类汇总")
            summary_headers = [
                "清单序号", "清单编码", "清单名称", "单位", "工程量", "定额数量",
                "人工费", "材料费", "辅材费", "主材费", "机械费", "专业分包",
                "其他", "管理费", "利润", "综合单价", "清单合价",
            ]
            if has_source_price:
                summary_headers.extend([
                    "原表综合单价", "套定额计算价", "价格差额", "价格偏差率", "偏差等级",
                ])
            summary_sheet.append(summary_headers)
            for cell in summary_sheet[1]:
                cell.fill = fill
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center")
            selected_categories = self._selected_categories()
            for row in self._rows:
                category_totals = {category: 0.0 for category in [*self.EXPENSE_CATEGORIES, "其他"]}
                for detail in row.get("compositions") or []:
                    category = str(detail.get("cat") or "其他")
                    included = bool(detail.get("included", True)) and (
                        category not in self.EXPENSE_CATEGORIES or category in selected_categories
                    )
                    if not included:
                        continue
                    category_totals[category if category in category_totals else "其他"] += float(
                        detail.get("unitNoTaxTotal") or 0
                    )
                quantity = _numeric(row.get("quantity"))
                unit_price = _numeric(row.get("comprehensive_price"))
                summary_values = [
                    row.get("seq", ""), row.get("code", ""), row.get("name", ""), row.get("unit", ""),
                    row.get("quantity", ""), self._row_quota_count(row),
                    category_totals["人工费"], category_totals["材料费"], category_totals["辅材费"],
                    category_totals["主材费"], category_totals["机械费"], category_totals["专业分包"],
                    category_totals["其他"], row.get("management", ""), row.get("profit", ""),
                    row.get("comprehensive_price", ""), unit_price * quantity if row.get("quantity") not in (None, "") else "",
                ]
                if has_source_price:
                    summary_values.extend([
                        row.get("source_comprehensive_price", ""),
                        row.get("calculated_comprehensive_price", ""),
                        row.get("price_difference", ""),
                        row.get("price_difference_rate", ""),
                        row.get("price_deviation_level", ""),
                    ])
                summary_sheet.append(summary_values)
            summary_sheet.freeze_panes = "A2"
            for column in summary_sheet.columns:
                summary_sheet.column_dimensions[column[0].column_letter].width = 15
            summary_sheet.column_dimensions["C"].width = 28

            detail_sheet = workbook.create_sheet("分量计算明细")
            detail_headers = [
                "清单序号", "清单编码", "清单名称", "清单特征及工作内容", "清单单位",
                *self.DETAIL_HEADERS, "证据等级", "价格计算依据", "本地价格证据", "匹配置信度", "匹配依据",
            ]
            detail_sheet.append(detail_headers)
            for cell in detail_sheet[1]:
                cell.fill = fill
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center")
            for row in self._rows:
                for detail in [*(row.get("compositions") or []), *(row.get("fee_details") or [])]:
                    if not detail.get("calculatedFee"):
                        detail.update(composition_cost_breakdown(detail, row.get("quantity")))
                    category = str(detail.get("cat") or "")
                    quota_label = " ".join(
                        value for value in (detail.get("quotaCode"), detail.get("quotaName")) if value
                    )
                    included = bool(detail.get("included", True)) and (
                        category not in self.EXPENSE_CATEGORIES or category in selected_categories
                    )
                    formula = detail.get("calcFormula") or (
                        f"{self._display_value(detail.get('qty'))} × {self._display_value(detail.get('quotaFactor'))}"
                        f" × (1+{_numeric(detail.get('loss')):g}%) × {self._display_value(detail.get('noTaxPrice'))}"
                        f" = {self._display_value(detail.get('unitNoTaxTotal'))}"
                    )
                    detail_sheet.append([
                        row.get("seq", ""), row.get("code", ""), row.get("name", ""), row.get("feature", ""),
                        row.get("unit", ""), "是" if included else "否", detail.get("quotaRole", ""),
                        quota_label, category, detail.get("code", ""), detail.get("name", ""),
                        detail.get("feature", ""), detail.get("unit", ""), detail.get("sourceQty", ""),
                        detail.get("qty", ""), detail.get("quotaFactor", ""), _numeric(detail.get("loss")),
                        detail.get("effectiveQty", ""), detail.get("engineeringUnit") or row.get("unit", ""),
                        detail.get("totalQty", ""), detail.get("unitConversion", ""),
                        detail.get("noTaxPrice", ""), detail.get("unitNoTaxTotal", ""), detail.get("engineeringQuantity", ""),
                        detail.get("engineeringNoTaxTotal", ""), _numeric(detail.get("taxRate")),
                        detail.get("taxPrice", ""), detail.get("unitTaxTotal", ""),
                        detail.get("engineeringTaxTotal", ""), formula, detail.get("note", ""),
                        detail.get("evidenceLevel", row.get("evidence_level", "")),
                        detail.get("calculationBasis", ""),
                        "；".join(str(value) for value in detail.get("sourceEvidence") or []),
                        detail.get("matchScore", row.get("score", "")),
                        "；".join(row.get("match_reasons") or []),
                    ])
            for column in detail_sheet.columns:
                letter = column[0].column_letter
                detail_sheet.column_dimensions[letter].width = 16
            detail_sheet.column_dimensions["C"].width = 24
            detail_sheet.column_dimensions["D"].width = 42
            detail_sheet.column_dimensions["H"].width = 28
            detail_sheet.column_dimensions["L"].width = 42
            detail_sheet.column_dimensions["AA"].width = 42
            detail_sheet.column_dimensions["AD"].width = 42
            detail_sheet.column_dimensions["AE"].width = 42
            detail_sheet.column_dimensions["AG"].width = 42
            detail_sheet.freeze_panes = "A2"

            audit_sheet = workbook.create_sheet("AI核查报告")
            audit_headers = [
                "清单序号", "清单编码", "工程名称", "单位", "工程量",
                "核查状态", "问题等级", "问题类别", "问题说明", "涉及分量",
                "应有计算/判断", "当前实际值", "建议处理", "AI核查结论",
            ]
            audit_sheet.append(audit_headers)
            for cell in audit_sheet[1]:
                cell.fill = fill
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center")
            audit_count = 0
            for row in self._rows:
                findings = row.get("ai_audit_findings") or []
                if not findings:
                    report = row.get("local_audit_report") or {}
                    findings = report.get("issues") or []
                status = "发现问题" if findings else (
                    "AI已核查" if row.get("ai_audited") else "未核查"
                )
                if not findings:
                    audit_sheet.append([
                        row.get("seq", ""), row.get("code", ""), row.get("name", ""),
                        row.get("unit", ""), row.get("quantity", ""), status,
                        "", "", "", "", "", "", "",
                        row.get("ai_audit_summary", ""),
                    ])
                    continue
                for finding in findings:
                    audit_sheet.append([
                        row.get("seq", ""), row.get("code", ""), row.get("name", ""),
                        row.get("unit", ""), row.get("quantity", ""), status,
                        finding.get("severity", ""), finding.get("category", ""),
                        finding.get("message", ""), finding.get("affected_component", ""),
                        finding.get("expected_calculation", ""), finding.get("actual_calculation", ""),
                        finding.get("recommended_action", ""), row.get("ai_audit_summary", ""),
                    ])
                    audit_count += 1
            for row_number in range(2, audit_sheet.max_row + 1):
                severity = str(audit_sheet.cell(row_number, 7).value or "")
                fill_color = "FEE2E2" if severity == "high" else "FEF3C7" if severity == "medium" else "F0FDF4"
                audit_sheet.cell(row_number, 6).fill = PatternFill(
                    start_color=fill_color, end_color=fill_color, fill_type="solid"
                )
                audit_sheet.cell(row_number, 7).fill = PatternFill(
                    start_color=fill_color, end_color=fill_color, fill_type="solid"
                )
                for column in range(1, audit_sheet.max_column + 1):
                    audit_sheet.cell(row_number, column).alignment = Alignment(
                        vertical="top", wrap_text=True
                    )
            for column in audit_sheet.columns:
                audit_sheet.column_dimensions[column[0].column_letter].width = 18
            for column, width in {"C": 28, "I": 44, "J": 28, "K": 32, "L": 28, "M": 36, "N": 42}.items():
                audit_sheet.column_dimensions[column].width = width
            audit_sheet.freeze_panes = "A2"

            basis_sheet = workbook.create_sheet("计价参数")
            basis_sheet.append(["参数", "数值", "说明"])
            default_fee = self._fee_settings.get("default") or {}
            basis_sheet.append([
                "默认管理费基数",
                self._fee_base_label(default_fee.get("management_base", "direct")),
                "未设置分部时使用的取费基数",
            ])
            basis_sheet.append([
                "默认管理费率",
                float(default_fee.get("management_rate", 0)) / 100,
                "需按地区计价依据和合同口径复核",
            ])
            basis_sheet.append([
                "默认利润基数",
                self._fee_base_label(default_fee.get("profit_base", "direct_management")),
                "未设置分部时使用的取费基数",
            ])
            basis_sheet.append([
                "默认利润率",
                float(default_fee.get("profit_rate", 0)) / 100,
                "需按地区计价依据和合同口径复核",
            ])
            for group, config in sorted(self._fee_settings.get("groups", {}).items()):
                basis_sheet.append([
                    f"{group}管理费基数",
                    self._fee_base_label(config.get("management_base", "direct")),
                    "按分部覆盖默认配置",
                ])
                basis_sheet.append([
                    f"{group}管理费率",
                    float(config.get("management_rate", 0)) / 100,
                    "按分部覆盖默认配置",
                ])
                basis_sheet.append([
                    f"{group}利润基数",
                    self._fee_base_label(config.get("profit_base", "direct_management")),
                    "按分部覆盖默认配置",
                ])
                basis_sheet.append([
                    f"{group}利润率",
                    float(config.get("profit_rate", 0)) / 100,
                    "按分部覆盖默认配置",
                ])
            basis_sheet.append(["参与计价类别", "、".join(sorted(selected_categories)), "未勾选类别不计入清单汇总价"])
            basis_sheet.append(["分量单位合价", "调整后含量×定额系数×(1+损耗率)×除税单价", "来源合价仅在含量或单价缺失时兜底"])
            basis_sheet.append(["分量工程合价", "分量单位合价×清单工程量", "清单没有工程量时保持空白"])
            basis_sheet.append(["管理费", "按取费设置基数×管理费率", "定额有明确管理费分量时优先采用定额值"])
            basis_sheet.append(["利润", "按取费设置基数×利润率", "定额有明确利润分量时优先采用定额值"])
            basis_sheet.append(["证据颜色", "绿色/黄色/红色", "绿色=本地确认价格且地区、计价期、税价口径相容；黄色=部分证据需复核；红色=无可靠来源或逻辑风险"])
            basis_sheet.append(["AI补充定额", "仅保存于当前项目", "不写入官方定额库，必须在复核窗确认后才能应用"])
            workbook.save(path)
            QMessageBox.information(self, "导出完成", f"已导出 {len(self._rows)} 条匹配结果到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))

    def _clear(self):
        self._rows = []
        self._source_file = ""
        self._source_format = ""
        self._clear_pending_draft()
        project_id = self._active_project_id()
        if project_id:
            session = get_session()
            try:
                session.query(ProjectQuotaMatch).filter(
                    ProjectQuotaMatch.project_id == project_id
                ).delete(synchronize_session=False)
                write_audit(session, "delete", "project_quota_match", detail="清空项目定额匹配结果")
                session.commit()
            except Exception:
                session.rollback()
            finally:
                session.close()
        self._render_table()
        self._stats_label.setText("尚未导入清单")

