"""DeepSeek 多轮对话工作区。"""
from __future__ import annotations

import html

from PySide6.QtCore import QEvent, Qt, QThread, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from src.ai_service import ai
from src.config import config
from src.db import get_db_stats
from src.ui.widgets import AIBadge, ActionButton, SectionHeader


SYSTEM_PROMPT = """你是智能工程造价辅助系统内置的工程造价 AI 助手。
请用中文回答，优先给出可执行、可核查的步骤。涉及工程造价信息价时：
1. 区分官方信息价、市场参考价和用户导入数据；
2. 不凭空编造价格、官网地址、期数或法规条文；
3. 需要实时价格时说明应回到官方原始文件核对；
4. 可以帮助用户分析材料、清单、价格对比、抓取失败原因和数据审核，但不能替用户确认未经核对的数据入库。
"""


class AIChatWorker(QThread):
    completed = Signal(bool, str)

    def __init__(self, messages: list[dict]):
        super().__init__()
        self.messages = messages

    def run(self):
        success, content = ai.chat(self.messages)
        self.completed.emit(success, content)


class AIChatPage(QWidget):
    """提供类似聊天助手的多轮 DeepSeek 对话入口。"""

    navigate_requested = Signal(str)

    def __init__(self):
        super().__init__()
        self._messages: list[dict] = []
        self._worker: AIChatWorker | None = None
        self._setup_ui()
        self._reset_view()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 18, 22, 18)
        layout.setSpacing(12)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title = QLabel("AI 智能")
        title.setFont(QFont("Microsoft YaHei", 18, QFont.Bold))
        title.setStyleSheet("color:#0f172a;")
        title_box.addWidget(title)
        subtitle = QLabel("连接 DeepSeek，协助分析造价数据、清单和抓取问题")
        subtitle.setStyleSheet("color:#64748b; font-size:12px;")
        title_box.addWidget(subtitle)
        header.addLayout(title_box)
        header.addStretch()
        self._status_badge = AIBadge()
        header.addWidget(self._status_badge)
        config_btn = ActionButton("DeepSeek 配置", "default")
        config_btn.clicked.connect(lambda: self.navigate_requested.emit("deepseek_config"))
        header.addWidget(config_btn)
        clear_btn = ActionButton("清空会话", "default")
        clear_btn.clicked.connect(self._reset_view)
        header.addWidget(clear_btn)
        layout.addLayout(header)

        body = QHBoxLayout()
        body.setSpacing(12)
        chat_frame = QFrame()
        chat_frame.setStyleSheet("QFrame{background:#fff;border:1px solid #e2e8f0;border-radius:12px;}")
        chat_layout = QVBoxLayout(chat_frame)
        chat_layout.setContentsMargins(14, 14, 14, 12)
        self._chat_view = QTextBrowser()
        self._chat_view.setOpenExternalLinks(False)
        self._chat_view.setStyleSheet(
            "QTextBrowser{border:none;background:#fff;color:#1e293b;font-size:13px;}"
        )
        chat_layout.addWidget(self._chat_view, 1)

        self._prompt = QPlainTextEdit()
        self._prompt.setPlaceholderText("输入问题，例如：为什么上海可以抓取而西安需要登录？")
        self._prompt.setFixedHeight(92)
        self._prompt.setStyleSheet(
            "QPlainTextEdit{border:1px solid #dbe3ef;border-radius:10px;padding:9px;background:#f8fafc;}"
        )
        self._prompt.installEventFilter(self)
        chat_layout.addWidget(self._prompt)
        action_row = QHBoxLayout()
        self._hint = QLabel("Enter 发送，Shift+Enter 换行")
        self._hint.setStyleSheet("color:#94a3b8;font-size:11px;")
        action_row.addWidget(self._hint)
        action_row.addStretch()
        self._stop_btn = ActionButton("停止生成", "warn")
        self._stop_btn.setVisible(False)
        self._stop_btn.clicked.connect(self._stop_generation)
        action_row.addWidget(self._stop_btn)
        self._send_btn = ActionButton("发送", "primary")
        self._send_btn.clicked.connect(self._send_message)
        action_row.addWidget(self._send_btn)
        chat_layout.addLayout(action_row)
        body.addWidget(chat_frame, 1)

        side = QFrame()
        side.setFixedWidth(250)
        side.setStyleSheet("QFrame{background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;}")
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(14, 14, 14, 14)
        side_layout.addWidget(SectionHeader("当前数据上下文"))
        self._context_label = QLabel()
        self._context_label.setWordWrap(True)
        self._context_label.setStyleSheet("color:#475569;font-size:12px;border:none;")
        side_layout.addWidget(self._context_label)
        side_layout.addSpacing(14)
        side_layout.addWidget(SectionHeader("可处理的问题"))
        topics = QLabel("材料名称与规格分析\n价格库与清单对比\n官网抓取失败排查\n信息价来源核验\n报价风险与异常说明")
        topics.setStyleSheet("color:#475569;font-size:12px;line-height:1.5;border:none;")
        topics.setWordWrap(True)
        side_layout.addWidget(topics)
        side_layout.addStretch()
        side_layout.addWidget(QLabel("实时价格、法规和官网内容仍需回到原始来源核对。"))
        body.addWidget(side)
        layout.addLayout(body, 1)
        self._refresh_context()

    def eventFilter(self, watched, event):
        if watched is self._prompt and event.type() == QEvent.KeyPress:
            if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not (event.modifiers() & Qt.ShiftModifier):
                self._send_message()
                return True
        return super().eventFilter(watched, event)

    def _refresh_context(self):
        try:
            stats = get_db_stats()
            self._context_label.setText(
                f"材料：{stats['materials']:,} 条\n"
                f"价格：{stats['prices']:,} 条\n"
                f"固定清单：{stats['cost_items']:,} 条\n"
                f"待确认价格：{stats['pending_prices']:,} 条\n"
                f"项目：{stats['projects']:,} 个\n\n"
                "对话不会自动修改数据库，确认入库仍由用户执行。"
            )
        except Exception as error:
            self._context_label.setText(f"数据上下文暂不可用：{error}")

    def _reset_view(self):
        self._messages = []
        if hasattr(self, "_chat_view"):
            self._chat_view.setHtml(
                '<div style="margin:12px 4px;color:#334155;">'
                '<b>你好，我是智能工程造价辅助系统 AI 助手。</b><br><br>'
                '可以直接询问材料、清单、价格对比、官网抓取和数据审核问题。'
                '</div>'
            )
        if hasattr(self, "_prompt"):
            self._prompt.clear()
        self._refresh_context()

    def _append_message(self, role: str, content: str):
        safe = html.escape(content).replace("\n", "<br>")
        if role == "user":
            block = (
                '<div style="margin:10px 4px 10px 48px;padding:10px 12px;'
                'background:#eff6ff;border-radius:10px;color:#1e3a8a;">'
                f"<b>我</b><br>{safe}</div>"
            )
        else:
            block = (
                '<div style="margin:10px 48px 10px 4px;padding:10px 12px;'
                'background:#f8fafc;border-radius:10px;color:#334155;">'
                f"<b>AI 智能</b><br>{safe}</div>"
            )
        self._chat_view.append(block)
        self._chat_view.verticalScrollBar().setValue(self._chat_view.verticalScrollBar().maximum())

    def _send_message(self):
        if self._worker is not None:
            return
        content = self._prompt.toPlainText().strip()
        if not content:
            return
        if not ai.is_available:
            QMessageBox.information(
                self,
                "AI 尚未配置",
                "请先到左侧“系统设置 → DeepSeek 配置”填写并保存 API Key。",
            )
            return
        self._messages.append({"role": "user", "content": content})
        self._append_message("user", content)
        self._prompt.clear()
        context = self._context_label.text()
        messages = [{"role": "system", "content": SYSTEM_PROMPT + "\n当前本地数据概况：\n" + context}]
        messages.extend(self._messages[-20:])
        self._send_btn.setEnabled(False)
        self._prompt.setEnabled(False)
        self._stop_btn.setVisible(True)
        self._status_badge.setText(" AI 处理中 ")
        self._worker = AIChatWorker(messages)
        self._worker.completed.connect(self._on_response)
        self._worker.start()

    def _stop_generation(self):
        if self._worker is not None:
            self._worker.requestInterruption()
            self._stop_btn.setEnabled(False)
            self._hint.setText("正在停止当前请求...")

    def _on_response(self, success: bool, content: str):
        worker = self._worker
        self._worker = None
        if worker is not None:
            worker.deleteLater()
        self._send_btn.setEnabled(True)
        self._prompt.setEnabled(True)
        self._stop_btn.setVisible(False)
        self._stop_btn.setEnabled(True)
        self._hint.setText("Enter 发送，Shift+Enter 换行")
        self._status_badge.refresh()
        if success:
            self._messages.append({"role": "assistant", "content": content})
            self._append_message("assistant", content)
        else:
            self._append_message("assistant", f"请求失败：{content}")

    def refresh_data(self):
        self._refresh_context()
        self._status_badge.refresh()

    def closeEvent(self, event):
        if self._worker is not None and self._worker.isRunning():
            self._worker.requestInterruption()
            self._worker.wait(3000)
        super().closeEvent(event)
