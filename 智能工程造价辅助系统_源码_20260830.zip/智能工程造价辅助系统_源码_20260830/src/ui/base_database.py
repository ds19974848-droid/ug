"""基础数据库：动态信息价、固定清单、地区标准和材料标准库。"""
import re
from datetime import datetime
from uuid import uuid4

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from sqlalchemy import or_

from src.ai_service import ai
from src.config import config
from src.cost_item_service import export_cost_items_to_excel, import_cost_items_from_excel
from src.db import get_session, write_audit
from src.models import CostItem, Material, MaterialPrice, PriceHistory, Region, RegionStandard
from src.ui.widgets import ActionButton, SectionHeader, StatusBadge
from src.utils import export_prices_to_excel, import_prices_from_excel
from src.material_service import find_or_create_material, infer_price_basis, normalize_material_identity


TABLE_STYLE = (
    "QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:8px; gridline-color:#edf1f6; } "
    "QTableWidget::item { padding:7px; } "
    "QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:9px 7px; }"
)
INPUT_STYLE = "border:1px solid #dbe3ef; border-radius:8px; padding:6px 10px; font-size:12px;"


class BaseDatabasePage(QWidget):
    data_changed = Signal()
    TAB_ROUTES = {
        "price_library": 0,
        "bq_library": 1,
        "market_library": 2,
        "material_library": 3,
    }

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        self._tabs = QTabWidget()
        self._tabs.setStyleSheet(
            "QTabWidget::pane { border:none; background:#f0f4f9; }"
            "QTabBar::tab { padding:10px 20px; font-weight:bold; border:none; color:#667085; }"
            "QTabBar::tab:selected { color:#2563eb; border-bottom:3px solid #2563eb; }"
        )
        self._official_prices = PriceLibraryTab("official")
        self._fixed_items = BQLibraryTab()
        self._market_prices = PriceLibraryTab("market_reference")
        self._materials = MaterialLibraryTab()
        for tab, label in [
            (self._official_prices, "地方官方信息价库"),
            (self._fixed_items, "固定工程清单库"),
            (self._market_prices, "市场参考库"),
            (self._materials, "材料标准库"),
        ]:
            if hasattr(tab, "data_changed"):
                tab.data_changed.connect(self.data_changed)
            self._tabs.addTab(tab, label)
        layout.addWidget(self._tabs)

    def show_route(self, route_key: str):
        index = self.TAB_ROUTES.get(route_key, 0)
        self._tabs.setCurrentIndex(index)
        self.refresh_data()

    def refresh_data(self):
        current = self._tabs.currentWidget()
        if hasattr(current, "refresh_data"):
            current.refresh_data()

    def set_search_query(self, query: str):
        self._tabs.setCurrentIndex(0)
        self._official_prices.set_search_query(query)


class PriceLibraryTab(QWidget):
    data_changed = Signal()

    def __init__(self, trust_filter: str = "official"):
        super().__init__()
        self._trust_filter = trust_filter
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        tools = QHBoxLayout()
        title = "动态地方官方信息价库" if trust_filter == "official" else "主流造价网站市场参考库（非官方）"
        tools.addWidget(SectionHeader(title))
        tools.addStretch()
        add_button = ActionButton("新增价格", "primary")
        add_button.clicked.connect(self._add_price)
        tools.addWidget(add_button)
        import_button = ActionButton("导入 Excel", "default")
        import_button.clicked.connect(self._import_excel)
        tools.addWidget(import_button)
        export_button = ActionButton("导出 Excel", "default")
        export_button.clicked.connect(self._export_excel)
        tools.addWidget(export_button)
        layout.addLayout(tools)

        filters = QHBoxLayout()
        self._keyword = QLineEdit()
        self._keyword.setPlaceholderText("材料名称或规格")
        self._keyword.setStyleSheet(INPUT_STYLE)
        self._keyword.returnPressed.connect(self.refresh_data)
        filters.addWidget(self._keyword, 1)
        self._region = QComboBox()
        self._region.setStyleSheet(INPUT_STYLE)
        filters.addWidget(self._region)
        self._period = QLineEdit()
        self._period.setPlaceholderText("期数，如 2026-06")
        self._period.setMaximumWidth(145)
        self._period.setStyleSheet(INPUT_STYLE)
        self._period.returnPressed.connect(self.refresh_data)
        filters.addWidget(self._period)
        filter_button = ActionButton("筛选", "primary")
        filter_button.clicked.connect(self.refresh_data)
        filters.addWidget(filter_button)
        self._count_label = QLabel()
        self._count_label.setStyleSheet("color:#64748b;")
        filters.addWidget(self._count_label)
        layout.addLayout(filters)

        self._table = QTableWidget(0, 10)
        self._table.setHorizontalHeaderLabels(["材料名称", "规格", "单位", "地区", "期数", "价格", "状态", "来源", "来源类型", "价格依据"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(TABLE_STYLE)
        layout.addWidget(self._table, 1)
        self._load_regions()
        self.refresh_data()

    def set_search_query(self, query: str):
        query = query.strip()
        self._load_regions()
        region_names = [self._region.itemText(index) for index in range(1, self._region.count())]
        matched_region = max(
            (name for name in region_names if name and name in query),
            key=len,
            default="",
        )
        self._region.setCurrentText(matched_region or "全部地区")
        period_match = re.search(r"(20\d{2})\s*[年./-]\s*(\d{1,2})\s*月?", query)
        self._period.setText(
            f"{period_match.group(1)}-{int(period_match.group(2)):02d}"
            if period_match else ""
        )
        material_query = query
        if matched_region:
            material_query = material_query.replace(matched_region, " ")
        if period_match:
            material_query = material_query.replace(period_match.group(0), " ")
        tokens = re.findall(
            r"[A-Za-z]+(?:[.-]?\d+)+(?:[A-Za-z0-9.-]*)|[\u4e00-\u9fff]+",
            material_query,
        )
        self._keyword.setText(" ".join(tokens))
        self.refresh_data()

    def _load_regions(self):
        selected = self._region.currentText() if self._region.count() else "全部地区"
        session = get_session()
        try:
            names = [row.name for row in session.query(Region).order_by(Region.name).all()]
        finally:
            session.close()
        self._region.clear()
        self._region.addItems(["全部地区", *names])
        index = self._region.findText(selected)
        self._region.setCurrentIndex(max(index, 0))

    def refresh_data(self):
        session = get_session()
        try:
            query = session.query(MaterialPrice).join(Material).join(Region).filter(MaterialPrice.is_withdrawn.is_(False))
            if self._trust_filter == "official":
                query = query.filter(MaterialPrice.trust_level.in_(["official", "official_manual"]))
            else:
                query = query.filter(MaterialPrice.trust_level == "market_reference")
            keyword = self._keyword.text().strip()
            if keyword:
                for token in keyword.split():
                    query = query.filter(or_(Material.name.contains(token), MaterialPrice.spec.contains(token)))
            if self._region.currentText() != "全部地区":
                query = query.filter(Region.name == self._region.currentText())
            period = self._period.text().strip()
            if period:
                query = query.filter(MaterialPrice.period == period)
            total = query.count()
            prices = query.order_by(MaterialPrice.period.desc(), MaterialPrice.updated_at.desc()).limit(1000).all()
            count_text = f"共 {total:,} 条" + ("，显示前 1,000 条" if total > 1000 else "")
            if total == 0 and (keyword or period or self._region.currentText() != "全部地区"):
                count_text = "未找到已入库价格"
            self._count_label.setText(count_text)
            self._table.setRowCount(len(prices))
            for row, price in enumerate(prices):
                self._table.setItem(row, 0, QTableWidgetItem(price.material.name if price.material else ""))
                self._table.setItem(row, 1, QTableWidgetItem(price.spec))
                self._table.setItem(row, 2, QTableWidgetItem(price.unit))
                self._table.setItem(row, 3, QTableWidgetItem(price.region_obj.name if price.region_obj else ""))
                self._table.setItem(row, 4, QTableWidgetItem(price.period))
                self._table.setItem(row, 5, QTableWidgetItem(f"{price.price:,.2f}"))
                self._table.setCellWidget(row, 6, StatusBadge("已入库", "ok"))
                source_text = "官方订阅" if price.trust_level == "official" else "手动官方价" if price.trust_level == "official_manual" else "市场网站参考"
                self._table.setItem(row, 7, QTableWidgetItem(source_text))
                source_type = {"official": "官方", "market_reference": "市场参考", "manual": "手动"}.get(price.source_type, price.source_type or "未标注")
                basis = {
                    "tax_inclusive": "含税",
                    "tax_exclusive": "除税",
                    "delivered": "到场/工地",
                    "ex_factory": "出厂",
                    "as_published": "按原文",
                }.get(price.price_basis, price.price_basis or "未标注")
                self._table.setItem(row, 8, QTableWidgetItem(source_type))
                self._table.setItem(row, 9, QTableWidgetItem(basis))
        finally:
            session.close()

    def _add_price(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("新增地方信息价")
        form = QFormLayout(dialog)
        name = QLineEdit()
        spec = QLineEdit()
        unit = QLineEdit()
        region = QComboBox()
        session = get_session()
        try:
            region.addItems([row.name for row in session.query(Region).order_by(Region.name).all()])
        finally:
            session.close()
        period = QLineEdit(datetime.now().strftime("%Y-%m"))
        price = QDoubleSpinBox()
        price.setRange(0.01, 100000000)
        price.setDecimals(4)
        for label, widget in [("材料名称", name), ("规格", spec), ("单位", unit), ("地区", region), ("期数", period), ("价格", price)]:
            form.addRow(label, widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        if not name.text().strip() or not period.text().strip():
            QMessageBox.warning(self, "信息不完整", "材料名称和期数不能为空。")
            return
        session = get_session()
        try:
            region_row = session.query(Region).filter(Region.name == region.currentText()).first()
            material, _ = find_or_create_material(
                session,
                name.text(),
                unit=unit.text(),
                spec=spec.text(),
            )
            existing = session.query(MaterialPrice).filter(
                MaterialPrice.material_id == material.id,
                MaterialPrice.region_id == region_row.id,
                MaterialPrice.period == period.text().strip(),
                MaterialPrice.spec == spec.text().strip(),
            ).first()
            if existing is None:
                existing = MaterialPrice(material_id=material.id, region_id=region_row.id, period=period.text().strip(), spec=spec.text().strip())
                session.add(existing)
            existing.unit = unit.text().strip()
            existing.price = price.value()
            existing.trust_level = "official_manual" if self._trust_filter == "official" else "market_reference"
            existing.source_type = "manual" if self._trust_filter == "official" else "market_reference"
            existing.price_basis = infer_price_basis("官方手动录入" if self._trust_filter == "official" else "市场参考")
            existing.is_confirmed = True
            session.add(PriceHistory(
                material_id=material.id,
                region_id=region_row.id,
                period=existing.period,
                spec=existing.spec,
                unit=existing.unit,
                price=existing.price,
                trust_level="manual",
                source_type="manual",
                price_basis=existing.price_basis,
                notes="手动新增",
            ))
            write_audit(session, "create", "material_price", detail=f"手动新增: {material.name} {existing.period}")
            session.commit()
            self.refresh_data()
            self.data_changed.emit()
            QMessageBox.information(self, "保存成功", "地方信息价已保存。")
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _import_excel(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入地方信息价", "", "Excel 文件 (*.xlsx *.xls)")
        if not path:
            return
        session = get_session()
        try:
            result = import_prices_from_excel(path, session)
            if not result.get("success"):
                QMessageBox.warning(self, "导入失败", result.get("error", "未知错误"))
                return
            self.refresh_data()
            self.data_changed.emit()
            QMessageBox.information(self, "导入完成", f"已处理 {result.get('imported', 0):,} 条，跳过 {result.get('skipped', 0):,} 条。")
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "导入失败", str(error))
        finally:
            session.close()

    def _export_excel(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出地方信息价", "地方信息价库.xlsx", "Excel 文件 (*.xlsx)")
        if not path:
            return
        session = get_session()
        try:
            export_prices_to_excel(session, path)
            write_audit(session, "export", "material_price", detail=f"导出地方信息价: {path}")
            session.commit()
            QMessageBox.information(self, "导出完成", f"已导出到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))
        finally:
            session.close()


class BQLibraryTab(QWidget):
    data_changed = Signal()
    PAGE_SIZE = 300
    PRIMARY_CATEGORIES = [
        ("新建", "新建"),
        ("装修", "装修"),
        ("旧改", "旧改"),
        ("测试数据", "测试数据"),
    ]
    OTHER_CATEGORY = "__other__"

    def __init__(self):
        super().__init__()
        self._page = 0
        self._current_items = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("固定工程清单库（软件内置，与地方信息价分开）"))
        tools.addStretch()
        add_button = ActionButton("新增清单", "primary")
        add_button.clicked.connect(self._add_item)
        tools.addWidget(add_button)
        import_button = ActionButton("导入 Excel", "default")
        import_button.clicked.connect(self._import_excel)
        tools.addWidget(import_button)
        export_button = ActionButton("导出当前结果", "default")
        export_button.clicked.connect(self._export_excel)
        tools.addWidget(export_button)
        detail_button = ActionButton("查看详情", "default")
        detail_button.clicked.connect(self._show_selected_detail)
        tools.addWidget(detail_button)
        layout.addLayout(tools)

        filters = QHBoxLayout()
        self._keyword = QLineEdit()
        self._keyword.setPlaceholderText("搜索项目名称、特征或分类")
        self._keyword.setStyleSheet(INPUT_STYLE)
        self._keyword.returnPressed.connect(self._reset_and_refresh)
        filters.addWidget(self._keyword, 1)
        self._source = QComboBox()
        self._source.setStyleSheet(INPUT_STYLE)
        filters.addWidget(self._source)
        self._category = QComboBox()
        self._category.setStyleSheet(INPUT_STYLE)
        filters.addWidget(self._category)
        search_button = ActionButton("搜索", "primary")
        search_button.clicked.connect(self._reset_and_refresh)
        filters.addWidget(search_button)
        self._count = QLabel()
        self._count.setStyleSheet("color:#64748b;")
        filters.addWidget(self._count)
        layout.addLayout(filters)

        self._table = QTableWidget(0, 8)
        self._table.setHorizontalHeaderLabels(["数据来源", "项目名称", "单位", "综合单价", "含税价", "人工费", "材料费", "分类"])
        self._table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setStyleSheet(TABLE_STYLE)
        self._table.cellDoubleClicked.connect(lambda *_: self._show_selected_detail())
        layout.addWidget(self._table, 1)

        paging = QHBoxLayout()
        paging.addStretch()
        previous = ActionButton("上一页", "default")
        previous.clicked.connect(self._previous_page)
        paging.addWidget(previous)
        self._page_label = QLabel()
        paging.addWidget(self._page_label)
        following = ActionButton("下一页", "default")
        following.clicked.connect(self._next_page)
        paging.addWidget(following)
        layout.addLayout(paging)
        self._load_filters()
        self.refresh_data()

    def _load_filters(self):
        source_text = self._source.currentText() if self._source.count() else "全部来源"
        category_value = self._category.currentData() if self._category.count() else ""
        session = get_session()
        try:
            sources = [value[0] for value in session.query(CostItem.data_source).distinct().order_by(CostItem.data_source).all() if value[0]]
            full_categories = {
                value[0].strip()
                for value in session.query(CostItem.full_category).distinct().all()
                if value[0] and value[0].strip()
            }
        finally:
            session.close()
        self._source.clear()
        self._source.addItems(["全部来源", *sources])
        self._source.setCurrentIndex(max(self._source.findText(source_text), 0))
        self._category.clear()
        self._category.addItem("全部分类", "")
        known_prefixes = {value for _, value in self.PRIMARY_CATEGORIES}
        available_prefixes = {
            category.split("/", 1)[0].strip()
            for category in full_categories
        }
        for label, value in self.PRIMARY_CATEGORIES:
            if value in available_prefixes:
                self._category.addItem(label, value)
        if any(prefix not in known_prefixes for prefix in available_prefixes):
            self._category.addItem("其他", self.OTHER_CATEGORY)
        selected_index = self._category.findData(category_value)
        self._category.setCurrentIndex(max(selected_index, 0))

    def _query(self, session):
        query = session.query(CostItem)
        keyword = self._keyword.text().strip()
        if keyword:
            query = query.filter(or_(CostItem.item_name.contains(keyword), CostItem.features.contains(keyword), CostItem.full_category.contains(keyword)))
        if self._source.currentText() != "全部来源":
            query = query.filter(CostItem.data_source == self._source.currentText())
        category = self._category.currentData()
        if category == self.OTHER_CATEGORY:
            known_filters = [
                or_(CostItem.full_category == prefix, CostItem.full_category.like(f"{prefix} /%"))
                for _, prefix in self.PRIMARY_CATEGORIES
            ]
            query = query.filter(or_(
                CostItem.full_category.is_(None),
                CostItem.full_category == "",
                ~or_(*known_filters),
            ))
        elif category:
            query = query.filter(or_(
                CostItem.full_category == category,
                CostItem.full_category.like(f"{category} /%"),
            ))
        return query

    def refresh_data(self):
        session = get_session()
        try:
            query = self._query(session)
            total = query.count()
            max_page = max(0, (total - 1) // self.PAGE_SIZE)
            self._page = min(self._page, max_page)
            self._current_items = query.order_by(CostItem.data_source, CostItem.original_seq, CostItem.id).offset(self._page * self.PAGE_SIZE).limit(self.PAGE_SIZE).all()
            self._count.setText(f"共 {total:,} 条")
            self._page_label.setText(f"第 {self._page + 1} / {max_page + 1} 页")
            self._table.setRowCount(len(self._current_items))
            for row, item in enumerate(self._current_items):
                name = QTableWidgetItem(item.item_name)
                name.setData(Qt.UserRole, item.id)
                values = [
                    item.data_source, name, item.unit, f"{item.comprehensive_price:,.2f}",
                    f"{item.tax_inclusive_price:,.2f}", f"{item.labor_cost:,.2f}",
                    f"{item.material_cost:,.2f}", item.full_category,
                ]
                for column, value in enumerate(values):
                    self._table.setItem(row, column, value if isinstance(value, QTableWidgetItem) else QTableWidgetItem(str(value)))
        finally:
            session.close()

    def _reset_and_refresh(self):
        self._page = 0
        self.refresh_data()

    def _previous_page(self):
        if self._page > 0:
            self._page -= 1
            self.refresh_data()

    def _next_page(self):
        session = get_session()
        try:
            total = self._query(session).count()
        finally:
            session.close()
        if (self._page + 1) * self.PAGE_SIZE < total:
            self._page += 1
            self.refresh_data()

    def _selected_item(self):
        row = self._table.currentRow()
        if row < 0 or row >= len(self._current_items):
            return None
        return self._current_items[row]

    def _show_selected_detail(self):
        item = self._selected_item()
        if item is None:
            QMessageBox.information(self, "请选择清单", "请先选中一条清单。")
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(item.item_name)
        dialog.resize(760, 600)
        layout = QVBoxLayout(dialog)
        summary = QLabel(f"{item.data_source}  |  {item.full_category}  |  {item.unit}  |  综合单价 {item.comprehensive_price:,.2f}")
        summary.setStyleSheet("font-weight:bold; color:#1d4ed8;")
        layout.addWidget(summary)
        text = QTextEdit()
        text.setReadOnly(True)
        text.setPlainText(
            f"项目特征\n{item.features}\n\n价格组成\n人工费 {item.labor_cost:,.2f}  材料费 {item.material_cost:,.2f}  "
            f"机械费 {item.machinery_cost:,.2f}  管理费 {item.management_cost:,.2f}  利润 {item.profit:,.2f}\n\n"
            f"价格分析\n{item.price_analysis}\n\nAI 分析\n{item.ai_analysis}\n\n备注\n{item.notes}"
        )
        layout.addWidget(text)
        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        dialog.exec()

    def _add_item(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("新增固定清单")
        form = QFormLayout(dialog)
        name = QLineEdit()
        features = QTextEdit()
        features.setMaximumHeight(100)
        unit = QLineEdit()
        price = QDoubleSpinBox()
        price.setRange(0, 100000000)
        price.setDecimals(4)
        category = QLineEdit()
        source = QLineEdit("用户自建")
        for label, widget in [("项目名称", name), ("项目特征", features), ("单位", unit), ("综合单价", price), ("分类", category), ("来源", source)]:
            form.addRow(label, widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        if not name.text().strip():
            QMessageBox.warning(self, "信息不完整", "项目名称不能为空。")
            return
        session = get_session()
        try:
            session.add(CostItem(source_key=f"user-{uuid4().hex}", data_source=source.text().strip() or "用户自建", item_name=name.text().strip(), features=features.toPlainText().strip(), unit=unit.text().strip(), comprehensive_price=price.value(), full_category=category.text().strip(), original_category=category.text().strip()))
            write_audit(session, "create", "cost_item", detail=f"新增固定清单: {name.text().strip()}")
            session.commit()
            self._load_filters()
            self._reset_and_refresh()
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _import_excel(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入固定工程清单", "", "Excel 文件 (*.xlsx)")
        if not path:
            return
        session = get_session()
        try:
            result = import_cost_items_from_excel(path, session)
            if not result.get("success"):
                QMessageBox.warning(self, "导入失败", result.get("error", "未知错误"))
                return
            session.commit()
            self._load_filters()
            self._reset_and_refresh()
            self.data_changed.emit()
            QMessageBox.information(self, "导入完成", f"新增 {result['imported']:,} 条，更新 {result['updated']:,} 条，跳过 {result['skipped']:,} 条。")
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "导入失败", str(error))
        finally:
            session.close()

    def _export_excel(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出固定工程清单", "固定工程清单库.xlsx", "Excel 文件 (*.xlsx)")
        if not path:
            return
        try:
            export_cost_items_to_excel(self._current_items, path)
            QMessageBox.information(self, "导出完成", f"当前页 {len(self._current_items):,} 条数据已导出到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))


class RegionStandardsTab(QWidget):
    data_changed = Signal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("地区计价标准"))
        tools.addStretch()
        add_button = ActionButton("新增标准", "primary")
        add_button.clicked.connect(self._add_standard)
        tools.addWidget(add_button)
        layout.addLayout(tools)
        self._table = QTableWidget(0, 7)
        self._table.setHorizontalHeaderLabels(["地区", "标准版本", "税率(%)", "规费费率(%)", "措施费费率(%)", "利润率(%)", "状态"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setStyleSheet(TABLE_STYLE)
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            standards = session.query(RegionStandard).order_by(RegionStandard.created_at.desc()).limit(500).all()
            self._table.setRowCount(len(standards))
            for row, standard in enumerate(standards):
                region = session.query(Region).filter(Region.id == standard.region_id).first()
                for column, value in enumerate([region.name if region else "", standard.version, f"{standard.tax_rate * 100:.2f}", f"{standard.regulation_fee_rate * 100:.2f}", f"{standard.measure_fee_rate * 100:.2f}", f"{standard.profit_rate * 100:.2f}"]):
                    self._table.setItem(row, column, QTableWidgetItem(value))
                self._table.setCellWidget(row, 6, StatusBadge("启用" if standard.is_active else "停用", "ok" if standard.is_active else "neutral"))
        finally:
            session.close()

    def _add_standard(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("新增地区标准")
        form = QFormLayout(dialog)
        region = QComboBox()
        session = get_session()
        try:
            region.addItems([row.name for row in session.query(Region).order_by(Region.name).all()])
        finally:
            session.close()
        version = QLineEdit(datetime.now().strftime("%Y版"))
        name = QLineEdit()
        spins = []
        for _ in range(4):
            spin = QDoubleSpinBox()
            spin.setRange(0, 100)
            spin.setDecimals(3)
            spins.append(spin)
        spins[0].setValue(9)
        spins[1].setValue(3)
        spins[2].setValue(2.5)
        spins[3].setValue(7)
        for label, widget in [("地区", region), ("版本", version), ("标准名称", name), ("税率(%)", spins[0]), ("规费(%)", spins[1]), ("措施费(%)", spins[2]), ("利润率(%)", spins[3])]:
            form.addRow(label, widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        session = get_session()
        try:
            region_row = session.query(Region).filter(Region.name == region.currentText()).first()
            session.add(RegionStandard(region_id=region_row.id, version=version.text().strip(), name=name.text().strip() or f"{region.currentText()}{version.text().strip()}计价标准", tax_rate=spins[0].value() / 100, regulation_fee_rate=spins[1].value() / 100, measure_fee_rate=spins[2].value() / 100, profit_rate=spins[3].value() / 100, is_active=True))
            write_audit(session, "create", "region_standard", detail=f"新增地区标准: {region.currentText()} {version.text().strip()}")
            session.commit()
            self.refresh_data()
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()


class MaterialLibraryTab(QWidget):
    data_changed = Signal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("材料标准库（同物不同名归并）"))
        tools.addStretch()
        add_button = ActionButton("新增材料", "primary")
        add_button.clicked.connect(self._add_material)
        tools.addWidget(add_button)
        merge_button = ActionButton("AI 归并选中项", "default")
        merge_button.clicked.connect(self._ai_merge)
        tools.addWidget(merge_button)
        layout.addLayout(tools)
        self._table = QTableWidget(0, 5)
        self._table.setHorizontalHeaderLabels(["标准名称", "分类", "单位", "规格模板", "别名数"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setStyleSheet(TABLE_STYLE)
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            materials = session.query(Material).order_by(Material.category, Material.name).limit(2000).all()
            self._table.setRowCount(len(materials))
            for row, material in enumerate(materials):
                item = QTableWidgetItem(material.name)
                item.setData(Qt.UserRole, material.id)
                for column, value in enumerate([item, material.category, material.default_unit, material.spec_template, str(len(material.aliases))]):
                    self._table.setItem(row, column, value if isinstance(value, QTableWidgetItem) else QTableWidgetItem(value))
        finally:
            session.close()

    def _add_material(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("新增标准材料")
        form = QFormLayout(dialog)
        name = QLineEdit()
        category = QComboBox()
        category.addItems(config.MATERIAL_CATEGORIES)
        unit = QLineEdit()
        spec = QLineEdit()
        for label, widget in [("标准名称", name), ("分类", category), ("单位", unit), ("规格模板", spec)]:
            form.addRow(label, widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.Accepted or not name.text().strip():
            return
        session = get_session()
        try:
            identity = normalize_material_identity(name.text())
            if any(normalize_material_identity(item.name) == identity for item in session.query(Material).all()):
                QMessageBox.information(self, "已存在", "该标准材料已经存在。")
                return
            session.add(Material(name=name.text().strip(), category=category.currentText(), default_unit=unit.text().strip(), spec_template=spec.text().strip()))
            write_audit(session, "create", "material", detail=f"新增材料: {name.text().strip()}")
            session.commit()
            self.refresh_data()
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _ai_merge(self):
        row = self._table.currentRow()
        if row < 0:
            QMessageBox.information(self, "请选择材料", "请先选中一条材料。")
            return
        if not ai.is_available:
            QMessageBox.information(self, "AI 未配置", "请先在系统设置中配置并测试 DeepSeek；材料库的本地功能不受影响。")
            return
        item = self._table.item(row, 0)
        result = ai.standardize_material_name(item.text())
        standard_name = result.get("standard_name", item.text()).strip()
        if not standard_name or standard_name == item.text():
            QMessageBox.information(self, "归并结果", "AI 判断当前名称已经规范，无需修改。")
            return
        reply = QMessageBox.question(self, "确认归并", f"建议将“{item.text()}”规范为“{standard_name}”。是否应用？", QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        session = get_session()
        try:
            material = session.query(Material).filter(Material.id == item.data(Qt.UserRole)).first()
            target = session.query(Material).filter(Material.name == standard_name).first()
            if target and target.id != material.id:
                for price in list(material.prices):
                    price.material_id = target.id
                session.delete(material)
            else:
                material.name = standard_name
                material.category = result.get("category", material.category)
            write_audit(session, "update", "material", detail=f"AI 规范材料名称: {item.text()} -> {standard_name}")
            session.commit()
            self.refresh_data()
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "归并失败", str(error))
        finally:
            session.close()
