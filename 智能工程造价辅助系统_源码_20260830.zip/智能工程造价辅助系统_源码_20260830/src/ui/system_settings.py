﻿"""系统设置模块页面"""
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget,
    QPushButton, QLineEdit, QScrollArea, QSpinBox, QDoubleSpinBox,
    QCheckBox, QTextEdit, QMessageBox, QFileDialog,
)
from PySide6.QtCore import Qt, Signal, QThread, QUrl
from PySide6.QtGui import QDesktopServices, QFont

from src.ai_service import ai
from src.config import config
from src.db import (
    backup_database, get_db_stats, restore_backup, get_session,
    get_setting, set_settings, check_database_integrity,
)
from src.models import BackupRecord
from src.ui.widgets import StatusBadge, ActionButton, SectionHeader, AIBadge
from src.ui.user_guide import UserGuidePage
from src.ui.license_management import LicenseManagementTab


class AIConnectionWorker(QThread):
    completed = Signal(bool, str)

    def run(self):
        success, message = ai.test_connection()
        self.completed.emit(success, message)


class SystemSettingsPage(QWidget):
    TAB_ROUTES = {
        "user_guide": 0,
        "deepseek_config": 1,
        "sub_rules": 2,
        "anomaly_threshold": 3,
        "license_management": 4,
        "db_management": 5,
    }

    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        self._tabs = QTabWidget()
        self._tabs.setStyleSheet("""
            QTabWidget::pane { border: none; background: #f0f4f9; }
            QTabBar::tab { padding: 10px 20px; font-weight: bold; border: none; color: #667085; }
            QTabBar::tab:selected { color: #2563eb; border-bottom: 3px solid #2563eb; }
        """)
        self._tabs.addTab(UserGuidePage(), "使用说明")
        self._tabs.addTab(DeepSeekConfigTab(), "DeepSeek 配置")
        self._tabs.addTab(SubRulesTab(), "订阅规则")
        self._tabs.addTab(AnomalyThresholdTab(), "异常阈值")
        self._tabs.addTab(LicenseManagementTab(), "授权管理")
        self._tabs.addTab(DbManagementTab(), "数据库管理")
        layout.addWidget(self._tabs)

    def show_route(self, route_key: str):
        index = self.TAB_ROUTES.get(route_key, 0)
        self._tabs.setCurrentIndex(index)
        current_tab = self._tabs.widget(index)
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()

    def refresh_data(self):
        current_tab = self._tabs.currentWidget()
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()


class DeepSeekConfigTab(QWidget):
    def __init__(self):
        super().__init__()
        self._connection_worker = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(16)

        card = QFrame()
        card.setStyleSheet("background:#fff; border:1px solid #e4eaf2; border-radius:18px; padding:20px;")
        cl = QVBoxLayout(card)

        cl.addWidget(SectionHeader("DeepSeek API 配置"))
        status_row = QHBoxLayout()
        status_row.addWidget(QLabel("当前连接状态"))
        self._ai_status_badge = AIBadge()
        status_row.addWidget(self._ai_status_badge)
        status_row.addStretch()
        cl.addLayout(status_row)

        api_label = QLabel("API Key")
        api_label.setStyleSheet("color:#667085; font-size:12px; border:none;")
        cl.addWidget(api_label)
        self._api_key = QLineEdit()
        self._api_key.setEchoMode(QLineEdit.Password)
        self._api_key.setPlaceholderText("sk-...")
        self._api_key.setText(config.DEEPSEEK_API_KEY)
        self._api_key.setStyleSheet("border:1px solid #dbe3ef; border-radius:11px; padding:8px 12px;")
        cl.addWidget(self._api_key)

        obtain_row = QHBoxLayout()
        obtain_label = QLabel("获取方式：登录 DeepSeek 官方开放平台，在 API Keys 页面创建密钥")
        obtain_label.setStyleSheet("color:#64748b; font-size:12px; border:none;")
        obtain_row.addWidget(obtain_label)
        obtain_row.addStretch()
        obtain_btn = ActionButton("获取 API Key", "default")
        obtain_btn.clicked.connect(self._open_api_key_page)
        obtain_row.addWidget(obtain_btn)
        cl.addLayout(obtain_row)

        url_label = QLabel("API 地址")
        url_label.setStyleSheet("color:#667085; font-size:12px; border:none;")
        cl.addWidget(url_label)
        self._base_url = QLineEdit(config.DEEPSEEK_BASE_URL)
        self._base_url.setStyleSheet("border:1px solid #dbe3ef; border-radius:11px; padding:8px 12px;")
        cl.addWidget(self._base_url)

        model_label = QLabel("模型")
        model_label.setStyleSheet("color:#667085; font-size:12px; border:none;")
        cl.addWidget(model_label)
        self._model = QLineEdit(config.DEEPSEEK_MODEL)
        self._model.setStyleSheet("border:1px solid #dbe3ef; border-radius:11px; padding:8px 12px;")
        cl.addWidget(self._model)

        cl.addSpacing(12)
        button_row = QHBoxLayout()
        save_btn = ActionButton("保存配置", "primary")
        save_btn.clicked.connect(self._save_config)
        button_row.addWidget(save_btn)
        test_btn = ActionButton("测试真实连接", "default")
        test_btn.clicked.connect(self._test_connection)
        button_row.addWidget(test_btn)
        button_row.addStretch()
        cl.addLayout(button_row)
        layout.addWidget(card)

        info = QFrame()
        info.setStyleSheet("background:#eff6ff; border:1px solid #dbeafe; border-radius:14px; padding:14px;")
        il = QVBoxLayout(info)
        il.addWidget(QLabel("DeepSeek 使用规则"))
        rules = QLabel(
            "允许：搜索官方来源线索、判断网页是否为官方来源、解析PDF/Excel表格字段、"
            "标准化材料名称、归并同物不同名、检测异常价格、生成解析说明。\n\n"
            "禁止：无来源生成价格、自动覆盖正式价格、将第三方价格伪装成官方信息价、未经确认直接入库。"
        )
        rules.setWordWrap(True)
        rules.setStyleSheet("color:#475569; font-size:12px; border:none;")
        il.addWidget(rules)
        layout.addWidget(info)

        layout.addStretch()

    def _open_api_key_page(self):
        opened = QDesktopServices.openUrl(QUrl("https://platform.deepseek.com/api_keys"))
        if not opened:
            QMessageBox.warning(self, "无法打开网页", "请在浏览器访问 DeepSeek 官方开放平台：platform.deepseek.com/api_keys")

    def _save_config(self):
        api_key = self._api_key.text().strip()
        base_url = self._base_url.text().strip() or "https://api.deepseek.com"
        model = self._model.text().strip() or "deepseek-chat"
        env_path = config.USER_DATA_DIR / ".env"
        try:
            config.ensure_dirs()
            env_path.write_text(
                "\n".join([
                    f"DEEPSEEK_API_KEY={api_key}",
                    f"DEEPSEEK_BASE_URL={base_url}",
                    f"DEEPSEEK_MODEL={model}",
                    "",
                ]),
                encoding="utf-8",
            )
            config.DEEPSEEK_API_KEY = api_key
            config.DEEPSEEK_BASE_URL = base_url
            config.DEEPSEEK_MODEL = model
            ai.reload()
            self._ai_status_badge.refresh()
            QMessageBox.information(self, "保存成功", "DeepSeek 配置已保存。未填写 API Key 时，软件会保持本地模式运行。")
        except Exception as error:
            QMessageBox.warning(self, "保存失败", str(error))

    def _test_connection(self):
        if self._api_key.text().strip() != config.DEEPSEEK_API_KEY:
            QMessageBox.information(self, "请先保存", "API Key 或地址有修改，请先保存配置，再测试真实连接。")
            return
        if not config.DEEPSEEK_API_KEY:
            QMessageBox.information(self, "AI 未配置", "请先填写并保存 DeepSeek API Key。")
            return
        self._ai_status_badge.setText(" AI 正在检测 ")
        self._connection_worker = AIConnectionWorker()
        self._connection_worker.completed.connect(self._on_connection_tested)
        self._connection_worker.start()

    def _on_connection_tested(self, success: bool, message: str):
        self._ai_status_badge.refresh()
        if success:
            QMessageBox.information(self, "AI 连接成功", message)
        else:
            QMessageBox.warning(self, "AI 连接失败", message)


class SubRulesTab(QWidget):
    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(16)

        layout.addWidget(SectionHeader("自动订阅规则"))

        card = QFrame()
        card.setStyleSheet("background:#fff; border:1px solid #e4eaf2; border-radius:18px; padding:20px;")
        cl = QVBoxLayout(card)

        row = QHBoxLayout()
        row.addWidget(QLabel("订阅间隔（天）"))
        self._interval = QSpinBox()
        self._interval.setRange(1, 90)
        self._interval.setValue(int(get_setting("subscription_interval_days", "7")))
        self._interval.setStyleSheet("border:1px solid #dbe3ef; border-radius:10px; padding:6px;")
        row.addWidget(self._interval)
        row.addStretch()
        cl.addLayout(row)

        row2 = QHBoxLayout()
        self._auto_enabled = QCheckBox("启用自动订阅")
        self._auto_enabled.setChecked(get_setting("auto_subscription_enabled", "true") == "true")
        row2.addWidget(self._auto_enabled)
        self._official_only = QCheckBox("自动任务仅订阅官方来源")
        self._official_only.setChecked(get_setting("subscription_official_only", "true") == "true")
        row2.addWidget(self._official_only)
        self._notify = QCheckBox("发现新数据时通知")
        self._notify.setChecked(get_setting("subscription_notify", "true") == "true")
        row2.addWidget(self._notify)
        self._download_attachments = QCheckBox("自动下载附件")
        self._download_attachments.setChecked(get_setting("subscription_download_attachments", "true") == "true")
        row2.addWidget(self._download_attachments)
        cl.addLayout(row2)

        layout.addWidget(card)

        official_source_note = QFrame()
        official_source_note.setStyleSheet("background:#fef3c7; border:1px solid #fed7aa; border-radius:14px; padding:14px;")
        onl = QVBoxLayout(official_source_note)
        onl.addWidget(QLabel("官方来源识别规则"))
        rules = QLabel(
            "系统自动识别 .gov.cn 域名及各级住建部门网站。"
            "第三方造价网站、论坛、公众号、网盘等来源不会被自动订阅。"
            "如需添加新的官方来源，请在【来源配置】页面中手动添加。"
        )
        rules.setWordWrap(True)
        rules.setStyleSheet("color:#92400e; font-size:12px; border:none;")
        onl.addWidget(rules)
        layout.addWidget(official_source_note)
        save_button = ActionButton("保存订阅规则", "primary")
        save_button.clicked.connect(self._save_rules)
        layout.addWidget(save_button)
        layout.addStretch()

    def _save_rules(self):
        try:
            set_settings({
                "subscription_interval_days": str(self._interval.value()),
                "auto_subscription_enabled": str(self._auto_enabled.isChecked()).lower(),
                "subscription_official_only": str(self._official_only.isChecked()).lower(),
                "subscription_notify": str(self._notify.isChecked()).lower(),
                "subscription_download_attachments": str(self._download_attachments.isChecked()).lower(),
            })
            QMessageBox.information(self, "保存成功", "订阅规则已保存，下次自动检查将按此规则执行。")
        except Exception as error:
            QMessageBox.warning(self, "保存失败", str(error))


class AnomalyThresholdTab(QWidget):
    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(16)

        layout.addWidget(SectionHeader("异常检测阈值"))

        card = QFrame()
        card.setStyleSheet("background:#fff; border:1px solid #e4eaf2; border-radius:18px; padding:20px;")
        cl = QVBoxLayout(card)
        self._number_inputs = {}
        self._check_inputs = {}

        rows = [
            ("价格涨跌阈值（%）", 30.0, "单月价格涨跌超过此比例则标记为异常"),
            ("最小合理价格（元）", 0.01, "低于此值的价格被视为异常"),
            ("最大合理价格（元）", 100000000.0, "超过此值的价格被视为异常"),
            ("规格缺失检测", 0, "数据中规格字段为空时标记异常"),
            ("单位变化检测", 0, "同一材料单位发生变化时标记异常"),
        ]
        for label, default, hint in rows:
            if isinstance(default, float) and default > 0:
                row = QHBoxLayout()
                lbl = QLabel(label)
                lbl.setStyleSheet("border:none;")
                row.addWidget(lbl)
                spin = QDoubleSpinBox()
                spin.setRange(0, 1000000000)
                spin.setValue(default)
                spin.setDecimals(2)
                spin.setStyleSheet("border:1px solid #dbe3ef; border-radius:10px; padding:6px;")
                row.addWidget(spin)
                self._number_inputs[label] = spin
                row.addStretch()
                row.addWidget(QLabel(hint))
                cl.addLayout(row)
            else:
                row = QHBoxLayout()
                chk = QCheckBox(label)
                chk.setChecked(True)
                self._check_inputs[label] = chk
                row.addWidget(chk)
                row.addStretch()
                hintl = QLabel(hint)
                hintl.setStyleSheet("color:#94a3b8; font-size:11px; border:none;")
                row.addWidget(hintl)
                cl.addLayout(row)

        layout.addWidget(card)
        save_button = ActionButton("保存阈值设置", "primary")
        save_button.clicked.connect(self._save_thresholds)
        layout.addWidget(save_button)
        layout.addStretch()

    def _save_thresholds(self):
        change = self._number_inputs["价格涨跌阈值（%）"].value() / 100
        minimum = self._number_inputs["最小合理价格（元）"].value()
        maximum = self._number_inputs["最大合理价格（元）"].value()
        if maximum <= minimum:
            QMessageBox.warning(self, "设置无效", "最大合理价格必须大于最小合理价格。")
            return
        try:
            set_settings({
                "price_change_threshold": str(change),
                "price_min_sane": str(minimum),
                "price_max_sane": str(maximum),
                "detect_missing_spec": str(self._check_inputs["规格缺失检测"].isChecked()).lower(),
                "detect_unit_change": str(self._check_inputs["单位变化检测"].isChecked()).lower(),
            })
            config.PRICE_CHANGE_THRESHOLD = change
            config.PRICE_MIN_SANE = minimum
            config.PRICE_MAX_SANE = maximum
            QMessageBox.information(self, "保存成功", "异常检测阈值已保存并立即生效。")
        except Exception as error:
            QMessageBox.warning(self, "保存失败", str(error))


class DbManagementTab(QWidget):
    def __init__(self):
        super().__init__()
        self._pending_data_dir = ""
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(16)

        stats_card = QFrame()
        stats_card.setStyleSheet("background:#fff; border:1px solid #e4eaf2; border-radius:18px; padding:20px;")
        sl = QVBoxLayout(stats_card)
        sl.addWidget(SectionHeader("数据库状态"))
        sl.addWidget(QLabel("数据库引擎: SQLite (WAL模式)"))
        self._db_file_label = QLabel("数据库文件: dashuo_cost_cloud.db")
        sl.addWidget(self._db_file_label)
        data_dir_row = QHBoxLayout()
        data_dir_row.addWidget(QLabel("数据保存目录"))
        self._data_dir_input = QLineEdit(str(config.USER_DATA_DIR))
        self._data_dir_input.setReadOnly(True)
        self._data_dir_input.setToolTip("数据目录切换将在重启软件后生效")
        self._data_dir_input.setStyleSheet("border:1px solid #dbe3ef; border-radius:10px; padding:6px 10px; background:#f8fafc;")
        data_dir_row.addWidget(self._data_dir_input, 1)
        choose_dir_btn = ActionButton("选择文件夹", "default")
        choose_dir_btn.clicked.connect(self._on_choose_data_directory)
        data_dir_row.addWidget(choose_dir_btn)
        sl.addLayout(data_dir_row)
        self._stats_label = QLabel("正在加载...")
        self._stats_label.setStyleSheet("color:#667085; border:none;")
        sl.addWidget(self._stats_label)
        layout.addWidget(stats_card)

        backup_card = QFrame()
        backup_card.setStyleSheet("background:#fff; border:1px solid #e4eaf2; border-radius:18px; padding:20px;")
        bl = QVBoxLayout(backup_card)
        bl.addWidget(SectionHeader("数据备份与恢复"))
        btn_row = QHBoxLayout()
        backup_btn = ActionButton("立即备份", "primary")
        backup_btn.clicked.connect(self._on_backup)
        btn_row.addWidget(backup_btn)
        restore_btn = ActionButton("恢复备份", "warn")
        restore_btn.clicked.connect(self._on_restore)
        btn_row.addWidget(restore_btn)
        integrity_btn = ActionButton("完整性检查", "default")
        integrity_btn.clicked.connect(self._on_integrity)
        btn_row.addWidget(integrity_btn)
        btn_row.addStretch()
        bl.addLayout(btn_row)

        self._backup_table = QTableWidget()
        self._backup_table.setColumnCount(4)
        self._backup_table.setHorizontalHeaderLabels(["文件名", "类型", "大小", "创建时间"])
        self._backup_table.horizontalHeader().setStretchLastSection(True)
        self._backup_table.setAlternatingRowColors(True)
        self._backup_table.setStyleSheet("QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } QTableWidget::item { padding:8px; } QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }")
        bl.addWidget(self._backup_table)
        layout.addWidget(backup_card)
        layout.addStretch()
        self.refresh_data()

    def refresh_data(self):
        stats = get_db_stats()
        self._data_dir_input.setText(self._pending_data_dir or str(config.USER_DATA_DIR))
        self._db_file_label.setText(f"数据库文件: {config.db_path()}")
        self._stats_label.setText(
            f"地区 {stats['regions']} 个，材料 {stats['materials']} 条，"
            f"价格 {stats['prices']} 条，项目 {stats['projects']} 个，备份 {stats['backups']} 个"
        )
        session = get_session()
        try:
            backups = session.query(BackupRecord).order_by(BackupRecord.created_at.desc()).limit(50).all()
            self._backup_table.setRowCount(len(backups))
            for row_index, backup in enumerate(backups):
                item = QTableWidgetItem(backup.file_name)
                item.setData(Qt.UserRole, backup.id)
                self._backup_table.setItem(row_index, 0, item)
                self._backup_table.setItem(row_index, 1, QTableWidgetItem(backup.backup_type))
                self._backup_table.setItem(row_index, 2, QTableWidgetItem(f"{backup.file_size / 1024:.1f} KB"))
                self._backup_table.setItem(row_index, 3, QTableWidgetItem(backup.created_at.strftime("%Y-%m-%d %H:%M")))
        finally:
            session.close()

    def _on_choose_data_directory(self):
        selected = QFileDialog.getExistingDirectory(
            self,
            "选择数据保存文件夹",
            str(config.USER_DATA_DIR),
        )
        if not selected:
            return
        success, message = config.configure_data_directory(selected)
        if not success:
            QMessageBox.warning(self, "切换失败", message)
            return
        self._pending_data_dir = selected
        self._data_dir_input.setText(selected)
        QMessageBox.information(
            self,
            "数据目录已准备",
            message + "\n\n请关闭并重新启动软件后生效。当前窗口仍继续使用旧目录。",
        )

    def _on_backup(self):
        result = backup_database("manual", "系统设置页手动备份")
        if result:
            QMessageBox.information(self, "备份成功", f"数据库已备份到：\n{result}")
            self.refresh_data()
        else:
            QMessageBox.warning(self, "备份失败", "无法创建备份，请检查数据库文件和磁盘空间。")

    def _on_restore(self):
        row = self._backup_table.currentRow()
        item = self._backup_table.item(row, 0) if row >= 0 else None
        if item is None:
            QMessageBox.information(self, "请选择备份", "请先选中要恢复的备份记录。")
            return
        reply = QMessageBox.question(self, "确认恢复", "恢复会先保留当前数据库副本，然后替换为选中备份。是否继续？", QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        if restore_backup(item.data(Qt.UserRole)):
            QMessageBox.information(self, "恢复完成", "备份已恢复。请重新启动软件以确保所有页面使用恢复后的数据。")
        else:
            QMessageBox.warning(self, "恢复失败", "无法恢复该备份，原数据库未被删除。")

    def _on_integrity(self):
        success, message = check_database_integrity()
        if success:
            QMessageBox.information(self, "检查通过", "数据库完整性正常。")
        else:
            QMessageBox.warning(self, "检查失败", message)
