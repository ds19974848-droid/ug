﻿"""数据记录模块页面：历史记录、操作日志、备份恢复、审计导出"""
import os
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget,
    QPushButton, QLineEdit, QMessageBox, QFileDialog,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont

from src.db import backup_database, get_session, restore_backup
from src.config import config
from src.models import AuditLog, BackupRecord, Material, PriceHistory, Region, SubscriptionTask, OfficialSource
from src.ui.widgets import StatusBadge, ActionButton, SectionHeader
from src.source_display import display_source_name, redact_text


class DataRecordsPage(QWidget):
    TAB_ROUTES = {
        "history": 0,
        "audit_logs": 1,
        "backup_restore": 2,
        "audit_export": 3,
    }

    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        self._tabs = QTabWidget()
        self._tabs.setStyleSheet("""
            QTabWidget::pane { border: none; background: #f0f4f9; }
            QTabBar::tab { padding: 10px 20px; font-weight: bold; border: none; color: #667085; }
            QTabBar::tab:selected { color: #2563eb; border-bottom: 3px solid #2563eb; }
        """)
        self._tabs.addTab(HistoryTab(), "历史记录")
        self._tabs.addTab(AuditLogsTab(), "操作日志")
        self._tabs.addTab(BackupRestoreTab(), "备份恢复")
        self._tabs.addTab(AuditExportTab(), "审计导出")
        layout.addWidget(self._tabs)

    def show_route(self, route_key: str):
        index = self.TAB_ROUTES.get(route_key, 0)
        self._tabs.setCurrentIndex(index)
        current_tab = self._tabs.widget(index)
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()

    def refresh_data(self):
        current_tab = self._tabs.currentWidget()
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()


class HistoryTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        filters = QHBoxLayout()
        self._filters = []
        for ph in ["按材料筛选", "按地区筛选", "按期数筛选"]:
            inp = QLineEdit()
            inp.setPlaceholderText(ph)
            inp.setFixedWidth(140)
            inp.setStyleSheet("border: 1px solid #dbe3ef; border-radius: 10px; padding: 6px 10px; font-size: 12px;")
            filters.addWidget(inp)
            self._filters.append(inp)
        filters.addStretch()
        search_btn = ActionButton("搜索", "primary")
        search_btn.clicked.connect(self.refresh_data)
        filters.addWidget(search_btn)
        export_btn = ActionButton("导出历史", "default")
        export_btn.clicked.connect(self._export_history)
        filters.addWidget(export_btn)
        layout.addLayout(filters)

        layout.addWidget(SectionHeader("价格历史（持久保存，关闭软件不丢失）"))

        self._table = QTableWidget()
        self._table.setColumnCount(6)
        self._table.setHorizontalHeaderLabels(["材料", "地区", "期数", "价格", "来源", "入库时间"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet("QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } QTableWidget::item { padding:8px; } QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }")
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            query = session.query(PriceHistory).join(Material).join(Region)
            material_keyword, region_keyword, period_keyword = [widget.text().strip() for widget in self._filters]
            if material_keyword:
                query = query.filter(Material.name.contains(material_keyword))
            if region_keyword:
                query = query.filter(Region.name.contains(region_keyword))
            if period_keyword:
                query = query.filter(PriceHistory.period.contains(period_keyword))
            rows = query.order_by(PriceHistory.created_at.desc()).limit(2000).all()
            self._table.setRowCount(len(rows))
            for row_index, history in enumerate(rows):
                material = session.query(Material).filter(Material.id == history.material_id).first()
                region = session.query(Region).filter(Region.id == history.region_id).first()
                self._table.setItem(row_index, 0, QTableWidgetItem(material.name if material else ""))
                self._table.setItem(row_index, 1, QTableWidgetItem(region.name if region else ""))
                self._table.setItem(row_index, 2, QTableWidgetItem(history.period))
                self._table.setItem(row_index, 3, QTableWidgetItem(f"{history.price:.2f}"))
                self._table.setItem(row_index, 4, QTableWidgetItem("官方信息价" if history.trust_level == "official" else ("公开市场参考数据" if history.trust_level == "market_reference" else history.trust_level)))
                self._table.setItem(row_index, 5, QTableWidgetItem(history.created_at.strftime("%Y-%m-%d %H:%M")))
        finally:
            session.close()

    def _export_history(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出价格历史", "价格历史.xlsx", "Excel 文件 (*.xlsx)")
        if not path:
            return
        try:
            from openpyxl import Workbook
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "价格历史"
            sheet.append([self._table.horizontalHeaderItem(column).text() for column in range(self._table.columnCount())])
            for row in range(self._table.rowCount()):
                sheet.append([self._table.item(row, column).text() if self._table.item(row, column) else "" for column in range(self._table.columnCount())])
            workbook.save(path)
            QMessageBox.information(self, "导出完成", f"已导出 {self._table.rowCount()} 条到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))


class AuditLogsTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        layout.addWidget(SectionHeader("操作日志（所有关键操作自动记录）"))

        self._table = QTableWidget()
        self._table.setColumnCount(5)
        self._table.setHorizontalHeaderLabels(["时间", "操作类型", "实体类型", "操作详情", "操作人"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet("QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } QTableWidget::item { padding:8px; } QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }")
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            logs = session.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(300).all()
            self._table.setRowCount(len(logs))
            for row_index, log in enumerate(logs):
                self._table.setItem(row_index, 0, QTableWidgetItem(log.created_at.strftime("%Y-%m-%d %H:%M")))
                self._table.setItem(row_index, 1, QTableWidgetItem(log.action))
                self._table.setItem(row_index, 2, QTableWidgetItem(log.entity_type))
                self._table.setItem(row_index, 3, QTableWidgetItem(log.detail))
                self._table.setItem(row_index, 4, QTableWidgetItem(log.user_name))
        finally:
            session.close()


class BackupRestoreTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        btns = QHBoxLayout()
        backup_btn = ActionButton("立即备份", "primary")
        backup_btn.clicked.connect(self._on_backup)
        btns.addWidget(backup_btn)
        restore_btn = ActionButton("恢复选中备份", "warn")
        restore_btn.clicked.connect(self._on_restore)
        btns.addWidget(restore_btn)
        open_btn = ActionButton("打开备份目录", "default")
        open_btn.clicked.connect(self._on_open_folder)
        btns.addWidget(open_btn)
        btns.addStretch()
        layout.addLayout(btns)

        layout.addWidget(SectionHeader("备份记录"))

        self._empty = QLabel("暂无备份。点击【立即备份】创建数据库备份。")
        self._empty.setStyleSheet("color:#94a3b8; font-size:13px;")
        self._empty.setAlignment(Qt.AlignCenter)
        layout.addWidget(self._empty)

        self._table = QTableWidget()
        self._table.setColumnCount(4)
        self._table.setHorizontalHeaderLabels(["备份文件", "类型", "大小", "创建时间"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet("QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } QTableWidget::item { padding:8px; } QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }")
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            backups = session.query(BackupRecord).order_by(BackupRecord.created_at.desc()).limit(100).all()
            self._empty.setVisible(len(backups) == 0)
            self._table.setRowCount(len(backups))
            for row_index, backup in enumerate(backups):
                item = QTableWidgetItem(backup.file_name)
                item.setData(Qt.UserRole, backup.id)
                self._table.setItem(row_index, 0, item)
                self._table.setItem(row_index, 1, QTableWidgetItem(backup.backup_type))
                self._table.setItem(row_index, 2, QTableWidgetItem(f"{backup.file_size / 1024:.1f} KB"))
                self._table.setItem(row_index, 3, QTableWidgetItem(backup.created_at.strftime("%Y-%m-%d %H:%M")))
        finally:
            session.close()

    def _on_backup(self):
        result = backup_database("manual", "数据记录页手动备份")
        if result:
            QMessageBox.information(self, "备份成功", f"数据库已备份到：\n{result}")
            self.refresh_data()
        else:
            QMessageBox.warning(self, "备份失败", "无法创建备份，请检查数据库文件和磁盘空间。")

    def _on_restore(self):
        row = self._table.currentRow()
        item = self._table.item(row, 0) if row >= 0 else None
        if item is None:
            QMessageBox.information(self, "请选择备份", "请先选中一条备份记录。")
            return
        reply = QMessageBox.question(self, "确认恢复", "确定恢复选中的数据库备份吗？当前数据库会先自动保留副本。", QMessageBox.Yes | QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        if restore_backup(item.data(Qt.UserRole)):
            QMessageBox.information(self, "恢复完成", "备份已恢复，请重新启动软件。")
        else:
            QMessageBox.warning(self, "恢复失败", "备份恢复失败，当前数据库保持不变。")

    def _on_open_folder(self):
        try:
            config.ensure_dirs()
            os.startfile(str(config.BACKUP_DIR))
        except Exception as error:
            QMessageBox.warning(self, "无法打开", str(error))


class AuditExportTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        layout.addWidget(SectionHeader("审计导出"))
        desc = QLabel("导出完整的操作记录和价格变更历史用于审计。数据格式为 Excel，包含所有操作日志、价格历史、备份记录。")
        desc.setWordWrap(True)
        desc.setStyleSheet("color:#667085; font-size:13px;")
        layout.addWidget(desc)

        filters = QHBoxLayout()
        self._filters = []
        for ph in ["开始日期 YYYY-MM-DD", "结束日期 YYYY-MM-DD", "操作类型"]:
            inp = QLineEdit()
            inp.setPlaceholderText(ph)
            inp.setFixedWidth(160)
            inp.setStyleSheet("border: 1px solid #dbe3ef; border-radius: 10px; padding: 6px 10px; font-size: 12px;")
            filters.addWidget(inp)
            self._filters.append(inp)
        filters.addStretch()
        export_btn = ActionButton("导出审计报告", "primary")
        export_btn.clicked.connect(self._export_audit)
        filters.addWidget(export_btn)
        layout.addLayout(filters)

        info = QFrame()
        info.setStyleSheet("background:#eff6ff; border:1px solid #dbeafe; border-radius:14px; padding:14px;")
        il = QVBoxLayout(info)
        il.addWidget(QLabel("审计导出内容"))
        items = QLabel(
            "操作日志（所有增删改查、导入导出、确认入库、版本恢复）\n"
            "价格历史（所有材料各月价格记录及来源）\n"
            "订阅记录（信息价订阅时间、来源、结果）\n"
            "备份记录（备份时间、类型、文件信息）"
        )
        items.setStyleSheet("color:#475569; font-size:12px; border:none;")
        il.addWidget(items)
        layout.addWidget(info)
        layout.addStretch()

    def _export_audit(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出审计报告", "审计报告.xlsx", "Excel 文件 (*.xlsx)")
        if not path:
            return
        start_text, end_text, action_text = [widget.text().strip() for widget in self._filters]
        try:
            start = datetime.strptime(start_text, "%Y-%m-%d") if start_text else None
            end = datetime.strptime(end_text, "%Y-%m-%d") if end_text else None
        except ValueError:
            QMessageBox.warning(self, "日期格式错误", "日期请使用 YYYY-MM-DD 格式。")
            return
        session = get_session()
        try:
            from openpyxl import Workbook
            workbook = Workbook()
            log_sheet = workbook.active
            log_sheet.title = "操作日志"
            log_sheet.append(["时间", "操作类型", "实体类型", "实体ID", "详情", "操作人"])
            log_query = session.query(AuditLog)
            if start:
                log_query = log_query.filter(AuditLog.created_at >= start)
            if end:
                log_query = log_query.filter(AuditLog.created_at <= end.replace(hour=23, minute=59, second=59))
            if action_text:
                log_query = log_query.filter(AuditLog.action.contains(action_text))
            for log in log_query.order_by(AuditLog.created_at).all():
                log_sheet.append([log.created_at, log.action, log.entity_type, log.entity_id, log.detail, log.user_name])

            history_sheet = workbook.create_sheet("价格历史")
            history_sheet.append(["材料", "地区", "期数", "价格", "单位", "规格", "可信等级", "时间"])
            for history in session.query(PriceHistory).order_by(PriceHistory.created_at).all():
                material = session.query(Material).filter(Material.id == history.material_id).first()
                region = session.query(Region).filter(Region.id == history.region_id).first()
                history_sheet.append([material.name if material else "", region.name if region else "", history.period, history.price, history.unit, history.spec, history.trust_level, history.created_at])

            task_sheet = workbook.create_sheet("订阅记录")
            task_sheet.append(["时间", "地区", "来源", "期数", "状态", "结果条数", "失败原因"])
            for task in session.query(SubscriptionTask).order_by(SubscriptionTask.created_at).all():
                region = session.query(Region).filter(Region.id == task.region_id).first()
                source = session.query(OfficialSource).filter(OfficialSource.id == task.source_id).first()
                task_sheet.append([task.created_at, region.name if region else "", display_source_name(source.name, source.url, source.source_type) if source else "", task.period, task.status, task.result_count, redact_text(task.message)])

            backup_sheet = workbook.create_sheet("备份记录")
            backup_sheet.append(["时间", "文件名", "类型", "大小", "路径"])
            for backup in session.query(BackupRecord).order_by(BackupRecord.created_at).all():
                backup_sheet.append([backup.created_at, backup.file_name, backup.backup_type, backup.file_size, backup.file_path])
            workbook.save(path)
            QMessageBox.information(self, "导出完成", f"审计报告已导出到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))
        finally:
            session.close()
