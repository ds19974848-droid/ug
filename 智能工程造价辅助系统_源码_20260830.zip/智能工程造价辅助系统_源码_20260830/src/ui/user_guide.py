"""首次使用说明和帮助入口。"""
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QDialogButtonBox, QHBoxLayout, QLabel,
    QPushButton, QTextBrowser, QVBoxLayout, QWidget,
)
from PySide6.QtCore import Qt

from src.db import get_setting, set_settings
from src.ui.widgets import ActionButton, SectionHeader


GUIDE_HTML = """
<style>
body { color:#334155; font-family:'Microsoft YaHei'; font-size:13px; line-height:1.65; }
h2 { color:#102b3d; font-size:18px; margin:0 0 8px; }
h3 { color:#146c72; font-size:14px; margin:16px 0 4px; }
.lead { color:#64748b; margin:0 0 14px; }
.step { background:#f8fafc; border-left:4px solid #49d7d0; padding:8px 12px; margin:7px 0; }
.warn { background:#fff7ed; border-left:4px solid #ffca70; padding:8px 12px; margin-top:12px; }
.contact { color:#dc2626; background:#fef2f2; border:1px solid #fecaca; font-size:18px; font-weight:700; padding:10px 12px; margin:8px 0 14px; }
strong { color:#102b3d; }
</style>
<h2>智能工程造价辅助系统｜操作说明</h2>
<div class="contact">获取授权码加V：13362385093，可以帮助安装 Codex，一起开发进步。</div>
<p class="lead">本软件用于工程清单整理、定额匹配、人材机组价、信息价查询、价格联动和成果导出。建议按以下顺序使用。</p>

<h3>一、开始前：新建项目信息</h3>
<div class="step"><strong>1. 新建项目</strong>：填写项目名称、项目类型、建设单位、施工单位、计价城市、计价日期、计价依据、税率和报价阶段。</div>
<div class="step"><strong>2. 先确定口径</strong>：地区、计价期、含税/除税口径和取费设置会影响匹配与价格计算，不能只看一个总价。</div>

<h3>二、定额库、信息价和基础数据库</h3>
<div class="step"><strong>定额库</strong>：维护可套用的定额及人材机明细。重点检查类别、定额编码、定额名称、单位、含量、除税单价和含税单价；同一材料不同规格、地区和计价期不要混为一条。</div>
<div class="step"><strong>信息价管理</strong>：管理官方来源、来源配置、原始文件、抓取任务和已入库价格。可查看哪些城市能直接抓取、哪些城市需要登录；需要登录时按提示登录后再抓取，也可以填写官方网址作为来源。</div>
<div class="step"><strong>官方价格入库</strong>：抓取后系统会识别城市、月份、材料名称、规格、单位、价格、含税/除税口径和来源文件，清理明显异常数据后入库。入库管理可按城市和月份筛选，并用于月度价格对比。</div>
<div class="step"><strong>基础数据库</strong>：地方官方信息价库用于已入库官方价格；固定工程清单库用于已确认的工程单价证据；市场参考库用于市场线索和估算；材料标准库用于统一材料名称、别名、规格和单位。四者用途不同，不能把市场参考价冒充官方价。</div>
<div class="step"><strong>企业参考定额表</strong>：位于“定额库”下，可导入企业参考定额总表和定额子目组成明细。系统按企业编码关联主项目、人工费、材料费、机械费和子目组成，保留地区、价格月份及全费用口径，仅作为同类案例参考，不会改写正式定额库。</div>

<h3>三、导入工程清单</h3>
<div class="step">进入“造价工作台 → 匹配定额库”，导入工程量清单、投标报价清单、投标文件或结算清单。系统会提取清单编码、工程名称、项目特征及工作内容、单位、工程量和原表价格。</div>
<div class="step">优先使用包含<strong>工程名称、项目特征及工作内容、单位、工程量</strong>的分部分项清单。没有项目特征时，系统会提示人工补充；原表空白不会自动填 0。</div>

<h3>四、造价工作台三个模块</h3>
<div class="step"><strong>匹配定额库</strong>：以清单名称、项目特征及工作内容为主，逐条识别人材机和工艺，计算单位综合单价及工程合价。</div>
<div class="step"><strong>匹配信息价与基础信息库</strong>：用于查询某一材料的地区、月份、规格、单位和价格证据，结果联动到组价明细，不是重新导入一份无来源的表。</div>
<div class="step"><strong>造价变化联动</strong>：可选择当前项目清单，也可导入表一、表二进行对比；系统按清单编码、名称、材料、工程量和综合单价对齐，展示差额、变化率和来源。</div>

<h3>五、匹配定额和组价</h3>
<div class="step"><strong>批量匹配</strong>：可匹配全部、筛选结果、选中一行或多行。系统会逐条识别项目特征中的材料、规格、强度等级、厚度、工艺和工作内容。</div>
<div class="step"><strong>每条清单只保留一个最佳定额</strong>：系统在内部比较候选后，只将逻辑最一致的一个定额写入清单；该定额自己的人工、主材、辅材、机械等组成明细完整进入组价和计算。双击定额库或组价明细中的单元格可以编辑。</div>
<div class="step"><strong>人工复核重点</strong>：低置信度、规格不完整、单位不一致、材料冲突、重复人材机、工作内容未覆盖和计算异常。</div>
<div class="warn"><strong>价格不是第一判断条件：</strong>只有定额、人材机、规格、单位和工艺逻辑合格后，系统才会在候选中参考原表价格择优。不能为了接近报价而套错定额。</div>

<h3>六、AI辅助流程</h3>
<div class="step"><strong>AI自动生成补充定额</strong>：本地定额无合适结果时，根据工程名称、项目特征及工作内容生成当前清单的人材机组成，并标注地区、计价期、来源、假设和复核状态。</div>
<div class="step"><strong>AI兜底匹配</strong>：本地定额、信息价和基础数据库均无法形成相关结果时，才进行相似材料或联网检索。AI不能凭空生成与清单无关的材料和价格。</div>
<div class="step"><strong>AI核查</strong>：重点检查人材机是否遗漏、重复、乱匹配，以及单位含量、税价和综合单价计算是否正常。所有 AI 结果都要人工复核。</div>

<h3>七、保存、联动和导出</h3>
<div class="step"><strong>保存</strong>：导入和匹配过程会自动保存到当前项目。关闭软件后重新打开项目，清单和匹配结果仍可恢复。</div>
<div class="step"><strong>造价变化联动</strong>：可以选择当前项目清单，或导入表一、表二进行对比；系统按清单、材料、工程量和价格展示变化。</div>
<div class="step"><strong>导出</strong>：匹配结果包含清单行、人材机子行、单位含量、工程量、含税/除税金额、价格偏差和匹配依据，导出后仍需按项目口径复核。</div>

<h3>八、设置、记录和安全</h3>
<div class="step"><strong>DeepSeek 配置</strong>：在系统设置填写 API 地址、模型和 API Key，测试成功后才启用联网 AI；未配置时本地定额、信息价和基础库仍可使用。</div>
<div class="step"><strong>订阅规则</strong>：设置自动订阅周期、是否仅官方来源、是否下载原始附件和是否通知。来源页面保留抓取状态、登录要求和失败原因。</div>
<div class="step"><strong>数据记录</strong>：历史记录、操作日志、审计导出用于追溯导入、匹配、修改、入库和导出；备份恢复用于保护项目和数据库。</div>
<div class="warn"><strong>建议顺序：</strong>项目信息 → 定额库/信息价库检查 → 导入分部分项清单 → 匹配定额 → 查看组价明细 → AI核查 → 保存 → 导出。发现异常先看项目特征、单位、规格和明细，不要只看综合单价。</div>
"""


class UserGuideBody(QWidget):
    """可嵌入设置页或首次启动对话框的说明内容。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        self._browser = QTextBrowser()
        self._browser.setOpenExternalLinks(False)
        self._browser.setHtml(GUIDE_HTML)
        self._browser.setStyleSheet(
            "QTextBrowser { background:#ffffff; border:1px solid #e2e8f0; "
            "border-radius:10px; padding:16px; }"
        )
        layout.addWidget(self._browser, 1)


class UserGuidePage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.addWidget(SectionHeader("使用说明"))
        intro = QLabel("按项目、数据库、清单、匹配、AI复核和导出的顺序操作，可减少漏项和误套定额。")
        intro.setStyleSheet("color:#64748b; padding:0 2px 6px;")
        layout.addWidget(intro)
        layout.addWidget(UserGuideBody(), 1)


class UserGuideDialog(QDialog):
    def __init__(self, parent=None, first_run: bool = False):
        super().__init__(parent)
        self.setWindowTitle("智能工程造价辅助系统｜操作说明")
        self.resize(900, 720)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 14)
        layout.addWidget(UserGuideBody(), 1)

        footer = QHBoxLayout()
        self._remember = QCheckBox("下次启动不再自动显示")
        self._remember.setChecked(first_run)
        footer.addWidget(self._remember)
        footer.addStretch()
        close_button = ActionButton("开始使用", "primary")
        close_button.clicked.connect(self.accept)
        footer.addWidget(close_button)
        layout.addLayout(footer)

    @property
    def remember_choice(self) -> bool:
        return self._remember.isChecked()


def show_first_run_guide(parent=None) -> None:
    if get_setting("user_guide_seen", "false") == "true":
        return
    dialog = UserGuideDialog(parent, first_run=True)
    dialog.exec()
    if dialog.remember_choice:
        set_settings({"user_guide_seen": "true"})
