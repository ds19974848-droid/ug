"""定额库页面：定额数据维护、工料机组成维护和 Excel/JSON 导入导出。"""
from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QCursor, QFontMetrics
from PySide6.QtWidgets import (
    QAbstractItemView,
    QAbstractSpinBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QInputDialog,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from src.db import get_session, write_audit
from src.models import QuotaComposition, QuotaItem
from src.quota_service import (
    calculate_direct_fee,
    delete_quota_item,
    export_quota_excel,
    export_quota_json,
    infer_quota_major,
    import_quota_excel,
    import_quota_json,
    list_quota_categories,
    list_quota_majors,
    QUOTA_DETAIL_CATEGORIES,
    save_quota_item,
    search_quota_items,
)
from src.ui.widgets import ActionButton, SectionHeader, install_long_text_tooltip


TABLE_STYLE = (
    "QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:8px; gridline-color:#edf1f6; } "
    "QTableWidget::item { padding:3px 6px; } "
    "QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:7px 7px; }"
)
INPUT_STYLE = "border:1px solid #dbe3ef; border-radius:8px; padding:6px 10px; font-size:12px;"


def _number_text(value) -> str:
    if value in (None, ""):
        return ""
    try:
        return f"{float(value):g}"
    except (TypeError, ValueError):
        return str(value)


def _percent_text(value) -> str:
    if not value:
        return ""
    try:
        return f"{float(value):g}%"
    except (TypeError, ValueError):
        return str(value)


def _parse_number(value: str, *, percent: bool = False) -> float:
    text = str(value or "").strip().replace(",", "").replace("%", "")
    if not text:
        return 0.0
    result = float(text)
    if percent and result != 0 and abs(result) <= 1:
        result *= 100
    return result


class CellContentEditDialog(QDialog):
    """在独立窗口中查看或修改单元格的完整内容。"""

    def __init__(self, title: str, value: str, *, editable: bool = True, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(620, 300)
        layout = QVBoxLayout(self)
        self._editor = QTextEdit()
        self._editor.setPlainText(value)
        self._editor.setReadOnly(not editable)
        self._editor.setStyleSheet(
            "QTextEdit { background:#fff; border:1px solid #dbe3ef; "
            "border-radius:8px; padding:8px; font-size:13px; }"
        )
        layout.addWidget(self._editor, 1)
        buttons = QDialogButtonBox(
            QDialogButtonBox.Save | QDialogButtonBox.Cancel
            if editable
            else QDialogButtonBox.Close
        )
        if editable:
            buttons.accepted.connect(self.accept)
            buttons.rejected.connect(self.reject)
        else:
            buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def value(self) -> str:
        return self._editor.toPlainText().strip()


class QuotaCompositionEditDialog(QDialog):
    def __init__(self, parent=None, values=None):
        super().__init__(parent)
        self.setWindowTitle("编辑工料机组成")
        self.setMinimumWidth(620)
        form = QFormLayout(self)

        self._category = QComboBox()
        self._category.setEditable(True)
        self._category.addItems([
            "人工费", "材料费", "辅材费", "主材费", "机械费", "专业分包", "其他",
        ])
        self._code = QLineEdit()
        self._name = QLineEdit()
        self._feature = QTextEdit()
        self._feature.setMaximumHeight(70)
        self._unit = QLineEdit()
        self._qty = self._spin(4)
        self._loss_rate = self._spin(4)
        self._no_tax_price = self._spin(4)
        self._tax_rate = self._spin(4)
        self._tax_price = self._spin(4)
        self._no_tax_total = self._spin(4)
        self._tax_total = self._spin(4)
        self._note = QLineEdit()

        for label, widget in [
            ("费用类别", self._category),
            ("工料机编码", self._code),
            ("工料机名称", self._name),
            ("工作内容", self._feature),
            ("单位", self._unit),
            ("单位含量", self._qty),
            ("损耗率%", self._loss_rate),
            ("除税单价", self._no_tax_price),
            ("税率%", self._tax_rate),
            ("含税单价", self._tax_price),
            ("除税合价", self._no_tax_total),
            ("含税合价", self._tax_total),
            ("备注", self._note),
        ]:
            form.addRow(label, widget)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        if values:
            self.load_values(values)

    def _spin(self, decimals: int) -> QDoubleSpinBox:
        spin = QDoubleSpinBox()
        spin.setRange(0, 1000000000)
        spin.setDecimals(decimals)
        spin.setButtonSymbols(QAbstractSpinBox.NoButtons)
        return spin

    def load_values(self, values: dict):
        category = str(values.get("cat") or values.get("category") or "")
        index = self._category.findText(category)
        if index >= 0:
            self._category.setCurrentIndex(index)
        else:
            self._category.setCurrentText(category)
        self._code.setText(str(values.get("code") or ""))
        self._name.setText(str(values.get("name") or ""))
        self._feature.setPlainText(str(values.get("feature") or ""))
        self._unit.setText(str(values.get("unit") or ""))
        self._qty.setValue(float(values.get("qty") or 0))
        self._loss_rate.setValue(float(values.get("loss") or 0))
        self._no_tax_price.setValue(float(values.get("noTaxPrice") or values.get("no_tax_price") or 0))
        self._tax_rate.setValue(float(values.get("taxRate") or values.get("tax_rate") or 0))
        self._tax_price.setValue(float(values.get("taxPrice") or values.get("tax_price") or 0))
        self._no_tax_total.setValue(float(values.get("noTaxTotal") or values.get("no_tax_total") or 0))
        self._tax_total.setValue(float(values.get("taxTotal") or values.get("tax_total") or 0))
        self._note.setText(str(values.get("note") or ""))

    def values(self) -> dict:
        return {
            "cat": self._category.currentText().strip(),
            "code": self._code.text().strip(),
            "name": self._name.text().strip(),
            "feature": self._feature.toPlainText().strip(),
            "unit": self._unit.text().strip(),
            "qty": self._qty.value(),
            "loss": self._loss_rate.value(),
            "noTaxPrice": self._no_tax_price.value(),
            "taxRate": self._tax_rate.value(),
            "taxPrice": self._tax_price.value(),
            "noTaxTotal": self._no_tax_total.value(),
            "taxTotal": self._tax_total.value(),
            "note": self._note.text().strip(),
        }


class QuotaEditDialog(QDialog):
    COMPOSITION_HEADERS = [
        "费用类别", "编码", "名称", "工作内容", "单位", "含量", "损耗率%",
        "除税单价", "税率%", "含税单价", "除税合价", "含税合价", "备注",
    ]

    def __init__(self, parent=None, initial=None, compositions=None):
        super().__init__(parent)
        self.setWindowTitle("新增定额" if not initial else "编辑定额")
        self.resize(960, 700)
        self._compositions = list(compositions or [])
        root = QVBoxLayout(self)

        header_form = QFormLayout()
        self._major = QComboBox()
        self._major.setEditable(True)
        self._major.addItems(["装修", "土建", "安装", "市政", "园林", "其他"])
        self._code = QLineEdit()
        self._name = QLineEdit()
        self._feature = QTextEdit()
        self._feature.setMaximumHeight(80)
        self._unit = QLineEdit()
        self._tax_price = self._spin()
        self._no_tax_price = self._spin()
        self._category = QLineEdit()
        self._source = QLineEdit()
        self._notes = QLineEdit()
        for label, widget in [
            ("专业", self._major),
            ("定额编码", self._code),
            ("定额名称", self._name),
            ("工作内容", self._feature),
            ("单位", self._unit),
            ("含税单价", self._tax_price),
            ("除税单价", self._no_tax_price),
            ("分类/备注", self._category),
            ("来源", self._source),
            ("说明", self._notes),
        ]:
            header_form.addRow(label, widget)
        root.addLayout(header_form)

        tools = QHBoxLayout()
        tools.addWidget(QLabel("工料机组成"))
        tools.addStretch()
        add_btn = ActionButton("添加组成", "primary")
        add_btn.clicked.connect(self._add_composition)
        tools.addWidget(add_btn)
        edit_btn = ActionButton("编辑组成", "default")
        edit_btn.clicked.connect(self._edit_composition)
        tools.addWidget(edit_btn)
        delete_btn = ActionButton("删除组成", "danger")
        delete_btn.clicked.connect(self._delete_composition)
        tools.addWidget(delete_btn)
        root.addLayout(tools)

        self._composition_table = QTableWidget(0, len(self.COMPOSITION_HEADERS))
        self._composition_table.setHorizontalHeaderLabels(self.COMPOSITION_HEADERS)
        self._composition_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self._composition_table.setSelectionBehavior(QTableWidget.SelectRows)
        self._composition_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._composition_table.setStyleSheet(TABLE_STYLE)
        install_long_text_tooltip(self._composition_table)
        root.addWidget(self._composition_table, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        if initial:
            self.load_initial(initial)
        self._refresh_composition_table()

    def _spin(self) -> QDoubleSpinBox:
        spin = QDoubleSpinBox()
        spin.setRange(0, 1000000000)
        spin.setDecimals(4)
        spin.setButtonSymbols(QAbstractSpinBox.NoButtons)
        return spin

    def load_initial(self, values: dict):
        major = str(values.get("major") or "装修")
        index = self._major.findText(major)
        if index >= 0:
            self._major.setCurrentIndex(index)
        else:
            self._major.setCurrentText(major)
        self._code.setText(str(values.get("code") or ""))
        self._name.setText(str(values.get("name") or ""))
        self._feature.setPlainText(str(values.get("feature") or ""))
        self._unit.setText(str(values.get("unit") or ""))
        self._tax_price.setValue(float(values.get("tax_price") or 0))
        self._no_tax_price.setValue(float(values.get("no_tax_price") or 0))
        self._category.setText(str(values.get("category") or ""))
        self._source.setText(str(values.get("source") or ""))
        self._notes.setText(str(values.get("notes") or ""))

    def _selected_composition_index(self) -> int:
        row = self._composition_table.currentRow()
        return row if 0 <= row < len(self._compositions) else -1

    def _refresh_composition_table(self):
        self._composition_table.setRowCount(len(self._compositions))
        for row, composition in enumerate(self._compositions):
            values = [
                composition.get("cat", ""),
                composition.get("code", ""),
                composition.get("name", ""),
                composition.get("feature", ""),
                composition.get("unit", ""),
                _number_text(composition.get("qty")),
                _percent_text(composition.get("loss")),
                _number_text(composition.get("noTaxPrice") or composition.get("no_tax_price")),
                _percent_text(composition.get("taxRate") or composition.get("tax_rate")),
                _number_text(composition.get("taxPrice") or composition.get("tax_price")),
                _number_text(composition.get("noTaxTotal") or composition.get("no_tax_total")),
                _number_text(composition.get("taxTotal") or composition.get("tax_total")),
                composition.get("note", ""),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                self._composition_table.setItem(row, column, item)

    def _add_composition(self):
        dialog = QuotaCompositionEditDialog(self)
        if dialog.exec() == QDialog.Accepted:
            self._compositions.append(dialog.values())
            self._refresh_composition_table()

    def _edit_composition(self):
        index = self._selected_composition_index()
        if index < 0:
            return
        dialog = QuotaCompositionEditDialog(self, self._compositions[index])
        if dialog.exec() == QDialog.Accepted:
            self._compositions[index] = dialog.values()
            self._refresh_composition_table()

    def _delete_composition(self):
        index = self._selected_composition_index()
        if index < 0:
            return
        self._compositions.pop(index)
        self._refresh_composition_table()

    def result_values(self) -> dict:
        return {
            "major": self._major.currentText().strip() or "装修",
            "code": self._code.text().strip(),
            "name": self._name.text().strip(),
            "feature": self._feature.toPlainText().strip(),
            "unit": self._unit.text().strip(),
            "tax_price": self._tax_price.value(),
            "no_tax_price": self._no_tax_price.value(),
            "category": self._category.text().strip(),
            "source": self._source.text().strip(),
            "notes": self._notes.text().strip(),
        }

    def result_compositions(self) -> list[dict]:
        return self._compositions

    def accept(self):
        if not self._name.text().strip():
            QMessageBox.warning(self, "信息不完整", "定额名称不能为空。")
            return
        super().accept()


class QuotaLibraryPage(QWidget):
    data_changed = Signal()
    navigate_requested = Signal(str)

    UPPER_HEADERS = ["类别", "定额编码", "定额名称", "单位", "除税单价", "含税单价"]
    LOWER_HEADERS = [
        "费用类别", "编码", "名称", "工作内容", "单位", "含量", "损耗率%",
        "除税单价", "税率%", "含税单价", "除税合价", "含税合价", "备注",
    ]
    UPPER_WIDTHS = [90, 130, 260, 70, 120, 120]
    LOWER_WIDTHS = [90, 100, 200, 320, 60, 80, 80, 100, 70, 100, 100, 100, 120]
    UPPER_FIELDS = ["category", "code", "name", "unit", "no_tax_price", "tax_price"]
    LOWER_FIELDS = [
        "category", "code", "name", "feature", "unit", "qty", "loss_rate",
        "no_tax_price", "tax_rate", "tax_price", "no_tax_total", "tax_total", "note",
    ]
    UPPER_NUMERIC_FIELDS = {"tax_price", "no_tax_price"}
    LOWER_NUMERIC_FIELDS = {
        "qty", "loss_rate", "no_tax_price", "tax_rate", "tax_price",
        "no_tax_total", "tax_total",
    }
    PERCENT_FIELDS = {"loss_rate", "tax_rate"}
    TOOLTIP_DURATION_MS = 30000

    def __init__(self):
        super().__init__()
        self._items: list[QuotaItem] = []
        self._detail_rows: list[dict] = []
        self._setup_ui()

    def show_route(self, route_key: str):
        self.refresh_data()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("定额明细库"))
        tools.addStretch()
        for text, callback, kind in [
            ("新增定额", self._add_quota, "primary"),
            ("编辑归属定额", self._edit_selected, "default"),
            ("删除明细", self._delete_selected, "danger"),
            ("导入 Excel", self._import_excel, "default"),
            ("导入 JSON", self._import_json, "default"),
            ("导出完整 JSON", self._export_json, "default"),
            ("导出明细 Excel", self._export_excel, "default"),
            ("恢复列宽", self._reset_column_widths, "default"),
            ("刷新", self.refresh_data, "default"),
        ]:
            button = ActionButton(text, kind)
            button.clicked.connect(callback)
            tools.addWidget(button)
        layout.addLayout(tools)

        filters = QHBoxLayout()
        self._keyword = QLineEdit()
        self._keyword.setPlaceholderText("搜索类别/定额名称/编码/单位")
        self._keyword.setStyleSheet(INPUT_STYLE)
        self._keyword.returnPressed.connect(self.refresh_data)
        filters.addWidget(self._keyword, 1)
        self._major = QComboBox()
        self._major.setStyleSheet(INPUT_STYLE)
        filters.addWidget(self._major)
        self._category = QComboBox()
        self._category.setStyleSheet(INPUT_STYLE)
        filters.addWidget(self._category)
        search_btn = ActionButton("筛选", "primary")
        search_btn.clicked.connect(self.refresh_data)
        filters.addWidget(search_btn)
        self._count_label = QLabel()
        self._count_label.setStyleSheet("color:#64748b;")
        filters.addWidget(self._count_label)
        layout.addLayout(filters)

        layout.addWidget(self._build_upper_table(), 1)
        # 保留下层控件接口兼容旧调用，但明细库页面只展示一张明细表。
        self._build_lower_table().hide()

        self._load_filters()
        self.refresh_data()

    def _build_upper_table(self) -> QTableWidget:
        table = QTableWidget(0, len(self.UPPER_HEADERS))
        table.setHorizontalHeaderLabels(self.UPPER_HEADERS)
        table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        table.setWordWrap(False)
        table.setTextElideMode(Qt.ElideRight)
        table.setMouseTracking(True)
        table.setSortingEnabled(False)
        header = table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setDefaultSectionSize(110)
        header.setHighlightSections(False)
        table.verticalHeader().setVisible(True)
        table.verticalHeader().setDefaultSectionSize(27)
        table.verticalHeader().setMinimumSectionSize(24)
        table.verticalHeader().setMinimumWidth(48)
        for column, width in enumerate(self.UPPER_WIDTHS):
            table.setColumnWidth(column, width)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.setStyleSheet(TABLE_STYLE)
        install_long_text_tooltip(table)
        table.itemSelectionChanged.connect(self._on_selection_changed)
        table.cellDoubleClicked.connect(self._on_cell_clicked)
        table.cellEntered.connect(self._on_cell_entered)
        self._upper_table = table
        return table

    def _build_lower_table(self) -> QTableWidget:
        table = QTableWidget(0, len(self.LOWER_HEADERS))
        table.setHorizontalHeaderLabels(self.LOWER_HEADERS)
        table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        table.setWordWrap(False)
        table.setTextElideMode(Qt.ElideRight)
        table.setMouseTracking(True)
        table.setSortingEnabled(False)
        header = table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setDefaultSectionSize(100)
        header.setHighlightSections(False)
        table.verticalHeader().setVisible(True)
        table.verticalHeader().setDefaultSectionSize(25)
        table.verticalHeader().setMinimumSectionSize(22)
        table.verticalHeader().setMinimumWidth(44)
        for column, width in enumerate(self.LOWER_WIDTHS):
            table.setColumnWidth(column, width)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.setStyleSheet(TABLE_STYLE)
        install_long_text_tooltip(table)
        table.cellDoubleClicked.connect(self._on_cell_clicked)
        table.cellEntered.connect(self._on_cell_entered)
        self._lower_table = table
        return table

    def _reset_column_widths(self):
        for column, width in enumerate(self.UPPER_WIDTHS):
            self._upper_table.setColumnWidth(column, width)
        for column, width in enumerate(self.LOWER_WIDTHS):
            self._lower_table.setColumnWidth(column, width)

    def _on_cell_clicked(self, row: int, column: int):
        table = self.sender()
        if table is self._upper_table:
            headers = self.UPPER_HEADERS
            fields = self.UPPER_FIELDS
        elif table is self._lower_table:
            headers = self.LOWER_HEADERS
            fields = self.LOWER_FIELDS
        else:
            return
        item = table.item(row, column)
        text = item.text() if item is not None else ""
        field = fields[column]
        editable = field is not None
        dialog = CellContentEditDialog(
            f"{headers[column]} - {'编辑内容' if editable else '查看内容'}",
            text,
            editable=editable,
            parent=self,
        )
        if dialog.exec() != QDialog.Accepted or not editable:
            return
        self._save_cell_value(table, row, column, field, dialog.value())

    def _on_cell_entered(self, row: int, column: int):
        table = self.sender()
        if table not in (self._upper_table, self._lower_table):
            return
        item = table.item(row, column)
        if item is None or not item.text():
            QToolTip.hideText()
            return
        text = item.text()
        metrics = QFontMetrics(table.font())
        longest_line = max(text.splitlines() or [""] , key=len)
        available_width = max(table.columnWidth(column) - 14, 0)
        if "\n" in text or metrics.horizontalAdvance(longest_line) > available_width:
            QToolTip.showText(
                QCursor.pos(), text, table, msecShowTime=self.TOOLTIP_DURATION_MS
            )
        else:
            QToolTip.hideText()

    def _save_cell_value(
        self,
        table: QTableWidget,
        row: int,
        column: int,
        field: str,
        value: str,
    ):
        item = table.item(row, column)
        record_id = item.data(Qt.UserRole) if item is not None else None
        if table is self._upper_table and item is not None:
            record_id = item.data(Qt.UserRole + 1) or record_id
        if not record_id:
            QMessageBox.warning(self, "保存失败", "未找到该单元格对应的数据记录。")
            return
        numeric_fields = (
            self.UPPER_NUMERIC_FIELDS
            if table is self._upper_table
            else self.LOWER_NUMERIC_FIELDS
        )
        try:
            parsed_value = (
                _parse_number(value, percent=field in self.PERCENT_FIELDS)
                if field in numeric_fields
                else value
            )
        except ValueError:
            QMessageBox.warning(self, "内容格式不正确", "该列必须填写数字。")
            return
        if table is self._upper_table and field == "name" and not value:
            QMessageBox.warning(self, "内容不能为空", "定额名称不能为空。")
            return

        session = get_session()
        try:
            model = QuotaComposition if table is self._upper_table else QuotaComposition
            record = session.query(model).filter(model.id == int(record_id)).first()
            if record is None:
                raise ValueError("数据记录已不存在，请刷新页面后重试。")
            old_value = getattr(record, field, "")
            setattr(record, field, parsed_value)
            quota_id = record.quota_item_id
            if table is self._upper_table:
                quota = session.query(QuotaItem).filter(QuotaItem.id == quota_id).first()
                if quota is None:
                    raise ValueError("该明细所属定额已不存在，请刷新页面后重试。")
                # 兼容旧版按主定额编码定位的调用；明细编码仍保存到组成表。
                if field == "code" and not quota.code:
                    quota.code = parsed_value
            record.updated_at = datetime.now()
            write_audit(
                session,
                "update",
                "quota_item" if table is self._upper_table else "quota_composition",
                record.id,
                f"单元格编辑: {self.UPPER_HEADERS[column] if table is self._upper_table else self.LOWER_HEADERS[column]}",
            )
            session.commit()
            self.refresh_data()
            self._select_quota_id(quota_id)
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _select_quota_id(self, quota_id: int):
        for row, detail in enumerate(self._detail_rows):
            if detail["quota"].id == quota_id:
                self._upper_table.selectRow(row)
                self._upper_table.scrollToItem(self._upper_table.item(row, 0))
                return

    def _load_filters(self):
        major_text = self._major.currentText() if self._major.count() else ""
        category_text = self._category.currentData() if self._category.count() else ""
        session = get_session()
        try:
            majors = list_quota_majors(session)
            categories = list(QUOTA_DETAIL_CATEGORIES)
        finally:
            session.close()
        self._major.blockSignals(True)
        self._major.clear()
        self._major.addItem("全部专业", "")
        for major in majors:
            self._major.addItem(major, major)
        index = self._major.findText(major_text)
        self._major.setCurrentIndex(max(index, 0))
        self._major.blockSignals(False)
        self._category.blockSignals(True)
        self._category.clear()
        self._category.addItem("全部分类", "")
        for category in categories:
            self._category.addItem(category, category)
        selected = self._category.findData(category_text)
        self._category.setCurrentIndex(max(selected, 0))
        self._category.blockSignals(False)

    def refresh_data(self):
        session = get_session()
        try:
            self._items = search_quota_items(
                session,
                major=self._major.currentData() or "",
                keyword="",
                category="",
            )
            keyword = self._keyword.text().strip().lower()
            category = self._category.currentData() or ""
            self._detail_rows = []
            for quota in self._items:
                for composition in quota.compositions:
                    if composition.category not in QUOTA_DETAIL_CATEGORIES:
                        continue
                    if category and composition.category != category:
                        continue
                    search_text = " ".join(str(value or "") for value in (
                        composition.category, composition.code, composition.name,
                        composition.unit,
                    )).lower()
                    if keyword and keyword not in search_text:
                        continue
                    self._detail_rows.append({"quota": quota, "composition": composition})
            self._count_label.setText(f"共 {len(self._detail_rows):,} 条明细")
            self._upper_table.setRowCount(len(self._detail_rows))
            for row, detail in enumerate(self._detail_rows):
                composition = detail["composition"]
                values = [
                    composition.category,
                    composition.code,
                    composition.name,
                    composition.unit,
                    _number_text(composition.no_tax_price),
                    _number_text(composition.tax_price),
                ]
                for column, value in enumerate(values):
                    table_item = QTableWidgetItem(str(value))
                    table_item.setData(Qt.UserRole, detail["quota"].id)
                    table_item.setData(Qt.UserRole + 1, composition.id)
                    if column in (4, 5):
                        table_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    else:
                        table_item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                    self._upper_table.setItem(row, column, table_item)
        finally:
            session.close()
        if self._items:
            self._upper_table.selectRow(0)
        else:
            self._lower_table.setRowCount(0)

    def _selected_index(self) -> int:
        row = self._upper_table.currentRow()
        return row if 0 <= row < len(self._detail_rows) else -1

    def _selected_detail(self) -> dict | None:
        index = self._selected_index()
        return self._detail_rows[index] if index >= 0 else None

    def _selected_item(self) -> QuotaItem | None:
        detail = self._selected_detail()
        return detail["quota"] if detail else None

    def _current_major_for_edit(self) -> str:
        value = self._major.currentData()
        return value or "装修"

    def _on_selection_changed(self):
        self._lower_table.setRowCount(0)

    def _add_quota(self):
        dialog = QuotaEditDialog(self, initial={"major": self._current_major_for_edit()})
        if dialog.exec() != QDialog.Accepted:
            return
        values = dialog.result_values()
        session = get_session()
        try:
            save_quota_item(
                session,
                major=values["major"],
                code=values["code"],
                name=values["name"],
                feature=values["feature"],
                unit=values["unit"],
                tax_price=values["tax_price"],
                no_tax_price=values["no_tax_price"],
                category=values["category"],
                source=values["source"] or "用户自建",
                notes=values["notes"],
                compositions=dialog.result_compositions(),
            )
            session.commit()
            self._load_filters()
            self.refresh_data()
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _edit_selected(self):
        item = self._selected_item()
        if item is None:
            QMessageBox.information(self, "请选择定额", "请先选中一条定额。")
            return
        initial = {
            "major": item.major,
            "code": item.code,
            "name": item.name,
            "feature": item.feature,
            "unit": item.unit,
            "tax_price": item.tax_price,
            "no_tax_price": item.no_tax_price,
            "category": item.category,
            "source": item.source,
            "notes": item.notes,
        }
        compositions = [
            {
                "cat": composition.category,
                "code": composition.code,
                "name": composition.name,
                "feature": composition.feature,
                "unit": composition.unit,
                "qty": composition.qty,
                "loss": composition.loss_rate,
                "noTaxPrice": composition.no_tax_price,
                "taxRate": composition.tax_rate,
                "taxPrice": composition.tax_price,
                "noTaxTotal": composition.no_tax_total,
                "taxTotal": composition.tax_total,
                "note": composition.note,
            }
            for composition in item.compositions
        ]
        item_id = item.id
        dialog = QuotaEditDialog(self, initial=initial, compositions=compositions)
        if dialog.exec() != QDialog.Accepted:
            return
        values = dialog.result_values()
        session = get_session()
        try:
            save_quota_item(
                session,
                quota_id=item_id,
                major=values["major"],
                code=values["code"],
                name=values["name"],
                feature=values["feature"],
                unit=values["unit"],
                tax_price=values["tax_price"],
                no_tax_price=values["no_tax_price"],
                category=values["category"],
                source=values["source"] or item.source,
                notes=values["notes"],
                compositions=dialog.result_compositions(),
            )
            session.commit()
            self.refresh_data()
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _delete_selected(self):
        detail = self._selected_detail()
        if detail is None:
            QMessageBox.information(self, "请选择明细", "请先选中一条工料机明细。")
            return
        item = detail["quota"]
        composition = detail["composition"]
        if QMessageBox.question(
            self,
            "删除确认",
            f"确定删除明细“{composition.name}”？\n所属定额：{item.name}",
            QMessageBox.Yes | QMessageBox.No,
        ) != QMessageBox.Yes:
            return
        session = get_session()
        try:
            record = session.query(QuotaComposition).filter(
                QuotaComposition.id == composition.id
            ).first()
            if record is not None:
                session.delete(record)
                write_audit(
                    session,
                    "delete",
                    "quota_composition",
                    composition.id,
                    f"删除定额明细: {composition.name}",
                )
            session.commit()
            self.refresh_data()
            self.data_changed.emit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "删除失败", str(error))
        finally:
            session.close()

    def _import_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "导入定额 Excel",
            "",
            "Excel 文件 (*.xlsx *.xls)",
        )
        if not path:
            return
        suggested_major = infer_quota_major(path, self._current_major_for_edit())
        major, confirmed = QInputDialog.getText(
            self,
            "确认定额专业",
            f"文件：{path}\n请确认该文件归入哪个专业：",
            text=suggested_major,
        )
        if not confirmed:
            return
        major = major.strip()
        if not major:
            QMessageBox.warning(self, "专业不能为空", "请填写专业名称后再导入。")
            return
        session = get_session()
        try:
            result = import_quota_excel(path, session, major=major)
            if not result.get("success"):
                QMessageBox.warning(self, "导入失败", result.get("error", "未知错误"))
                return
            session.commit()
            self._load_filters()
            self.refresh_data()
            self.data_changed.emit()
            reasons = result.get("rejection_reasons") or {}
            reason_text = ""
            if reasons:
                top_reasons = sorted(reasons.items(), key=lambda item: item[1], reverse=True)[:3]
                reason_text = "\n主要拦截原因：" + "；".join(
                    f"{reason} {count} 行" for reason, count in top_reasons
                )
            QMessageBox.information(
                self,
                "导入完成",
                f"专业：{result.get('major', major)}\n"
                f"识别工作表 {result.get('sheets', 1):,} 个，新增 {result['imported']:,} 条，"
                f"更新 {result['updated']:,} 条，拦截 {result['skipped']:,} 行。"
                f"{reason_text}",
            )
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "导入失败", str(error))
        finally:
            session.close()

    def _import_json(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "导入定额 JSON",
            "",
            "JSON 文件 (*.json)",
        )
        if not path:
            return
        session = get_session()
        try:
            result = import_quota_json(path, session, major=self._current_major_for_edit())
            if not result.get("success"):
                QMessageBox.warning(self, "导入失败", result.get("error", "未知错误"))
                return
            session.commit()
            self._load_filters()
            self.refresh_data()
            self.data_changed.emit()
            QMessageBox.information(
                self,
                "导入完成",
                f"新增 {result['imported']:,} 条，更新 {result['updated']:,} 条，跳过 {result['skipped']:,} 条。",
            )
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "导入失败", str(error))
        finally:
            session.close()

    def _export_json(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出定额 JSON", "装饰成本定额.json", "JSON 文件 (*.json)")
        if not path:
            return
        try:
            export_quota_json(self._items, path)
            QMessageBox.information(self, "导出完成", f"已导出 {len(self._items):,} 条定额到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))

    def _export_excel(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出定额 Excel", "装饰成本定额.xlsx", "Excel 文件 (*.xlsx)")
        if not path:
            return
        try:
            export_quota_excel(self._items, path)
            QMessageBox.information(self, "导出完成", f"已导出 {len(self._detail_rows):,} 条明细到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))
