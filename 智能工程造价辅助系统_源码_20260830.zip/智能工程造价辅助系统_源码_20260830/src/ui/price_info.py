"""信息价管理模块页面。"""
import json
import ipaddress
import os
import re
import webbrowser
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import requests
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget,
    QPushButton, QLineEdit, QScrollArea, QComboBox, QTextEdit, QCheckBox,
    QMessageBox, QFileDialog, QDialog, QDialogButtonBox, QInputDialog,
    QProgressBar, QSplitter,
)
from PySide6.QtCore import Qt, Signal, QThread, QTimer
from PySide6.QtGui import QFont

from src.db import get_session, get_setting, set_settings, write_audit
from src.models import (
    OfficialSource, SubscriptionTask, SourceDocument, Region, RegionStandard,
    Material, MaterialPrice,
)
from src.ui.widgets import StatusBadge, ActionButton, SectionHeader
from src.config import config
from src.source_display import display_file_name, display_source_name, display_source_url, redact_text


def _text(value) -> str:
    """Normalize optional database/UI values before rendering them."""
    return "" if value is None else str(value).strip()


class SubscriptionWorker(QThread):
    completed = Signal(dict)
    progress_changed = Signal(dict)

    def __init__(
        self,
        source_ids: list[int],
        period: str = "",
        specialty: str = "",
        keywords: list[str] | None = None,
    ):
        super().__init__()
        self.source_ids = source_ids
        self.period = period
        self.specialty = specialty
        self.keywords = keywords or []

    def run(self):
        try:
            from src.subscription import SubscriptionEngine
            with SubscriptionEngine(
                self.period,
                self.specialty,
                self.keywords,
                progress_callback=self.progress_changed.emit,
            ) as engine:
                self.completed.emit(engine.run_sources(self.source_ids))
        except Exception as error:
            self.completed.emit({
                "total": len(self.source_ids), "success": 0, "failed": len(self.source_ids),
                "new_prices": 0, "errors": [str(error)],
            })


class AISourceSearchWorker(QThread):
    completed = Signal(str, dict)
    progress_changed = Signal(str)

    def __init__(
        self,
        city: str,
        period: str = "",
        specialty: str = "",
        province: str = "",
        seed_sources: list[dict] | None = None,
    ):
        super().__init__()
        self.city = city
        self.period = period
        self.specialty = specialty
        self.province = province
        self.seed_sources = seed_sources or []

    def run(self):
        try:
            from src.ai_service import ai
            from src.official_source_discovery import discover_official_sources

            self.progress_changed.emit(f"正在搜索 {self.city} 官方信息价发布线索...")
            evidence_result = discover_official_sources(
                self.city,
                self.period,
                self.specialty,
                self.province,
                seed_sources=self.seed_sources,
            )
            evidence = evidence_result.get("sources", [])
            self.progress_changed.emit(
                f"已验证 {len(evidence)} 个官方候选，正在由 AI 识别接口、附件和登录要求..."
            )
            result = ai.search_official_sources(
                self.city,
                self.period,
                self.specialty,
                research_evidence=evidence,
            )
            result["queries"] = evidence_result.get("queries", [])
            result["strategy_steps"] = evidence_result.get("strategy_steps", [])
            result["searched_count"] = evidence_result.get("searched_count", 0)
            result["candidate_count"] = evidence_result.get("candidate_count", 0)
            result["rejected"] = evidence_result.get("rejected", [])
            self.completed.emit(self.city, result)
        except Exception as error:
            self.completed.emit(self.city, {"sources": [], "error": str(error)})


class ApiSnifferWorker(QThread):
    completed = Signal(dict)
    progress_changed = Signal(str)

    def __init__(self, url: str, timeout: int = 30):
        super().__init__()
        self.url = url
        self.timeout = timeout

    def run(self):
        try:
            from src.api_sniffer import sniff_apis

            result = sniff_apis(
                self.url,
                timeout=self.timeout,
                progress_callback=self.progress_changed.emit,
                should_stop=self.isInterruptionRequested,
            )
        except Exception as error:
            result = {"error": str(error)}
        self.completed.emit(result)


class BrowserLoginWorker(QThread):
    completed = Signal(dict)
    progress_changed = Signal(str)

    def __init__(self, source_url: str):
        super().__init__()
        self.source_url = source_url
        self._session_info = None
        self._capture_requested = False

    def request_capture(self):
        self._capture_requested = True

    def run(self):
        from src.browser_login import (
            launch_visible_browser,
            wait_for_user_login_and_capture,
            close_browser_login,
        )
        try:
            self.progress_changed.emit("正在启动浏览器...")
            session = launch_visible_browser(
                self.source_url,
                timeout_seconds=300,
                progress_callback=self.progress_changed.emit,
            )
            if not session.get("success"):
                self.completed.emit({"success": False, "error": session.get("error", "浏览器启动失败")})
                return
            self._session_info = session
            from src.browser_capture import _CdpSession
            cdp = _CdpSession(session["socket"])
            result = wait_for_user_login_and_capture(
                cdp,
                timeout_seconds=300,
                progress_callback=self.progress_changed.emit,
                capture_requested=lambda: self._capture_requested,
            )
            self.completed.emit(result)
        except Exception as exc:
            self.completed.emit({"success": False, "error": str(exc)[:500]})
        finally:
            if self._session_info:
                close_browser_login(self._session_info)
                self._session_info = None


def _canonical_url(url: str) -> str:
    parsed = urlparse(url.strip())
    return f"{(parsed.hostname or '').lower()}{parsed.path.rstrip('/')}"


def _friendly_connection_error(error: Exception) -> str:
    text = str(error)
    if "NameResolutionError" in text or "getaddrinfo failed" in text or "Failed to resolve" in text:
        return "网址域名不存在或已失效，可能是 AI 返回了错误网址"
    if "timed out" in text.lower() or "timeout" in text.lower():
        return "网站响应超时，请稍后重试"
    if "403" in text:
        return "网站拒绝自动访问（HTTP 403），需要浏览器登录或来源适配"
    if "404" in text:
        return "页面不存在（HTTP 404），网址可能已调整"
    return text[:240]


class PriceInfoPage(QWidget):
    """信息价管理：包含官方订阅、来源配置、原始文件三个子页面"""
    data_changed = Signal()
    navigate_requested = Signal(str)

    TAB_ROUTES = {
        "subscription": 0,
        "source_config": 1,
        "source_docs": 2,
    }

    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        self._tabs = QTabWidget()
        self._tabs.setStyleSheet("""
            QTabWidget::pane { border: none; background: #f0f4f9; }
            QTabBar::tab { padding: 10px 20px; font-weight: bold; border: none; color: #667085; }
            QTabBar::tab:selected { color: #2563eb; border-bottom: 3px solid #2563eb; }
        """)
        self._subscription_tab = SubscriptionTab()
        self._source_tab = SourceConfigTab()
        self._docs_tab = SourceDocsTab()
        for tab in (self._subscription_tab, self._source_tab, self._docs_tab):
            tab.data_changed.connect(self.data_changed)
        self._subscription_tab.navigate_requested.connect(self.navigate_requested)
        self._tabs.addTab(self._subscription_tab, "官方订阅")
        self._tabs.addTab(self._source_tab, "来源配置")
        self._tabs.addTab(self._docs_tab, "原始文件")
        layout.addWidget(self._tabs)

    def show_route(self, route_key: str):
        index = self.TAB_ROUTES.get(route_key, 0)
        self._tabs.setCurrentIndex(index)
        current_tab = self._tabs.widget(index)
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()
        if route_key == "subscription":
            pending_city = get_setting("price_info_pending_city_query", "").strip()
            pending_period = get_setting("price_info_pending_period", "").strip()
            if pending_city:
                self._subscription_tab.set_city_query(pending_city)
            if pending_period:
                self._subscription_tab.set_period(pending_period)
            if pending_city or pending_period:
                set_settings({
                    "price_info_pending_city_query": "",
                    "price_info_pending_period": "",
                })

    def set_city_query(self, query: str):
        self.show_route("subscription")
        self._subscription_tab.set_city_query(query)

    def refresh_data(self):
        current_tab = self._tabs.currentWidget()
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()


class SubscriptionTab(QWidget):
    data_changed = Signal()
    navigate_requested = Signal(str)

    STRATEGY_META = {
        "api": (
            "第一步：官方专用接口；仅在官方价格数据验证通过时使用",
            "",
        ),
        "market_reference": (
            "第二步：公开市场参考价；官方没有接口、失败或无数据时自动进入",
            "",
        ),
        "browser_login": (
            "第三步：官方动态页面或登录来源；需要用户完成浏览器登录",
            "",
        ),
        "crawl": (
            "第四步：公开文件通用解析；下载后识别 Excel、PDF、CSV 等格式",
            "",
        ),
    }
    STATUS_LABELS = {
        "working": "可抓取",
        "public_document": "附件公开/待解析",
        "login_required": "需要登录",
        "membership_required": "需要会员",
        "connection_blocked": "连接受阻",
        "wrong_url": "网址失效或错误",
        "wrong_content": "栏目内容不符",
        "pending_parser": "待定制解析",
        "pending_adapter": "待定位/适配",
        "browser_dynamic": "浏览器动态/待适配",
        "public_scanned_document": "扫描附件/OCR待纠错",
        "province_fallback": "省级资料/非城市月刊",
        "no_current_source": "仅有旧资料",
        "no_public_source": "官网未公开现行数据",
        "waf_blocked": "网站防火墙拦截",
    }

    def __init__(self):
        super().__init__()
        self._subscription_worker = None
        self._browser_worker = None
        self._source_search_worker = None
        self._discovery_validation_worker = None
        self._last_fetch_context = {}
        self._setup_ui()
        self._load_cities()
        self._refresh_strategy_table()
        self._refresh_results()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(8)
        toolbar.addWidget(QLabel("城市"))
        self._city_combo = QComboBox()
        self._city_combo.setEditable(True)
        self._city_combo.setMinimumWidth(150)
        self._city_combo.setMinimumHeight(32)
        self._city_combo.currentTextChanged.connect(self._on_city_changed)
        toolbar.addWidget(self._city_combo)
        self._ai_source_btn = QPushButton("AI查找官方接口")
        self._ai_source_btn.setCursor(Qt.PointingHandCursor)
        self._ai_source_btn.setMinimumHeight(32)
        self._ai_source_btn.setToolTip(
            "搜索并验证该城市的官方信息价页面、公开附件和接口线索；不会覆盖现有来源"
        )
        self._ai_source_btn.clicked.connect(self._on_ai_source_search)
        toolbar.addWidget(self._ai_source_btn)
        toolbar.addWidget(QLabel("期数"))
        self._period_input = QLineEdit()
        self._period_input.setPlaceholderText("如 2026-07，留空抓最新")
        self._period_input.setMaximumWidth(155)
        toolbar.addWidget(self._period_input)
        self._query_btn = QPushButton("按最佳策略抓取")
        self._query_btn.setCursor(Qt.PointingHandCursor)
        self._query_btn.setMinimumHeight(36)
        self._query_btn.clicked.connect(self._on_query_prices)
        toolbar.addWidget(self._query_btn)
        self._market_query_btn = QPushButton("抓取公开市场参考价")
        self._market_query_btn.setCursor(Qt.PointingHandCursor)
        self._market_query_btn.setMinimumHeight(36)
        self._market_query_btn.setToolTip("没有可用官方 API 时，按所选城市和期数抓取公开市场参考价")
        self._market_query_btn.clicked.connect(self._on_market_query)
        toolbar.addWidget(self._market_query_btn)
        toolbar.addStretch()
        toolbar.addWidget(QLabel("用户网址"))
        self._custom_url_input = QLineEdit()
        self._custom_url_input.setPlaceholderText("输入本人有权访问的官网/信息价栏目网址")
        self._custom_url_input.setMinimumHeight(32)
        self._custom_url_input.textChanged.connect(self._update_custom_url_controls)
        self._custom_url_input.setMinimumWidth(260)
        toolbar.addWidget(self._custom_url_input, 1)
        self._open_custom_url_btn = QPushButton("打开网址")
        self._open_custom_url_btn.setCursor(Qt.PointingHandCursor)
        self._open_custom_url_btn.setMinimumHeight(32)
        self._open_custom_url_btn.clicked.connect(self._on_open_custom_url)
        toolbar.addWidget(self._open_custom_url_btn)
        self._login_custom_url_btn = QPushButton("登录网址")
        self._login_custom_url_btn.setCursor(Qt.PointingHandCursor)
        self._login_custom_url_btn.setMinimumHeight(32)
        self._login_custom_url_btn.setToolTip("在可见浏览器中登录，并加密保存该来源的 Cookie")
        self._login_custom_url_btn.clicked.connect(self._on_custom_url_login)
        toolbar.addWidget(self._login_custom_url_btn)
        self._custom_fetch_btn = QPushButton("抓取输入网址")
        self._custom_fetch_btn.setCursor(Qt.PointingHandCursor)
        self._custom_fetch_btn.setMinimumHeight(32)
        self._custom_fetch_btn.clicked.connect(self._on_custom_url_fetch)
        toolbar.addWidget(self._custom_fetch_btn)
        layout.addLayout(toolbar)

        status_row = QHBoxLayout()
        status_row.setSpacing(8)
        self._city_status = QLabel("请选择城市查看实测抓取状态。")
        self._city_status.setWordWrap(True)
        self._city_status.setStyleSheet("color:#475569; font-size:12px;")
        status_row.addWidget(self._city_status, 1)
        self._summary_values = {}
        chip_colors = {
            "working": ("#15803d", "#dcfce7"),
            "login": ("#b45309", "#fef3c7"),
            "document": ("#1d4ed8", "#dbeafe"),
            "checked": ("#475569", "#f1f5f9"),
        }
        for key, label in [
            ("working", "可直接抓取"),
            ("login", "需登录/会员"),
            ("document", "公开文件待适配"),
            ("checked", "已核查城市"),
        ]:
            chip = QLabel(f"0 {label}")
            fg, bg = chip_colors[key]
            chip.setStyleSheet(
                f"color:{fg};background:{bg};border-radius:10px;padding:3px 9px;font-size:11px;"
            )
            status_row.addWidget(chip)
            self._summary_values[key] = chip
        layout.addLayout(status_row)

        self._custom_consent = QCheckBox("仅抓取本人有权访问的网址，不绕过登录、会员、验证码和访问控制")
        self._custom_consent.setStyleSheet("color:#9a3412;font-size:11px;")
        self._custom_consent.stateChanged.connect(self._update_custom_url_controls)
        layout.addWidget(self._custom_consent)

        self._custom_url_status = QLabel("")
        self._custom_url_status.setStyleSheet("color:#64748b;font-size:12px;")
        layout.addWidget(self._custom_url_status)

        self._progress_bar = QProgressBar()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setFixedHeight(12)
        self._progress_bar.setVisible(False)
        layout.addWidget(self._progress_bar)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(6)
        splitter.setStyleSheet("QSplitter::handle { background:#e2e8f0; }")

        strategy_panel = QWidget()
        strategy_layout = QVBoxLayout(strategy_panel)
        strategy_layout.setContentsMargins(0, 0, 0, 0)
        strategy_layout.setSpacing(8)
        strategy_layout.addWidget(SectionHeader("城市抓取策略"))
        self._strategy_table = QTableWidget()
        self._strategy_table.setColumnCount(3)
        self._strategy_table.setHorizontalHeaderLabels(["策略", "说明", "实测城市/状态"])
        self._strategy_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self._strategy_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self._strategy_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self._strategy_table.verticalHeader().setVisible(False)
        self._strategy_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._strategy_table.setSelectionMode(QTableWidget.NoSelection)
        self._strategy_table.setWordWrap(True)
        self._strategy_table.setAlternatingRowColors(True)
        self._strategy_table.setMinimumHeight(220)
        self._strategy_table.setStyleSheet(
            "QTableWidget{background:#fff;border:1px solid #e5e7eb;border-radius:8px;gridline-color:#eef2f7;}"
            "QTableWidget::item{padding:7px;}"
            "QHeaderView::section{background:#fff;color:#111827;font-weight:bold;border:none;border-bottom:1px solid #e5e7eb;padding:7px;}"
        )
        strategy_layout.addWidget(self._strategy_table, 1)
        self._unsupported_label = QLabel("")
        self._unsupported_label.setWordWrap(True)
        self._unsupported_label.setStyleSheet("color:#64748b; font-size:11px;")
        strategy_layout.addWidget(self._unsupported_label)
        strategy_panel.setMinimumWidth(390)
        splitter.addWidget(strategy_panel)

        result_panel = QWidget()
        result_layout = QVBoxLayout(result_panel)
        result_layout.setContentsMargins(0, 0, 0, 0)
        result_layout.setSpacing(8)
        result_layout.addWidget(SectionHeader("最近抓取结果"))
        self._result_summary = QLabel("选择城市后显示已入库价格；抓取完成后会立即刷新本区域。")
        self._result_summary.setWordWrap(True)
        self._result_summary.setStyleSheet("color:#475569; font-size:12px; padding:2px 4px;")
        result_layout.addWidget(self._result_summary)
        self._result_table = QTableWidget()
        self._result_table.setColumnCount(9)
        self._result_table.setHorizontalHeaderLabels(["城市", "材料", "规格", "单位", "价格", "期数", "状态", "来源类型", "价格依据"])
        self._result_table.horizontalHeader().setStretchLastSection(True)
        self._result_table.setAlternatingRowColors(True)
        self._result_table.setStyleSheet(
            "QTableWidget{background:#fff;border:1px solid #edf1f6;border-radius:8px;gridline-color:#edf1f6;}"
            "QTableWidget::item{padding:7px;}"
            "QHeaderView::section{background:#f8fafc;color:#64748b;font-weight:bold;border:none;padding:7px;}"
        )
        result_layout.addWidget(self._result_table, 1)
        result_panel.setMinimumWidth(560)
        splitter.addWidget(result_panel)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 5)
        splitter.setSizes([420, 760])
        layout.addWidget(splitter, 1)

        bottom = QHBoxLayout()
        for label_text, route in [("来源配置", "source_config"), ("价格库", "price_library")]:
            btn = QPushButton(label_text)
            btn.setFlat(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet("color:#2563eb; font-size:12px; border:none;")
            btn.clicked.connect(lambda checked=False, r=route: self.navigate_requested.emit(r))
            bottom.addWidget(btn)
        bottom.addStretch()
        layout.addLayout(bottom)

    def _load_cities(self):
        session = get_session()
        try:
            from src.official_sources_config import CITY_SOURCES, _ZAOJIAHOME_CITY_PROVINCES

            db_cities = [
                region.name for region in session.query(Region).filter(Region.is_active == True).all()
                if region.name
            ]
            cities = sorted({*db_cities, *CITY_SOURCES.keys(), *_ZAOJIAHOME_CITY_PROVINCES.keys()})
            previous_city = self._city_combo.currentText().strip()
            self._city_combo.clear()
            self._city_combo.addItem("-- 选择城市 --")
            for city in cities:
                self._city_combo.addItem(city)
            preferred_city = previous_city if previous_city and not previous_city.startswith("--") else "上海"
            preferred_index = self._city_combo.findText(preferred_city, Qt.MatchFixedString)
            self._city_combo.setCurrentIndex(preferred_index if preferred_index >= 0 else 0)
        finally:
            session.close()

    def set_city_query(self, query: str):
        query = query.strip()
        if not query:
            return
        for index in range(self._city_combo.count()):
            city_name = self._city_combo.itemText(index)
            if city_name and city_name != "-- 选择城市 --" and city_name in query:
                self._city_combo.setCurrentIndex(index)
                self._on_city_changed(city_name)
                return
        city_name = query.split()[0]
        self._city_combo.setEditText(city_name)
        self._city_status.setText(f"已输入 {city_name}，若没有可用来源会标注为待分析。")

    @staticmethod
    def _catalog_city_name(city: str) -> str:
        from src.official_sources_config import CITY_SOURCES

        value = (city or "").strip()
        if value in CITY_SOURCES:
            return value
        if value.endswith("市") and value[:-1] in CITY_SOURCES:
            return value[:-1]
        return value

    def _city_discovery_state(self, city: str) -> dict:
        from src.api_fetcher import has_api_handler
        from src.official_sources_config import CITY_SOURCES, get_public_market_source_config

        catalog_city = self._catalog_city_name(city)
        configs = list(CITY_SOURCES.get(catalog_city, []))
        generic_market = get_public_market_source_config(catalog_city)
        if generic_market and not any(item.get("source_class") == "market_reference" for item in configs):
            configs.append(generic_market)
        api_sources = [
            item for item in configs
            if item.get("strategy") == "api"
            and item.get("data_status") == "working"
            and has_api_handler(item.get("url", ""))
            and item.get("is_official", True)
        ]
        market_sources = [
            item for item in configs
            if item.get("strategy") == "api"
            and item.get("data_status") == "working"
            and item.get("source_class") == "market_reference"
            and has_api_handler(item.get("url", ""))
        ]
        generic_sources = [
            item for item in configs
            if item.get("url")
            and item.get("is_official", True)
            and item.get("data_status") not in {"wrong_content", "no_public_source"}
        ]
        discovered_sources = []
        validated_sources = []
        login_sources = []
        retry_sources = []
        province = ""
        session = get_session()
        try:
            region_names = {city, catalog_city}
            regions = session.query(Region).filter(Region.name.in_(region_names)).all()
            if regions:
                province = next((region.province for region in regions if region.province), "")
                region_ids = [region.id for region in regions]
                db_sources = session.query(OfficialSource).filter(
                    OfficialSource.region_id.in_(region_ids),
                    OfficialSource.is_active.is_(True),
                ).all()
                for source in db_sources:
                    discovered = source.source_type == "ai_discovered"
                    metadata = {}
                    if not discovered:
                        try:
                            metadata = json.loads(source.notes or "{}")
                            discovered = bool(
                                isinstance(metadata, dict)
                                and metadata.get("ai_discovery_completed")
                            )
                        except json.JSONDecodeError:
                            discovered = False
                    if discovered:
                        discovered_sources.append(source)
                        if not metadata:
                            try:
                                metadata = json.loads(source.notes or "{}")
                                if not isinstance(metadata, dict):
                                    metadata = {}
                            except json.JSONDecodeError:
                                metadata = {}
                        validation_status = metadata.get("validation_status", "")
                        if validation_status == "working":
                            validated_sources.append(source)
                        elif validation_status == "login_required":
                            login_sources.append(source)
                        else:
                            retry_sources.append(source)
        finally:
            session.close()
        if not any(item.get("source_class") == "market_reference" for item in configs):
            generic_market = get_public_market_source_config(catalog_city, province)
            if generic_market:
                configs.append(generic_market)
                market_sources.append(generic_market)
        return {
            "catalog_city": catalog_city,
            "province": province,
            "configs": configs,
            "api_sources": api_sources,
            "market_sources": market_sources,
            "generic_sources": generic_sources,
            "discovered_sources": discovered_sources,
            "validated_sources": validated_sources,
            "login_sources": login_sources,
            "retry_sources": retry_sources,
        }

    @staticmethod
    def _is_market_reference_config(config: dict | None) -> bool:
        return bool(
            config
            and config.get("source_class") == "market_reference"
            and config.get("strategy") == "api"
            and config.get("data_status") == "working"
        )

    def _on_ai_source_search(self):
        city = self._city_combo.currentText().strip()
        if not city or city.startswith("--"):
            QMessageBox.warning(self, "请输入城市", "请先选择或输入需要查找官方来源的城市。")
            return
        if self._source_search_worker is not None:
            QMessageBox.information(self, "正在查找", "当前官方来源查找任务尚未完成，请稍候。")
            return
        state = self._city_discovery_state(city)
        if state["api_sources"]:
            source = state["api_sources"][0]
            self._custom_url_input.setText(source.get("url", ""))
            self._city_status.setText(f"{city} 已有经过价格数据验证的官方API，不再重复查找。")
            QMessageBox.information(
                self,
                "已有官方API",
                f"{city} 已接入经过验证的官方API，不需要再次联网查找。\n\n"
                f"来源：{display_source_name(source.get('name', '官方来源'), source.get('url', ''), 'api')}\n"
                "系统将按已验证的来源策略直接获取，不显示内部访问地址。",
            )
            return
        if state["market_sources"]:
            self._custom_url_input.clear()
            self._city_status.setText(
                f"{city} 没有可用官方API时，可更新公开市场参考价；按当前城市和期数入库。"
            )
            QMessageBox.information(
                self,
                "已有公开参考来源",
                f"{city} 可调用公开市场参考价。\n\n"
                "系统会按当前城市和期数自动定位公开数据，按城市、期数、规格和单位分开入库，"
                "不使用其他城市价格，也不替代政府官方信息价。",
            )
            return
        if state["validated_sources"]:
            source = state["validated_sources"][0]
            self._custom_url_input.setText(source.url or "")
            self._city_status.setText(f"{city} 官方来源已经验证并可抓取，本次直接复用。")
            QMessageBox.information(
                self,
                "来源已验证可抓取",
                f"{city} 已有 {len(state['validated_sources'])} 个通过真实价格数据验证的来源，"
                "无需再次搜索。可直接按最佳策略更新。",
            )
            return
        if state["login_sources"]:
            source = state["login_sources"][0]
            self._custom_url_input.setText(source.url or "")
            reply = QMessageBox.question(
                self,
                "来源需要登录",
                f"{display_source_name(source.name, source.url, source.source_type)} 已确认需要登录或会员权限。\n"
                "仅在你有权访问该账号和数据时继续。是否现在打开软件浏览器登录？",
                QMessageBox.Yes | QMessageBox.No,
            )
            if reply == QMessageBox.Yes:
                self._custom_consent.setChecked(True)
                self._on_custom_url_login()
            return
        if state["retry_sources"]:
            self._start_discovered_source_validation(
                city,
                [source.id for source in state["retry_sources"]],
            )
            return
        self._ai_source_btn.setEnabled(False)
        self._ai_source_btn.setText("正在查找...")
        self._progress_bar.setRange(0, 0)
        self._progress_bar.setVisible(True)
        self._city_status.setText(
            f"正在搜索 {city} 官方信息价页面和接口线索；现有来源不会被修改。"
        )
        self._source_search_worker = AISourceSearchWorker(
            city,
            self._period_input.text().strip(),
            province=state["province"],
            seed_sources=state["configs"],
        )
        self._source_search_worker.progress_changed.connect(self._city_status.setText)
        self._source_search_worker.completed.connect(self._on_ai_source_search_complete)
        self._source_search_worker.start()

    def _on_ai_source_search_complete(self, city: str, result: dict):
        worker = self._source_search_worker
        self._source_search_worker = None
        if worker is not None:
            worker.deleteLater()
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setVisible(False)
        if result.get("error"):
            message = _friendly_connection_error(RuntimeError(str(result["error"])))
            self._city_status.setText(f"{city} 官方来源查找失败：{message}")
            QMessageBox.warning(self, "查找失败", message)
            self._on_city_changed(city)
            return

        candidates = [item for item in result.get("sources", []) if item.get("verified")]
        if not candidates:
            rejected = result.get("rejected", [])
            detail = rejected[0].get("reason", "没有搜索到经验证的官方信息价页面") if rejected else "没有搜索到经验证的官方信息价页面"
            self._city_status.setText(
                f"{city} 本次检索了 {result.get('searched_count', 0)} 条线索，未发现可确认候选：{detail}"
            )
            QMessageBox.information(
                self,
                "未发现可确认来源",
                "系统已按市住建局、市造价/定额站、省住建厅、省造价机构和官网内二次检索逐层查找。\n"
                "AI不会编造不存在的网址，本次未发现同时满足归属、官方身份、可访问性和信息价内容证据的候选。\n\n"
                f"首要原因：{detail}",
            )
            self._on_city_changed(city)
            return
        saved = self._save_ai_discovered_sources(city, candidates, result)
        first_url = next((item.get("url", "") for item in candidates if item.get("url")), "")
        if first_url:
            self._custom_url_input.setText(first_url)
        self._load_cities()
        self._refresh_strategy_table()
        self.data_changed.emit()
        source_ids = saved.get("source_ids", [])
        if not source_ids:
            self._city_status.setText(f"{city} 找到候选，但没有可进入数据验证的来源。")
            QMessageBox.warning(self, "无法验证", "候选来源未通过最终官方域名校验，未进入抓取验证。")
            self._on_city_changed(city)
            return
        self._start_discovered_source_validation(city, source_ids)

    def _start_discovered_source_validation(self, city: str, source_ids: list[int]):
        if self._discovery_validation_worker is not None:
            QMessageBox.information(self, "正在验证", "当前官方来源数据验证尚未完成，请稍候。")
            return
        source_ids = list(dict.fromkeys(int(value) for value in source_ids if value))
        if not source_ids:
            return
        self._ai_source_btn.setEnabled(False)
        self._ai_source_btn.setText("正在验证数据...")
        self._progress_bar.setRange(0, 100)
        self._progress_bar.setValue(0)
        self._progress_bar.setVisible(True)
        self._city_status.setText(
            f"{city} 已找到 {len(source_ids)} 个官方来源，正在验证表格、附件、接口和动态页面中的真实价格数据..."
        )
        self._discovery_validation_worker = SubscriptionWorker(
            source_ids,
            period=self._period_input.text().strip(),
        )
        self._discovery_validation_worker.progress_changed.connect(
            self._on_discovered_validation_progress
        )
        self._discovery_validation_worker.completed.connect(
            lambda result, c=city, ids=source_ids: self._on_discovered_validation_complete(c, ids, result)
        )
        self._discovery_validation_worker.start()

    def _on_discovered_validation_progress(self, progress: dict):
        percent = int(progress.get("percent", 0) or 0)
        self._progress_bar.setValue(percent)
        self._city_status.setText(
            f"{redact_text(progress.get('source_name', '官方来源'))}：{redact_text(progress.get('stage', '正在验证'))} ({percent}%)"
        )

    def _on_discovered_validation_complete(self, city: str, source_ids: list[int], result: dict):
        worker = self._discovery_validation_worker
        self._discovery_validation_worker = None
        if worker is not None:
            worker.deleteLater()
        self._progress_bar.setVisible(False)
        try:
            summary = self._record_discovered_validation(source_ids, result)
        except Exception as error:
            self._city_status.setText(f"{city} 抓取已完成，但结果状态写回失败：{error}")
            self._on_city_changed(city)
            QMessageBox.critical(
                self,
                "结果处理失败",
                f"抓取线程已经结束，但保存验证状态时失败：\n{error}\n\n"
                "原始抓取任务和文档仍已保留，可重新点击验证。",
            )
            return
        self._refresh_strategy_table()
        self._refresh_results()
        self.data_changed.emit()
        self._on_city_changed(city)

        working = summary["working"]
        login_sources = summary["login_sources"]
        failed = summary["failed"]
        if working:
            self._city_status.setText(
                f"{city} 验证通过 {working} 个来源，已解析并抓取或更新真实价格数据。"
            )
        elif login_sources:
            self._city_status.setText(f"{city} 官方来源需要登录，登录后将继续验证和抓取。")
        else:
            self._city_status.setText(f"{city} 已完成验证，但尚未解析出有效信息价数据。")

        if login_sources:
            source = login_sources[0]
            self._custom_url_input.setText(source["url"])
            reply = QMessageBox.question(
                self,
                "官方来源需要登录",
                f"{source['name']} 需要登录、会员权限或身份认证后才能读取价格数据。\n\n"
                "仅在你有权访问该账号和数据时继续。是否现在打开软件浏览器登录？"
                "登录状态仅加密保存在本机。",
                QMessageBox.Yes | QMessageBox.No,
            )
            if reply == QMessageBox.Yes:
                self._custom_consent.setChecked(True)
                self._on_custom_url_login()
                return
        if working:
            QMessageBox.information(
                self,
                "官方来源验证通过",
                f"验证通过 {working} 个来源，抓取或更新 {result.get('new_prices', 0):,} 条价格。\n"
                f"需要登录 {len(login_sources)} 个；未通过 {failed} 个。\n\n"
                "通过的来源以后可直接更新，不再重复搜索。",
            )
        elif not login_sources:
            reasons = "；".join(result.get("errors", [])[:3]) or "页面可访问，但没有解析出材料名称、单位和价格完整记录"
            QMessageBox.warning(
                self,
                "官方来源验证未通过",
                f"已实际检查 {len(source_ids)} 个来源，但没有得到可入库价格数据。\n\n原因：{reasons}",
            )

    def _record_discovered_validation(self, source_ids: list[int], result: dict) -> dict:
        details = {
            int(item.get("source_id")): item
            for item in result.get("details", [])
            if item.get("source_id") is not None
        }
        login_words = ("登录", "会员", "401", "403", "身份认证", "授权")
        working = 0
        failed = 0
        login_sources = []
        session = get_session()
        try:
            for source in session.query(OfficialSource).filter(OfficialSource.id.in_(source_ids)).all():
                detail = details.get(source.id, {})
                try:
                    metadata = json.loads(source.notes or "{}")
                    if not isinstance(metadata, dict):
                        metadata = {"description": source.notes or ""}
                except json.JSONDecodeError:
                    metadata = {"description": source.notes or ""}
                message = str(detail.get("error") or detail.get("message") or "")
                login_hint = bool(metadata.get("login_required"))
                discovery = metadata.get("ai_discovery") or {}
                login_hint = login_hint or bool(discovery.get("login_required"))
                needs_login = login_hint or any(word in message for word in login_words)
                new_count = int(detail.get("new_prices") or 0)
                parsed_count = int(detail.get("parsed_prices") or new_count)
                if detail.get("success") and parsed_count > 0:
                    validation_status = "working"
                    working += 1
                    source.last_result = "success"
                elif needs_login:
                    validation_status = "login_required"
                    source.last_result = "login_required"
                    login_sources.append({"id": source.id, "name": display_source_name(source.name, source.url, source.source_type), "url": display_source_url(source.url, source.name, source.source_type)})
                else:
                    validation_status = "no_price_data" if detail.get("success") else "failed"
                    failed += 1
                    source.last_result = validation_status
                metadata["ai_validation_requested"] = False
                metadata["validation_status"] = validation_status
                metadata["validation_at"] = datetime.now().isoformat(timespec="seconds")
                metadata["validation_price_count"] = parsed_count
                metadata["validation_new_price_count"] = new_count
                metadata["validation_message"] = message[:1000]
                source.notes = json.dumps(metadata, ensure_ascii=False)
                write_audit(
                    session,
                    "update",
                    "official_source",
                    source.id,
                    f"官方来源自动验证: {validation_status}; 解析价格 {parsed_count} 条; 新增更新 {new_count} 条",
                )
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
        return {"working": working, "failed": failed, "login_sources": login_sources}

    def _existing_source_keys(self, city: str) -> set[str]:
        from src.official_source_discovery import canonical_source_url
        from src.official_sources_config import CITY_SOURCES

        keys = {
            canonical_source_url(item.get("url", ""))
            for item in CITY_SOURCES.get(city, [])
            if item.get("url")
        }
        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == city).first()
            if region:
                for source in session.query(OfficialSource).filter(OfficialSource.region_id == region.id).all():
                    if source.url:
                        keys.add(canonical_source_url(source.url))
        finally:
            session.close()
        return {key for key in keys if key}

    def _show_ai_source_results(self, city: str, result: dict, candidates: list[dict]):
        from src.official_source_discovery import canonical_source_url

        existing_keys = self._existing_source_keys(city)
        dialog = QDialog(self)
        dialog.setWindowTitle(f"{city} 官方来源发现结果")
        dialog.resize(1120, 560)
        layout = QVBoxLayout(dialog)
        summary = QLabel(
            f"搜索 {result.get('searched_count', 0)} 条，验证出 {len(candidates)} 个官方候选。"
            f"现有 {len(existing_keys)} 个来源保持不变；新发现项保存后标记为“待适配”，不会直接当作可用API。"
        )
        summary.setWordWrap(True)
        summary.setStyleSheet("color:#334155;padding:4px 0;")
        layout.addWidget(summary)

        table = QTableWidget(len(candidates), 7)
        table.setHorizontalHeaderLabels([
            "选择", "来源名称", "可能类型", "访问要求", "验证状态", "API/附件线索", "官方网址",
        ])
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.setWordWrap(True)
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        kind_labels = {"api": "接口候选", "web": "网页", "pdf": "PDF附件", "excel": "Excel附件"}
        for row, source in enumerate(candidates):
            select_item = QTableWidgetItem()
            select_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
            select_item.setCheckState(Qt.Unchecked)
            table.setItem(row, 0, select_item)
            table.setItem(row, 1, QTableWidgetItem(display_source_name(source.get("name", "官方信息价来源"), source.get("url", ""), source.get("source_type", ""))))
            table.setItem(row, 2, QTableWidgetItem(kind_labels.get(source.get("source_kind"), "网页")))
            table.setItem(row, 3, QTableWidgetItem("可能需要登录" if source.get("login_required") else "公开访问"))
            key = canonical_source_url(source.get("url", ""))
            verification = "已存在，保留原配置" if key in existing_keys else source.get("verification_status", "已验证")
            table.setItem(row, 4, QTableWidgetItem(verification))
            clues = source.get("api_hint", "")
            attachments = source.get("attachment_candidates") or []
            if attachments:
                clues += f"；发现 {len(attachments)} 个附件链接"
            if source.get("ai_description"):
                clues += f"；AI判断：{source['ai_description']}"
            clue_item = QTableWidgetItem(clues)
            clue_item.setToolTip(redact_text(source.get("excerpt", "") or source.get("description", "")))
            table.setItem(row, 5, clue_item)
            url_item = QTableWidgetItem("已隐藏来源地址")
            url_item.setToolTip("系统已隐藏自动发现的来源地址；保存后可在来源配置中继续验证。")
            table.setItem(row, 6, url_item)
        table.resizeRowsToContents()
        layout.addWidget(table, 1)

        note = QLabel(
            "保存仅登记发现证据。需要动态接口的页面，应在“来源配置”中选择该来源并使用“API嗅探（排错）”；"
            "需要登录的页面仍须由用户本人完成登录。"
        )
        note.setWordWrap(True)
        note.setStyleSheet("color:#92400e;background:#fffbeb;padding:8px;border:1px solid #fde68a;")
        layout.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("保存选中")
        buttons.button(QDialogButtonBox.Cancel).setText("取消")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.Accepted:
            self._city_status.setText(f"{city} 已完成官方来源检索，未保存候选。")
            return
        selected = [
            source for row, source in enumerate(candidates)
            if table.item(row, 0) and table.item(row, 0).checkState() == Qt.Checked
        ]
        if not selected:
            QMessageBox.information(self, "未选择来源", "没有勾选候选，现有来源未发生任何变化。")
            self._city_status.setText(f"{city} 已完成官方来源检索，未选择新增来源。")
            return
        saved = self._save_ai_discovered_sources(city, selected, result)
        first_url = next((item.get("url", "") for item in selected if item.get("url")), "")
        if first_url:
            self._custom_url_input.setText(first_url)
        self._load_cities()
        self._refresh_strategy_table()
        self.data_changed.emit()
        self._city_status.setText(
            f"{city}：新增 {saved['created']} 个待适配来源，跳过 {saved['existing']} 个已有来源。"
        )
        QMessageBox.information(
            self,
            "保存完成",
            f"新增 {saved['created']} 个待适配来源，已有来源 {saved['existing']} 个保持不变。\n"
            "已把首个候选填入“用户网址”，可打开核查或登录；接口适配请到“来源配置”继续。",
        )

    def _save_ai_discovered_sources(self, city: str, sources: list[dict], search_result: dict) -> dict:
        from src.official_source_discovery import canonical_source_url
        from src.utils import is_official_domain

        session = get_session()
        created = 0
        existing_count = 0
        source_ids = []
        try:
            region = session.query(Region).filter(Region.name == city).first()
            if region is None:
                region = Region(name=city, province="", is_active=True)
                session.add(region)
                session.flush()
            existing_sources = session.query(OfficialSource).filter(OfficialSource.region_id == region.id).all()
            existing_by_key = {
                canonical_source_url(source.url): source
                for source in existing_sources
                if source.url
            }
            for candidate in sources:
                url = str(candidate.get("url") or "").strip()
                key = canonical_source_url(url)
                is_existing = key in existing_by_key
                if (
                    not candidate.get("verified")
                    or not key
                    or (not is_official_domain(url) and not is_existing)
                ):
                    continue
                if is_existing:
                    source = existing_by_key[key]
                    try:
                        existing_metadata = json.loads(source.notes or "{}")
                        if not isinstance(existing_metadata, dict):
                            existing_metadata = {"description": source.notes or ""}
                    except json.JSONDecodeError:
                        existing_metadata = {"description": source.notes or ""}
                    existing_metadata["ai_discovery_completed"] = True
                    existing_metadata["ai_validation_requested"] = True
                    existing_metadata["ai_discovery"] = {
                        "recorded_at": datetime.now().isoformat(timespec="seconds"),
            "source_kind": candidate.get("source_kind", "web"),
                        "jurisdiction": candidate.get("jurisdiction", ""),
                        "institution": candidate.get("institution", ""),
                        "verification_status": candidate.get("verification_status", ""),
                        "login_required": bool(candidate.get("login_required")),
                        "api_hint": candidate.get("api_hint", ""),
                        "api_candidates": candidate.get("api_candidates", []),
                        "attachment_candidates": candidate.get("attachment_candidates", []),
                        "search_query": candidate.get("search_query", ""),
                    }
                    source.notes = json.dumps(existing_metadata, ensure_ascii=False)
                    source.last_check_at = datetime.now()
                    write_audit(
                        session,
                        "update",
                        "official_source",
                        source.id,
                        f"AI检索确认已有官方来源，保留原配置: {url}",
                    )
                    source_ids.append(source.id)
                    existing_count += 1
                    continue
                metadata = {
                    "ai_discovery_completed": True,
                    "ai_validation_requested": True,
                    "discovery_status": "pending_adapter",
                    "discovered_by": "verified_web_search_ai_review",
                    "discovered_at": datetime.now().isoformat(timespec="seconds"),
                    "source_kind": candidate.get("source_kind", "web"),
                    "jurisdiction": candidate.get("jurisdiction", ""),
                    "institution": candidate.get("institution", ""),
                    "relevance_score": candidate.get("relevance_score", 0),
                    "verification_status": candidate.get("verification_status", ""),
                    "http_status": candidate.get("http_status"),
                    "login_required": bool(candidate.get("login_required")),
                    "api_hint": candidate.get("api_hint", ""),
                    "api_candidates": candidate.get("api_candidates", []),
                    "attachment_candidates": candidate.get("attachment_candidates", []),
                    "search_query": candidate.get("search_query", ""),
                    "search_note": search_result.get("search_note", ""),
                    "description": candidate.get("description", ""),
                    "ai_description": candidate.get("ai_description", ""),
                }
                source = OfficialSource(
                    region_id=region.id,
                    name=str(candidate.get("name") or f"{city} AI发现官方来源")[:300],
                    url=url,
                    source_type="ai_discovered",
                    is_official=True,
                    is_active=True,
                    last_check_at=datetime.now(),
                    last_result="pending_adapter",
                    notes=json.dumps(metadata, ensure_ascii=False),
                )
                session.add(source)
                session.flush()
                write_audit(
                    session,
                    "create",
                    "official_source",
                    source.id,
                    f"AI检索并验证的官方来源，待适配: {url}",
                )
                existing_by_key[key] = source
                source_ids.append(source.id)
                created += 1
            session.commit()
            return {
                "created": created,
                "existing": existing_count,
                "source_ids": list(dict.fromkeys(source_ids)),
            }
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def refresh_data(self):
        self._load_cities()
        self._refresh_strategy_table()
        self._refresh_results()
        self._on_city_changed(self._city_combo.currentText())

    @staticmethod
    def _joined_cities(cities: list[str]) -> str:
        return "、".join(cities) if cities else "暂无"

    @staticmethod
    def _city_audit(city: str) -> dict:
        from src.official_sources_config import CITY_AUDIT_STATUS

        return CITY_AUDIT_STATUS.get(city, {
            "status": "pending_adapter",
            "note": "尚未完成价格数据级实验。",
        })

    def _on_city_changed(self, city: str):
        self._refresh_results()
        city = (city or "").strip()
        if not city or city.startswith("--"):
            self._query_btn.setEnabled(False)
            self._market_query_btn.setEnabled(False)
            self._ai_source_btn.setEnabled(False)
            self._query_btn.setText("选择城市")
            self._city_status.setText("请选择城市查看实测抓取状态。")
            self._update_custom_url_controls()
            return
        audit = self._city_audit(city)
        status = audit.get("status", "pending_adapter")
        label = self.STATUS_LABELS.get(status, status)
        # 不可自动抓取的城市仍保留入口，用于打开已核查官网、登录或人工验证。
        self._query_btn.setEnabled(True)
        discovery_state = self._city_discovery_state(city)
        market_available = bool(discovery_state.get("market_sources"))
        official_available = bool(discovery_state.get("api_sources"))
        if official_available:
            status = "working"
            label = self.STATUS_LABELS.get(status, status)
        elif status != "working" and market_available:
            status = "market_reference"
            label = "公开市场可抓取（待验证）"
        self._ai_source_btn.setEnabled(self._source_search_worker is None)
        if discovery_state["api_sources"]:
            self._ai_source_btn.setText("已有官方API")
            self._ai_source_btn.setToolTip("该城市已有经过价格数据验证的专用API，点击查看来源")
        elif discovery_state["validated_sources"]:
            self._ai_source_btn.setText("已验证可抓取")
            self._ai_source_btn.setToolTip("该城市已有通过真实价格数据验证的来源，点击查看")
        elif discovery_state["login_sources"]:
            self._ai_source_btn.setText("需要登录")
            self._ai_source_btn.setToolTip("已找到官方来源，但需要用户登录或会员权限")
        elif discovery_state["retry_sources"]:
            self._ai_source_btn.setText("重新验证已保存来源")
            self._ai_source_btn.setToolTip("不重复搜索，直接重新验证已保存来源中的价格数据")
        elif self._source_search_worker is None:
            self._ai_source_btn.setText("AI查找官方接口")
            self._ai_source_btn.setToolTip(
                "按住建局、造价站、定额站、省住建厅等官方机构路径查找接口和附件"
            )
        can_auto_fetch = bool(
            status == "working"
            or discovery_state.get("market_sources")
            or discovery_state.get("generic_sources")
        )
        self._query_btn.setText("按最佳策略抓取" if can_auto_fetch else "打开官网/验证")
        self._market_query_btn.setEnabled(market_available and not official_available)
        status_note = audit.get("note", "")
        if market_available and not official_available:
            status_note += "；另有公开市场参考价可直接抓取（不等同政府官方信息价）"
        self._city_status.setText(f"{city}｜{label}：{status_note}")
        self._update_custom_url_controls()

    def set_period(self, period: str):
        self._period_input.setText((period or "").strip())

    def _strategy_city_map(self) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES

        strategy_cities = {"api": set(), "market_reference": set(), "browser_login": set(), "crawl": set()}
        status_cities = {}
        for city, sources in CITY_SOURCES.items():
            status = CITY_AUDIT_STATUS.get(city, {}).get("status", "pending_adapter")
            has_market_source = any(
                item.get("source_class") == "market_reference"
                and item.get("strategy") == "api"
                and item.get("data_status") == "working"
                for item in sources
            )
            if status != "working" and has_market_source:
                status = "market_reference"
            status_cities.setdefault(status, []).append(city)
            if status == "working":
                for source in sources:
                    strategy = source.get("strategy", "crawl")
                    if source.get("data_status") == "working" and strategy in strategy_cities:
                        strategy_cities[strategy].add(city)
                        if source.get("source_class") == "market_reference":
                            strategy_cities["market_reference"].add(city)
            elif status == "market_reference":
                # Keep api as the automatic-entry bucket for compatibility;
                # the separate row makes the second-step market route explicit.
                strategy_cities["api"].add(city)
                strategy_cities["market_reference"].add(city)
            elif status in {"login_required", "membership_required", "browser_dynamic", "waf_blocked"}:
                strategy_cities["browser_login"].add(city)
            elif status in {"public_document", "public_scanned_document", "province_fallback"}:
                strategy_cities["crawl"].add(city)

        return (
            {key: sorted(values) for key, values in strategy_cities.items()},
            {key: sorted(values) for key, values in status_cities.items()},
        )

    def _refresh_strategy_table(self):
        city_map, status_cities = self._strategy_city_map()
        login_statuses = {"login_required", "membership_required", "browser_dynamic", "waf_blocked"}
        document_statuses = {"public_document", "public_scanned_document", "province_fallback", "pending_parser"}
        checked_count = sum(
            len(cities) for status, cities in status_cities.items()
            if status != "pending_adapter"
        )
        if self._summary_values:
            self._summary_values["working"].setText(
                f"{len(status_cities.get('working', []))} 可直接抓取"
            )
            self._summary_values["login"].setText(
                f"{sum(len(status_cities.get(status, [])) for status in login_statuses)} 需登录/会员"
            )
            self._summary_values["document"].setText(
                f"{sum(len(status_cities.get(status, [])) for status in document_statuses)} 公开文件待适配"
            )
            self._summary_values["checked"].setText(f"{checked_count} 已核查城市")
        rows = ["api", "market_reference", "browser_login", "crawl"]
        self._strategy_table.setRowCount(len(rows))
        for row, strategy in enumerate(rows):
            description, fixed_cities = self.STRATEGY_META[strategy]
            cities = fixed_cities or self._joined_cities(city_map[strategy])
            key_item = QTableWidgetItem(strategy)
            key_item.setFont(QFont("Consolas", 10))
            self._strategy_table.setItem(row, 0, key_item)
            self._strategy_table.setItem(row, 1, QTableWidgetItem(description))
            self._strategy_table.setItem(row, 2, QTableWidgetItem(cities))
        self._strategy_table.resizeRowsToContents()
        summaries = []
        for status, cities in status_cities.items():
            if status == "working":
                continue
            label = self.STATUS_LABELS.get(status, status)
            summaries.append(f"{label} {len(cities)}城")
        detail = "其他城市实测分类：" + "；".join(summaries) + "。选择城市可查看具体原因。"
        self._unsupported_label.setText("其他城市实测分类已汇总，选择城市可查看具体原因。")
        self._unsupported_label.setToolTip(detail)

    def _ensure_city_sources(self, city: str, *, prefer_market: bool = False) -> list[int]:
        from src.official_sources_config import (
            CITY_SOURCES,
            get_public_market_source_config,
            get_zaojiahome_province,
        )

        catalog_city = self._catalog_city_name(city)
        all_configs = [source for source in CITY_SOURCES.get(catalog_city, []) if source.get("url")]
        market_configs = [
            source for source in all_configs
            if source.get("source_class") == "market_reference"
            and source.get("data_status") == "working"
        ]
        official_configs = [
            source for source in all_configs
            if source.get("is_official", True)
            and source.get("data_status") not in {"wrong_content", "no_public_source"}
        ]
        generic_market = get_public_market_source_config(catalog_city)
        if generic_market and not market_configs:
            market_configs = [generic_market]

        def priority(source: dict) -> tuple[int, int]:
            status = source.get("data_status", "")
            strategy = source.get("strategy", "crawl")
            return (
                0 if status == "working" and strategy == "api" else
                1 if status == "working" else
                2 if status in {"public_document", "public_scanned_document", "province_fallback"} else
                3 if status in {"login_required", "membership_required", "browser_dynamic"} else
                4,
                0 if strategy == "api" else 1 if strategy == "crawl" else 2,
            )

        if prefer_market:
            configs = market_configs[:1]
        elif official_configs:
            # Return the best official source plus one public market fallback.
            # SubscriptionEngine runs them in this order and stops after the
            # first source produces valid records, so source classes are never
            # mixed in a successful city update.
            configs = sorted(official_configs, key=priority)[:1]
            if market_configs:
                configs.extend(market_configs[:1])
        else:
            configs = market_configs[:1]
        if not configs:
            return []

        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == city).first()
            if not region:
                region = Region(name=city, province=get_zaojiahome_province(catalog_city), is_active=True)
                session.add(region)
                session.flush()
            elif not region.province:
                region.province = get_zaojiahome_province(catalog_city)
            existing_sources = session.query(OfficialSource).filter(OfficialSource.region_id == region.id).all()
            selected = []
            for cfg in configs:
                configured_url = cfg["url"].rstrip("/")
                configured_host = urlparse(cfg["url"]).netloc.lower()
                source = next((item for item in existing_sources if item.url.rstrip("/") == configured_url), None)
                if source is None:
                    source = next((item for item in existing_sources if urlparse(item.url).netloc.lower() == configured_host), None)
                if source is None:
                    source = OfficialSource(
                        region_id=region.id,
                    )
                    session.add(source)
                    existing_sources.append(source)
                source.name = cfg.get("name", f"{city}官方来源")
                source.url = cfg["url"]
                source.source_type = cfg.get("strategy", "api")
                source.is_official = cfg.get("is_official", True)
                source.is_active = True
                source.notes = json.dumps({
                    "description": cfg.get("note", ""),
                    "source_class": cfg.get("source_class", "official" if source.is_official else "market_reference"),
                    "province": cfg.get("province", get_zaojiahome_province(catalog_city)),
                    "catalog_url": cfg.get("url", ""),
                }, ensure_ascii=False)
                selected.append(source)
            session.commit()
            return [source.id for source in selected]
        finally:
            session.close()

    def _on_query_prices(self):
        city = self._city_combo.currentText().strip()
        if not city or city.startswith("--"):
            QMessageBox.warning(self, "请选择城市", "请先选择或输入一个城市名称。")
            return

        audit = self._city_audit(city)
        discovery_state = self._city_discovery_state(city)
        has_market_reference = bool(discovery_state.get("market_sources"))
        has_official_reference = bool(discovery_state.get("api_sources"))
        source_ids = self._ensure_city_sources(city)
        if not source_ids:
            entered_url = self._custom_url_input.text().strip()
            entered_valid, _ = self._validate_custom_url(entered_url)
            official_url = entered_url if entered_valid else self._prepare_city_url(city)
            if official_url:
                self._custom_url_input.setText(official_url)
                self._on_open_custom_url()
                self._city_status.setText(
                    f"{city} 当前不能自动抓取，已打开已配置官网。请在浏览器中完成登录或核查；"
                    "如确认网址可访问，再勾选免责声明后点击“抓取输入网址”。"
                )
            else:
                self._city_status.setText(
                    f"{city} 当前不能自动抓取，尚未配置可直接打开的官网入口；"
                    "请在“用户网址”中输入有权访问的官网栏目地址。"
                )
            self._update_custom_url_controls()
            return

        self._query_btn.setEnabled(False)
        self._query_btn.setText("抓取中...")
        self._progress_bar.setVisible(True)
        self._progress_bar.setValue(0)
        source_label = "官方信息价"
        if not has_official_reference and not discovery_state.get("generic_sources"):
            source_label = "公开市场参考价"
        self._city_status.setText(
            f"正在按城市和期数抓取 {city} 的{source_label}（官方来源优先，公开市场参考为补充）..."
        )

        self._subscription_worker = SubscriptionWorker(source_ids, period=self._period_input.text().strip())
        self._subscription_worker.progress_changed.connect(self._on_query_progress)
        self._subscription_worker.completed.connect(lambda result, c=city: self._on_query_complete(c, result, False))
        self._subscription_worker.start()

    def _on_market_query(self):
        """Fetch the configured public market reference source for the selected city."""
        city = self._city_combo.currentText().strip()
        if not city or city.startswith("--"):
            QMessageBox.warning(self, "请选择城市", "请先选择城市，再抓取公开市场参考价。")
            return
        if self._subscription_worker is not None:
            QMessageBox.information(self, "正在抓取", "当前抓取任务尚未完成，请稍候。")
            return

        state = self._city_discovery_state(city)
        if state.get("api_sources"):
            self._market_query_btn.setEnabled(False)
            self._city_status.setText(
                f"{city} 已有可用官方来源，本次只使用官方数据，不调用公开市场参考价。"
            )
            return
        if not state.get("market_sources"):
            self._market_query_btn.setEnabled(False)
            self._city_status.setText(
                f"{city} 暂无可用的公开市场参考价来源；请先更新来源配置或使用用户网址。"
            )
            return

        source_ids = self._ensure_city_sources(city, prefer_market=True)
        if not source_ids:
            self._city_status.setText(
                f"{city} 的公开市场参考价来源未加载成功，请先刷新来源状态。"
            )
            self._refresh_strategy_table()
            return

        self._query_btn.setEnabled(False)
        self._market_query_btn.setEnabled(False)
        self._market_query_btn.setText("公开参考价抓取中...")
        self._progress_bar.setVisible(True)
        self._progress_bar.setValue(0)
        period = self._period_input.text().strip()
        period_text = period or "最新一期"
        self._city_status.setText(
            f"正在抓取 {city} {period_text} 的公开市场参考价，结果将按城市和期数直接入库..."
        )
        self._subscription_worker = SubscriptionWorker(source_ids, period=period)
        self._subscription_worker.progress_changed.connect(self._on_query_progress)
        self._subscription_worker.completed.connect(
            lambda result, c=city: self._on_query_complete(c, result, False)
        )
        self._subscription_worker.start()

    @staticmethod
    def _validate_custom_url(url: str) -> tuple[bool, str]:
        """Validate a user URL before it is opened or sent to the fetch worker."""
        value = (url or "").strip()
        if not value:
            return False, "请先输入网址。"
        if len(value) > 500:
            return False, "网址长度不能超过 500 个字符。"
        try:
            parsed = urlparse(value)
            hostname = parsed.hostname or ""
            port = parsed.port
        except ValueError:
            return False, "网址格式无效，请检查端口或特殊字符。"
        if parsed.scheme.lower() not in {"http", "https"} or not hostname:
            return False, "仅支持完整的 http:// 或 https:// 网址。"
        if parsed.username or parsed.password:
            return False, "网址不能包含用户名或密码，请在网站页面中登录。"
        if port is not None and not (1 <= port <= 65535):
            return False, "网址端口号无效。"
        normalized_host = hostname.rstrip(".").lower()
        if normalized_host in {"localhost", "localhost.localdomain"} or normalized_host.endswith(".local"):
            return False, "不允许抓取 localhost 或本地域名。"
        try:
            address = ipaddress.ip_address(normalized_host)
        except ValueError:
            address = None
        if address is not None and (
            address.is_private
            or address.is_loopback
            or address.is_link_local
            or address.is_reserved
            or address.is_multicast
            or address.is_unspecified
        ):
            return False, "不允许抓取回环、内网或其他保留 IP 地址。"
        return True, ""

    def _update_custom_url_controls(self, *_args):
        value = self._custom_url_input.text().strip()
        valid, reason = self._validate_custom_url(value)
        consented = self._custom_consent.isChecked()
        self._open_custom_url_btn.setEnabled(valid)
        self._login_custom_url_btn.setEnabled(valid and self._browser_worker is None)
        self._custom_fetch_btn.setEnabled(valid and consented and self._subscription_worker is None)
        if not value:
            self._custom_url_status.setText(
                "用户网址尚未设置。不可自动抓取的城市，可先点击“打开官网/验证”查看核查路径。"
            )
        elif not valid:
            self._custom_url_status.setText(f"网址校验未通过：{reason}")
        elif not consented:
            self._custom_url_status.setText("网址格式有效；如需抓取，请先阅读并勾选免责声明。")
        else:
            self._custom_url_status.setText(
                "已确认用户网址。抓取结果会清理异常数据后直接入库，并保留用户输入来源。"
            )

    def _on_open_custom_url(self):
        url = self._custom_url_input.text().strip()
        valid, reason = self._validate_custom_url(url)
        if not valid:
            QMessageBox.warning(self, "网址不可打开", reason)
            return
        try:
            if hasattr(os, "startfile"):
                os.startfile(url)
            else:
                webbrowser.open(url)
            self._custom_url_status.setText(
                "已在普通浏览器打开网址。普通浏览器的登录状态不会自动传给软件；"
                "需要抓取会员内容时，请使用旁边的“登录网址”。"
            )
        except Exception as error:
            QMessageBox.warning(self, "无法打开网址", str(error))

    def _on_custom_url_login(self):
        city = self._city_combo.currentText().strip()
        if not city or city.startswith("--"):
            QMessageBox.warning(self, "请选择信息来源地", "请先选择或输入网址对应的城市。")
            return
        url = self._custom_url_input.text().strip()
        valid, reason = self._validate_custom_url(url)
        if not valid:
            QMessageBox.warning(self, "网址不可登录", reason)
            return
        if self._browser_worker is not None:
            self._browser_worker.request_capture()
            self._login_custom_url_btn.setEnabled(False)
            self._login_custom_url_btn.setText("正在确认...")
            self._custom_url_status.setText("正在读取软件浏览器中的登录状态...")
            return
        source_id = self._ensure_user_url_source(city, url)
        self._login_custom_url_btn.setEnabled(True)
        self._login_custom_url_btn.setText("我已完成登录")
        self._custom_url_status.setText(
            "请在软件打开的浏览器中完成登录，然后点击“我已完成登录”；登录状态将加密保存在本机。"
        )
        self._browser_worker = BrowserLoginWorker(url)
        self._browser_worker.progress_changed.connect(
            lambda message: self._custom_url_status.setText(str(message))
        )
        self._browser_worker.completed.connect(
            lambda result, sid=source_id: self._on_custom_url_login_complete(sid, result)
        )
        self._browser_worker.start()

    def _on_custom_url_login_complete(self, source_id: int, result: dict):
        worker = self._browser_worker
        self._browser_worker = None
        if worker is not None:
            worker.deleteLater()
        self._login_custom_url_btn.setText("登录网址")
        self._update_custom_url_controls()
        if not result.get("success") or not result.get("cookie_header"):
            message = result.get("error") or "未捕获到有效 Cookie，请确认已完成登录。"
            self._custom_url_status.setText(f"登录未完成：{message}")
            QMessageBox.warning(self, "登录未完成", message)
            return
        try:
            from src.browser_login import save_browser_cookies

            save_browser_cookies(source_id, result.get("cookie_header", ""))
            count = int(result.get("cookie_count") or 0)
            self._custom_url_status.setText(
                f"登录成功，已加密保存 {count} 个 Cookie，正在抓取当前网址。"
            )
            session = get_session()
            try:
                source = session.query(OfficialSource).filter(OfficialSource.id == source_id).first()
                is_discovered = bool(source and source.source_type == "ai_discovered")
            finally:
                session.close()
            if is_discovered:
                city = self._city_combo.currentText().strip()
                QTimer.singleShot(0, lambda c=city, sid=source_id: self._start_discovered_source_validation(c, [sid]))
            else:
                QTimer.singleShot(0, self._on_custom_url_fetch)
        except Exception as error:
            QMessageBox.warning(self, "保存登录状态失败", str(error))

    def _on_custom_url_fetch(self):
        city = self._city_combo.currentText().strip()
        if not city or city.startswith("--"):
            QMessageBox.warning(self, "请选择城市", "请先选择网址对应的城市，再执行抓取。")
            return
        url = self._custom_url_input.text().strip()
        valid, reason = self._validate_custom_url(url)
        if not valid:
            QMessageBox.warning(self, "网址不可抓取", reason)
            return
        if not self._custom_consent.isChecked():
            QMessageBox.warning(
                self,
                "需要确认免责声明",
                "抓取用户输入网址前，请先阅读并勾选免责声明。",
            )
            return
        if self._subscription_worker is not None:
            QMessageBox.information(self, "正在抓取", "当前抓取任务尚未完成，请稍候。")
            return

        source_id = self._ensure_user_url_source(city, url)
        login_statuses = {
            "login_required", "membership_required", "browser_dynamic", "waf_blocked",
        }
        if self._city_audit(city).get("status") in login_statuses:
            from src.browser_login import has_valid_cookies

            if not has_valid_cookies(source_id):
                self._custom_url_status.setText(
                    "该地区来源需要会员登录。请点击“登录网址”，在软件打开的浏览器中完成登录；"
                    "登录成功后软件会自动开始抓取。"
                )
                QMessageBox.information(
                    self,
                    "需要软件登录",
                    "你在普通浏览器中的登录状态不能直接用于软件抓取。\n\n"
                    "请点击“登录网址”，在软件打开的浏览器窗口中完成会员登录。",
                )
                return
        self._query_btn.setEnabled(False)
        self._custom_fetch_btn.setEnabled(False)
        self._open_custom_url_btn.setEnabled(False)
        self._progress_bar.setVisible(True)
        self._progress_bar.setValue(0)
        self._city_status.setText(f"正在抓取用户输入网址：{url}")
        self._subscription_worker = SubscriptionWorker(
            [source_id], period=self._period_input.text().strip(),
        )
        self._subscription_worker.progress_changed.connect(self._on_query_progress)
        self._subscription_worker.completed.connect(
            lambda result, c=city: self._on_query_complete(c, result, True)
        )
        self._subscription_worker.start()

    def _prepare_city_url(self, city: str) -> str:
        """Return the best configured URL for the city so users have a verification path."""
        from src.official_sources_config import CITY_SOURCES

        configs = CITY_SOURCES.get(city, [])
        if configs:
            working = [item for item in configs if item.get("data_status") == "working"]
            candidate = (working or configs)[0]
            if candidate.get("url"):
                return candidate["url"].strip()
        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == city).first()
            if region:
                source = session.query(OfficialSource).filter(
                    OfficialSource.region_id == region.id,
                    OfficialSource.is_active.is_(True),
                ).order_by(OfficialSource.is_official.desc(), OfficialSource.id).first()
                if source and source.url:
                    return source.url.strip()
        finally:
            session.close()
        return ""

    def _ensure_user_url_source(self, city: str, url: str) -> int:
        normalized_url = url.strip().rstrip("/")
        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == city).first()
            if region is None:
                region = Region(name=city, province="", is_active=True)
                session.add(region)
                session.flush()
            source = session.query(OfficialSource).filter(
                OfficialSource.region_id == region.id,
                OfficialSource.url == normalized_url,
            ).first()
            if source is None:
                source = OfficialSource(
                    region_id=region.id,
                    name=f"{city}用户输入网址",
                    url=normalized_url,
                    source_type="user_url",
                    is_official=False,
                    is_active=True,
                )
                session.add(source)
                source.notes = (
                    "用户自定义网址；抓取前已确认免责声明；仅作为用户输入来源，"
                    "异常数据自动清理后直接入库。"
                )
                audit_action = "create"
            elif source.source_type == "user_url":
                source.name = f"{city}用户输入网址"
                source.is_active = True
                audit_action = "update"
            else:
                source.is_active = True
                try:
                    metadata = json.loads(source.notes or "{}")
                    if not isinstance(metadata, dict):
                        metadata = {"description": source.notes or ""}
                except json.JSONDecodeError:
                    metadata = {"description": source.notes or ""}
                metadata["browser_login_requested_at"] = datetime.now().isoformat(timespec="seconds")
                source.notes = json.dumps(metadata, ensure_ascii=False)
                audit_action = "update"
            session.flush()
            write_audit(session, audit_action, "user_url_source", source.id, f"用户输入网址: {normalized_url}")
            session.commit()
            return source.id
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _on_query_progress(self, progress: dict):
        percent = int(progress.get("percent", 0))
        self._progress_bar.setValue(percent)
        phase_labels = {
            "source_discovery": "识别来源、城市和期数",
            "access_check": "检查访问状态",
            "login_check": "检查登录授权",
            "api_fetch": "调用专用接口",
            "document_fetch": "寻找公开文件和网页数据",
            "browser_dynamic": "加载动态页面和数据接口",
            "validate": "校验价格、单位和期数",
            "store": "写入城市和期数对应的价格库",
            "complete": "抓取完成",
            "failed": "抓取失败",
        }
        stage = phase_labels.get(
            progress.get("phase"),
            progress.get("stage", "处理中"),
        )
        detail = []
        if progress.get("pages"):
            detail.append(f"页面 {progress['pages']}")
        if progress.get("documents"):
            detail.append(f"文件 {progress['documents']}")
        if progress.get("eta_seconds") is not None:
            detail.append(f"预计剩余 {progress['eta_seconds']} 秒")
        suffix = f"；{'，'.join(detail)}" if detail else ""
        self._city_status.setText(
            f"{redact_text(progress.get('source_name', ''))}：{stage}（{percent}%{suffix}）"
        )

    def _on_query_complete(self, city: str, result: dict, custom_url: bool = False):
        self._query_btn.setEnabled(True)
        audit = self._city_audit(city)
        state = self._city_discovery_state(city)
        can_auto_fetch = audit.get("status") == "working" or bool(state.get("market_sources"))
        self._query_btn.setText("按最佳策略抓取" if can_auto_fetch else "打开官网/验证")
        self._market_query_btn.setEnabled(
            bool(state.get("market_sources")) and not bool(state.get("api_sources"))
        )
        self._market_query_btn.setText("抓取公开市场参考价")
        self._progress_bar.setVisible(False)
        worker = self._subscription_worker
        self._subscription_worker = None
        if worker:
            worker.deleteLater()

        # Keep the exact source/period returned by the completed task. The
        # result table must show what was just stored, even if pruning or a
        # delayed city-combo signal changes the current page state.
        details = [value for value in (result.get("details") or []) if isinstance(value, dict)]
        completed_detail = next(
            (value for value in reversed(details) if value.get("success")),
            result if result.get("success") else {},
        )
        self._last_fetch_context = {
            "region_id": completed_detail.get("region_id"),
            "city": completed_detail.get("city") or city,
            "period": completed_detail.get("period") or self._period_input.text().strip(),
            "count": int(completed_detail.get("new_prices") or result.get("new_prices") or 0),
        }

        count = result.get("new_prices", 0)
        detail = next((value for value in reversed(details) if value.get("source_id")), result)
        parsed_count = int(detail.get("parsed_prices") or result.get("parsed_prices") or 0)
        stored_count = int(detail.get("stored_prices") or result.get("stored_prices") or count or 0)
        rejected_count = int(detail.get("rejected_prices") or result.get("rejected_prices") or 0)
        failure_reason = detail.get("failure_reason") or result.get("failure_reason") or ""
        next_action = detail.get("next_action") or result.get("next_action") or ""
        if count:
            prefix = "用户网址抓取完成" if custom_url else "已抓取并更新"
            suffix = (
                f"；候选 {parsed_count:,} 条，入库 {stored_count:,} 条，"
                f"剔除异常 {rejected_count:,} 条。结果已显示在下方。"
            )
            self._city_status.setText(f"{city}：{prefix} {count:,} 条价格{suffix}")
        elif failure_reason or result.get("errors"):
            reason = failure_reason or str(result.get("errors", ["未发现可用价格数据"])[0])
            action = f" 下一步：{next_action}" if next_action else ""
            self._city_status.setText(
                f"{city}：本次未形成可入库价格；候选 {parsed_count:,} 条，"
                f"剔除 {rejected_count:,} 条。原因：{redact_text(reason)[:280]}。{action}"
            )
        else:
            self._city_status.setText(
                f"{city}：来源已访问，但未识别到可入库价格。"
                "请到来源配置查看抓取阶段和失败原因。"
            )
        self._update_custom_url_controls()
        self._refresh_strategy_table()
        self._refresh_results(self._last_fetch_context)
        self.data_changed.emit()

    def _refresh_results(self, fetch_context: dict | None = None):
        session = get_session()
        try:
            city = self._city_combo.currentText().strip()
            if not city or city.startswith("--"):
                self._result_table.setRowCount(0)
                self._result_summary.setText("请选择城市后查看已入库价格。")
                return
            context = fetch_context or {}
            region_id = context.get("region_id")
            region = (
                session.query(Region).filter(Region.id == int(region_id)).first()
                if region_id not in (None, "") else None
            )
            if region is None:
                region = session.query(Region).filter(Region.name == city).first()
            if not region:
                self._result_table.setRowCount(0)
                self._result_summary.setText(f"{city} 暂无已入库价格。")
                return
            period = _text(context.get("period"))
            price_query = session.query(MaterialPrice).filter(
                MaterialPrice.region_id == region.id,
                MaterialPrice.is_withdrawn.is_(False),
            )
            if period:
                price_query = price_query.filter(MaterialPrice.period == period)
            prices = price_query.order_by(
                MaterialPrice.period.desc(), MaterialPrice.price.desc()
            ).limit(500).all()
            if context.get("count"):
                self._result_summary.setText(
                    f"本次抓取已完成并自动入库：{region.name} {period or '最新期'}，"
                    f"新增或更新 {int(context['count']):,} 条；下方显示该城市该期前500条结果。"
                )
            elif prices:
                self._result_summary.setText(
                    f"当前显示已入库价格：{region.name} {period or '最新期'}，"
                    f"共 {len(prices):,} 条（最多显示500条）。"
                )
            else:
                self._result_summary.setText(
                    f"{region.name} {period or '当前期数'} 没有已入库价格；请查看上方抓取状态和来源配置。"
                )
            self._result_table.setRowCount(len(prices))
            for row, price in enumerate(prices):
                material_name = price.material.name if price.material else ""
                actual_city = region.name or city
                self._result_table.setItem(row, 0, QTableWidgetItem(actual_city))
                self._result_table.setItem(row, 1, QTableWidgetItem(material_name))
                self._result_table.setItem(row, 2, QTableWidgetItem(price.spec or ""))
                self._result_table.setItem(row, 3, QTableWidgetItem(price.unit or ""))
                self._result_table.setItem(row, 4, QTableWidgetItem(f"{price.price:,.2f}" if price.price else ""))
                self._result_table.setItem(row, 5, QTableWidgetItem(price.period or ""))
                self._result_table.setItem(row, 6, QTableWidgetItem("已入库"))
                source_type = {
                    "official": "官方",
                    "market_reference": "市场参考",
                    "user_url": "用户输入网址（已入库）",
                    "manual": "手动导入",
                }.get(price.source_type, price.source_type or price.trust_level or "未标注")
                basis = {
                    "tax_inclusive": "含税",
                    "tax_exclusive": "除税",
                    "delivered": "到场/工地",
                    "ex_factory": "出厂",
                    "as_published": "按原文",
                }.get(price.price_basis, price.price_basis or "未标注")
                self._result_table.setItem(row, 7, QTableWidgetItem(source_type))
                self._result_table.setItem(row, 8, QTableWidgetItem(basis))
        finally:
            session.close()


class PendingConfirmTab(QWidget):
    data_changed = Signal()
    PAGE_SIZE = 200

    def __init__(self):
        super().__init__()
        self._summary_labels = {}
        self._page = 0
        self._total_pending = 0
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("待入库价格确认"))
        tools.addStretch()
        self._prev_btn = ActionButton("上一页", "default")
        self._prev_btn.clicked.connect(lambda: self._change_page(-1))
        tools.addWidget(self._prev_btn)
        self._page_label = QLabel("第 1 / 1 页")
        self._page_label.setStyleSheet("color:#64748b; min-width:90px; qproperty-alignment:AlignCenter;")
        tools.addWidget(self._page_label)
        self._next_btn = ActionButton("下一页", "default")
        self._next_btn.clicked.connect(lambda: self._change_page(1))
        tools.addWidget(self._next_btn)
        confirm_btn = ActionButton("确认选中", "primary")
        confirm_btn.clicked.connect(self._on_confirm_selected)
        tools.addWidget(confirm_btn)
        reject_btn = ActionButton("驳回选中", "warn")
        reject_btn.clicked.connect(self._on_reject_selected)
        tools.addWidget(reject_btn)
        export_btn = ActionButton("导出 Excel", "default")
        export_btn.clicked.connect(self._on_export)
        tools.addWidget(export_btn)
        layout.addLayout(tools)

        self._table = QTableWidget()
        self._table.setColumnCount(8)
        self._table.setHorizontalHeaderLabels([
            "材料名称", "规格型号", "计量单位", "单价（元）", "地区 / 期数",
            "官方来源", "原始文件", "校验结果",
        ])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setStyleSheet("QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } QTableWidget::item { padding:8px; } QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }")
        self._table.itemSelectionChanged.connect(self._update_selected_count)
        layout.addWidget(self._table, 1)

        bottom = QFrame()
        bottom.setStyleSheet("background:#0b1220; border-radius:16px; padding:14px;")
        bl = QHBoxLayout(bottom)
        for label, value in [("待确认总数", "0"), ("可入库", "0"), ("异常待审", "0"), ("已选中", "0")]:
            item = QVBoxLayout()
            value_label = QLabel(value)
            value_label.setFont(QFont("Microsoft YaHei", 16, QFont.Bold))
            value_label.setStyleSheet("color:#fff; border:none;")
            item.addWidget(value_label)
            name_label = QLabel(label)
            name_label.setStyleSheet("color:#94a3b8; font-size:11px; border:none;")
            item.addWidget(name_label)
            bl.addLayout(item)
            self._summary_labels[label] = value_label
        bl.addStretch()
        layout.addWidget(bottom)
        self.refresh_data()

    def _change_page(self, offset: int):
        max_page = max(0, (self._total_pending - 1) // self.PAGE_SIZE)
        target = min(max(self._page + offset, 0), max_page)
        if target != self._page:
            self._page = target
            self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            base_query = session.query(MaterialPrice).filter(MaterialPrice.is_confirmed.is_(False))
            self._total_pending = base_query.count()
            normal_count = base_query.filter(MaterialPrice.is_anomaly.is_(False)).count()
            anomaly_count = self._total_pending - normal_count
            max_page = max(0, (self._total_pending - 1) // self.PAGE_SIZE)
            self._page = min(self._page, max_page)
            rows = (
                session.query(MaterialPrice, Material, Region, SourceDocument, OfficialSource)
                .join(Material, Material.id == MaterialPrice.material_id)
                .join(Region, Region.id == MaterialPrice.region_id)
                .outerjoin(SourceDocument, SourceDocument.id == MaterialPrice.source_doc_id)
                .outerjoin(OfficialSource, OfficialSource.id == SourceDocument.source_id)
                .filter(MaterialPrice.is_confirmed.is_(False))
                .order_by(MaterialPrice.updated_at.desc(), MaterialPrice.id.desc())
                .offset(self._page * self.PAGE_SIZE)
                .limit(self.PAGE_SIZE)
                .all()
            )
            self._table.setUpdatesEnabled(False)
            self._table.setRowCount(len(rows))
            for row_index, (price, material, region, document, source) in enumerate(rows):
                name_item = QTableWidgetItem(material.name if material else str(price.material_id))
                name_item.setData(Qt.UserRole, price.id)
                self._table.setItem(row_index, 0, name_item)
                self._table.setItem(row_index, 1, QTableWidgetItem(price.spec))
                self._table.setItem(row_index, 2, QTableWidgetItem(price.unit))
                self._table.setItem(row_index, 3, QTableWidgetItem(f"{price.price:.2f}"))
                self._table.setItem(row_index, 4, QTableWidgetItem(f"{region.name if region else ''} / {price.period}"))
                source_text = display_source_name(source.name, source.url, source.source_type) if source else (
                    "市场参考来源" if price.trust_level == "market_reference" else "手动导入"
                )
                self._table.setItem(row_index, 5, QTableWidgetItem(source_text))
                file_name = display_file_name(
                    document.file_name if document else "手动导入",
                    source.name if source else "",
                    source.url if source else "",
                    source.source_type if source else "",
                )
                if document and source and display_source_url(document.url, source.name, source.source_type) == "已隐藏公开来源地址":
                    file_name = f"{price.period}公开市场价格文件"
                file_item = QTableWidgetItem(file_name)
                if document and document.url and source:
                    safe_url = display_source_url(document.url, source.name, source.source_type)
                    if safe_url and safe_url != "已隐藏公开来源地址":
                        file_item.setToolTip(safe_url)
                        file_item.setData(Qt.UserRole, safe_url)
                self._table.setItem(row_index, 6, file_item)
                status_text = "异常待审" if price.is_anomaly else "自动校验通过"
                self._table.setItem(row_index, 7, QTableWidgetItem(status_text))
                badge = StatusBadge(status_text, "warn" if price.is_anomaly else "ok")
                self._table.setCellWidget(row_index, 7, badge)
            self._table.setUpdatesEnabled(True)
            self._summary_labels["待确认总数"].setText(f"{self._total_pending:,}")
            self._summary_labels["可入库"].setText(f"{normal_count:,}")
            self._summary_labels["异常待审"].setText(f"{anomaly_count:,}")
            total_pages = max_page + 1
            self._page_label.setText(f"第 {self._page + 1} / {total_pages} 页")
            self._prev_btn.setEnabled(self._page > 0)
            self._next_btn.setEnabled(self._page < max_page)
            self._update_selected_count()
        finally:
            self._table.setUpdatesEnabled(True)
            session.close()

    def _selected_price_ids(self) -> list[int]:
        selected_rows = {index.row() for index in self._table.selectionModel().selectedRows()}
        selected_rows.update(index.row() for index in self._table.selectedIndexes())
        current_row = self._table.currentRow()
        if current_row >= 0:
            selected_rows.add(current_row)
        pending_ids = []
        for row_index in sorted(selected_rows):
            item = self._table.item(row_index, 0)
            if item and item.data(Qt.UserRole) is not None:
                pending_ids.append(item.data(Qt.UserRole))
        return pending_ids

    def _update_selected_count(self):
        if self._summary_labels:
            self._summary_labels["已选中"].setText(str(len(self._selected_price_ids())))

    def _on_confirm_selected(self):
        pending_ids = self._selected_price_ids()
        if not pending_ids:
            QMessageBox.information(self, "请选择数据", "请先选中一行或多行待入库价格。")
            return
        from src.subscription import confirm_pending_prices
        result = confirm_pending_prices(pending_ids)
        if result.get("success"):
            confirmed = result.get("confirmed", 0)
            self.refresh_data()
            self.data_changed.emit()
            if confirmed > 0:
                QMessageBox.information(self, "确认完成", f"已确认入库 {confirmed} 条，价格库、首页和历史记录已同步刷新。")
            else:
                QMessageBox.information(self, "无需处理", "选中数据已确认或已被其他操作处理。")
        else:
            QMessageBox.warning(self, "确认失败", result.get("error", "未知错误"))

    def _on_reject_selected(self):
        pending_ids = self._selected_price_ids()
        if not pending_ids:
            QMessageBox.information(self, "请选择数据", "请先选中要驳回的待入库价格。")
            return
        reply = QMessageBox.question(
            self, "确认驳回", f"确定驳回并删除选中的 {len(pending_ids)} 条待入库价格吗？",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        from src.subscription import reject_pending_prices
        result = reject_pending_prices(pending_ids)
        if result.get("success"):
            self.refresh_data()
            self.data_changed.emit()
            QMessageBox.information(self, "驳回完成", f"已驳回 {result.get('rejected', 0)} 条。")
        else:
            QMessageBox.warning(self, "驳回失败", result.get("error", "未知错误"))

    def _on_export(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出待入库价格", "待入库价格.xlsx", "Excel 文件 (*.xlsx)")
        if not path:
            return
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Font, PatternFill
            from openpyxl.utils import get_column_letter
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "待入库价格"
            headers = [
                self._table.horizontalHeaderItem(column).text()
                for column in range(self._table.columnCount())
            ] + ["原始网址"]
            sheet.append(headers)
            session = get_session()
            try:
                rows = (
                    session.query(MaterialPrice, Material, Region, SourceDocument, OfficialSource)
                    .join(Material, Material.id == MaterialPrice.material_id)
                    .join(Region, Region.id == MaterialPrice.region_id)
                    .outerjoin(SourceDocument, SourceDocument.id == MaterialPrice.source_doc_id)
                    .outerjoin(OfficialSource, OfficialSource.id == SourceDocument.source_id)
                    .filter(MaterialPrice.is_confirmed.is_(False))
                    .order_by(MaterialPrice.updated_at.desc(), MaterialPrice.id.desc())
                    .yield_per(500)
                )
                exported = 0
                for price, material, region, document, source in rows:
                    source_text = display_source_name(source.name, source.url, source.source_type) if source else (
                        "市场参考来源" if price.trust_level == "market_reference" else "手动导入"
                    )
                    sheet.append([
                        material.name,
                        price.spec,
                        price.unit,
                        price.price,
                        f"{region.name} / {price.period}",
                        source_text,
                        (
                            f"{price.period}公开市场价格文件"
                            if document and source and display_source_url(document.url, source.name, source.source_type) == "已隐藏公开来源地址"
                            else display_file_name(
                                document.file_name if document else "手动导入",
                                source.name if source else "",
                                source.url if source else "",
                                source.source_type if source else "",
                            )
                        ),
                        "异常待审" if price.is_anomaly else "自动校验通过",
                        display_source_url(document.url if document else "", source.name if source else "", source.source_type if source else ""),
                    ])
                    exported += 1
            finally:
                session.close()
            header_fill = PatternFill("solid", fgColor="2563EB")
            for cell in sheet[1]:
                cell.fill = header_fill
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")
            widths = [30, 24, 12, 14, 18, 30, 34, 18, 60]
            for index, width in enumerate(widths, 1):
                sheet.column_dimensions[get_column_letter(index)].width = width
            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions

            guide = workbook.create_sheet("审核说明")
            guide.append(["项目", "说明"])
            guide.append(["这是什么", "抓取后尚未进入正式价格库的候选材料价格。"])
            guide.append(["自动校验通过", "来源、材料名称、计量单位和价格字段完整，但入库前仍应核对原始文件。"])
            guide.append(["异常待审", "价格涨跌或数值异常，不能直接确认。"])
            guide.append(["原始文件 / 网址", "用于回到官方发布文件逐条核对，确保期数、专业和价格口径一致。"])
            guide.append(["明确拒绝", "规范目录、通知公告、招标文件、操作手册等内容不会进入待入库列表。"])
            guide.column_dimensions["A"].width = 22
            guide.column_dimensions["B"].width = 90
            for cell in guide[1]:
                cell.fill = header_fill
                cell.font = Font(color="FFFFFF", bold=True)
            workbook.save(path)
            QMessageBox.information(self, "导出完成", f"已导出 {exported:,} 条到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))


class SourceConfigTab(QWidget):
    data_changed = Signal()

    STATUS_LABELS = {
        "working": "已验证可抓取",
        "user_url": "用户网址/待核验",
        "login_required": "需要登录",
        "membership_required": "需要会员",
        "browser_dynamic": "浏览器验证/待适配",
        "public_document": "公开附件/待适配",
        "public_scanned_document": "扫描附件/OCR待纠错",
        "connection_blocked": "连接受阻",
        "waf_blocked": "网站防火墙拦截",
        "pending_adapter": "待适配",
        "pending_parser": "待解析",
        "wrong_url": "网址失效或错误",
        "wrong_content": "栏目内容不符",
        "no_current_source": "暂无当前来源",
        "no_public_source": "官网未公开现行数据",
        "province_fallback": "省级资料/非城市月刊",
        "no_price_data": "未解析出价格数据",
    }

    def __init__(self):
        super().__init__()
        self._worker = None
        self._browser_worker = None
        self._browser_login_btn = None
        self._update_mode = ""
        self._sniff_worker = None
        self._sniff_source_id = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("信息来源配置（官方 / 市场参考）"))
        tools.addStretch()
        add_btn = ActionButton("添加来源", "primary")
        add_btn.clicked.connect(self._on_add_source)
        tools.addWidget(add_btn)
        test_btn = ActionButton("测试连接", "default")
        test_btn.clicked.connect(self._on_test_connection)
        tools.addWidget(test_btn)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        actions.addWidget(QLabel("选中来源操作"))
        actions.addStretch()

        self._sniff_btn = ActionButton("API嗅探（排错）", "default")
        self._sniff_btn.setToolTip("仅供接口适配和故障排查，日常更新不需要逐个点击")
        self._sniff_btn.clicked.connect(self._on_sniff_apis)
        actions.addWidget(self._sniff_btn)
        self._update_selected_btn = ActionButton("更新选中", "default")
        self._update_selected_btn.clicked.connect(self._on_update_source)
        actions.addWidget(self._update_selected_btn)
        self._update_all_btn = ActionButton("一键更新全部", "primary")
        self._update_all_btn.setToolTip("批量更新所有已接入专用抓取适配器的官方来源")
        self._update_all_btn.clicked.connect(self._on_update_all_sources)
        tools.addWidget(self._update_all_btn)
        open_btn = ActionButton("打开网站", "default")
        open_btn.clicked.connect(self._on_open_site)
        actions.addWidget(open_btn)
        auth_btn = ActionButton("登录授权", "default")
        auth_btn.clicked.connect(self._on_configure_auth)
        actions.addWidget(auth_btn)
        self._browser_login_btn = ActionButton("浏览器登录", "default")
        self._browser_login_btn.setToolTip("打开浏览器，在官网完成登录后自动捕获Cookie")
        self._browser_login_btn.clicked.connect(self._on_browser_login)
        actions.addWidget(self._browser_login_btn)
        layout.addLayout(tools)
        layout.addLayout(actions)

        self._table = QTableWidget()
        self._table.setColumnCount(9)
        self._table.setHorizontalHeaderLabels([
            "城市", "来源", "来源级别", "抓取方法", "实测状态", "抓取结果", "下一步", "最后检查", "官网",
        ])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setStyleSheet("QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } QTableWidget::item { padding:8px; } QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }")
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            sources = self._sync_official_catalog(session)
            session.commit()
            self._table.setRowCount(len(sources))
            for row_index, source in enumerate(sources):
                region = session.query(Region).filter(Region.id == source.region_id).first()
                city = region.name if region else ""
                from src.official_sources_config import get_city_audit_status, get_city_source_config
                audit = get_city_audit_status(city)
                source_config = get_city_source_config(city, source.url) or {}
                status = source_config.get("data_status") or audit.get("status", "pending_adapter")
                if (
                    source_config.get("source_class") == "market_reference"
                    and audit.get("status") != "working"
                    and status == "working"
                ):
                    status = "market_reference"
                try:
                    source_metadata = json.loads(source.notes or "{}")
                    if not isinstance(source_metadata, dict):
                        source_metadata = {}
                except json.JSONDecodeError:
                    source_metadata = {}
                validation_status = source_metadata.get("validation_status", "")
                if source.source_type == "user_url":
                    status = "user_url"
                elif validation_status in {"working", "login_required", "no_price_data", "failed"}:
                    status = validation_status
                elif source.source_type == "ai_discovered":
                    status = "pending_adapter"
                name_item = QTableWidgetItem(city)
                name_item.setData(Qt.UserRole, source.id)
                self._table.setItem(row_index, 0, name_item)
                self._table.setItem(row_index, 1, QTableWidgetItem(display_source_name(source.name, source.url, source.source_type)))
                self._table.setItem(row_index, 2, QTableWidgetItem("官方" if source.is_official else "第三方参考"))
                strategy = source_config.get("strategy", source.source_type or "")
                self._table.setItem(row_index, 3, QTableWidgetItem(self._strategy_label(strategy)))
                status_text = (
                    "公开市场可抓取（待验证）"
                    if status == "market_reference"
                    else self.STATUS_LABELS.get(status, status)
                )
                status_kind = "ok" if status == "working" else "warn"
                if status == "working" and source.last_result == "failed":
                    status_text += "（上次失败）"
                    status_kind = "error"
                self._table.setCellWidget(row_index, 4, StatusBadge(status_text, status_kind))
                latest_task = session.query(SubscriptionTask).filter(
                    SubscriptionTask.source_id == source.id,
                ).order_by(SubscriptionTask.created_at.desc()).first()
                self._table.setItem(row_index, 5, QTableWidgetItem(self._task_result_text(source, latest_task)))
                self._table.setItem(row_index, 6, QTableWidgetItem(self._next_step(status)))
                last_check = source.last_check_at.strftime("%Y-%m-%d %H:%M") if source.last_check_at else "未检查"
                self._table.setItem(row_index, 7, QTableWidgetItem(last_check))
                display_url = display_source_url(source.url, source.name, source.source_type)
                self._table.setItem(row_index, 8, QTableWidgetItem(display_url))
        finally:
            session.close()

    @staticmethod
    def _strategy_label(strategy: str) -> str:
        if strategy == "api":
            return "API式自动适配"
        return {
            "api": "专用接口/附件适配器",
            "browser_login": "浏览器动态验证",
            "crawl": "官网栏目待适配",
            "user_url": "用户输入网址抓取",
            "ai_discovered": "AI发现/待验证适配",
        }.get(strategy, strategy or "未配置")

    @staticmethod
    def _next_step(status: str) -> str:
        if status == "market_reference":
            return "可直接抓取公开市场参考价；按城市和期数分别入库"
        return {
            "working": "可更新选中；一键更新仅包含此类",
            "user_url": "用户已确认网址；抓取后自动清理异常数据并直接入库",
            "login_required": "打开官网并完成登录，再点浏览器登录",
            "membership_required": "登录/会员授权后再重试",
            "browser_dynamic": "需固化浏览器动态接口，暂不自动抓取",
            "connection_blocked": "需解决官网连接或网络拦截",
            "waf_blocked": "需解决网站防火墙拦截",
            "pending_adapter": "先打开官网核查；动态页面可使用API嗅探（排错）",
            "no_price_data": "页面可访问但未解析出完整价格记录，可重新验证或登录后再试",
            "failed": "自动验证失败，查看抓取结果后重试",
        }.get(status, "继续核查官网栏目与解析方法")

    @staticmethod
    def _task_result_text(source, task) -> str:
        if task is None:
            return "尚未抓取"
        if task.status == "failed":
            reason = task.failure_reason or task.message or "未知原因"
            return f"失败（{task.failure_stage or '流程'}）：{reason.splitlines()[-1][:80]}"
        if source.last_result == "restricted":
            catalog_match = re.search(r"材料目录\s+([\d,]+)\s+条", task.message or "")
            return f"目录 {catalog_match.group(1) if catalog_match else '已获取'} 条/单价受限"
        parsed = int(getattr(task, "parsed_count", 0) or 0)
        stored = int(getattr(task, "stored_count", 0) or task.result_count or 0)
        rejected = int(getattr(task, "rejected_count", 0) or 0)
        if parsed or stored or rejected:
            return f"有效 {parsed:,} 条，入库 {stored:,} 条，剔除 {rejected:,} 条"
        return "0 条" if not task.message else f"0 条：{task.message.splitlines()[-1][:80]}"

    @staticmethod
    def _sync_official_catalog(session):
        """Make the verified city catalog the single source of truth for this table."""
        from src.official_sources_config import CITY_SOURCES

        selected_ids = set()
        for city, configs in CITY_SOURCES.items():
            region = session.query(Region).filter(Region.name == city).first()
            if region is None:
                region = Region(name=city, province="", is_active=True)
                session.add(region)
                session.flush()
            existing = session.query(OfficialSource).filter(
                OfficialSource.region_id == region.id,
            ).all()
            by_url = {item.url.rstrip("/"): item for item in existing if item.url}
            for cfg in configs:
                configured_url = cfg["url"].rstrip("/")
                source = by_url.get(configured_url)
                if source is None:
                    source = OfficialSource(
                        region_id=region.id,
                        name=cfg.get("name", f"{city}官方来源"),
                        url=cfg["url"],
                        source_type=cfg.get("strategy", "api"),
                        is_official=cfg.get("is_official", True),
                        is_active=True,
                    )
                    session.add(source)
                    session.flush()
                source.name = cfg.get("name", f"{city}官方来源")
                source.url = cfg["url"]
                source.source_type = cfg.get("strategy", "api")
                source.is_official = cfg.get("is_official", True)
                source.is_active = True
                try:
                    metadata = json.loads(source.notes or "")
                    if not isinstance(metadata, dict):
                        metadata = {"description": source.notes or ""}
                except json.JSONDecodeError:
                    metadata = {"description": source.notes or ""}
                metadata["catalog_note"] = cfg.get("note", "")
                metadata["source_class"] = cfg.get(
                    "source_class",
                    "official" if source.is_official else "market_reference",
                )
                metadata["province"] = cfg.get("province", "")
                metadata["catalog_url"] = cfg.get("url", "")
                source.notes = json.dumps(metadata, ensure_ascii=False)
                selected_ids.add(source.id)
            for old_source in existing:
                if (
                    old_source.is_official
                    and old_source.source_type != "ai_discovered"
                    and old_source.id not in selected_ids
                    and old_source.url
                ):
                    old_source.is_active = False
                    old_source.last_result = "disabled"
                    old_source.notes = "已由官方验证目录替代，停用旧来源"
        sources = session.query(OfficialSource).filter(
            OfficialSource.is_active.is_(True),
        ).join(Region, Region.id == OfficialSource.region_id).order_by(Region.name, OfficialSource.name).all()
        return [source for source in sources if source.is_official or source.id in selected_ids or source.source_type == "user_url"]

    def _selected_source_id(self):
        row = self._table.currentRow()
        item = self._table.item(row, 0) if row >= 0 else None
        return item.data(Qt.UserRole) if item else None

    def _on_add_source(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("添加信息来源")
        dialog.setMinimumWidth(520)
        layout = QVBoxLayout(dialog)
        region_combo = QComboBox()
        session = get_session()
        try:
            region_combo.addItems([region.name for region in session.query(Region).order_by(Region.name).all()])
        finally:
            session.close()
        name_input = QLineEdit()
        url_input = QLineEdit()
        url_input.setPlaceholderText("https://...")
        type_combo = QComboBox()
        type_combo.addItems(["web", "excel", "pdf"])
        tier_combo = QComboBox()
        tier_combo.addItems(["官方地方信息价来源", "市场造价网站（仅供参考）"])
        for label, widget in [("地区", region_combo), ("来源名称", name_input), ("网址", url_input), ("来源类型", type_combo), ("数据级别", tier_combo)]:
            layout.addWidget(QLabel(label))
            layout.addWidget(widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        name = name_input.text().strip()
        url = url_input.text().strip()
        if not name or not url.startswith(("http://", "https://")):
            QMessageBox.warning(self, "信息不完整", "请填写来源名称和完整的 http/https 网址。")
            return
        official = tier_combo.currentIndex() == 0
        from src.utils import is_official_domain
        if official and not is_official_domain(url):
            QMessageBox.warning(self, "官方校验未通过", "该网址未通过官方域名校验。请改为“市场造价网站”或填写官方网址。")
            return
        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == region_combo.currentText()).first()
            if session.query(OfficialSource).filter(OfficialSource.region_id == region.id, OfficialSource.url == url).first():
                QMessageBox.information(self, "已存在", "该地区已经配置过这个网址。")
                return
            source = OfficialSource(region_id=region.id, name=name, url=url, source_type=type_combo.currentText(), is_official=official, is_active=True)
            session.add(source)
            session.flush()
            write_audit(session, "create", "official_source" if official else "market_source", source.id, f"添加来源: {name}")
            session.commit()
            self.refresh_data()
            self.data_changed.emit()
            QMessageBox.information(self, "添加完成", "来源已保存。需要会员授权时，请选中该来源后点击“登录授权”。")
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "添加失败", str(error))
        finally:
            session.close()
    def _on_sniff_apis(self):
        if self._sniff_worker is not None and self._sniff_worker.isRunning():
            QMessageBox.information(self, "正在嗅探", "当前来源仍在分析，请等待完成。")
            return
        source_id = self._selected_source_id()
        if source_id is None:
            QMessageBox.information(self, "请选择来源", "请先在表中选择一个来源。")
            return
        row = self._table.currentRow()
        url_item = self._table.item(row, 8)
        url = url_item.text().strip() if url_item else ""
        if not url:
            QMessageBox.warning(self, "来源无网址", "该来源没有可访问的网址。")
            return
        self._sniff_source_id = source_id
        self._sniff_btn.setEnabled(False)
        self._sniff_btn.setText("启动浏览器...")
        self._sniff_worker = ApiSnifferWorker(url, timeout=30)
        self._sniff_worker.progress_changed.connect(self._on_sniff_progress)
        self._sniff_worker.completed.connect(self._on_sniff_complete)
        self._sniff_worker.start()

    def _on_sniff_progress(self, message: str):
        self._sniff_btn.setText(message[:12] + ("..." if len(message) > 12 else ""))

    def _on_sniff_complete(self, result: dict):
        source_id = self._sniff_source_id
        self._sniff_btn.setEnabled(True)
        self._sniff_btn.setText("API嗅探（排错）")
        worker = self._sniff_worker
        self._sniff_worker = None
        self._sniff_source_id = None
        if worker is not None:
            worker.deleteLater()
        if result.get("error"):
            QMessageBox.warning(self, "嗅探失败", result["error"])
            return
        relevant = result.get("relevant", [])
        total = result.get("total_captured", 0)
        if not relevant:
            QMessageBox.information(
                self, "嗅探完成",
                f"共捕获 {total} 个 XHR/Fetch 请求，但未发现明显的造价信息API。\n\n"
                "请把来源网址调整为具体的信息价栏目页后再试。"
            )
            return

        lines = [f"发现 {len(relevant)} 个相关 API 端点（共捕获 {total} 个请求）：\n"]
        for endpoint in relevant[:20]:
            lines.append(f"{endpoint.get('method', '?')}  {endpoint.get('url', '?')}")
            if endpoint.get("post_data"):
                lines.append(f"参数：{endpoint['post_data'][:240]}")
        if len(relevant) > 20:
            lines.append(f"  ... 还有 {len(relevant) - 20} 个")
        lines.append("\n端点已保存到该来源，可用于配置城市专用抓取适配器。")

        session = get_session()
        try:
            source = session.query(OfficialSource).filter(OfficialSource.id == source_id).first()
            if source:
                try:
                    metadata = json.loads(source.notes or "{}")
                    if not isinstance(metadata, dict):
                        metadata = {"description": source.notes or ""}
                except json.JSONDecodeError:
                    metadata = {"description": source.notes or ""}
                metadata["api_sniffer"] = {
                    "endpoints": relevant[:100],
                    "captured_at": result.get("captured_at", datetime.now().isoformat(timespec="seconds")),
                    "browser": result.get("browser", ""),
                    "page_url": result.get("page_url", source.url),
                    "total_captured": total,
                }
                source.notes = json.dumps(metadata, ensure_ascii=False)
                write_audit(session, "update", "official_source", source.id, f"API嗅探发现 {len(relevant)} 个端点")
                session.commit()
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "端点保存失败", str(error))
            return
        finally:
            session.close()

        QMessageBox.information(self, "API嗅探结果", "\n".join(lines))

    def closeEvent(self, event):
        if self._sniff_worker is not None and self._sniff_worker.isRunning():
            self._sniff_worker.requestInterruption()
            self._sniff_worker.wait(3000)
        super().closeEvent(event)


    def _on_test_connection(self):
        source_id = self._selected_source_id()
        if source_id is None:
            QMessageBox.information(self, "请选择来源", "请先选中一个来源。")
            return
        session = get_session()
        try:
            source = session.query(OfficialSource).filter(OfficialSource.id == source_id).first()
            from src.source_credentials import source_auth_headers
            headers = {"User-Agent": config.USER_AGENT}
            headers.update(source_auth_headers(source_id))
            response = requests.get(source.url, headers=headers, timeout=12)
            response.raise_for_status()
            from src.utils import is_official_domain
            if source.is_official and not is_official_domain(response.url):
                raise ValueError("网站跳转后不是 gov.cn 官方域名")
            source.last_check_at = __import__("datetime").datetime.utcnow()
            source.last_result = "connected"
            session.commit()
            self.refresh_data()
            QMessageBox.information(
                self,
                "连接成功",
                f"已连接 {display_source_name(source.name, source.url, source.source_type)}\n"
                f"HTTP {response.status_code}，响应 {len(response.content):,} 字节。",
            )
        except Exception as error:
            if "source" in locals() and source is not None:
                source.last_check_at = __import__("datetime").datetime.utcnow()
                source.last_result = "failed"
                session.commit()
                self.refresh_data()
            QMessageBox.warning(
                self,
                "连接失败",
                f"{_friendly_connection_error(error)}\n\n这个来源目前不能抓取价格数据，请核对网址或改用准确的官方栏目页。",
            )
        finally:
            session.close()

    def _on_open_site(self):
        source_id = self._selected_source_id()
        if source_id is None:
            QMessageBox.information(self, "请选择来源", "请先选中一个来源。")
            return
        session = get_session()
        try:
            source = session.query(OfficialSource).filter(OfficialSource.id == source_id).first()
            os.startfile(source.url)
        except Exception as error:
            QMessageBox.warning(self, "无法打开", str(error))
        finally:
            session.close()

    def _on_update_source(self):
        source_id = self._selected_source_id()
        if source_id is None:
            QMessageBox.information(self, "请选择来源", "请先选中要更新的来源。")
            return
        source, city, source_config, audit = self._selected_source_context(source_id)
        if source is None:
            return
        if not self._can_auto_update(source, city, source_config, audit, notify=True):
            return
        self._start_source_update([source_id], "selected")

    def _on_update_all_sources(self):
        from src.api_fetcher import has_api_handler
        from src.official_sources_config import get_city_audit_status, get_city_source_config

        session = get_session()
        try:
            sources = session.query(OfficialSource).filter(
                OfficialSource.is_active.is_(True),
                OfficialSource.is_official.is_(True),
            ).order_by(OfficialSource.created_at).all()
            source_ids = []
            for source in sources:
                region = session.query(Region).filter(Region.id == source.region_id).first()
                city = region.name if region else ""
                audit = get_city_audit_status(city)
                source_config = get_city_source_config(city, source.url)
                if (
                    audit.get("status") == "working"
                    and source_config
                    and source_config.get("data_status") == "working"
                    and source_config.get("strategy") == "api"
                    and has_api_handler(source.url)
                ):
                    source_ids.append(source.id)
                    continue
                try:
                    metadata = json.loads(source.notes or "{}")
                    if not isinstance(metadata, dict):
                        metadata = {}
                except json.JSONDecodeError:
                    metadata = {}
                if (
                    source.source_type == "ai_discovered"
                    and metadata.get("validation_status") == "working"
                ):
                    source_ids.append(source.id)
        finally:
            session.close()
        if not source_ids:
            QMessageBox.information(
                self,
                "暂无可批量更新来源",
                "目前没有已接入专用抓取适配器的启用官方来源。",
            )
            return
        self._start_source_update(source_ids, "all")

    def _selected_source_context(self, source_id):
        from src.official_sources_config import get_city_audit_status, get_city_source_config

        session = get_session()
        try:
            source = session.query(OfficialSource).filter(OfficialSource.id == source_id).first()
            if source is None:
                QMessageBox.warning(self, "来源不存在", "该官方来源已被移除，请刷新来源配置。")
                return None, "", None, {}
            region = session.query(Region).filter(Region.id == source.region_id).first()
            city = region.name if region else ""
            return source, city, get_city_source_config(city, source.url), get_city_audit_status(city)
        finally:
            session.close()

    def _can_auto_update(self, source, city, source_config, audit, notify=False) -> bool:
        from src.api_fetcher import has_api_handler

        try:
            metadata = json.loads(source.notes or "{}")
            if not isinstance(metadata, dict):
                metadata = {}
        except json.JSONDecodeError:
            metadata = {}
        validation_status = metadata.get("validation_status", "")
        if source.source_type == "ai_discovered" or metadata.get("ai_discovery_completed"):
            if validation_status == "working":
                return True
            if validation_status == "login_required":
                message = f"{city}官方来源需要登录或会员权限，请先点击“浏览器登录”。"
            else:
                message = f"{city}来源尚未解析出有效价格数据，请重新执行官方来源验证。"
            if notify:
                QMessageBox.information(self, "来源尚不可更新", message)
            return False
        status = source_config.get("data_status") if source_config else audit.get("status", "pending_adapter")
        if status in {"login_required", "membership_required"} and source_config is not None:
            message = f"{city}：{self.STATUS_LABELS.get(status, status)}。请打开来源网站完成登录/购买授权，"
            message += "当前页面明细未授权，不能直接抓取。"
        elif (
            source_config
            and source_config.get("source_class") == "market_reference"
            and source_config.get("data_status") == "working"
            and source_config.get("strategy") == "api"
            and has_api_handler(source.url)
        ):
            return True
        elif not source.is_official or source_config is None:
            message = "该来源不在已验证的官方自动抓取目录中，不能使用通用抓取。"
        elif status == "working":
            if (
                source_config.get("data_status") == "working"
                and source_config.get("strategy") == "api"
                and has_api_handler(source.url)
            ):
                return True
            message = f"{city}的专用抓取适配器未正确加载，已阻止抓取，避免取错数据。"
        elif status == "browser_dynamic":
            message = f"{city}需要浏览器动态验证，当前专用适配器尚未固化，暂不自动抓取。"
        else:
            message = f"{city}当前不能自动抓取：{audit.get('note', '尚未完成价格数据级实验')}"
        if notify:
            QMessageBox.information(self, "暂不能自动抓取", message)
        return False

    def _start_source_update(self, source_ids: list[int], mode: str):
        if self._worker is not None and self._worker.isRunning():
            QMessageBox.information(self, "正在更新", "当前更新任务尚未完成，请稍候。")
            return
        self._update_mode = mode
        self._update_selected_btn.setEnabled(False)
        self._update_all_btn.setEnabled(False)
        self._update_all_btn.setText(f"正在更新 0/{len(source_ids)}")
        self._worker = SubscriptionWorker(source_ids)
        self._worker.progress_changed.connect(self._on_update_progress)
        self._worker.completed.connect(self._on_update_complete)
        self._worker.start()

    def _on_update_progress(self, progress: dict):
        current = progress.get("source_index", 1)
        total = progress.get("source_total", 1)
        percent = progress.get("percent", 0)
        self._update_all_btn.setText(f"更新 {current}/{total} · {percent}%")

    def _on_update_complete(self, result: dict):
        worker = self._worker
        self._worker = None
        self._update_selected_btn.setEnabled(True)
        self._update_all_btn.setEnabled(True)
        self._update_all_btn.setText("一键更新全部")
        mode = self._update_mode
        self._update_mode = ""
        if worker is not None:
            worker.deleteLater()
        self.refresh_data()
        self.data_changed.emit()
        errors = result.get("errors", [])
        total = result.get("total", 0)
        success = result.get("success", 0)
        failed = result.get("failed", 0)
        count = result.get("new_prices", 0)
        title = "批量更新完成" if mode == "all" else "更新完成"
        message = f"已处理 {total} 个来源：成功 {success} 个，失败 {failed} 个。\n新增或更新 {count:,} 条价格。"
        details = result.get("details", [])
        reason = next((item.get("message") for item in details if item.get("message")), "")
        if count == 0 and reason:
            message += f"\n\n结果说明：{reason}"
        if errors:
            message += "\n\n失败原因：" + "；".join(errors[:3])
        if success:
            QMessageBox.information(self, title, message)
        else:
            QMessageBox.warning(self, "更新失败", message)

    def _on_configure_auth(self):
        ...

    def _on_browser_login(self):
        source_id = self._selected_source_id()
        if source_id is None:
            QMessageBox.information(self, "请选择来源", "请先选中需要浏览器登录的来源。")
            return
        if self._browser_worker is not None and self._browser_worker.isRunning():
            QMessageBox.information(self, "正在登录", "浏览器登录任务正在进行中，请等待完成或关闭浏览器窗口。")
            return
        session = get_session()
        try:
            source = session.query(OfficialSource).filter(OfficialSource.id == source_id).first()
            if not source:
                QMessageBox.warning(self, "来源不存在", "该来源已被删除。")
                return
            url = source.url
        finally:
            session.close()

        self._browser_login_btn.setEnabled(False)
        self._browser_login_btn.setText("启动浏览器...")
        self._browser_worker = BrowserLoginWorker(url)
        self._browser_worker.progress_changed.connect(self._on_browser_login_progress)
        self._browser_worker.completed.connect(lambda result, sid=source_id: self._on_browser_login_complete(sid, result))
        self._browser_worker.start()

    def _on_browser_login_progress(self, message: str):
        self._browser_login_btn.setText(message[:14] + ("..." if len(message) > 14 else ""))

    def _on_browser_login_complete(self, source_id: int, result: dict):
        self._browser_login_btn.setEnabled(True)
        self._browser_login_btn.setText("浏览器登录")
        worker = self._browser_worker
        self._browser_worker = None
        if worker is not None:
            worker.deleteLater()
        if result.get("success"):
            cookie_header = result.get("cookie_header", "")
            count = result.get("cookie_count", 0)
            if cookie_header:
                from src.browser_login import save_browser_cookies
                try:
                    save_browser_cookies(source_id, cookie_header)
                    self.refresh_data()
                    self.data_changed.emit()
                    msg = f"登录成功，已捕获并加密保存 {count} 个 Cookie。\n\n现在可以点击「更新选中」或「一键更新全部」抓取该来源的数据。"
                    warning = result.get("warning", "")
                    if warning:
                        msg += f"\n\n⚠ {warning}"
                    QMessageBox.information(self, "浏览器登录完成", msg)
                except Exception as exc:
                    QMessageBox.warning(self, "Cookie保存失败", f"Cookie捕获成功但保存失败：{exc}")
            else:
                QMessageBox.warning(self, "未捕获到Cookie", "浏览器登录完成但未捕获到有效的 Cookie。请确认是否已成功登录。")
        else:
            self.refresh_data()
            QMessageBox.warning(
                self,
                "浏览器登录失败",
                f"未能获取登录 Cookie。{result.get('error', '请确认已在浏览器中完成登录操作。')}\n\n"
                "提示：部分官网可能使用非 Cookie 的认证方式（如加密狗），此类网站需要专用适配器。",
            )

    def _on_configure_auth(self):
        source_id = self._selected_source_id()
        if source_id is None:
            QMessageBox.information(self, "请选择来源", "请先选中需要授权的会员网站。")
            return
        from src.source_credentials import load_source_credentials, save_source_credentials
        current = load_source_credentials(source_id, include_secret=False)
        dialog = QDialog(self)
        dialog.setWindowTitle("网站登录授权")
        dialog.setMinimumWidth(520)
        layout = QVBoxLayout(dialog)
        note = QLabel("凭据使用 Windows 本机加密保存。Cookie/令牌仅发送给当前来源域名，不写入日志。")
        note.setWordWrap(True)
        layout.addWidget(note)
        auth_type = QComboBox()
        auth_type.addItem("无需授权", "none")
        auth_type.addItem("HTTP 基本认证（账号+密码）", "basic")
        auth_type.addItem("访问令牌 Bearer", "bearer")
        auth_type.addItem("浏览器 Cookie", "cookie")
        index = auth_type.findData(current.get("auth_type", "none"))
        auth_type.setCurrentIndex(max(index, 0))
        username = QLineEdit(current.get("username", ""))
        secret = QLineEdit()
        secret.setEchoMode(QLineEdit.Password)
        secret.setPlaceholderText("密码、令牌或 Cookie；留空会清除旧凭据")
        for label, widget in [("授权方式", auth_type), ("账号（可选）", username), ("密码 / 令牌 / Cookie", secret)]:
            layout.addWidget(QLabel(label))
            layout.addWidget(widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        try:
            save_source_credentials(source_id, auth_type.currentData(), username.text().strip(), secret.text())
            QMessageBox.information(self, "授权已保存", "登录信息已使用当前 Windows 用户密钥加密保存。请点击“测试连接”验证。")
        except Exception as error:
            QMessageBox.warning(self, "保存失败", str(error))


class SourceDocsTab(QWidget):
    data_changed = Signal()

    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("原始文件管理"))
        tools.addStretch()
        upload_btn = ActionButton("上传官方文件", "primary")
        upload_btn.clicked.connect(self._on_upload)
        tools.addWidget(upload_btn)
        view_btn = ActionButton("查看原件", "default")
        view_btn.clicked.connect(self._on_view)
        tools.addWidget(view_btn)
        layout.addLayout(tools)

        self._empty = QLabel("暂无原始文件。点击【上传官方文件】手动上传PDF/Excel信息价文件。")
        self._empty.setStyleSheet("color:#94a3b8; font-size:13px;")
        self._empty.setAlignment(Qt.AlignCenter)
        layout.addWidget(self._empty)

        self._table = QTableWidget()
        self._table.setColumnCount(5)
        self._table.setHorizontalHeaderLabels(["文件名", "期数", "类型", "大小", "上传时间"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setStyleSheet("QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } QTableWidget::item { padding:8px; } QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }")
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            docs = session.query(SourceDocument).order_by(SourceDocument.created_at.desc()).limit(100).all()
            source_ids = {doc.source_id for doc in docs if doc.source_id}
            sources_by_id = {
                source.id: source
                for source in session.query(OfficialSource).filter(OfficialSource.id.in_(source_ids)).all()
            } if source_ids else {}
            self._empty.setVisible(len(docs) == 0)
            self._table.setRowCount(len(docs))
            for row_index, doc in enumerate(docs):
                source = sources_by_id.get(doc.source_id)
                file_item = QTableWidgetItem(display_file_name(doc.file_name, source.name if source else "", source.url if source else "", source.source_type if source else ""))
                file_item.setData(Qt.UserRole, doc.id)
                self._table.setItem(row_index, 0, file_item)
                self._table.setItem(row_index, 1, QTableWidgetItem(doc.period))
                self._table.setItem(row_index, 2, QTableWidgetItem(doc.file_type))
                self._table.setItem(row_index, 3, QTableWidgetItem(f"{doc.file_size / 1024:.1f} KB" if doc.file_size else "0 KB"))
                self._table.setItem(row_index, 4, QTableWidgetItem(doc.created_at.strftime("%Y-%m-%d %H:%M")))
        finally:
            session.close()

    def _on_upload(self):
        path, _ = QFileDialog.getOpenFileName(self, "上传官方信息价原文件", "", "信息价文件 (*.xlsx *.xls *.csv *.pdf)")
        if not path:
            return
        session = get_session()
        try:
            sources = session.query(OfficialSource).filter(OfficialSource.is_active.is_(True)).order_by(OfficialSource.name).all()
            options = [
                f"{source.region_obj.name if source.region_obj else ''} | "
                f"{display_source_name(source.name, source.url, source.source_type)}"
                for source in sources
            ]
        finally:
            session.close()
        if not options:
            QMessageBox.information(self, "无可用来源", "请先在“来源配置”中添加文件所属来源。")
            return
        selected, ok = QInputDialog.getItem(self, "选择文件来源", "该文件来自：", options, 0, False)
        if not ok:
            return
        source_id = sources[options.index(selected)].id
        from src.subscription import SubscriptionEngine
        with SubscriptionEngine() as engine:
            result = engine.ingest_local_file(source_id, path)
        if result.get("success"):
            self.refresh_data()
            self.data_changed.emit()
            QMessageBox.information(self, "解析完成", f"原文件已保存，异常数据已清理，新增或更新 {result.get('new_prices', 0):,} 条并直接入库。")
        else:
            QMessageBox.warning(self, "解析失败", result.get("error", "未知错误"))

    def _on_view(self):
        row = self._table.currentRow()
        item = self._table.item(row, 0) if row >= 0 else None
        if item is None:
            QMessageBox.information(self, "请选择文件", "请先选中一个原始文件。")
            return
        session = get_session()
        try:
            document = session.query(SourceDocument).filter(SourceDocument.id == item.data(Qt.UserRole)).first()
            target = document.file_path if document and document.file_path and Path(document.file_path).exists() else ""
            if not target:
                QMessageBox.warning(self, "文件不可打开", "该公开来源只保留了脱敏记录；请重新执行对应城市和期数的抓取。")
                return
            os.startfile(target)
        except Exception as error:
            QMessageBox.warning(self, "无法打开", str(error))
        finally:
            session.close()
