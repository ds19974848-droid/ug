﻿"""共享 UI 组件 — 使用 Qt 动态属性匹配 QSS 选择器"""
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView,
    QToolTip,
)
from PySide6.QtCore import QEvent, QObject, QRect, Qt, Signal
from PySide6.QtGui import QCursor, QFont, QFontMetrics


LONG_TEXT_TOOLTIP_MS = 30000


class _LongTextTooltipFilter(QObject):
    """Keep long table-cell content readable while preserving compact rows."""

    def __init__(self, table: QTableWidget, duration_ms: int):
        super().__init__(table)
        self._table = table
        self._duration_ms = duration_ms

    def eventFilter(self, watched, event):
        try:
            table = self._table
            viewport = table.viewport()
        except (AttributeError, RuntimeError):
            return False
        if watched is viewport:
            if event.type() == QEvent.MouseMove:
                item = table.itemAt(event.position().toPoint())
                if item is not None:
                    self._show_for_item(item)
                else:
                    QToolTip.hideText()
            elif event.type() in (QEvent.Leave, QEvent.Hide):
                QToolTip.hideText()
        return super().eventFilter(watched, event)

    def _show_for_item(self, item: QTableWidgetItem):
        text = item.text()
        if not text:
            QToolTip.hideText()
            return
        column = item.column()
        metrics = QFontMetrics(self._table.font())
        longest_width = max(
            (metrics.horizontalAdvance(line) for line in text.splitlines()),
            default=0,
        )
        available_width = max(self._table.columnWidth(column) - 14, 0)
        custom_tip = item.toolTip()
        needs_tooltip = (
            "\n" in text
            or longest_width > available_width
            or bool(custom_tip and custom_tip != text)
        )
        if not needs_tooltip:
            QToolTip.hideText()
            return
        tip = text
        if custom_tip and custom_tip != text:
            tip = f"{text}\n\n{custom_tip}"
        QToolTip.showText(
            QCursor.pos(), tip, self._table, QRect(), self._duration_ms
        )


def install_long_text_tooltip(table: QTableWidget, duration_ms: int = LONG_TEXT_TOOLTIP_MS):
    """Install reliable long-cell hover behavior on a table viewport."""
    table.setMouseTracking(True)
    table.viewport().setMouseTracking(True)
    existing = getattr(table, "_long_text_tooltip_filter", None)
    if existing is not None:
        return existing
    event_filter = _LongTextTooltipFilter(table, duration_ms)
    table.viewport().installEventFilter(event_filter)
    table._long_text_tooltip_filter = event_filter
    return event_filter


class NavGroup(QWidget):
    """左侧导航分组按钮（带展开/收起子菜单）"""
    clicked = Signal(str)

    def __init__(self, title: str, icon: str, children: list, parent=None):
        super().__init__(parent)
        self.title = title
        self.icon = icon
        self.children_labels = children
        self._expanded = False
        self._active = False
        self._active_child = ""
        self._child_widgets = []
        self._setup_ui()
        if title == "首页":
            self._expanded = True
            self._active = True
            self._update_styles()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        title_row = QWidget()
        title_row.setObjectName("nav-title-row")
        title_layout = QHBoxLayout(title_row)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.setSpacing(8)

        self._icon_badge = QLabel(self.icon)
        self._icon_badge.setObjectName("nav-icon-badge")
        self._icon_badge.setAlignment(Qt.AlignCenter)
        self._icon_badge.setFixedSize(28, 28)
        title_layout.addWidget(self._icon_badge)

        self._title_btn = QPushButton(self.title)
        self._title_btn.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        self._title_btn.setCursor(Qt.PointingHandCursor)
        self._title_btn.setFixedHeight(38)
        self._title_btn.clicked.connect(self._toggle)
        title_layout.addWidget(self._title_btn, 1)
        layout.addWidget(title_row)

        if self.children_labels:
            self._children_container = QWidget()
            self._children_container.setVisible(False)
            cl = QVBoxLayout(self._children_container)
            cl.setContentsMargins(34, 1, 0, 3)
            cl.setSpacing(2)
            for label in self.children_labels:
                btn = QPushButton(label)
                btn.setFont(QFont("Microsoft YaHei", 10))
                btn.setCursor(Qt.PointingHandCursor)
                btn.setFixedHeight(30)
                btn.clicked.connect(lambda checked, l=label: self._on_child_click(l))
                cl.addWidget(btn)
                self._child_widgets.append(btn)
            layout.addWidget(self._children_container)

        self._update_styles()

    def _toggle(self):
        if self.children_labels:
            self._expanded = not self._expanded
            self._children_container.setVisible(self._expanded)
        else:
            self.clicked.emit(self.title)
        self._update_styles()

    def _on_child_click(self, label: str):
        self._active_child = label
        self._update_styles()
        self.clicked.emit(label)

    def set_active_child(self, label: str):
        self._active_child = label
        self._active = label in self.children_labels
        if self._active and self.children_labels:
            self._expanded = True
            self._children_container.setVisible(True)
        self._update_styles()

    def set_active_label(self, label: str):
        self._active = label == self.title or label in self.children_labels
        self._active_child = label if label in self.children_labels else ""
        if self.children_labels:
            self._expanded = self._active
            self._children_container.setVisible(self._expanded)
        self._update_styles()

    def _update_styles(self):
        title_style = "titleActive" if (self._active or self._expanded) else "title"
        self._title_btn.setProperty("navStyle", title_style)
        self._title_btn.style().unpolish(self._title_btn)
        self._title_btn.style().polish(self._title_btn)
        icon_style = "active" if (self._active or self._expanded) else "idle"
        self._icon_badge.setProperty("navIconStyle", icon_style)
        self._icon_badge.style().unpolish(self._icon_badge)
        self._icon_badge.style().polish(self._icon_badge)

        for btn in self._child_widgets:
            if btn.text() == self._active_child:
                btn.setProperty("navStyle", "childActive")
            else:
                btn.setProperty("navStyle", "child")
            btn.style().unpolish(btn)
            btn.style().polish(btn)


class SectionHeader(QWidget):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 8)
        lbl = QLabel(title)
        lbl.setFont(QFont("Microsoft YaHei", 11, QFont.Bold))
        lbl.setStyleSheet("color: #101828;")
        layout.addWidget(lbl)
        layout.addStretch()


class StatusBadge(QLabel):
    COLORS = {
        "ok": ("#dcfce7", "#15803d"),
        "warn": ("#fef3c7", "#b45309"),
        "error": ("#fee2e2", "#dc2626"),
        "info": ("#dbeafe", "#1d4ed8"),
        "neutral": ("#f1f5f9", "#64748b"),
    }

    def __init__(self, text: str, kind: str = "ok", parent=None):
        super().__init__(text, parent)
        bg, fg = self.COLORS.get(kind, self.COLORS["neutral"])
        self.setFont(QFont("Microsoft YaHei", 8, QFont.Bold))
        self.setFixedHeight(22)
        self.setStyleSheet(f"background:{bg}; color:{fg}; border-radius:10px; padding:2px 10px;")


class ActionButton(QPushButton):
    def __init__(self, text: str, kind: str = "default", parent=None):
        super().__init__(text, parent)
        self.setFont(QFont("Microsoft YaHei", 9, QFont.Bold))
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(34)
        # Set default inline stylesheet as fallback
        styles = {
            "primary": "background:#2563eb; color:#fff; border:none; border-radius:11px; padding:0 14px;",
            "warn": "background:#fff7ed; color:#c2410c; border:1px solid #fed7aa; border-radius:11px; padding:0 14px;",
            "danger": "background:#fef2f2; color:#dc2626; border:1px solid #fecaca; border-radius:11px; padding:0 14px;",
            "default": "background:#fff; color:#475569; border:1px solid #e2e8f0; border-radius:11px; padding:0 14px;",
        }
        self.setStyleSheet(styles.get(kind, styles["default"]))


class AIBadge(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.refresh()
        self.setFixedHeight(22)

    def refresh(self):
        from src.ai_service import ai
        state = ai.connection_state
        states = {
            "connected": ("AI 已连接", "#dcfce7", "#15803d"),
            "failed": ("AI 连接失败", "#fee2e2", "#b91c1c"),
            "not_tested": ("AI 待检测", "#fef3c7", "#a16207"),
            "not_configured": ("AI 未配置", "#f1f5f9", "#64748b"),
        }
        text, bg, fg = states.get(state, states["not_configured"])
        self.setText(f" {text} ")
        self.setToolTip(ai.connection_message)
        self.setStyleSheet(f"background:{bg}; color:{fg}; border-radius:10px; padding:2px 10px; font-weight:bold; font-size:11px;")
