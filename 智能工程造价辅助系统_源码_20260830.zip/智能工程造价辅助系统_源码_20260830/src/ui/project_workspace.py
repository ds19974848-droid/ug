﻿"""项目工作台模块页面 - 含 AI 辅助报价与报价合理性验证"""
import json
import re
from datetime import datetime

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QFrame,
    QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget,
    QPushButton, QLineEdit, QScrollArea, QMessageBox, QDialog,
    QDialogButtonBox, QTextEdit, QProgressBar, QFileDialog, QComboBox,
    QDoubleSpinBox, QAbstractItemView, QMenu,
)
from PySide6.QtCore import Qt, Signal, QThread
from PySide6.QtGui import QColor, QFont
from rapidfuzz import fuzz

from src.ai_service import ai
from src.db import get_session, write_audit, get_setting, set_settings
from src.models import Project, ProjectItem, ProjectPriceSnapshot, Region, Material, MaterialPrice, CostItem, PriceHistory, OfficialSource
from src.cost_item_service import find_cost_item_reference
from src.source_display import display_source_name
from src.ui.quota_match import QuotaMatchTab
from src.ui.widgets import (
    StatusBadge, ActionButton, SectionHeader, AIBadge, install_long_text_tooltip,
)


class AISuggestWorker(QThread):
    """AI 辅助报价后台线程"""
    finished = Signal(list)
    error = Signal(str)

    def __init__(self, items, region):
        super().__init__()
        self.items = items
        self.region = region

    def run(self):
        try:
            result = ai.suggest_prices(self.items, self.region)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


class AIValidateWorker(QThread):
    """AI 报价验证后台线程"""
    finished = Signal(dict)
    error = Signal(str)

    def __init__(self, items, region):
        super().__init__()
        self.items = items
        self.region = region

    def run(self):
        try:
            result = ai.validate_quote(self.items, self.region)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


class OfficialPriceUpdateWorker(QThread):
    completed = Signal(dict)
    progress_changed = Signal(dict)

    def __init__(self, source_ids: list[int], period: str, specialty: str, keywords: list[str]):
        super().__init__()
        self.source_ids = source_ids
        self.period = period
        self.specialty = specialty
        self.keywords = keywords

    def run(self):
        try:
            from src.subscription import SubscriptionEngine
            with SubscriptionEngine(
                self.period,
                self.specialty,
                self.keywords,
                progress_callback=self.progress_changed.emit,
            ) as engine:
                self.completed.emit(engine.run_sources(self.source_ids))
        except Exception as error:
            self.completed.emit({
                "total": len(self.source_ids), "success": 0, "empty": 0,
                "failed": len(self.source_ids), "new_prices": 0, "errors": [str(error)],
            })


class ProjectWorkspacePage(QWidget):
    data_changed = Signal()
    navigate_requested = Signal(str)
    TAB_ROUTES = {
        "quota_match": 0,
        "project_quote": 1,
        "price_linkage": 2,
        "project_snapshot": 3,
    }

    def __init__(self):
        super().__init__()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        self._tabs = QTabWidget()
        self._tabs.setStyleSheet("""
            QTabWidget::pane { border: none; background: #f0f4f9; }
            QTabBar::tab { padding: 10px 20px; font-weight: bold; border: none; color: #667085; }
            QTabBar::tab:selected { color: #2563eb; border-bottom: 3px solid #2563eb; }
        """)
        # Project identity is still loaded into the working tabs, but the
        # large clickable banner is intentionally omitted from the workspace.
        self._project_context = QLabel()
        self._quote_tab = ProjectQuoteTab()
        self._linkage_tab = PriceLinkageTab()
        self._linkage_tab.set_project_quote_tab(self._quote_tab)
        self._linkage_tab.data_changed.connect(self.data_changed)
        self._snapshot_tab = ProjectSnapshotTab()
        self._quote_tab.data_changed.connect(self.data_changed)
        self._quote_tab.navigate_requested.connect(self.navigate_requested)
        self._quota_match_tab = QuotaMatchTab()
        self._quota_match_tab.data_changed.connect(self.data_changed)
        self._quota_match_tab.navigate_requested.connect(self.navigate_requested)
        self._linkage_tab.set_quota_match_tab(self._quota_match_tab)
        self._tabs.addTab(self._quota_match_tab, "匹配定额库")
        self._tabs.addTab(self._quote_tab, "匹配信息价与基础信息库")
        self._tabs.addTab(self._linkage_tab, "造价变化联动")
        self._tabs.addTab(self._snapshot_tab, "项目快照")
        self._tabs.setTabVisible(3, False)
        self._load_active_project()
        layout.addWidget(self._tabs)

    def show_route(self, route_key: str):
        self._load_active_project()
        index = self.TAB_ROUTES.get(route_key, 0)
        self._tabs.setCurrentIndex(index)
        current_tab = self._tabs.widget(index)
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()

    def refresh_data(self):
        self._load_active_project()
        current_tab = self._tabs.currentWidget()
        if hasattr(current_tab, "refresh_data"):
            current_tab.refresh_data()

    def _load_active_project(self):
        """把项目档案中的当前项目带入报价页，避免工作台重新丢失项目身份。"""
        try:
            active_id = int(get_setting("active_project_id", "0") or 0)
        except (TypeError, ValueError):
            active_id = 0
        if not active_id:
            self._project_context.setText("当前项目：未选择，点击此处前往“项目信息”选择项目")
            return
        session = get_session()
        try:
            project = session.query(Project).filter(Project.id == active_id).first()
            if not project:
                self._project_context.setText("当前项目：未选择，点击此处前往“项目信息”选择项目")
                return
            context = project.name
            if project.code:
                context += f"  ·  {project.code}"
            if project.stage:
                context += f"  ·  {project.stage}"
            self._project_context.setText(f"当前项目：{context}  （点击可切换）")
            self._quote_tab._name_input.setText(project.name or "")
            self._quote_tab._region_input.setText(project.pricing_city or project.project_location or "郑州")
            self._quote_tab._material_region_input.setText(
                project.pricing_city or project.project_location or "郑州"
            )
            if project.pricing_date:
                period_match = re.match(r"(\d{4})[-/](\d{1,2})", project.pricing_date)
                if period_match:
                    period = f"{period_match.group(1)}-{int(period_match.group(2)):02d}"
                    self._quote_tab._period_input.setText(period)
                    self._quote_tab._material_period_input.setText(period)
        finally:
            session.close()


class ProjectQuoteTab(QWidget):
    data_changed = Signal()
    navigate_requested = Signal(str)

    CORE_HEADERS = [
        "序号", "清单编号", "清单名称", "规格", "单位", "工程量",
        "人工费单价", "材料费单价", "机械费单价", "未拆分直接费单价",
        "管理费单价", "利润单价", "综合单价", "合价", "价格来源", "备注",
    ]
    MAX_IMPORT_COLUMNS = 30
    MAX_CUSTOM_COLUMNS = 10
    COL_SEQ = 0
    COL_CODE = 1
    COL_NAME = 2
    COL_SPEC = 3
    COL_UNIT = 4
    COL_QUANTITY = 5
    COL_LABOR = 6
    COL_MATERIAL = 7
    COL_MACHINERY = 8
    COL_UNALLOCATED = 9
    COL_MANAGEMENT = 10
    COL_PROFIT = 11
    COL_UNIT_PRICE = 12
    COL_TOTAL = 13
    COL_SOURCE = 14
    COL_NOTES = 15
    CALCULATED_COLUMNS = {COL_MANAGEMENT, COL_PROFIT, COL_UNIT_PRICE, COL_TOTAL}
    MATERIAL_LOOKUP_HEADERS = [
        "匹配度", "材料名称", "规格", "单位", "地区", "期数",
        "价格", "价格口径", "价格级别", "状态",
    ]
    MATERIAL_LOOKUP_SOURCES = [
        ("已确认官方与自有价格", ["official", "official_manual", "manual"]),
        ("全部已确认价格（含市场参考）", ["official", "official_manual", "manual", "market_reference"]),
        ("仅地方官方信息价", ["official", "official_manual"]),
    ]

    def __init__(self):
        super().__init__()
        self._ai_worker = None
        self._official_update_worker = None
        self._material_fetch_worker = None
        self._updating_table = False
        self._material_lookup_rows = []
        self._material_lookup_updating = False
        self._summary_labels = {}
        self._custom_headers = []
        try:
            hidden_headers = json.loads(get_setting("quote_hidden_columns", "[]"))
        except (TypeError, ValueError, json.JSONDecodeError):
            hidden_headers = []
        self._hidden_headers = {
            str(header) for header in hidden_headers if isinstance(header, str)
        }
        self._current_summary = {}
        self._setup_ui()

    def _setup_ui(self):
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 8, 0, 0)
        outer_layout.setSpacing(12)
        self._mode_tabs = QTabWidget()
        self._mode_tabs.setStyleSheet(
            "QTabWidget::pane { border: none; background: transparent; } "
            "QTabBar::tab { padding: 8px 16px; font-weight: bold; border: none; color: #667085; } "
            "QTabBar::tab:selected { color: #2563eb; border-bottom: 3px solid #2563eb; }"
        )
        project_tab = QWidget()
        layout = QVBoxLayout(project_tab)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(8)
        self._mode_tabs.addTab(project_tab, "项目清单报价")

        header = QFrame()
        header.setObjectName("quote-context-bar")
        header.setStyleSheet(
            "QFrame#quote-context-bar { background:#ffffff; border:1px solid #dbe3ef; "
            "border-left:4px solid #2563eb; border-radius:8px; padding:4px; } "
            "QFrame#quote-context-bar QLabel { background:transparent; border:none; color:#475569; } "
            "QFrame#quote-context-bar QLineEdit { border:1px solid #dbe3ef; "
            "border-radius:6px; padding:6px 9px; background:#ffffff; }"
        )
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(12, 8, 12, 8)
        header_layout.setSpacing(8)
        header_layout.addWidget(QLabel("项目"))
        self._name_input = QLineEdit()
        self._name_input.setPlaceholderText("输入项目名称")
        self._name_input.setMinimumWidth(180)
        header_layout.addWidget(self._name_input, 1)
        header_layout.addWidget(QLabel("地区"))
        self._region_input = QLineEdit("郑州")
        self._region_input.setFixedWidth(120)
        header_layout.addWidget(self._region_input)
        header_layout.addWidget(QLabel("期数"))
        self._period_input = QLineEdit(datetime.now().strftime("%Y-%m"))
        self._period_input.setFixedWidth(105)
        header_layout.addWidget(self._period_input)
        self._ai_badge = AIBadge()
        header_layout.addWidget(self._ai_badge)
        self._ai_progress = QProgressBar()
        self._ai_progress.setVisible(False)
        self._ai_progress.setFixedWidth(120)
        self._ai_progress.setRange(0, 0)
        header_layout.addWidget(self._ai_progress)
        header_layout.addStretch()
        lock_btn = ActionButton("锁定价格版本", "warn")
        lock_btn.clicked.connect(self._on_lock_snapshot)
        header_layout.addWidget(lock_btn)
        export_btn = ActionButton("导出报价", "default")
        export_btn.clicked.connect(self._on_export_quote)
        header_layout.addWidget(export_btn)
        layout.addWidget(header)

        official_progress_row = QHBoxLayout()
        self._official_progress = QProgressBar()
        self._official_progress.setRange(0, 100)
        self._official_progress.setValue(0)
        self._official_progress.setFixedHeight(18)
        self._official_progress.setVisible(False)
        official_progress_row.addWidget(self._official_progress, 1)
        self._official_progress_text = QLabel("")
        self._official_progress_text.setStyleSheet("color:#475569; font-size:12px;")
        self._official_progress_text.setWordWrap(True)
        self._official_progress_text.setVisible(False)
        official_progress_row.addWidget(self._official_progress_text, 2)
        layout.addLayout(official_progress_row)

        lookup_tab = QWidget()
        lookup_layout = QVBoxLayout(lookup_tab)
        lookup_layout.setContentsMargins(0, 8, 0, 0)
        lookup_layout.setSpacing(12)
        self._setup_material_lookup_panel(lookup_layout)
        self._mode_tabs.addTab(lookup_tab, "单材料价格查询")

        criteria_block = QVBoxLayout()
        criteria_block.setSpacing(6)
        criteria_row = QHBoxLayout()
        criteria_row.addWidget(QLabel("造价专业:"))
        self._specialty_combo = QComboBox()
        self._specialty_combo.addItems([
            "全部专业", "建筑与装饰工程", "安装工程", "市政工程", "园林绿化工程",
            "城市轨道交通工程", "公路工程", "桥梁与隧道工程", "水利水电工程",
        ])
        self._specialty_combo.setMinimumWidth(170)
        criteria_row.addWidget(self._specialty_combo)
        self._material_period_input.setText(self._period_input.text())
        criteria_row.addWidget(QLabel("匹配来源:"))
        self._pricing_source_combo = QComboBox()
        self._pricing_source_combo.addItem("官方地方价优先，固定清单补缺", "official_then_fixed")
        self._pricing_source_combo.addItem("仅地方官方信息价", "official_only")
        self._pricing_source_combo.addItem("仅固定工程清单价", "fixed_only")
        self._pricing_source_combo.addItem("官方价优先，固定库和市场价补缺", "all_sources")
        self._pricing_source_combo.setMinimumWidth(230)
        criteria_row.addWidget(self._pricing_source_combo)
        criteria_row.addStretch()
        criteria_block.addLayout(criteria_row)
        criteria_actions = QHBoxLayout()
        criteria_actions.addStretch()
        self._official_update_btn = ActionButton("官方价抓取中心", "primary")
        self._official_update_btn.setToolTip(
            "打开官方订阅页面：查看可直接抓取和需登录的城市，或输入用户网址抓取"
        )
        self._official_update_btn.clicked.connect(
            lambda: self.navigate_requested.emit("subscription")
        )
        criteria_actions.addWidget(self._official_update_btn)
        batch_lookup_btn = ActionButton("批量匹配报价", "primary")
        batch_lookup_btn.clicked.connect(self._on_batch_lookup)
        criteria_actions.addWidget(batch_lookup_btn)
        self._fee_toggle_btn = ActionButton("费用设置", "default")
        criteria_actions.addWidget(self._fee_toggle_btn)
        criteria_block.addLayout(criteria_actions)
        layout.addLayout(criteria_block)

        fee_panel = QFrame()
        fee_panel.setObjectName("quote-fee-panel")
        fee_panel.setStyleSheet(
            "QFrame#quote-fee-panel { background:#ffffff; border:1px solid #dbe3ef; "
            "border-radius:8px; padding:8px; }"
        )
        fee_layout = QVBoxLayout(fee_panel)
        fee_layout.setContentsMargins(6, 2, 6, 2)
        fee_layout.setSpacing(6)
        management_row = QHBoxLayout()
        management_row.setSpacing(8)
        management_row.addWidget(QLabel("管理费基础"))
        self._management_base_combo = QComboBox()
        self._management_base_combo.addItem("人工费", "labor")
        self._management_base_combo.addItem("人工费+机械费", "labor_machine")
        self._management_base_combo.addItem("人工费+材料费+机械费+未拆分费", "direct")
        self._management_base_combo.setMinimumWidth(205)
        management_row.addWidget(self._management_base_combo)
        management_row.addWidget(QLabel("管理费率"))
        self._management_rate = QDoubleSpinBox()
        self._management_rate.setRange(0, 100)
        self._management_rate.setDecimals(2)
        self._management_rate.setSuffix(" %")
        self._management_rate.setValue(float(get_setting("quote_management_rate", "5")))
        management_row.addWidget(self._management_rate)
        management_row.addStretch()
        fee_layout.addLayout(management_row)

        profit_row = QHBoxLayout()
        profit_row.setSpacing(8)
        profit_row.addWidget(QLabel("利润基础"))
        self._profit_base_combo = QComboBox()
        self._profit_base_combo.addItem("人工费", "labor")
        self._profit_base_combo.addItem("人工费+机械费", "labor_machine")
        self._profit_base_combo.addItem("人材机及未拆分费", "direct")
        self._profit_base_combo.addItem("人工费+机械费+管理费", "labor_machine_management")
        self._profit_base_combo.addItem("人材机及未拆分费+管理费", "direct_management")
        self._profit_base_combo.setMinimumWidth(210)
        profit_row.addWidget(self._profit_base_combo)
        profit_row.addWidget(QLabel("利润率"))
        self._profit_rate = QDoubleSpinBox()
        self._profit_rate.setRange(0, 100)
        self._profit_rate.setDecimals(2)
        self._profit_rate.setSuffix(" %")
        self._profit_rate.setValue(float(get_setting("quote_profit_rate", "7")))
        profit_row.addWidget(self._profit_rate)
        profit_row.addWidget(QLabel("税率"))
        self._tax_rate = QDoubleSpinBox()
        self._tax_rate.setRange(0, 100)
        self._tax_rate.setDecimals(2)
        self._tax_rate.setSuffix(" %")
        self._tax_rate.setValue(float(get_setting("quote_tax_rate", "9")))
        profit_row.addWidget(self._tax_rate)
        profit_row.addStretch()
        save_fee_btn = ActionButton("保存为默认", "default")
        save_fee_btn.clicked.connect(self._save_fee_settings)
        profit_row.addWidget(save_fee_btn)
        fee_layout.addLayout(profit_row)
        fee_panel.setVisible(False)
        self._fee_panel = fee_panel
        self._fee_toggle_btn.clicked.connect(self._toggle_fee_panel)
        layout.addWidget(fee_panel)

        management_base = get_setting("quote_management_base", "direct")
        management_index = self._management_base_combo.findData(management_base)
        self._management_base_combo.setCurrentIndex(max(0, management_index))
        profit_base = get_setting("quote_profit_base", "direct_management")
        profit_index = self._profit_base_combo.findData(profit_base)
        self._profit_base_combo.setCurrentIndex(max(0, profit_index))

        tools = QHBoxLayout()
        tools.addWidget(SectionHeader("清单编辑器"))
        add_row_btn = ActionButton("添加行", "primary")
        add_row_btn.clicked.connect(self._on_add_row)
        tools.addWidget(add_row_btn)
        import_btn = ActionButton("Excel导入", "default")
        import_btn.clicked.connect(self._on_import_excel)
        tools.addWidget(import_btn)
        lookup_btn = ActionButton("查材料价", "default")
        lookup_btn.clicked.connect(self._on_lookup_price)
        tools.addWidget(lookup_btn)
        self._ai_suggest_btn = ActionButton("* AI辅助报价", "default")
        self._ai_suggest_btn.clicked.connect(self._on_ai_suggest)
        tools.addWidget(self._ai_suggest_btn)
        self._ai_validate_btn = ActionButton("* AI验证报价", "warn")
        self._ai_validate_btn.clicked.connect(self._on_ai_validate)
        tools.addWidget(self._ai_validate_btn)
        tools.addStretch()
        select_all_btn = ActionButton("全选", "default")
        select_all_btn.clicked.connect(self._table_select_all)
        tools.addWidget(select_all_btn)
        clear_selection_btn = ActionButton("取消选择", "default")
        clear_selection_btn.clicked.connect(self._table_clear_selection)
        tools.addWidget(clear_selection_btn)
        duplicate_rows_btn = ActionButton("复制所选", "default")
        duplicate_rows_btn.clicked.connect(self._on_duplicate_selected_rows)
        tools.addWidget(duplicate_rows_btn)
        delete_rows_btn = ActionButton("删除所选", "warn")
        delete_rows_btn.clicked.connect(self._on_delete_selected_rows)
        tools.addWidget(delete_rows_btn)
        self._columns_btn = ActionButton("列设置", "default")
        self._columns_menu = QMenu(self._columns_btn)
        self._columns_menu.aboutToShow.connect(self._rebuild_column_menu)
        self._columns_btn.setMenu(self._columns_menu)
        self._columns_btn.clicked.connect(self._rebuild_column_menu)
        tools.addWidget(self._columns_btn)
        layout.addLayout(tools)

        # 清单表格
        self._table = QTableWidget()
        self._reset_table_columns([])
        self._table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self._table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._table.setStyleSheet(
            "QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } "
            "QTableWidget::item { padding:8px; } "
            "QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }"
        )
        install_long_text_tooltip(self._table)
        demo = [
            ("1", "010101001001", "平整场地", "", "m2", 1500.00, 3.50),
            ("2", "010502001001", "现浇C30砼柱", "C30", "m3", 120.00, 856.00),
            ("3", "010515001001", "现浇构件钢筋", "HRB400 D12", "t", 15.00, 4250.00),
            ("4", "010401001001", "砖基础", "MU10", "m3", 80.00, 350.00),
            ("5", "011101001001", "水泥砂浆楼地面", "20mm", "m2", 2000.00, 45.00),
        ]
        self._table.setRowCount(len(demo))
        self._updating_table = True
        for row_index, (seq, code, name, spec, unit, quantity, direct_price) in enumerate(demo):
            values = [
                seq, code, name, spec, unit, f"{quantity:.2f}",
                f"{direct_price * 0.35:.4f}", f"{direct_price * 0.55:.4f}",
                f"{direct_price * 0.10:.4f}", "0.0000", "0.0000", "0.0000",
                "0.0000", "0.00", "示范数据", "",
            ]
            for column, value in enumerate(values):
                self._table.setItem(row_index, column, QTableWidgetItem(value))
        self._updating_table = False
        self._table.itemChanged.connect(self._on_table_item_changed)
        self._table.currentCellChanged.connect(self._on_quote_cell_changed)
        layout.addWidget(self._table, 1)

        # 底部费用汇总
        bottom = QFrame()
        bottom.setObjectName("quote-summary")
        bottom.setStyleSheet(
            "QFrame#quote-summary { background:#0b1220; border-radius:8px; padding:8px; } "
            "QFrame#quote-summary QLabel { background-color:transparent; border:none; padding:0; }"
        )
        bottom_layout = QVBoxLayout(bottom)
        bottom_layout.setContentsMargins(10, 6, 10, 6)
        bottom_layout.setSpacing(4)
        summary_rows = [QHBoxLayout(), QHBoxLayout()]
        sums = [
            ("人工费", "0.00"), ("材料费", "0.00"), ("机械费", "0.00"),
            ("未拆分费", "0.00"), ("管理费", "0.00"), ("利润", "0.00"),
            ("税金", "0.00"),
        ]
        for index, (l, v) in enumerate(sums):
            box = QVBoxLayout()
            box.setSpacing(1)
            lb = QLabel(f"{l}（元）")
            lb.setStyleSheet(
                "color:#cbd5e1; background-color:transparent; border:none; padding:0; font-size:12px;"
            )
            box.addWidget(lb)
            vl = QLabel(v)
            vl.setFont(QFont("Microsoft YaHei", 15, QFont.Bold))
            vl.setStyleSheet(
                "color:#ffffff; background-color:transparent; border:none; padding:0; font-size:15px; font-weight:700;"
            )
            self._summary_labels[l] = vl
            box.addWidget(vl)
            summary_rows[0 if index < 4 else 1].addLayout(box)
            summary_rows[0 if index < 4 else 1].addStretch()
        total_label = QLabel("总造价（元）")
        total_label.setStyleSheet(
            "color:#bae6fd; background-color:transparent; border:none; padding:0; font-size:12px;"
        )
        self._total_val = QLabel("354,795.46")
        self._total_val.setFont(QFont("Microsoft YaHei", 18, QFont.Bold))
        self._total_val.setStyleSheet(
            "color:#22d3ee; background-color:transparent; border:none; padding:0; font-size:18px; font-weight:800;"
        )
        total_box = QVBoxLayout()
        total_box.setSpacing(1)
        total_box.addWidget(total_label)
        total_box.addWidget(self._total_val)
        summary_rows[1].addLayout(total_box)
        bottom_layout.addLayout(summary_rows[0])
        bottom_layout.addLayout(summary_rows[1])
        layout.addWidget(bottom)
        self._management_base_combo.currentIndexChanged.connect(self._on_fee_settings_changed)
        self._profit_base_combo.currentIndexChanged.connect(self._on_fee_settings_changed)
        self._management_rate.valueChanged.connect(self._on_fee_settings_changed)
        self._profit_rate.valueChanged.connect(self._on_fee_settings_changed)
        self._tax_rate.valueChanged.connect(self._on_fee_settings_changed)
        outer_layout.addWidget(self._mode_tabs)
        self._recalculate_all_rows()

    def _toggle_fee_panel(self):
        visible = self._fee_panel.isVisible()
        self._fee_panel.setVisible(not visible)
        self._fee_toggle_btn.setText("收起费用设置" if not visible else "费用设置")

    def _setup_material_lookup_panel(self, layout):
        panel = QFrame()
        panel.setObjectName("material-lookup-panel")
        panel.setStyleSheet(
            "QFrame#material-lookup-panel { background:#ffffff; border:1px solid #bfdbfe; "
            "border-left:4px solid #2563eb; border-radius:8px; padding:4px; } "
            "QFrame#material-lookup-panel QLabel { background:transparent; border:none; } "
            "QFrame#material-lookup-panel QLineEdit, QFrame#material-lookup-panel QComboBox { "
            "border:1px solid #cbd5e1; border-radius:6px; padding:7px 10px; background:#ffffff; } "
        )
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(12, 10, 12, 10)
        panel_layout.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("单材料价格查询")
        title.setFont(QFont("Microsoft YaHei", 12, QFont.Bold))
        title.setStyleSheet("color:#1d4ed8;")
        header.addWidget(title)
        header.addStretch()
        self._material_lookup_count = QLabel("等待查询")
        self._material_lookup_count.setStyleSheet("color:#64748b; font-size:12px;")
        header.addWidget(self._material_lookup_count)
        panel_layout.addLayout(header)

        form = QGridLayout()
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(7)
        label_style = "color:#475569; font-size:12px; font-weight:700;"

        def add_label(text, row, column):
            label = QLabel(text)
            label.setStyleSheet(label_style)
            form.addWidget(label, row, column)

        self._material_keyword_input = QLineEdit()
        self._material_keyword_input.setPlaceholderText("材料名称，如 C30 混凝土")
        self._material_keyword_input.returnPressed.connect(self._on_query_material_price)
        self._material_spec_input = QLineEdit()
        self._material_spec_input.setPlaceholderText("规格，如 C30")
        self._material_spec_input.returnPressed.connect(self._on_query_material_price)
        self._material_unit_input = QLineEdit()
        self._material_unit_input.setPlaceholderText("单位，如 m3")
        self._material_unit_input.returnPressed.connect(self._on_query_material_price)
        self._material_region_input = QLineEdit(self._region_input.text())
        self._material_region_input.setPlaceholderText("查询地区")
        self._material_region_input.returnPressed.connect(self._on_query_material_price)
        self._material_period_input = QLineEdit(datetime.now().strftime("%Y-%m"))
        self._material_period_input.setPlaceholderText("期数，如 2026-08")
        self._material_period_input.returnPressed.connect(self._on_query_material_price)
        self._material_source_combo = QComboBox()
        for label, _levels in self.MATERIAL_LOOKUP_SOURCES:
            self._material_source_combo.addItem(label)
        self._material_source_combo.setMinimumWidth(205)

        add_label("材料名称", 0, 0)
        form.addWidget(self._material_keyword_input, 0, 1, 1, 3)
        add_label("规格", 0, 4)
        form.addWidget(self._material_spec_input, 0, 5, 1, 2)
        add_label("单位", 0, 7)
        form.addWidget(self._material_unit_input, 0, 8)
        add_label("地区", 1, 0)
        form.addWidget(self._material_region_input, 1, 1, 1, 2)
        add_label("期数", 1, 3)
        form.addWidget(self._material_period_input, 1, 4, 1, 2)
        add_label("数据范围", 1, 6)
        form.addWidget(self._material_source_combo, 1, 7, 1, 2)
        form.setColumnStretch(1, 2)
        form.setColumnStretch(5, 1)
        form.setColumnStretch(8, 1)
        panel_layout.addLayout(form)

        actions = QHBoxLayout()
        query_button = ActionButton("查询单个材料", "primary")
        query_button.clicked.connect(self._on_query_material_price)
        actions.addWidget(query_button)
        current_row_button = ActionButton("从当前清单行读取", "default")
        current_row_button.clicked.connect(self._load_lookup_terms_from_current_row)
        actions.addWidget(current_row_button)
        self._material_apply_button = ActionButton("应用到当前清单行", "primary")
        self._material_apply_button.setStyleSheet(
            "background:#059669; color:#fff; border:none; border-radius:11px; padding:0 14px;"
        )
        self._material_apply_button.clicked.connect(self._on_apply_material_lookup)
        self._material_apply_button.setEnabled(False)
        actions.addWidget(self._material_apply_button)
        actions.addStretch()
        panel_layout.addLayout(actions)

        self._material_lookup_table = QTableWidget(0, len(self.MATERIAL_LOOKUP_HEADERS))
        self._material_lookup_table.setHorizontalHeaderLabels(self.MATERIAL_LOOKUP_HEADERS)
        self._material_lookup_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self._material_lookup_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self._material_lookup_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._material_lookup_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._material_lookup_table.setAlternatingRowColors(True)
        self._material_lookup_table.setMinimumHeight(145)
        self._material_lookup_table.setMaximumHeight(210)
        self._material_lookup_table.setStyleSheet(
            "QTableWidget { background:#fff; border:1px solid #e2e8f0; border-radius:7px; gridline-color:#edf1f6; } "
            "QTableWidget::item { padding:6px; } "
            "QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:8px 7px; }"
        )
        install_long_text_tooltip(self._material_lookup_table)
        self._material_lookup_table.itemSelectionChanged.connect(self._update_material_lookup_controls)
        self._material_lookup_table.cellDoubleClicked.connect(lambda *_: self._on_apply_material_lookup())
        panel_layout.addWidget(self._material_lookup_table)
        layout.addWidget(panel)

    def _reset_table_columns(self, custom_headers: list[str]):
        self._custom_headers = list(custom_headers[:self.MAX_CUSTOM_COLUMNS])
        headers = [*self.CORE_HEADERS, *self._custom_headers]
        self._table.setColumnCount(len(headers))
        self._table.setHorizontalHeaderLabels(headers)
        widths = {
            self.COL_SEQ: 56, self.COL_CODE: 130, self.COL_NAME: 210,
            self.COL_SPEC: 145, self.COL_UNIT: 70, self.COL_QUANTITY: 95,
            self.COL_SOURCE: 250, self.COL_NOTES: 180,
        }
        for column in range(len(headers)):
            self._table.setColumnWidth(column, widths.get(column, 115))
            self._table.setColumnHidden(column, headers[column] in self._hidden_headers)

    def _rebuild_column_menu(self):
        self._columns_menu.clear()
        show_all = self._columns_menu.addAction("显示全部列")
        show_all.triggered.connect(self._show_all_columns)
        self._columns_menu.addSeparator()
        for column in range(self._table.columnCount()):
            header_item = self._table.horizontalHeaderItem(column)
            header = header_item.text() if header_item else f"第 {column + 1} 列"
            action = self._columns_menu.addAction(header)
            action.setCheckable(True)
            action.setChecked(not self._table.isColumnHidden(column))
            action.toggled.connect(
                lambda visible, label=header: self._set_column_visible(label, visible)
            )

    def _set_column_visible(self, header: str, visible: bool):
        for column in range(self._table.columnCount()):
            item = self._table.horizontalHeaderItem(column)
            if item and item.text() == header:
                self._table.setColumnHidden(column, not visible)
                break
        if visible:
            self._hidden_headers.discard(header)
        else:
            self._hidden_headers.add(header)
        set_settings({
            "quote_hidden_columns": json.dumps(
                sorted(self._hidden_headers), ensure_ascii=False,
            ),
        })

    def _show_all_columns(self):
        self._hidden_headers.clear()
        for column in range(self._table.columnCount()):
            self._table.setColumnHidden(column, False)
        set_settings({"quote_hidden_columns": "[]"})

    def _text_at(self, row: int, column: int) -> str:
        item = self._table.item(row, column)
        return item.text().strip() if item else ""

    def _number_at(self, row: int, column: int) -> float:
        text = self._text_at(row, column).replace(",", "")
        try:
            return float(text or 0)
        except ValueError:
            return 0.0

    def _set_calculated_value(self, row: int, column: int, value: float | None, decimals: int = 4):
        text = "" if value is None else f"{value:,.{decimals}f}"
        item = self._table.item(row, column) or QTableWidgetItem()
        item.setText(text)
        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        item.setToolTip("由费用计取条件自动联动计算")
        item.setBackground(QColor("#f1f5f9"))
        self._table.setItem(row, column, item)

    def _fee_settings(self) -> dict:
        return {
            "management_base": self._management_base_combo.currentData() or "direct",
            "management_rate": self._management_rate.value() / 100,
            "profit_base": self._profit_base_combo.currentData() or "direct_management",
            "profit_rate": self._profit_rate.value() / 100,
            "tax_rate": self._tax_rate.value() / 100,
        }

    @staticmethod
    def _base_amount(code: str, labor: float, material: float, machinery: float,
                     unallocated: float, management: float = 0.0) -> float:
        direct = labor + material + machinery + unallocated
        bases = {
            "labor": labor,
            "labor_machine": labor + machinery,
            "direct": direct,
            "labor_machine_management": labor + machinery + management,
            "direct_management": direct + management,
        }
        return bases.get(code, direct)

    def _calculate_unit_breakdown(self, labor: float, material: float,
                                  machinery: float, unallocated: float) -> tuple[float, float, float]:
        settings = self._fee_settings()
        management_base = self._base_amount(
            settings["management_base"], labor, material, machinery, unallocated,
        )
        management = management_base * settings["management_rate"]
        profit_base = self._base_amount(
            settings["profit_base"], labor, material, machinery, unallocated, management,
        )
        profit = profit_base * settings["profit_rate"]
        unit_price = labor + material + machinery + unallocated + management + profit
        return management, profit, unit_price

    def _unallocated_for_target(self, target_price: float, labor: float = 0.0,
                                material: float = 0.0, machinery: float = 0.0) -> float:
        _, _, base_price = self._calculate_unit_breakdown(labor, material, machinery, 0.0)
        _, _, one_more = self._calculate_unit_breakdown(labor, material, machinery, 1.0)
        slope = one_more - base_price
        if target_price <= base_price or slope <= 0:
            return 0.0
        return (target_price - base_price) / slope

    def _get_table_data(self) -> list:
        data = []
        for row_index in range(self._table.rowCount()):
            custom_fields = {
                header: self._text_at(row_index, len(self.CORE_HEADERS) + offset)
                for offset, header in enumerate(self._custom_headers)
            }
            data.append({
                "seq_no": row_index + 1,
                "item_code": self._text_at(row_index, self.COL_CODE),
                "item_name": self._text_at(row_index, self.COL_NAME),
                "spec": self._text_at(row_index, self.COL_SPEC),
                "unit": self._text_at(row_index, self.COL_UNIT),
                "quantity": self._text_at(row_index, self.COL_QUANTITY),
                "labor_unit_price": self._text_at(row_index, self.COL_LABOR),
                "material_unit_price": self._text_at(row_index, self.COL_MATERIAL),
                "machinery_unit_price": self._text_at(row_index, self.COL_MACHINERY),
                "unallocated_unit_price": self._text_at(row_index, self.COL_UNALLOCATED),
                "management_unit_price": self._text_at(row_index, self.COL_MANAGEMENT),
                "profit_unit_price": self._text_at(row_index, self.COL_PROFIT),
                "unit_price": self._text_at(row_index, self.COL_UNIT_PRICE),
                "total_price": self._text_at(row_index, self.COL_TOTAL),
                "price_source": self._text_at(row_index, self.COL_SOURCE) or "manual",
                "notes": self._text_at(row_index, self.COL_NOTES),
                "custom_fields": custom_fields,
            })
        return data

    def _on_add_row(self):
        row_index = self._table.rowCount()
        self._table.insertRow(row_index)
        values = [str(row_index + 1), "", "", "", "", "0.00"] + ["0.0000"] * 7 + ["0.00", "手动", ""]
        values.extend([""] * len(self._custom_headers))
        self._updating_table = True
        try:
            for column, value in enumerate(values):
                self._table.setItem(row_index, column, QTableWidgetItem(value))
        finally:
            self._updating_table = False
        self._recalculate_row(row_index)
        self._table.setCurrentCell(row_index, self.COL_CODE)
        self._refresh_summary()

    def _table_select_all(self):
        self._table.selectAll()

    def _table_clear_selection(self):
        self._table.clearSelection()

    def _on_duplicate_selected_rows(self):
        rows = sorted({index.row() for index in self._table.selectionModel().selectedRows()})
        if not rows:
            QMessageBox.information(self, "请选择清单", "请先选择需要复制的清单行。")
            return
        copied_rows = []
        for row_index in rows:
            copied_rows.append([
                self._table.item(row_index, column).clone()
                if self._table.item(row_index, column) else QTableWidgetItem()
                for column in range(self._table.columnCount())
            ])
        first_new_row = self._table.rowCount()
        self._updating_table = True
        try:
            for copied in copied_rows:
                row_index = self._table.rowCount()
                self._table.insertRow(row_index)
                for column, item in enumerate(copied):
                    self._table.setItem(row_index, column, item)
                self._table.item(row_index, self.COL_SEQ).setText(str(row_index + 1))
        finally:
            self._updating_table = False
        self._recalculate_all_rows()
        self._table.clearSelection()
        self._table.setCurrentCell(first_new_row, self.COL_NAME)

    def _on_delete_selected_rows(self):
        rows = sorted({index.row() for index in self._table.selectionModel().selectedRows()}, reverse=True)
        if not rows:
            QMessageBox.information(self, "请选择清单", "请先选择需要删除的清单行。")
            return
        reply = QMessageBox.question(
            self, "删除所选清单", f"确认删除已选择的 {len(rows)} 行吗？",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        self._updating_table = True
        try:
            for row_index in rows:
                self._table.removeRow(row_index)
            for row_index in range(self._table.rowCount()):
                self._table.setItem(row_index, self.COL_SEQ, QTableWidgetItem(str(row_index + 1)))
        finally:
            self._updating_table = False
        self._refresh_summary()

    def _on_table_item_changed(self, item: QTableWidgetItem):
        if self._updating_table or item.column() in self.CALCULATED_COLUMNS:
            return
        if item.column() in {
            self.COL_QUANTITY, self.COL_LABOR, self.COL_MATERIAL,
            self.COL_MACHINERY, self.COL_UNALLOCATED,
        }:
            self._recalculate_row(item.row())
            self._refresh_summary()

    def _recalculate_row(self, row_index: int):
        quantity = self._number_at(row_index, self.COL_QUANTITY)
        labor = self._number_at(row_index, self.COL_LABOR)
        material = self._number_at(row_index, self.COL_MATERIAL)
        machinery = self._number_at(row_index, self.COL_MACHINERY)
        unallocated = self._number_at(row_index, self.COL_UNALLOCATED)
        has_price_input = any(
            self._text_at(row_index, column)
            for column in (
                self.COL_LABOR,
                self.COL_MATERIAL,
                self.COL_MACHINERY,
                self.COL_UNALLOCATED,
            )
        )
        management, profit, unit_price = self._calculate_unit_breakdown(
            labor, material, machinery, unallocated,
        )
        self._updating_table = True
        try:
            if not has_price_input:
                self._set_calculated_value(row_index, self.COL_MANAGEMENT, None)
                self._set_calculated_value(row_index, self.COL_PROFIT, None)
                self._set_calculated_value(row_index, self.COL_UNIT_PRICE, None)
                self._set_calculated_value(row_index, self.COL_TOTAL, None, decimals=2)
            else:
                self._set_calculated_value(row_index, self.COL_MANAGEMENT, management)
                self._set_calculated_value(row_index, self.COL_PROFIT, profit)
                self._set_calculated_value(row_index, self.COL_UNIT_PRICE, unit_price)
                total = (
                    None
                    if not self._text_at(row_index, self.COL_QUANTITY)
                    else quantity * unit_price
                )
                self._set_calculated_value(row_index, self.COL_TOTAL, total, decimals=2)
        finally:
            self._updating_table = False

    def _recalculate_all_rows(self):
        for row_index in range(self._table.rowCount()):
            self._recalculate_row(row_index)
        self._refresh_summary()

    def _on_fee_settings_changed(self, *_args):
        if hasattr(self, "_table"):
            self._recalculate_all_rows()

    def _save_fee_settings(self):
        settings = self._fee_settings()
        set_settings({
            "quote_management_base": settings["management_base"],
            "quote_management_rate": str(self._management_rate.value()),
            "quote_profit_base": settings["profit_base"],
            "quote_profit_rate": str(self._profit_rate.value()),
            "quote_tax_rate": str(self._tax_rate.value()),
        })
        QMessageBox.information(self, "保存成功", "当前管理费、利润和税率条件已保存为项目报价默认值。")

    def _refresh_summary(self):
        values = {
            "人工费": 0.0, "材料费": 0.0, "机械费": 0.0,
            "未拆分费": 0.0, "管理费": 0.0, "利润": 0.0,
        }
        column_by_label = {
            "人工费": self.COL_LABOR, "材料费": self.COL_MATERIAL,
            "机械费": self.COL_MACHINERY, "未拆分费": self.COL_UNALLOCATED,
            "管理费": self.COL_MANAGEMENT, "利润": self.COL_PROFIT,
        }
        subtotal = 0.0
        for row_index in range(self._table.rowCount()):
            quantity = self._number_at(row_index, self.COL_QUANTITY)
            for label, column in column_by_label.items():
                values[label] += quantity * self._number_at(row_index, column)
            subtotal += self._number_at(row_index, self.COL_TOTAL)
        tax = subtotal * self._fee_settings()["tax_rate"]
        total_amount = subtotal + tax
        values["税金"] = tax
        for label, value in values.items():
            if label in self._summary_labels:
                self._summary_labels[label].setText(f"{value:,.2f}")
        self._current_summary = {**values, "税前合计": subtotal, "总造价": total_amount}
        self._total_val.setText(f"{total_amount:,.2f}")

    def _sync_lookup_fields_from_row(self, row_index: int):
        self._material_keyword_input.setText(self._text_at(row_index, self.COL_NAME))
        self._material_spec_input.setText(self._text_at(row_index, self.COL_SPEC))
        self._material_unit_input.setText(self._text_at(row_index, self.COL_UNIT))
        region = self._region_input.text().strip()
        if region:
            self._material_region_input.setText(region)
        period = self._period_input.text().strip()
        if period:
            self._material_period_input.setText(period)

    def _load_lookup_terms_from_current_row(self, *_args):
        row_index = self._table.currentRow()
        if row_index < 0:
            QMessageBox.information(self, "请选择清单", "请先选中要查询价格的清单行。")
            return
        self._sync_lookup_fields_from_row(row_index)
        self._material_lookup_count.setText("已载入当前清单行，点击查询")

    def _on_quote_cell_changed(self, current_row: int, *_args):
        if self._updating_table or current_row < 0:
            return
        self._sync_lookup_fields_from_row(current_row)

    def _on_query_material_price(self, allow_network: bool = True):
        keyword = self._material_keyword_input.text().strip()
        spec = self._material_spec_input.text().strip()
        if not keyword and not spec:
            row_index = self._table.currentRow()
            if row_index < 0:
                QMessageBox.information(self, "请输入材料", "请输入材料名称或规格，或先选择一条项目清单。")
                return
            self._sync_lookup_fields_from_row(row_index)
            keyword = self._material_keyword_input.text().strip()
            spec = self._material_spec_input.text().strip()
        if not keyword and not spec:
            QMessageBox.information(self, "请输入材料", "请输入材料名称或规格后再查询。")
            return

        region = self._material_region_input.text().strip()
        period = self._material_period_input.text().strip()
        unit = self._material_unit_input.text().strip()
        source_index = max(0, self._material_source_combo.currentIndex())
        trust_levels = self.MATERIAL_LOOKUP_SOURCES[source_index][1]
        session = get_session()
        try:
            rows = self._search_material_prices(
                session, keyword, spec, unit, region, period, trust_levels,
            )
        finally:
            session.close()
        self._material_lookup_rows = rows
        self._refresh_material_lookup()
        if rows:
            exact = sum(bool(row["region_match"]) for row in rows)
            self._material_lookup_count.setText(f"共 {len(rows)} 条，本地区 {exact} 条")
        else:
            self._material_lookup_count.setText("未找到已确认价格")
            self._material_apply_button.setEnabled(False)
            if allow_network and region:
                self._try_official_network_query(keyword, spec, region, period)

    @staticmethod
    def _search_material_prices(session, keyword: str, spec: str, unit: str,
                                region: str, period: str, trust_levels: list[str]):
        query = session.query(MaterialPrice).join(Material).join(Region).filter(
            MaterialPrice.is_confirmed.is_(True),
            MaterialPrice.is_withdrawn.is_(False),
            MaterialPrice.trust_level.in_(trust_levels),
        )
        if period:
            query = query.filter(MaterialPrice.period == period)
        regional = []
        if region:
            regional = (
                query.filter(Region.name == region)
                .order_by(MaterialPrice.period.desc(), MaterialPrice.updated_at.desc())
                .limit(3000)
                .all()
            )
        candidates = regional or (
            query.order_by(MaterialPrice.period.desc(), MaterialPrice.updated_at.desc())
            .limit(3000)
            .all()
        )

        target = f"{keyword} {spec}".strip().lower()
        keyword_lower = keyword.lower()
        spec_lower = spec.lower()
        rows = []
        for price in candidates:
            material_name = price.material.name or ""
            material_spec = price.spec or ""
            material_text = f"{material_name} {material_spec}".strip().lower()
            aliases = [
                alias.alias_name
                for alias in price.material.aliases
                if alias.alias_name
            ]
            alias_scores = [
                max(fuzz.WRatio(target, alias.lower()), fuzz.partial_ratio(target, alias.lower()))
                for alias in aliases
            ]
            score = max(
                [fuzz.WRatio(target, material_text), fuzz.partial_ratio(target, material_text), *alias_scores],
                default=0,
            )
            if keyword_lower and keyword_lower not in material_text:
                if not any(keyword_lower in alias.lower() for alias in aliases):
                    score -= 16
            if spec_lower and material_spec and spec_lower in material_spec:
                score += 8
            if unit and price.unit and unit == price.unit:
                score += 8
            if region and price.region_obj and price.region_obj.name == region:
                score += 7
            elif region:
                score -= 7
            if price.trust_level in {"official", "official_manual"}:
                score += 3
            if score < 40:
                continue
            rows.append({
                "price_id": price.id,
                "material_id": price.material_id,
                "material_name": material_name,
                "spec": material_spec,
                "unit": price.unit,
                "region": price.region_obj.name if price.region_obj else "",
                "region_match": bool(region and price.region_obj and price.region_obj.name == region),
                "period": price.period,
                "price": price.price,
                "price_basis": price.price_basis,
                "trust_level": price.trust_level,
                "source_type": price.source_type,
                "confidence": min(score, 100) / 100,
            })
        return sorted(rows, key=lambda row: (row["confidence"], row["region_match"]), reverse=True)[:30]

    @staticmethod
    def _official_source_plan(region_name: str):
        session = get_session()
        try:
            from src.official_sources_config import get_city_audit_status, get_city_source_config
            from src.utils import is_official_domain
            from src.subscription import ensure_working_city_sources

            region = session.query(Region).filter(Region.name == region_name).first()
            audit = get_city_audit_status(region_name)
            status = audit.get("status", "pending_adapter")
            sources = (
                session.query(OfficialSource)
                .filter(
                    OfficialSource.region_id == region.id,
                    OfficialSource.is_official.is_(True),
                    OfficialSource.is_active.is_(True),
                ).all()
                if region is not None else []
            )
            if status == "working" and not any(
                source.source_type == "api"
                and is_official_domain(source.url)
                for source in sources
            ):
                sources = ensure_working_city_sources(session, region_name)
            direct_ids = []
            login_required = False
            source_names = []
            for source in sources:
                if not is_official_domain(source.url):
                    continue
                config = get_city_source_config(region_name, source.url) or {}
                source_status = config.get("data_status") or status
                strategy = config.get("strategy") or source.source_type or ""
                if source_status == "working" and strategy == "api":
                    direct_ids.append(source.id)
                    source_names.append(display_source_name(source.name, source.url, source.source_type))
                elif source_status in {
                    "login_required", "membership_required", "browser_dynamic", "waf_blocked",
                } or strategy == "browser_login":
                    login_required = True
            return {
                "status": status,
                "direct_source_ids": direct_ids,
                "source_names": source_names,
                "login_required": login_required,
                "note": audit.get("note", ""),
            }
        finally:
            session.close()

    def _try_official_network_query(self, keyword: str, spec: str, region: str, period: str):
        if self._material_fetch_worker is not None:
            return
        plan = self._official_source_plan(region)
        if plan["direct_source_ids"]:
            self._material_lookup_count.setText(
                f"本地未找到，正在通过信息价管理抓取 {region} ..."
            )
            self._official_progress.setVisible(True)
            self._official_progress_text.setVisible(True)
            self._official_progress_text.setText(f"正在抓取 {region} 官方信息价...")
            keywords = [token for token in (keyword, spec) if token]
            self._material_fetch_worker = OfficialPriceUpdateWorker(
                plan["direct_source_ids"],
                period,
                self._specialty_combo.currentText(),
                keywords,
            )
            self._material_fetch_worker.progress_changed.connect(self._on_official_update_progress)
            self._material_fetch_worker.completed.connect(
                lambda result, k=keyword, s=spec, r=region, p=period:
                self._on_query_official_fetch_completed(k, s, r, p, result)
            )
            self._material_fetch_worker.start()
            return
        if plan["login_required"]:
            QMessageBox.information(
                self,
                "当前城市需要登录",
                f"{region} 的官方信息价需要登录、会员或浏览器验证。\n\n"
                "请前往“信息价管理 → 官方订阅 → 官方价抓取中心”完成授权，然后重新搜索。",
            )
            self.navigate_requested.emit("subscription")
            return
        QMessageBox.information(
            self,
            "暂无联网来源",
            f"{region} 当前没有可直接抓取的官方来源，请前往官方价抓取中心查看城市策略或输入用户网址。",
        )
        self.navigate_requested.emit("subscription")

    def _on_query_official_fetch_completed(
        self, keyword: str, spec: str, region: str, period: str, result: dict,
    ):
        self._material_fetch_worker = None
        self._official_progress.setVisible(False)
        self._official_progress_text.setVisible(False)
        if result.get("new_prices"):
            self._material_lookup_count.setText("信息价管理抓取完成，正在重新查询")
            self._on_query_material_price(allow_network=False)
        else:
            detail = (result.get("errors") or ["来源可访问，但没有发现符合条件的新价格"])[0]
            QMessageBox.information(
                self,
                "联网查询完成",
                f"{region} 未获得新的已入库价格。\n{detail}",
            )

    def _refresh_material_lookup(self):
        self._material_lookup_updating = True
        try:
            self._material_lookup_table.setRowCount(len(self._material_lookup_rows))
            for row_index, row in enumerate(self._material_lookup_rows):
                basis_label = {
                    "tax_inclusive": "含税",
                    "tax_exclusive": "除税",
                    "delivered": "到场/工地",
                    "ex_factory": "出厂",
                    "as_published": "按原文",
                }.get(row.get("price_basis"), row.get("price_basis") or "按原文")
                level_label = {
                    "official": "官方信息价",
                    "official_manual": "官方/手动",
                    "manual": "自有/手动",
                    "market_reference": "市场参考",
                }.get(row.get("trust_level"), row.get("trust_level") or "")
                status = "本地区" if row.get("region_match") else "其他地区候选"
                values = [
                    f"{row['confidence']:.0%}", row["material_name"], row["spec"], row["unit"],
                    row["region"], row["period"], f"{row['price']:,.4f}",
                    basis_label, level_label, status,
                ]
                for column, value in enumerate(values):
                    item = QTableWidgetItem(str(value))
                    confidence = row["confidence"]
                    if confidence >= 0.80:
                        item.setBackground(QColor("#dcfce7"))
                    elif confidence >= 0.60:
                        item.setBackground(QColor("#fef9c3"))
                    else:
                        item.setBackground(QColor("#fff7ed"))
                    self._material_lookup_table.setItem(row_index, column, item)
        finally:
            self._material_lookup_updating = False
        self._update_material_lookup_controls()

    def _update_material_lookup_controls(self):
        selected = self._material_lookup_table.currentRow()
        self._material_apply_button.setEnabled(
            selected >= 0 and self._table.currentRow() >= 0,
        )

    def _on_apply_material_lookup(self, *_args):
        quote_row = self._table.currentRow()
        lookup_row = self._material_lookup_table.currentRow()
        if quote_row < 0:
            QMessageBox.information(self, "请选择清单", "请先选中要写入价格的清单行。")
            return
        if lookup_row < 0 or lookup_row >= len(self._material_lookup_rows):
            QMessageBox.information(self, "请选择价格", "请先在查询结果中选择一条材料价格。")
            return
        reference = self._material_lookup_rows[lookup_row]
        basis_label = {
            "tax_inclusive": "含税",
            "tax_exclusive": "除税",
            "delivered": "到场/工地",
            "ex_factory": "出厂",
            "as_published": "按原文",
        }.get(reference.get("price_basis"), reference.get("price_basis") or "按原文")
        source = (
            f"{reference['material_name']} / {reference['region']} / {reference['period']} / "
            f"{basis_label} / 匹配度 {reference['confidence']:.0%}"
        )
        self._updating_table = True
        try:
            self._table.setItem(
                quote_row, self.COL_MATERIAL,
                QTableWidgetItem(f"{float(reference['price']):.4f}"),
            )
            if not self._text_at(quote_row, self.COL_UNIT) and reference.get("unit"):
                self._table.setItem(
                    quote_row, self.COL_UNIT,
                    QTableWidgetItem(reference["unit"]),
                )
            if not self._text_at(quote_row, self.COL_SPEC) and reference.get("spec"):
                self._table.setItem(
                    quote_row, self.COL_SPEC,
                    QTableWidgetItem(reference["spec"]),
                )
            self._table.setItem(
                quote_row, self.COL_SOURCE,
                QTableWidgetItem(source),
            )
        finally:
            self._updating_table = False
        self._recalculate_row(quote_row)
        self._refresh_summary()
        self.data_changed.emit()
        self._material_lookup_count.setText("已写入当前清单行")

    def _on_lookup_price(self):
        row_index = self._table.currentRow()
        if row_index < 0:
            QMessageBox.information(self, "请选择清单", "请先选中要查询价格的清单行。")
            return
        session = get_session()
        try:
            reference = self._lookup_reference(session, row_index)
            if not reference:
                QMessageBox.information(self, "未找到价格", "允许使用的价格库中没有达到匹配阈值的参考数据。")
                return
            self._apply_reference(row_index, reference)
            self._refresh_summary()
            QMessageBox.information(
                self, "已填入参考价",
                f"已填入 {reference['price']:,.2f} 元\n来源：{reference['source']}\n匹配度：{reference['confidence']:.0%}",
            )
        finally:
            session.close()

    def _on_batch_lookup(self):
        if self._table.rowCount() == 0:
            QMessageBox.information(self, "没有清单", "请先添加或导入清单。")
            return
        session = get_session()
        matched = 0
        source_counts = {}
        try:
            for row_index in range(self._table.rowCount()):
                reference = self._lookup_reference(session, row_index)
                if not reference:
                    self._table.setItem(row_index, self.COL_SOURCE, QTableWidgetItem("未匹配"))
                    continue
                self._apply_reference(row_index, reference)
                matched += 1
                source_counts[reference["source_type"]] = source_counts.get(reference["source_type"], 0) + 1
            self._refresh_summary()
        finally:
            session.close()
        labels = {"official": "官方地方价", "fixed": "固定清单价", "market": "市场参考价"}
        breakdown = "，".join(f"{labels.get(key, key)} {value} 条" for key, value in source_counts.items()) or "无"
        QMessageBox.information(
            self, "批量匹配完成",
            f"共 {self._table.rowCount()} 条，成功匹配 {matched} 条，未匹配 {self._table.rowCount() - matched} 条。\n{breakdown}\n\n每行“价格来源”列已记录实际采用的数据。",
        )

    def _on_update_official_prices(self):
        region_name = self._region_input.text().strip()
        if not region_name:
            QMessageBox.information(self, "请填写地区", "请先填写项目所在城市，再抓取官方价。")
            return
        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == region_name).first()
            if region is None:
                QMessageBox.information(self, "地区未配置", f"请先在“官方订阅”中为 {region_name} 查找或添加官方来源。")
                return
            from src.utils import is_official_domain
            from src.official_sources_config import get_city_audit_status, get_city_source_config
            sources = session.query(OfficialSource).filter(
                OfficialSource.region_id == region.id,
                OfficialSource.is_official.is_(True),
                OfficialSource.is_active.is_(True),
            ).all()
            audit = get_city_audit_status(region_name)
            source_infos = []
            for source in sources:
                if not is_official_domain(source.url):
                    continue
                config = get_city_source_config(region_name, source.url) or {}
                status = config.get("data_status") or audit.get("status", "pending_adapter")
                strategy = config.get("strategy") or source.source_type or ""
                login_statuses = {
                    "login_required", "membership_required", "browser_dynamic", "waf_blocked",
                }
                login_required = status in login_statuses or strategy == "browser_login"
                direct = status == "working" and strategy == "api"
                source_infos.append({
                    "id": source.id,
                    "name": display_source_name(source.name, source.url, source.source_type),
                    "direct": direct,
                    "login_required": login_required,
                    "status": status,
                    "strategy": strategy,
                    "last_result": source.last_result,
                })
        finally:
            session.close()
        if not source_infos:
            QMessageBox.information(self, "没有可用来源", f"{region_name} 尚未配置经过官方域名校验的来源。")
            return
        direct_source_ids = [info["id"] for info in source_infos if info["direct"]]

        dialog = QDialog(self)
        dialog.setWindowTitle("官方信息价来源")
        dialog.resize(760, 360)
        dialog_layout = QVBoxLayout(dialog)
        dialog_layout.setContentsMargins(16, 14, 16, 14)
        dialog_layout.setSpacing(10)
        summary = QLabel(
            f"{region_name} · {self._specialty_combo.currentText()} · "
            f"{self._period_input.text().strip() or '自动识别最新期数'}\n"
            "本次仅执行“可直接抓取”的官方来源；需要登录、会员或浏览器验证的来源不会自动执行。"
        )
        summary.setWordWrap(True)
        summary.setStyleSheet("color:#334155; font-size:12px;")
        dialog_layout.addWidget(summary)
        table = QTableWidget(0, 3)
        table.setHorizontalHeaderLabels(["官方来源", "当前状态", "本次抓取"])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        table.setSelectionMode(QTableWidget.NoSelection)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.setStyleSheet(
            "QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:8px; gridline-color:#edf1f6; } "
            "QTableWidget::item { padding:7px; } "
            "QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:8px; }"
        )
        status_labels = {
            "working": "可直接抓取",
            "login_required": "需登录",
            "membership_required": "需登录/会员",
            "browser_dynamic": "需浏览器验证",
            "waf_blocked": "存在访问限制",
            "pending_adapter": "待来源适配",
            "restricted": "访问受限",
        }
        for row_index, info in enumerate(source_infos):
            table.insertRow(row_index)
            table.setItem(row_index, 0, QTableWidgetItem(info["name"]))
            if info["direct"]:
                status_text = "可直接抓取"
                action = "是"
                color = QColor("#dcfce7")
            elif info["login_required"] or info["last_result"] == "restricted":
                status_text = "需登录/会员" if info["login_required"] else "访问受限，需授权"
                action = "否"
                color = QColor("#fff7ed")
            else:
                status_text = status_labels.get(info["status"], info["status"] or "待适配")
                action = "否"
                color = QColor("#f1f5f9")
            table.setItem(row_index, 1, QTableWidgetItem(status_text))
            table.setItem(row_index, 2, QTableWidgetItem(action))
            for column in range(3):
                table.item(row_index, column).setBackground(color)
        dialog_layout.addWidget(table, 1)
        note = QLabel(
            "登录/会员来源请在“信息价管理 → 来源配置”中完成授权后重新抓取；"
            "通用抓取不会绕过登录、验证码或会员权限。"
        )
        note.setWordWrap(True)
        note.setStyleSheet("color:#64748b; font-size:12px;")
        dialog_layout.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        ok_button = buttons.button(QDialogButtonBox.Ok)
        ok_button.setText("开始抓取")
        ok_button.setEnabled(bool(direct_source_ids))
        cancel_button = buttons.button(QDialogButtonBox.Cancel)
        cancel_button.setText("取消")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        dialog_layout.addWidget(buttons)
        if dialog.exec() != QDialog.Accepted or not direct_source_ids:
            return
        source_ids = direct_source_ids

        keywords = []
        seen = set()
        for row_index in range(self._table.rowCount()):
            text = " ".join(
                self._table.item(row_index, column).text()
                for column in (2, 3)
                if self._table.item(row_index, column)
            )
            for token in re.findall(r"[A-Za-z]+\d+[A-Za-z0-9.-]*|[\u4e00-\u9fff]{2,}", text):
                if token not in seen:
                    seen.add(token)
                    keywords.append(token)
                if len(keywords) >= 30:
                    break
            if len(keywords) >= 30:
                break

        self._official_update_btn.setEnabled(False)
        self._official_update_btn.setText("正在抓取...")
        self._official_update_worker = OfficialPriceUpdateWorker(
            source_ids,
            self._period_input.text().strip(),
            self._specialty_combo.currentText(),
            keywords,
        )
        self._official_update_worker.progress_changed.connect(self._on_official_update_progress)
        self._official_update_worker.completed.connect(self._on_official_prices_updated)
        self._official_progress.setValue(0)
        self._official_progress.setVisible(True)
        self._official_progress_text.setVisible(True)
        self._official_progress_text.setText("正在准备抓取，剩余时间正在估算...")
        self._official_update_worker.start()

    @staticmethod
    def _format_crawl_eta(seconds: int | None) -> str:
        if seconds is None:
            return "正在估算"
        if seconds < 60:
            return f"约 {seconds} 秒"
        minutes, remaining_seconds = divmod(seconds, 60)
        if minutes < 60:
            return f"约 {minutes} 分 {remaining_seconds} 秒"
        hours, remaining_minutes = divmod(minutes, 60)
        return f"约 {hours} 小时 {remaining_minutes} 分"

    def _on_official_update_progress(self, progress: dict):
        self._official_progress.setVisible(True)
        self._official_progress_text.setVisible(True)
        self._official_progress.setValue(int(progress.get("percent", 0)))
        self._official_progress_text.setText(
            f"第 {progress.get('source_index', 1)}/{progress.get('source_total', 1)} 个来源 · "
            f"{progress.get('stage', '')} · 网页 {progress.get('pages', 0)} · "
            f"附件 {progress.get('documents', 0)} · 剩余 {self._format_crawl_eta(progress.get('eta_seconds'))}"
        )

    def _on_official_prices_updated(self, result: dict):
        self._official_update_btn.setEnabled(True)
        self._official_update_btn.setText("官方价抓取中心")
        self._official_progress.setValue(100)
        self.data_changed.emit()
        count = result.get("new_prices", 0)
        self._official_progress_text.setText(
            f"抓取完成：有效价格 {count:,} 条，失败 {result.get('failed', 0)} 个来源。"
        )
        if count:
            QMessageBox.information(
                self,
                "官方价抓取完成",
                f"异常数据已自动清理，新增或更新 {count:,} 条官方价格并直接入库。",
            )
            return
        errors = result.get("errors", [])
        detail = errors[0] if errors else "已连接来源，但没有发现符合期数和专业条件的可解析表格。"
        QMessageBox.warning(self, "没有抓到新价格", detail)

    def _lookup_reference(self, session, row_index: int):
        item_name = self._table.item(row_index, 2).text().strip() if self._table.item(row_index, 2) else ""
        spec = self._table.item(row_index, 3).text().strip() if self._table.item(row_index, 3) else ""
        unit = self._table.item(row_index, 4).text().strip() if self._table.item(row_index, 4) else ""
        mode = self._pricing_source_combo.currentData()
        if mode == "official_only":
            order = ["official"]
        elif mode == "fixed_only":
            order = ["fixed"]
        elif mode == "all_sources":
            order = ["official", "fixed", "market"]
        else:
            order = ["official", "fixed"]
        for source_type in order:
            if source_type == "fixed":
                item, confidence = find_cost_item_reference(session, item_name, unit)
                if item:
                    component_total = (
                        (item.labor_cost or 0) + (item.material_cost or 0) +
                        (item.machinery_cost or 0) + (item.management_cost or 0) +
                        (item.profit or 0)
                    )
                    return {
                        "price": item.comprehensive_price,
                        "unit": item.unit,
                        "source_type": "fixed",
                        "labor_unit_price": item.labor_cost or 0,
                        "material_unit_price": item.material_cost or 0,
                        "machinery_unit_price": item.machinery_cost or 0,
                        "unallocated_unit_price": max((item.comprehensive_price or 0) - component_total, 0),
                        "source": f"固定清单库 / {item.data_source} / {item.item_name}",
                        "confidence": confidence,
                    }
            else:
                trust_levels = ["official", "official_manual"] if source_type == "official" else ["market_reference"]
                match = self._match_dynamic_price(session, item_name, spec, unit, trust_levels)
                if match:
                    price, confidence = match
                    region_name = price.region_obj.name if price.region_obj else ""
                    label = "官方地方信息价" if source_type == "official" else "市场参考价（非官方）"
                    return {
                        "price": price.price,
                        "unit": price.unit,
                        "source_type": source_type,
                        "material_unit_price": price.price,
                        "source": f"{label} / {region_name} / {price.period} / {price.material.name}",
                        "confidence": confidence,
                    }
        return None

    def _match_dynamic_price(self, session, item_name: str, spec: str, unit: str, trust_levels: list[str]):
        query = session.query(MaterialPrice).join(Material).join(Region).filter(
            MaterialPrice.is_confirmed.is_(True),
            MaterialPrice.trust_level.in_(trust_levels),
        )
        period = self._period_input.text().strip()
        if period:
            query = query.filter(MaterialPrice.period == period)
        region_name = self._region_input.text().strip()
        if region_name:
            regional = query.filter(Region.name == region_name).order_by(MaterialPrice.period.desc()).limit(1500).all()
            candidates = regional or query.order_by(MaterialPrice.period.desc()).limit(1500).all()
        else:
            candidates = query.order_by(MaterialPrice.period.desc()).limit(1500).all()
        target = f"{item_name} {spec}".strip()
        best = None
        best_score = 0
        for candidate in candidates:
            candidate_text = f"{candidate.material.name} {candidate.spec}".strip()
            score = fuzz.WRatio(target, candidate_text)
            if unit and candidate.unit == unit:
                score += 8
            if score > best_score:
                best = candidate
                best_score = score
        if best is None or best_score < 48:
            return None
        return best, min(best_score, 100) / 100

    def _apply_reference(self, row_index: int, reference: dict):
        self._updating_table = True
        try:
            if reference.get("source_type") == "fixed":
                values = {
                    self.COL_LABOR: reference.get("labor_unit_price", 0),
                    self.COL_MATERIAL: reference.get("material_unit_price", 0),
                    self.COL_MACHINERY: reference.get("machinery_unit_price", 0),
                    self.COL_UNALLOCATED: reference.get("unallocated_unit_price", 0),
                }
                if not any(values.values()):
                    values[self.COL_UNALLOCATED] = self._unallocated_for_target(reference["price"])
                for column, value in values.items():
                    self._table.setItem(row_index, column, QTableWidgetItem(f"{value:.4f}"))
            else:
                self._table.setItem(
                    row_index, self.COL_MATERIAL,
                    QTableWidgetItem(f"{reference.get('material_unit_price', reference['price']):.4f}"),
                )
            if not self._text_at(row_index, self.COL_UNIT) and reference.get("unit"):
                self._table.setItem(row_index, self.COL_UNIT, QTableWidgetItem(reference["unit"]))
            self._table.setItem(row_index, self.COL_SOURCE, QTableWidgetItem(reference["source"]))
        finally:
            self._updating_table = False
        self._recalculate_row(row_index)

    def _on_lock_snapshot(self):
        project_name = self._name_input.text().strip() or "未命名项目"
        region_name = self._region_input.text().strip() or "郑州"
        table_data = self._get_table_data()
        fee_settings = self._fee_settings()
        total_amount = self._current_summary.get("总造价", 0.0)

        def number(row, key):
            raw = str(row.get(key, "") or "").strip()
            if not raw:
                return None
            try:
                return float(raw.replace(",", ""))
            except (TypeError, ValueError):
                return 0.0

        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == region_name).first()
            try:
                active_project_id = int(get_setting("active_project_id", "0") or 0)
            except (TypeError, ValueError):
                active_project_id = 0
            project = session.query(Project).filter(Project.id == active_project_id).first()
            created_project = project is None
            if created_project:
                project = Project(name=project_name)
                session.add(project)
            project.name = project_name
            project.region_id = region.id if region else project.region_id
            project.status = "locked"
            project.locked_version = datetime.now().strftime("%Y-%m-%d %H:%M")
            project.total_amount = total_amount
            project.management_rate = fee_settings["management_rate"]
            project.management_base = fee_settings["management_base"]
            project.profit_rate = fee_settings["profit_rate"]
            project.profit_base = fee_settings["profit_base"]
            project.tax_rate = fee_settings["tax_rate"]
            session.flush()
            if not created_project:
                session.query(ProjectItem).filter(ProjectItem.project_id == project.id).delete(
                    synchronize_session=False,
                )
            for row in table_data:
                project_item = ProjectItem(
                    project_id=project.id,
                    seq_no=row["seq_no"],
                    item_code=row["item_code"],
                    item_name=row["item_name"],
                    spec=row["spec"],
                    unit=row["unit"],
                    quantity=number(row, "quantity"),
                    labor_unit_price=number(row, "labor_unit_price"),
                    material_unit_price=number(row, "material_unit_price"),
                    machinery_unit_price=number(row, "machinery_unit_price"),
                    unallocated_unit_price=number(row, "unallocated_unit_price"),
                    management_unit_price=number(row, "management_unit_price"),
                    profit_unit_price=number(row, "profit_unit_price"),
                    unit_price=number(row, "unit_price"),
                    total_price=number(row, "total_price"),
                    price_source=row.get("price_source", "manual"),
                    custom_data=json.dumps(row.get("custom_fields", {}), ensure_ascii=False),
                    notes=row.get("notes", ""),
                )
                session.add(project_item)
            snapshot = ProjectPriceSnapshot(
                project_id=project.id,
                version=project.locked_version,
                total_amount=total_amount,
                data_json=json.dumps({
                    "items": table_data,
                    "fee_settings": fee_settings,
                    "summary": self._current_summary,
                }, ensure_ascii=False),
                notes="项目报价锁定快照",
            )
            session.add(snapshot)
            write_audit(session, "create", "project_snapshot", detail=f"锁定项目快照: {project_name}")
            session.commit()
            if created_project:
                set_settings({"active_project_id": str(project.id)})
            self.data_changed.emit()
            QMessageBox.information(self, "快照已保存", f"项目「{project_name}」已锁定，历史记录会持久保存。")
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "保存失败", str(error))
        finally:
            session.close()

    def _on_export_quote(self):
        path, _ = QFileDialog.getSaveFileName(self, "导出报价", "项目报价.xlsx", "Excel 文件 (*.xlsx)")
        if not path:
            return
        try:
            from openpyxl import Workbook
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "项目报价"
            headers = [self._table.horizontalHeaderItem(col).text() for col in range(self._table.columnCount())]
            sheet.append(headers)
            for row_index in range(self._table.rowCount()):
                sheet.append([
                    self._table.item(row_index, col).text() if self._table.item(row_index, col) else ""
                    for col in range(self._table.columnCount())
                ])
            sheet.append([])
            fee_settings = self._fee_settings()
            sheet.append([
                "计费条件", "管理费基础", self._management_base_combo.currentText(),
                "管理费率", self._management_rate.value() / 100,
                "利润基础", self._profit_base_combo.currentText(),
                "利润率", self._profit_rate.value() / 100,
                "税率", fee_settings["tax_rate"],
            ])
            for label in ("人工费", "材料费", "机械费", "未拆分费", "管理费", "利润", "税金"):
                sheet.append([label, self._current_summary.get(label, 0.0)])
            sheet.append(["总造价", self._current_summary.get("总造价", 0.0)])
            workbook.save(path)
            QMessageBox.information(self, "导出完成", f"报价已导出到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))

    def _on_import_excel(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入清单", "", "Excel 文件 (*.xlsx *.xls)")
        if not path:
            return
        workbook = None
        try:
            from openpyxl import load_workbook
            workbook = load_workbook(path, read_only=True, data_only=True)
            worksheet = workbook.active
            rows = worksheet.iter_rows(values_only=True)
            headers = next(rows, None)
            if not headers:
                QMessageBox.warning(self, "导入失败", "Excel 没有数据。")
                return
            valid_headers = [
                (index, str(value).strip())
                for index, value in enumerate(headers)
                if value is not None and str(value).strip()
            ]
            if len(valid_headers) > self.MAX_IMPORT_COLUMNS:
                QMessageBox.warning(
                    self, "表头列数过多",
                    f"当前表格有 {len(valid_headers)} 个有效表头，最多允许 {self.MAX_IMPORT_COLUMNS} 个。"
                    "请删除无关列后重新导入。",
                )
                return
            header_index = {}
            for index, label in valid_headers:
                header_index.setdefault(label, index)

            aliases = {
                self.COL_SEQ: ("序号",),
                self.COL_CODE: ("清单编号", "定额编号", "数据ID", "项目编号"),
                self.COL_NAME: ("清单名称", "项目名称", "单项名称", "材料名称", "工程名称"),
                self.COL_SPEC: ("规格", "项目特征", "规格型号", "型号", "项目特征及工作内容"),
                self.COL_UNIT: ("单位",),
                self.COL_QUANTITY: ("工程量", "数量"),
                self.COL_LABOR: ("人工费单价", "人工费"),
                self.COL_MATERIAL: ("材料费单价", "材料费"),
                self.COL_MACHINERY: ("机械费单价", "机械费"),
                self.COL_UNALLOCATED: ("未拆分直接费单价", "未拆分费", "其他直接费"),
                self.COL_MANAGEMENT: ("管理费单价", "管理费"),
                self.COL_PROFIT: ("利润单价", "利润"),
                self.COL_UNIT_PRICE: ("综合单价", "单价"),
                self.COL_TOTAL: ("合价", "合计"),
                self.COL_SOURCE: ("价格来源", "数据来源"),
                self.COL_NOTES: ("备注",),
            }
            recognized_labels = {label for names in aliases.values() for label in names}
            custom_columns = [(index, label) for index, label in valid_headers if label not in recognized_labels]
            if len(custom_columns) > self.MAX_CUSTOM_COLUMNS:
                QMessageBox.warning(
                    self, "自定义列过多",
                    f"识别到 {len(custom_columns)} 个非计价自定义列，最多允许保留 {self.MAX_CUSTOM_COLUMNS} 个。"
                    "请精简无关表头后重新导入。",
                )
                return

            unique_custom_columns = []
            used_custom_headers = set()
            for source_index, label in custom_columns:
                unique_label = label
                suffix = 2
                while unique_label in used_custom_headers:
                    unique_label = f"{label}_{suffix}"
                    suffix += 1
                used_custom_headers.add(unique_label)
                unique_custom_columns.append((source_index, unique_label))

            def cell(row, *names, default=""):
                for name in names:
                    column = header_index.get(name)
                    if column is not None and column < len(row) and row[column] is not None:
                        return row[column]
                return default

            def number(value):
                if value in (None, ""):
                    return 0.0
                try:
                    return float(str(value).replace(",", ""))
                except (TypeError, ValueError):
                    return 0.0

            def numeric_or_blank(value, decimals: int = 4):
                if value in (None, ""):
                    return ""
                return f"{number(value):,.{decimals}f}"

            self._table.setRowCount(0)
            self._reset_table_columns([label for _, label in unique_custom_columns])
            imported = 0
            self._updating_table = True
            for row in rows:
                if not any(value not in (None, "") for value in row):
                    continue
                labor_value = cell(row, *aliases[self.COL_LABOR], default=None)
                material_value = cell(row, *aliases[self.COL_MATERIAL], default=None)
                machinery_value = cell(row, *aliases[self.COL_MACHINERY], default=None)
                quantity_value = cell(row, *aliases[self.COL_QUANTITY], default=None)
                target_value = cell(row, *aliases[self.COL_UNIT_PRICE], default=None)
                unallocated_value = cell(row, *aliases[self.COL_UNALLOCATED], default=None)
                labor = number(labor_value)
                material = number(material_value)
                machinery = number(machinery_value)
                target_price = number(target_value)
                unallocated = (
                    number(unallocated_value)
                    if unallocated_value not in (None, "")
                    else self._unallocated_for_target(target_price, labor, material, machinery)
                    if target_value not in (None, "")
                    else 0.0
                )
                unallocated_display = (
                    unallocated
                    if unallocated_value not in (None, "")
                    or target_value not in (None, "")
                    else None
                )
                row_index = imported
                self._table.insertRow(row_index)
                values = [
                    str(row_index + 1),
                    str(cell(row, *aliases[self.COL_CODE])),
                    str(cell(row, *aliases[self.COL_NAME])),
                    str(cell(row, *aliases[self.COL_SPEC])),
                    str(cell(row, *aliases[self.COL_UNIT])),
                    numeric_or_blank(quantity_value, 2),
                    numeric_or_blank(labor_value, 4),
                    numeric_or_blank(material_value, 4),
                    numeric_or_blank(machinery_value, 4),
                    numeric_or_blank(unallocated_display, 4),
                    "", "", "", "",
                    str(cell(row, *aliases[self.COL_SOURCE], default="导入数据")),
                    str(cell(row, *aliases[self.COL_NOTES])),
                ]
                values.extend(
                    str(row[source_index]) if source_index < len(row) and row[source_index] is not None else ""
                    for source_index, _ in unique_custom_columns
                )
                for column, value in enumerate(values):
                    self._table.setItem(row_index, column, QTableWidgetItem(value))
                imported += 1
            self._updating_table = False
            self._recalculate_all_rows()
            QMessageBox.information(
                self, "导入完成",
                f"已导入 {imported} 条清单，保留 {len(unique_custom_columns)} 个原表自定义列。",
            )
        except Exception as error:
            self._updating_table = False
            QMessageBox.warning(self, "导入失败", str(error))
        finally:
            if workbook is not None:
                workbook.close()

    def _on_ai_suggest(self):
        if not ai.is_available:
            QMessageBox.information(
                self, "AI 未配置",
                "请在「系统设置 > DeepSeek 配置」中填写 API Key 后使用 AI 辅助报价功能。\n\n"
                "未接入 AI 时，软件可正常手动编辑报价。"
            )
            return
        data = self._get_table_data()
        if not data:
            QMessageBox.warning(self, "无数据", "请先添加清单项。")
            return
        region = self._region_input.text().strip() or "郑州"
        reply = QMessageBox.question(
            self, "AI 辅助报价",
            f"将使用 DeepSeek AI 为 {len(data)} 条清单建议综合单价。\n"
            f"地区：{region}\n\n"
            f"AI 参考数据仅作建议，不会自动覆盖现有价格。是否继续？",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        self._ai_progress.setVisible(True)
        self._ai_suggest_btn.setEnabled(False)
        self._ai_worker = AISuggestWorker(data, region)
        self._ai_worker.finished.connect(self._on_suggest_result)
        self._ai_worker.error.connect(self._on_ai_error)
        self._ai_worker.start()

    def _on_suggest_result(self, result: list):
        self._ai_progress.setVisible(False)
        self._ai_suggest_btn.setEnabled(True)
        if not result or all(r.get("suggested_price") is None for r in result):
            QMessageBox.information(self, "AI 提示", "AI 未找到可参考的价格数据。请手动填写价格。")
            return
        lines = []
        for r in result:
            if r.get("suggested_price") is not None:
                lines.append(
                    f"#{r.get('seq_no','?')} {r.get('unit','')}: "
                    f"建议 {r.get('suggested_price','?')} 元 | "
                    f"参考: {r.get('reference','')} "
                    f"(可信度 {r.get('confidence',0):.0%})"
                )
        msg = "\n".join(lines[:15])
        if len(lines) > 15:
            msg += f"\n... 共 {len(lines)} 条"
        reply = QMessageBox.question(
            self, "AI 报价建议",
            f"AI 给出的综合单价建议：\n\n{msg}\n\n是否将建议价格填入表格？\n"
            f"（建议价写入未拆分直接费，管理费和利润继续按当前条件联动）",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self._updating_table = True
            for r in result:
                idx = r.get("seq_no", 0) - 1
                if 0 <= idx < self._table.rowCount() and r.get("suggested_price") is not None:
                    target = float(r["suggested_price"])
                    unallocated = self._unallocated_for_target(
                        target,
                        self._number_at(idx, self.COL_LABOR),
                        self._number_at(idx, self.COL_MATERIAL),
                        self._number_at(idx, self.COL_MACHINERY),
                    )
                    self._table.setItem(idx, self.COL_UNALLOCATED, QTableWidgetItem(f"{unallocated:.4f}"))
                    self._table.setItem(idx, self.COL_SOURCE, QTableWidgetItem("DeepSeek AI 建议（需人工复核）"))
            self._updating_table = False
            self._recalculate_all_rows()

    def _on_ai_validate(self):
        if not ai.is_available:
            QMessageBox.information(
                self, "AI 未配置",
                "请在「系统设置 > DeepSeek 配置」中填写 API Key 后使用 AI 报价验证功能。"
            )
            return
        data = self._get_table_data()
        if not data:
            QMessageBox.warning(self, "无数据", "请先添加清单项并填写价格。")
            return
        region = self._region_input.text().strip() or "郑州"
        self._ai_progress.setVisible(True)
        self._ai_validate_btn.setEnabled(False)
        self._ai_worker = AIValidateWorker(data, region)
        self._ai_worker.finished.connect(self._on_validate_result)
        self._ai_worker.error.connect(self._on_ai_error)
        self._ai_worker.start()

    def _on_validate_result(self, result: dict):
        self._ai_progress.setVisible(False)
        self._ai_validate_btn.setEnabled(True)
        if not result:
            return
        score = result.get("overall_score", "N/A")
        risk = result.get("risk_level", "unknown")
        risk_map = {"low": "低风险", "medium": "中等风险", "high": "高风险", "unknown": "未知"}
        warnings = result.get("warnings", [])
        suggestions = result.get("suggestions", [])
        item_analysis = result.get("item_analysis", [])
        report = f"报价合理性评分：{score}/100\n"
        report += f"风险等级：{risk_map.get(risk, risk)}\n\n"
        if warnings:
            report += "警告：\n"
            for w in warnings[:5]:
                report += f"  - {w}\n"
            report += "\n"
        if suggestions:
            report += "建议：\n"
            for s in suggestions[:5]:
                report += f"  - {s}\n"
            report += "\n"
        if item_analysis:
            report += "逐项分析：\n"
            for ia in item_analysis[:8]:
                ok = "合理" if ia.get("price_reasonable") else "存疑"
                report += f"  {ia.get('item_name','?')}: {ok}"
                if ia.get("comment"):
                    report += f" ({ia['comment']})"
                report += "\n"
        dlg = QDialog(self)
        dlg.setWindowTitle("AI 报价验证报告")
        dlg.resize(600, 500)
        dl = QVBoxLayout(dlg)
        te = QTextEdit()
        te.setReadOnly(True)
        te.setText(report)
        te.setStyleSheet("font-size:13px; padding:12px;")
        dl.addWidget(te)
        btns = QDialogButtonBox(QDialogButtonBox.Ok)
        btns.accepted.connect(dlg.accept)
        dl.addWidget(btns)
        dlg.exec()

    def _on_ai_error(self, err: str):
        self._ai_progress.setVisible(False)
        self._ai_suggest_btn.setEnabled(True)
        self._ai_validate_btn.setEnabled(True)
        QMessageBox.warning(self, "AI 调用失败", f"AI 服务暂时不可用：{err}\n\n请检查网络或 API Key 配置。")


class PriceLinkageTab(QWidget):
    """项目清单与已确认信息价之间的材料费价格联动。"""
    data_changed = Signal()

    FILE_PREVIEW_HEADERS = [
        "Excel行号", "表1单项名称", "表2单项名称",
        "表1工程量", "表2工程量", "工程量差额",
        "表1综合单价", "表2综合单价", "综合单价差额",
        "表1合计", "表2合计", "合计差额",
        "对比结果", "差异字段",
    ]
    DATABASE_PREVIEW_HEADERS = [
        "序号", "清单编号", "清单名称", "规格", "单位", "工程量",
        "当前价格基数", "数据库最新材料价", "价格差额", "变化率", "预计造价变化",
        "数据库来源", "匹配度", "状态", "说明",
    ]

    def __init__(self):
        super().__init__()
        self._table_a = None
        self._table_b = None
        self._comparison = None
        self._database_rows = []
        self._database_source_name = ""
        self._result_mode = "file"
        self._project_quote_tab = None
        self._quota_match_tab = None
        self._setup_ui()

    def set_project_quote_tab(self, quote_tab):
        self._project_quote_tab = quote_tab

    def set_quota_match_tab(self, quota_match_tab):
        self._quota_match_tab = quota_match_tab

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        ai_row = QHBoxLayout()
        ai_row.addWidget(QLabel("AI 辅助状态："))
        ai_row.addWidget(AIBadge())
        ai_row.addStretch()
        layout.addLayout(ai_row)

        layout.addWidget(SectionHeader("造价变化联动"))
        desc = QLabel(
            "以当前项目清单为基准，逐行匹配已确认信息价；匹配成功后可统一写入当前项目报价，"
            "未匹配和跨地区候选只提示，不自动覆盖。"
        )
        desc.setStyleSheet("color:#667085; font-size:13px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)

        controls = QFrame()
        controls.setObjectName("price-linkage-controls")
        controls.setStyleSheet(
            "QFrame#price-linkage-controls { background:#ffffff; border:1px solid #dbe3ef; "
            "border-left:4px solid #059669; border-radius:8px; padding:4px; } "
            "QFrame#price-linkage-controls QLabel { background:transparent; border:none; } "
            "QFrame#price-linkage-controls QLineEdit { border:1px solid #cbd5e1; "
            "border-radius:6px; padding:7px 10px; background:#ffffff; } "
        )
        controls_layout = QVBoxLayout(controls)
        controls_layout.setContentsMargins(12, 10, 12, 10)
        controls_layout.setSpacing(8)

        mode_row = QHBoxLayout()
        mode_row.setSpacing(8)
        mode_row.addWidget(QLabel("对比模式"))
        self._mode_combo = QComboBox()
        self._mode_combo.addItem("项目清单 ↔ 造价数据库", "database")
        self._mode_combo.addItem("表1 ↔ 表2", "file")
        self._mode_combo.currentIndexChanged.connect(self._on_mode_changed)
        mode_row.addWidget(self._mode_combo)
        self._selection_hint = QLabel("未选中项目清单时对比全部；选中后仅对比选中行")
        self._selection_hint.setStyleSheet("color:#64748b; font-size:11px;")
        mode_row.addWidget(self._selection_hint)
        mode_row.addStretch()
        controls_layout.addLayout(mode_row)

        self._database_controls = QWidget()
        database_row = QHBoxLayout(self._database_controls)
        database_row.setContentsMargins(0, 0, 0, 0)
        database_row.setSpacing(8)
        database_row.addWidget(QLabel("地区"))
        self._db_region_input = QLineEdit("郑州")
        self._db_region_input.setFixedWidth(135)
        self._db_region_input.setPlaceholderText("如 郑州")
        database_row.addWidget(self._db_region_input)
        database_row.addWidget(QLabel("期数"))
        self._db_period_input = QLineEdit(datetime.now().strftime("%Y-%m"))
        self._db_period_input.setFixedWidth(115)
        self._db_period_input.setPlaceholderText("留空取最新")
        database_row.addWidget(self._db_period_input)
        self._load_project_button = ActionButton("读取当前项目清单", "primary")
        self._load_project_button.clicked.connect(self._on_compare_current_project)
        self._load_project_button.setToolTip("项目清单报价页未选中时对比全部，选中若干行时只对比选中行")
        database_row.addWidget(self._load_project_button)
        self._import_database_button = ActionButton("导入 Excel 清单", "default")
        self._import_database_button.setToolTip("导入外部清单生成联动候选，应用前不会修改数据库")
        self._import_database_button.clicked.connect(self._on_import_database_table)
        database_row.addWidget(self._import_database_button)
        self._apply_linkage_button = ActionButton("应用到当前项目报价", "primary")
        self._apply_linkage_button.setStyleSheet(
            "background:#059669; color:#fff; border:none; border-radius:11px; padding:0 14px;"
        )
        self._apply_linkage_button.clicked.connect(self._on_apply_linkage)
        database_row.addWidget(self._apply_linkage_button)
        self._export_button = ActionButton("导出联动结果", "default")
        self._export_button.clicked.connect(self._on_export)
        database_row.addWidget(self._export_button)
        database_row.addStretch()
        controls_layout.addWidget(self._database_controls)

        self._file_controls = QWidget()
        file_row = QHBoxLayout(self._file_controls)
        file_row.setContentsMargins(0, 0, 0, 0)
        file_row.setSpacing(8)
        file_row.addWidget(QLabel("表1（基准）"))
        self._table_a_label = QLabel("未导入")
        self._table_a_label.setMinimumWidth(230)
        self._table_a_label.setWordWrap(True)
        self._table_a_label.setStyleSheet(
            "color:#475569; background:#fff; border:1px solid #dbe3ef; border-radius:6px; padding:6px 8px;"
        )
        file_row.addWidget(self._table_a_label, 1)
        import_a = ActionButton("导入表1", "default")
        import_a.clicked.connect(lambda: self._on_import_table("a"))
        file_row.addWidget(import_a)
        file_row.addWidget(QLabel("表2（对比）"))
        self._table_b_label = QLabel("未导入")
        self._table_b_label.setMinimumWidth(230)
        self._table_b_label.setWordWrap(True)
        self._table_b_label.setStyleSheet(
            "color:#475569; background:#fff; border:1px solid #dbe3ef; border-radius:6px; padding:6px 8px;"
        )
        file_row.addWidget(self._table_b_label, 1)
        import_b = ActionButton("导入表2", "default")
        import_b.clicked.connect(lambda: self._on_import_table("b"))
        file_row.addWidget(import_b)
        self._compare_button = ActionButton("开始对比", "primary")
        self._compare_button.clicked.connect(self._on_compare)
        file_row.addWidget(self._compare_button)
        controls_layout.addWidget(self._file_controls)

        status_row = QHBoxLayout()
        self._database_source_label = QLabel("当前数据源：尚未读取")
        self._database_source_label.setStyleSheet("color:#64748b; font-size:12px;")
        status_row.addWidget(self._database_source_label)
        status_row.addStretch()
        self._summary = QLabel("点击“读取当前项目清单”开始联动。")
        self._summary.setStyleSheet("color:#475569; font-size:12px;")
        self._summary.setWordWrap(True)
        status_row.addWidget(self._summary, 1)
        controls_layout.addLayout(status_row)
        layout.addWidget(controls)

        self._table = QTableWidget()
        self._table.setColumnCount(len(self.DATABASE_PREVIEW_HEADERS))
        self._table.setHorizontalHeaderLabels(self.DATABASE_PREVIEW_HEADERS)
        for column in range(len(self.DATABASE_PREVIEW_HEADERS)):
            self._table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(len(self.DATABASE_PREVIEW_HEADERS) - 1, QHeaderView.Stretch)
        self._table.setAlternatingRowColors(True)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setStyleSheet(
            "QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } "
            "QTableWidget::item { padding:8px; } "
            "QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }"
        )
        install_long_text_tooltip(self._table)
        layout.addWidget(self._table, 1)
        self._on_mode_changed()
        self._update_controls()

    def _on_mode_changed(self, *_args):
        mode = self._mode_combo.currentData() or "database"
        database_mode = mode == "database"
        self._database_controls.setVisible(database_mode)
        self._file_controls.setVisible(not database_mode)
        self._table.setRowCount(0)
        if database_mode:
            self._comparison = None
            self._database_source_label.setText("当前数据源：尚未读取")
            self._summary.setText("项目清单报价页未选中时对比全部；选中后仅对比选中行。")
        else:
            self._database_rows = []
            self._result_mode = "file"
            self._database_source_label.setText("当前模式：表1 / 表2 外部文件对比")
            self._summary.setText("请分别导入表1和表2后开始对比。")
        self._update_controls()

    def refresh_data(self):
        if self._result_mode == "database" and self._database_rows:
            self._refresh_database_preview()
        elif self._comparison is not None:
            self._refresh_preview()
        else:
            self._update_controls()

    def _on_import_table(self, side: str):
        path, _ = QFileDialog.getOpenFileName(
            self,
            f"导入表{'1' if side == 'a' else '2'}",
            "",
            "Excel 文件 (*.xlsx *.xls)",
        )
        if not path:
            return
        try:
            from src.price_comparison import load_comparison_table

            table = load_comparison_table(path)
            if side == "a":
                self._table_a = table
                self._table_a_label.setText(f"{table.file_name}\n{table.sheet_name} · {table.max_row} 行 × {table.max_column} 列")
                self._table_a_label.setToolTip(table.path)
            else:
                self._table_b = table
                self._table_b_label.setText(f"{table.file_name}\n{table.sheet_name} · {table.max_row} 行 × {table.max_column} 列")
                self._table_b_label.setToolTip(table.path)
            self._comparison = None
            self._database_rows = []
            self._result_mode = "file"
            self._table.setRowCount(0)
            self._summary.setText("两张表都已导入后，可点击“开始对比”。" if self._table_a and self._table_b else "请继续导入另一张表。")
            self._update_controls()
            if self._table_a and self._table_b:
                self._on_compare()
        except Exception as error:
            QMessageBox.warning(self, "导入失败", str(error))

    def _on_compare(self):
        if not self._table_a or not self._table_b:
            QMessageBox.information(self, "材料不足", "请先分别导入表1和表2。")
            return
        try:
            from src.price_comparison import compare_tables

            self._comparison = compare_tables(self._table_a, self._table_b)
            self._database_rows = []
            self._result_mode = "file"
            self._database_source_label.setText(
                f"表1：{self._table_a.file_name}；表2：{self._table_b.file_name}"
            )
            self._refresh_preview()
            self._update_controls()
        except Exception as error:
            self._comparison = None
            QMessageBox.warning(self, "对比失败", str(error))

    def _quota_match_items(self):
        tab = self._quota_match_tab
        rows = list(tab._rows or [])
        selected_rows = sorted({
            index.row()
            for index in tab._table.selectionModel().selectedRows()
            if 0 <= index.row() < len(rows)
        })
        if selected_rows:
            chosen = selected_rows
            note = f"选中 {len(chosen)} 行"
        else:
            chosen = list(range(len(rows)))
            note = "全部清单"
        items = []
        for quota_row_index in chosen:
            row = rows[quota_row_index]
            name = str(row.get("name") or "").strip()
            if not name:
                continue
            material_price = self._numeric_or_zero(row.get("material"))
            unit_price = (
                material_price
                if material_price
                else self._numeric_or_zero(row.get("comprehensive_price"))
            )
            items.append({
                "seq_no": row.get("seq", quota_row_index + 1),
                "item_code": row.get("code", ""),
                "item_name": name,
                "spec": row.get("feature", ""),
                "unit": row.get("unit", ""),
                "quantity": row.get("quantity", "") or 0,
                "unit_price": unit_price,
                "total_price": "",
                "table_row": None,
                "quota_row_index": quota_row_index,
            })
        return items, note

    def _on_compare_current_project(self):
        items = []
        region = self._db_region_input.text().strip()
        period = self._db_period_input.text().strip()
        source_name = "当前项目报价页清单"
        if self._quota_match_tab is not None and self._quota_match_tab._rows:
            quota_items, selection_note = self._quota_match_items()
            items = quota_items
            if self._project_quote_tab is not None:
                region = self._project_quote_tab._region_input.text().strip() or region
                period = self._project_quote_tab._period_input.text().strip() or period
            source_name = f"匹配定额库结果（{selection_note}）"
        if self._project_quote_tab is not None:
            if not items:
                quote = self._project_quote_tab
                table_data = quote._get_table_data()
                selected_rows = sorted({
                    index.row()
                    for index in quote._table.selectionModel().selectedRows()
                })
                selected_rows = [
                    row_index
                    for row_index in selected_rows
                    if 0 <= row_index < len(table_data)
                ]
                if selected_rows:
                    row_items = [
                        (row_index, table_data[row_index])
                        for row_index in selected_rows
                    ]
                    selection_note = f"选中 {len(row_items)} 行"
                else:
                    row_items = list(enumerate(table_data))
                    selection_note = "全部清单"
                items = []
                for table_row, row in row_items:
                    if not str(row.get("item_name", "")).strip():
                        continue
                    comparison_row = dict(row)
                    material_price = self._numeric_or_zero(row.get("material_unit_price"))
                    if material_price:
                        comparison_row["unit_price"] = material_price
                    comparison_row["table_row"] = table_row
                    items.append(comparison_row)
                region = quote._region_input.text().strip() or region
                period = quote._period_input.text().strip() or period
                source_name = f"当前项目报价页清单（{selection_note}，优先对比材料费单价）"
        if not items:
            session = get_session()
            try:
                try:
                    active_project_id = int(get_setting("active_project_id", "0") or 0)
                except (TypeError, ValueError):
                    active_project_id = 0
                project_query = session.query(Project)
                if active_project_id:
                    project = project_query.filter(Project.id == active_project_id).first()
                else:
                    project = project_query.order_by(Project.updated_at.desc(), Project.id.desc()).first()
                if project:
                    items = []
                    quote_row_count = (
                        self._project_quote_tab._table.rowCount()
                        if self._project_quote_tab is not None else 0
                    )
                    for item in project.items:
                        if not item.item_name:
                            continue
                        table_row = item.seq_no - 1
                        if not 0 <= table_row < quote_row_count:
                            table_row = None
                        items.append({
                            "seq_no": item.seq_no,
                            "item_code": item.item_code,
                            "item_name": item.item_name,
                            "spec": item.spec,
                            "unit": item.unit,
                            "quantity": item.quantity,
                            "unit_price": item.material_unit_price or item.unit_price,
                            "total_price": item.total_price,
                            "table_row": table_row,
                            "project_item_id": item.id,
                            "labor_unit_price": item.labor_unit_price,
                            "machinery_unit_price": item.machinery_unit_price,
                            "unallocated_unit_price": item.unallocated_unit_price,
                            "management_unit_price": item.management_unit_price,
                            "profit_unit_price": item.profit_unit_price,
                        })
                    project_region = session.query(Region).filter(Region.id == project.region_id).first()
                    region = region or (project_region.name if project_region else "")
                    if not period and project.pricing_date:
                        period_match = re.match(r"(\d{4})[-/](\d{1,2})", project.pricing_date)
                        if period_match:
                            period = f"{period_match.group(1)}-{int(period_match.group(2)):02d}"
                    source_name = project.name
            finally:
                session.close()
        if not items:
            QMessageBox.information(self, "没有项目清单", "项目报价页没有清单行，也没有已保存项目可用于对比。")
            return
        self._db_region_input.setText(region)
        self._db_period_input.setText(period)
        self._database_source_label.setText(f"当前数据源：{source_name}")
        self._run_database_comparison(items, region, period, source_name)

    @staticmethod
    def _numeric_or_zero(value):
        try:
            return float(str(value).replace(",", "") or 0)
        except (TypeError, ValueError):
            return 0.0

    def _on_import_database_table(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "导入清单并对比价格库",
            "",
            "Excel 文件 (*.xlsx *.xls)",
        )
        if not path:
            return
        try:
            from src.price_comparison import load_comparison_table

            source_table = load_comparison_table(path)
            items = self._source_table_items(source_table)
            if not items:
                raise ValueError("未识别到包含单项名称和价格/工程量的清单行")
            region = self._db_region_input.text().strip()
            period = self._db_period_input.text().strip()
            self._database_source_label.setText(f"造价数据库对比表：{source_table.file_name}")
            self._run_database_comparison(items, region, period, source_table.file_name)
        except Exception as error:
            QMessageBox.warning(self, "导入并对比失败", str(error))

    @staticmethod
    def _source_table_items(source_table):
        from src.price_comparison import display_value, numeric_value

        def find_column(*keywords, fallback=None):
            for index, label in enumerate(source_table.column_labels):
                if any(keyword in label for keyword in keywords):
                    return index
            return fallback

        name_column = find_column("单项名称", "项目名称", "材料名称", "材料", fallback=2)
        code_column = find_column("定额编号", "清单编号", "项目编号", fallback=1)
        spec_column = find_column("规格", "项目特征", "型号")
        unit_column = find_column("单位", fallback=3)
        quantity_column = find_column("工程量", "数量", fallback=4)
        price_column = find_column("综合单价", "信息价", "单价", "价格", fallback=5)
        total_column = find_column("合计", "合价", fallback=6)
        ignored_names = {"序号", "定额编号", "单项名称", "项目名称", "单位", "工程量", "综合单价", "合计", "总计"}
        items = []
        for row_index, values in enumerate(source_table.rows, start=1):
            get = lambda column: values[column] if column is not None and column < len(values) else None
            name = display_value(get(name_column))
            if not name or name in ignored_names or name.startswith(("项目名称：", "金额单位：")):
                continue
            quantity = numeric_value(get(quantity_column))
            old_price = numeric_value(get(price_column))
            total_price = numeric_value(get(total_column))
            if quantity is None and old_price is None and total_price is None:
                continue
            items.append({
                "seq_no": row_index,
                "item_code": display_value(get(code_column)),
                "item_name": name,
                "spec": display_value(get(spec_column)),
                "unit": display_value(get(unit_column)),
                "quantity": quantity or 0.0,
                "unit_price": old_price or 0.0,
                "total_price": total_price or 0.0,
            })
        return items

    @staticmethod
    def _find_database_price(session, item_name, spec, unit, region, period):
        from sqlalchemy import or_
        from src.price_comparison import numeric_value

        allowed = ["official", "official_manual", "manual", "手动"]
        base_query = session.query(MaterialPrice).join(Material).join(Region).filter(
            MaterialPrice.is_confirmed.is_(True),
            MaterialPrice.is_withdrawn.is_(False),
            or_(MaterialPrice.trust_level.in_(allowed), MaterialPrice.source_type.in_(["official", "manual"])),
        )
        if period:
            base_query = base_query.filter(MaterialPrice.period == period)
        regional = base_query.filter(Region.name == region).order_by(MaterialPrice.period.desc()).limit(3000).all() if region else []
        candidates = regional or base_query.order_by(MaterialPrice.period.desc()).limit(3000).all()
        target = f"{item_name} {spec}".strip()
        best = None
        best_score = 0
        for candidate in candidates:
            candidate_text = f"{candidate.material.name} {candidate.spec}".strip()
            score = fuzz.WRatio(target, candidate_text)
            if unit and candidate.unit == unit:
                score += 8
            if score > best_score:
                best = candidate
                best_score = score
        if best is None or best_score < 48:
            return None
        return best, min(best_score, 100) / 100, bool(region and not regional)

    def _run_database_comparison(self, items, region, period, source_name):
        from src.price_comparison import numeric_value

        session = get_session()
        rows = []
        try:
            for item in items:
                old_price = numeric_value(item.get("unit_price"))
                quantity = numeric_value(item.get("quantity")) or 0.0
                match = self._find_database_price(
                    session,
                    str(item.get("item_name", "")).strip(),
                    str(item.get("spec", "")).strip(),
                    str(item.get("unit", "")).strip(),
                    region,
                    period,
                )
                new_price = None
                confidence = None
                source = ""
                note = "价格库未找到达到匹配阈值的地方官方价或自有导入价"
                status = "未匹配"
                if match:
                    price, confidence, used_fallback = match
                    new_price = price.price
                    source_label = "自有导入/手动" if price.trust_level != "official" or price.source_type == "manual" else "地方官方"
                    basis_label = {
                        "tax_inclusive": "含税",
                        "tax_exclusive": "除税",
                        "delivered": "到场",
                        "ex_factory": "出厂",
                    }.get(price.price_basis, price.price_basis or "原文")
                    source = f"{source_label} / {price.region_obj.name} / {price.period} / {basis_label} / {price.material.name}"
                    note = "本地区匹配" if not used_fallback else "本地区无匹配，使用其他地区同名价格"
                    status = "已匹配"
                    price_id = price.id
                    material_name = price.material.name
                    price_spec = price.spec
                    price_region = price.region_obj.name if price.region_obj else ""
                    price_period = price.period
                    price_basis = price.price_basis
                    trust_level = price.trust_level
                else:
                    price_id = None
                    material_name = ""
                    price_spec = ""
                    price_region = ""
                    price_period = ""
                    price_basis = ""
                    trust_level = ""
                price_diff = new_price - old_price if new_price is not None and old_price is not None else None
                change_rate = price_diff / old_price if price_diff is not None and old_price else None
                estimated_change = quantity * price_diff if price_diff is not None else None
                rows.append({
                    "seq_no": item.get("seq_no", len(rows) + 1),
                    "item_code": item.get("item_code", ""),
                    "item_name": item.get("item_name", ""),
                    "spec": item.get("spec", ""),
                    "unit": item.get("unit", ""),
                    "quantity": quantity,
                    "old_price": old_price,
                    "new_price": new_price,
                    "price_diff": price_diff,
                    "change_rate": change_rate,
                    "estimated_change": estimated_change,
                    "source": source,
                    "confidence": confidence,
                    "status": status,
                    "note": note,
                    "applied": False,
                    "table_row": item.get("table_row"),
                    "quota_row_index": item.get("quota_row_index"),
                    "project_item_id": item.get("project_item_id"),
                    "price_id": price_id,
                    "material_name": material_name,
                    "price_spec": price_spec,
                    "price_region": price_region,
                    "price_period": price_period,
                    "price_basis": price_basis,
                    "trust_level": trust_level,
                })
        finally:
            session.close()
        self._comparison = None
        self._database_rows = rows
        self._database_source_name = source_name
        self._result_mode = "database"
        self._refresh_database_preview()
        self._update_controls()

    def _target_quote_row(self, row: dict):
        if self._project_quote_tab is None:
            return None
        table_row = row.get("table_row")
        row_count = self._project_quote_tab._table.rowCount()
        if isinstance(table_row, int) and 0 <= table_row < row_count:
            return table_row
        code = str(row.get("item_code", "")).strip()
        name = str(row.get("item_name", "")).strip()
        spec = str(row.get("spec", "")).strip()
        for row_index in range(row_count):
            table_code = self._project_quote_tab._text_at(row_index, self._project_quote_tab.COL_CODE)
            table_name = self._project_quote_tab._text_at(row_index, self._project_quote_tab.COL_NAME)
            table_spec = self._project_quote_tab._text_at(row_index, self._project_quote_tab.COL_SPEC)
            if code and table_code == code:
                return row_index
            if name and fuzz.WRatio(name, table_name) >= 92:
                if not spec or not table_spec or fuzz.WRatio(spec, table_spec) >= 88:
                    return row_index
        return None

    def _apply_linkage_to_quote(self, rows: list[dict]):
        if self._project_quote_tab is None:
            return 0
        quote = self._project_quote_tab
        applied = 0
        quote._updating_table = True
        try:
            for row in rows:
                if row.get("status") != "已匹配" or row.get("new_price") is None:
                    continue
                target_row = self._target_quote_row(row)
                if target_row is None:
                    row["note"] = "未找到对应的当前项目报价行"
                    continue
                row["table_row"] = target_row
                source = row.get("source", "")
                quote._table.setItem(
                    target_row,
                    quote.COL_MATERIAL,
                    QTableWidgetItem(f"{float(row['new_price']):.4f}"),
                )
                if not quote._text_at(target_row, quote.COL_UNIT) and row.get("unit"):
                    quote._table.setItem(
                        target_row,
                        quote.COL_UNIT,
                        QTableWidgetItem(row["unit"]),
                    )
                if not quote._text_at(target_row, quote.COL_SPEC) and row.get("price_spec"):
                    quote._table.setItem(
                        target_row,
                        quote.COL_SPEC,
                        QTableWidgetItem(row["price_spec"]),
                    )
                quote._table.setItem(
                    target_row,
                    quote.COL_SOURCE,
                    QTableWidgetItem(f"造价变化联动 / {source}"),
                )
                row["applied"] = True
                row["status"] = "已应用"
                row["note"] = "已写入当前项目报价并重新计算"
                applied += 1
        finally:
            quote._updating_table = False
        quote._recalculate_all_rows()
        quote._refresh_summary()
        quote.data_changed.emit()
        return applied

    def _apply_linkage_to_database(self, rows: list[dict]):
        try:
            active_project_id = int(get_setting("active_project_id", "0") or 0)
        except (TypeError, ValueError):
            active_project_id = 0
        session = get_session()
        try:
            project = session.query(Project).filter(Project.id == active_project_id).first() if active_project_id else None
            if project is None:
                return 0
            item_ids = {
                int(row["project_item_id"])
                for row in rows
                if row.get("project_item_id") is not None
            }
            if not item_ids:
                return 0
            items = {
                item.id: item
                for item in session.query(ProjectItem).filter(ProjectItem.id.in_(item_ids)).all()
            }
            applied = 0
            for row in rows:
                if row.get("status") != "已匹配" or row.get("new_price") is None:
                    continue
                item = items.get(row.get("project_item_id"))
                if item is None:
                    continue
                labor = item.labor_unit_price or 0
                material = float(row["new_price"])
                machinery = item.machinery_unit_price or 0
                unallocated = item.unallocated_unit_price or 0
                management_base = {
                    "labor": labor,
                    "labor_machine": labor + machinery,
                    "direct": labor + material + machinery + unallocated,
                }.get(project.management_base or "direct", labor + material + machinery + unallocated)
                management = management_base * (project.management_rate or 0)
                profit_base = {
                    "labor": labor,
                    "labor_machine": labor + machinery,
                    "direct": labor + material + machinery + unallocated,
                    "labor_machine_management": labor + machinery + management,
                    "direct_management": labor + material + machinery + unallocated + management,
                }.get(project.profit_base or "direct_management", labor + material + machinery + unallocated + management)
                profit = profit_base * (project.profit_rate or 0)
                unit_price = labor + material + machinery + unallocated + management + profit
                item.material_unit_price = material
                if not item.unit and row.get("unit"):
                    item.unit = row["unit"]
                item.management_unit_price = management
                item.profit_unit_price = profit
                item.unit_price = unit_price
                item.total_price = (item.quantity or 0) * unit_price
                item.price_source = "info_price_linkage"
                item.notes = f"{item.notes}\n价格联动：{row.get('source', '')}".strip()
                row["applied"] = True
                row["status"] = "已应用"
                row["note"] = "已写入企业参考定额表并重新计算"
                applied += 1
            write_audit(
                session,
                "update",
                "project_price_linkage",
                detail=f"联动更新项目 {project.id} 材料费 {applied} 行",
            )
            session.commit()
            return applied
        except Exception as error:
            session.rollback()
            QMessageBox.warning(self, "数据库写入失败", str(error))
            return 0
        finally:
            session.close()

    def _on_apply_linkage(self):
        pending_rows = [
            row
            for row in self._database_rows
            if row.get("status") == "已匹配" and row.get("new_price") is not None
        ]
        if not pending_rows:
            QMessageBox.information(self, "没有可应用价格", "当前没有达到阈值且尚未应用的匹配结果。")
            return
        estimated_change = sum(row.get("estimated_change") or 0 for row in pending_rows)
        reply = QMessageBox.question(
            self,
            "应用造价变化联动",
            f"将把 {len(pending_rows)} 行匹配成功的材料价格写入当前项目报价并重新计算，"
            f"预计材料费影响 {estimated_change:+,.2f} 元。\n\n"
            "只更新材料费单价，不新增或删除定额，不修改人工费、机械费和人材机含量；"
            "未匹配和跨地区候选不会被覆盖。是否继续？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        quote_applied = self._apply_linkage_to_quote(pending_rows)
        database_pending = [
            row
            for row in pending_rows
            if row.get("status") == "已匹配" and row.get("project_item_id") is not None
        ]
        database_applied = self._apply_linkage_to_database(database_pending)
        applied = quote_applied + database_applied
        self._refresh_database_preview()
        self._update_controls()
        self._summary.setText(
            f"已应用 {applied} 行：项目报价 {quote_applied} 行，项目数据库 {database_applied} 行；"
            f"其余行保持为候选或未匹配状态。"
        )
        if applied:
            self.data_changed.emit() if hasattr(self, "data_changed") else None
            QMessageBox.information(self, "联动完成", f"已将 {applied} 行匹配价格写入项目。请人工复核价格口径和单位。")
        else:
            QMessageBox.information(self, "未写入", "未找到可对应的项目报价行，匹配结果仍保留在联动预览中。")

    def _refresh_database_preview(self):
        from src.price_comparison import display_value

        self._table.setColumnCount(len(self.DATABASE_PREVIEW_HEADERS))
        self._table.setHorizontalHeaderLabels(self.DATABASE_PREVIEW_HEADERS)
        for column in range(len(self.DATABASE_PREVIEW_HEADERS)):
            self._table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(len(self.DATABASE_PREVIEW_HEADERS) - 1, QHeaderView.Stretch)
        self._table.setRowCount(len(self._database_rows))
        for row_index, row in enumerate(self._database_rows):
            rate = row.get("change_rate")
            confidence = row.get("confidence")
            values = [
                str(row.get("seq_no", row_index + 1)), row.get("item_code", ""), row.get("item_name", ""),
                row.get("spec", ""), row.get("unit", ""), self._format_amount(row.get("quantity")),
                self._format_amount(row.get("old_price")), self._format_amount(row.get("new_price")),
                self._format_amount(row.get("price_diff")), f"{rate:+.2%}" if rate is not None else "",
                self._format_amount(row.get("estimated_change")), row.get("source", ""),
                f"{confidence:.0%}" if confidence is not None else "", row.get("status", ""), row.get("note", ""),
            ]
            for column, value in enumerate(values):
                item = QTableWidgetItem(display_value(value))
                status = row.get("status")
                if status == "已应用":
                    item.setBackground(QColor("#dcfce7"))
                elif status == "已匹配":
                    item.setBackground(QColor("#eff6ff"))
                else:
                    item.setBackground(QColor("#fff7ed"))
                self._table.setItem(row_index, column, item)
        old_total = sum((row.get("quantity") or 0) * (row.get("old_price") or 0) for row in self._database_rows)
        estimated = sum(row.get("estimated_change") or 0 for row in self._database_rows)
        matched = sum(row.get("status") in {"已匹配", "已应用"} for row in self._database_rows)
        applied = sum(row.get("status") == "已应用" for row in self._database_rows)
        self._summary.setText(
            f"联动结果：共 {len(self._database_rows)} 行，匹配 {matched} 行，已应用 {applied} 行，"
            f"未匹配 {len(self._database_rows) - matched} 行；预计材料费变化 {estimated:+,.2f} 元。"
        )

    @staticmethod
    def _format_amount(value):
        if value is None:
            return ""
        return f"{float(value):,.2f}"

    def _refresh_preview(self):
        result = self._comparison
        if result is None:
            self._table.setRowCount(0)
            return

        from src.price_comparison import display_value

        self._table.setColumnCount(len(self.FILE_PREVIEW_HEADERS))
        self._table.setHorizontalHeaderLabels(self.FILE_PREVIEW_HEADERS)
        for column in range(len(self.FILE_PREVIEW_HEADERS)):
            self._table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeToContents)
        self._table.horizontalHeader().setSectionResizeMode(len(self.FILE_PREVIEW_HEADERS) - 1, QHeaderView.Stretch)

        def column_for(label: str, fallback: int) -> int:
            return result.numeric_columns.get(label, fallback)

        def value(row, values, label: str, fallback: int) -> str:
            column = column_for(label, fallback)
            return display_value(values[column]) if column < len(values) else ""

        def difference(row, label: str) -> str:
            number = row.numeric_diffs.get(label)
            if number is None:
                return ""
            if abs(number - round(number)) < 1e-9:
                return str(int(round(number)))
            return f"{number:.6f}".rstrip("0").rstrip(".")

        name_column = next((index for index, label in enumerate(result.column_labels) if "单项名称" in label), 2)
        self._table.setRowCount(len(result.rows))
        for row_index, comparison_row in enumerate(result.rows):
            values = [
                str(comparison_row.excel_row),
                display_value(comparison_row.values_a[name_column]),
                display_value(comparison_row.values_b[name_column]),
                value(comparison_row, comparison_row.values_a, "工程量", 4),
                value(comparison_row, comparison_row.values_b, "工程量", 4),
                difference(comparison_row, "工程量"),
                value(comparison_row, comparison_row.values_a, "综合单价", 5),
                value(comparison_row, comparison_row.values_b, "综合单价", 5),
                difference(comparison_row, "综合单价"),
                value(comparison_row, comparison_row.values_a, "合计", 6),
                value(comparison_row, comparison_row.values_b, "合计", 6),
                difference(comparison_row, "合计"),
                "完全一致" if comparison_row.equal else "存在差异",
                "无" if comparison_row.equal else "、".join(comparison_row.diff_fields),
            ]
            for column, text in enumerate(values):
                item = QTableWidgetItem(text)
                if not comparison_row.equal:
                    item.setBackground(QColor("#fff7ed"))
                self._table.setItem(row_index, column, item)
        self._summary.setText(
            f"共对比 {len(result.rows)} 行：完全一致 {result.equal_rows} 行，存在差异 {result.different_rows} 行，"
            f"差异单元格 {result.diff_cells} 个。差额均为表2 - 表1。"
        )

    def _on_export(self):
        if self._result_mode == "database" and self._database_rows:
            default_name = "当前清单_造价变化联动.xlsx"
            dialog_title = "导出造价变化联动结果"
        elif self._comparison is not None:
            default_name = "工程施工费预算表_表3-1_逐行对比.xlsx"
            dialog_title = "导出表1/表2对比结果"
        else:
            QMessageBox.information(self, "暂无对比结果", "请先完成表1/表2对比，或执行价格库一键对比。")
            return
        path, _ = QFileDialog.getSaveFileName(
            self,
            dialog_title,
            default_name,
            "Excel 文件 (*.xlsx)",
        )
        if not path:
            return
        try:
            if self._result_mode == "database" and self._database_rows:
                from src.price_comparison import export_database_comparison

                export_database_comparison(
                    self._database_rows,
                    path,
                    title="当前项目清单造价变化联动",
                    region=self._db_region_input.text().strip(),
                    period=self._db_period_input.text().strip(),
                    source_name=self._database_source_name,
                )
            else:
                from src.price_comparison import export_comparison

                export_comparison(self._comparison, path)
            QMessageBox.information(self, "导出完成", f"对比结果已导出到：\n{path}")
        except Exception as error:
            QMessageBox.warning(self, "导出失败", str(error))

    def _on_clear(self):
        self._table_a = None
        self._table_b = None
        self._comparison = None
        self._database_rows = []
        self._database_source_name = ""
        self._result_mode = "file"
        self._database_source_label.setText("当前数据源：尚未读取")
        self._summary.setText("点击“读取当前项目清单”开始联动。")
        self._table.setRowCount(0)
        self._update_controls()

    def _update_controls(self):
        database_mode = (self._mode_combo.currentData() or "database") == "database"
        self._load_project_button.setEnabled(database_mode)
        self._import_database_button.setEnabled(database_mode)
        self._apply_linkage_button.setEnabled(
            database_mode
            and any(
                row.get("status") == "已匹配" and row.get("new_price") is not None
                for row in self._database_rows
            )
        )
        self._compare_button.setEnabled(
            not database_mode and self._table_a is not None and self._table_b is not None
        )
        self._export_button.setEnabled(
            (not database_mode and self._comparison is not None)
            or (database_mode and bool(self._database_rows))
        )


class ProjectSnapshotTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        layout.setSpacing(12)

        layout.addWidget(SectionHeader("项目价格快照"))
        desc = QLabel("记录每次项目报价锁定时的完整价格数据，支持版本对比和恢复。")
        desc.setStyleSheet("color:#667085; font-size:13px;")
        layout.addWidget(desc)

        self._table = QTableWidget()
        self._table.setColumnCount(5)
        self._table.setHorizontalHeaderLabels(["项目", "快照版本", "锁定价期", "总造价", "快照时间"])
        self._table.horizontalHeader().setStretchLastSection(True)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(
            "QTableWidget { background:#fff; border:1px solid #edf1f6; border-radius:14px; gridline-color:#edf1f6; } "
            "QTableWidget::item { padding:8px; } "
            "QHeaderView::section { background:#f8fafc; color:#667085; font-weight:bold; border:none; padding:10px 8px; }"
        )
        install_long_text_tooltip(self._table)
        self._empty = QLabel("暂无项目快照。请先在项目报价页面中锁定价格版本。")
        self._empty.setStyleSheet("color:#94a3b8; font-size:13px;")
        self._empty.setAlignment(Qt.AlignCenter)
        layout.addWidget(self._empty)
        layout.addWidget(self._table, 1)
        self.refresh_data()

    def refresh_data(self):
        session = get_session()
        try:
            snapshots = session.query(ProjectPriceSnapshot).order_by(ProjectPriceSnapshot.created_at.desc()).limit(500).all()
            self._empty.setVisible(not snapshots)
            self._table.setRowCount(len(snapshots))
            for row, snapshot in enumerate(snapshots):
                project = session.query(Project).filter(Project.id == snapshot.project_id).first()
                values = [
                    project.name if project else "", snapshot.version,
                    project.locked_version if project else "", f"{snapshot.total_amount:,.2f}",
                    snapshot.created_at.strftime("%Y-%m-%d %H:%M"),
                ]
                for column, value in enumerate(values):
                    self._table.setItem(row, column, QTableWidgetItem(value))
        finally:
            session.close()
