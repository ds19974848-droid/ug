﻿"""软件授权页面：查看本机机器码并激活授权。"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QVBoxLayout,
    QWidget,
)

from src.license_service import (
    activate_license,
    get_active_license_state,
    get_machine_code,
    revoke_local_license,
)
from src.ui.widgets import ActionButton, StatusBadge


class LicenseManagementTab(QWidget):
    def __init__(self):
        super().__init__()
        self._setup_ui()
        self.refresh_data()

    def _setup_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 20, 28, 28)
        outer.setSpacing(18)

        page_header = QHBoxLayout()
        title = QLabel("软件授权")
        title.setStyleSheet("font-size:22px; font-weight:700; color:#0f172a;")
        subtitle = QLabel("激活本机后可正常使用软件")
        subtitle.setStyleSheet("color:#64748b; font-size:13px;")
        page_header.addWidget(title)
        page_header.addStretch()
        page_header.addWidget(subtitle)
        outer.addLayout(page_header)

        contact = QLabel("获取授权码加V：13362385093，可以帮助安装 Codex，一起开发进步。")
        contact.setWordWrap(True)
        contact.setTextInteractionFlags(Qt.TextSelectableByMouse)
        contact.setStyleSheet(
            "color:#dc2626; font-size:18px; font-weight:700;"
            "background:#fef2f2; border:1px solid #fecaca;"
            "border-radius:10px; padding:12px 14px;"
        )
        outer.addWidget(contact)

        status_card = QFrame()
        status_card.setObjectName("licenseStatusCard")
        status_card.setStyleSheet(
            "#licenseStatusCard { background:#ffffff; border:1px solid #e5eaf2; border-radius:16px; }"
        )
        status_layout = QVBoxLayout(status_card)
        status_layout.setContentsMargins(24, 22, 24, 22)
        status_layout.setSpacing(16)

        status_header = QHBoxLayout()
        status_label = QLabel("当前授权状态")
        status_label.setStyleSheet("font-size:14px; font-weight:600; color:#334155;")
        self._status_badge = StatusBadge("未激活", "error")
        status_header.addWidget(status_label)
        status_header.addStretch()
        status_header.addWidget(self._status_badge)
        status_layout.addLayout(status_header)

        machine_title = QLabel("本机机器码")
        machine_title.setStyleSheet("font-size:13px; font-weight:600; color:#334155;")
        status_layout.addWidget(machine_title)

        self._machine_code = QLineEdit()
        self._machine_code.setReadOnly(True)
        self._machine_code.setStyleSheet(
            "QLineEdit { border:1px solid #d7e0ea; border-radius:10px; padding:11px 14px;"
            "background:#f8fafc; color:#0f172a; font-family:Consolas; font-size:16px; }"
            "QLineEdit:focus { border-color:#0f766e; }"
        )
        machine_row = QHBoxLayout()
        machine_row.setSpacing(10)
        machine_row.addWidget(self._machine_code, 1)
        copy_btn = ActionButton("复制机器码", "default")
        copy_btn.setMinimumHeight(42)
        copy_btn.clicked.connect(self._copy_machine_code)
        machine_row.addWidget(copy_btn)
        status_layout.addLayout(machine_row)

        self._license_summary = QLabel("")
        self._license_summary.setWordWrap(True)
        self._license_summary.setStyleSheet("color:#475569; font-size:13px;")
        status_layout.addWidget(self._license_summary)
        outer.addWidget(status_card)

        activation_card = QFrame()
        activation_card.setObjectName("licenseActivationCard")
        activation_card.setStyleSheet(
            "#licenseActivationCard { background:#ffffff; border:1px solid #e5eaf2; border-radius:16px; }"
        )
        activation_layout = QVBoxLayout(activation_card)
        activation_layout.setContentsMargins(24, 22, 24, 22)
        activation_layout.setSpacing(16)

        activation_header = QLabel("激活本机")
        activation_header.setStyleSheet("font-size:14px; font-weight:600; color:#334155;")
        activation_layout.addWidget(activation_header)

        hint = QLabel("请将机器码发给授权管理员，取得激活码后粘贴到下方。")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#64748b; font-size:13px;")
        activation_layout.addWidget(hint)

        self._activation_input = QLineEdit()
        self._activation_input.setPlaceholderText("粘贴授权管理工具生成的激活码")
        self._activation_input.setStyleSheet(
            "QLineEdit { border:1px solid #d7e0ea; border-radius:10px; padding:11px 14px;"
            "font-family:Consolas; font-size:14px; background:#ffffff; }"
            "QLineEdit:focus { border-color:#0f766e; }"
        )
        self._activation_input.returnPressed.connect(self._activate)
        activation_layout.addWidget(self._activation_input)

        action_row = QHBoxLayout()
        action_row.addStretch()
        revoke_btn = ActionButton("解除本机授权", "warn")
        revoke_btn.clicked.connect(self._revoke_local)
        activate_btn = ActionButton("立即激活", "primary")
        activate_btn.setMinimumWidth(120)
        activate_btn.setMinimumHeight(42)
        activate_btn.clicked.connect(self._activate)
        action_row.addWidget(revoke_btn)
        action_row.addWidget(activate_btn)
        activation_layout.addLayout(action_row)
        outer.addWidget(activation_card)
        outer.addStretch()

    def _copy_machine_code(self):
        code = self._machine_code.text().strip()
        if not code:
            QMessageBox.information(self, "没有内容", "当前没有可复制的机器码。")
            return
        QApplication.clipboard().setText(code)
        QMessageBox.information(self, "已复制", "机器码已复制，可直接粘贴发送给授权管理员。")

    def refresh_data(self):
        self._machine_code.setText(get_machine_code())
        state = get_active_license_state()
        if state.get("valid"):
            self._status_badge.setText("已授权")
            self._status_badge.setStyleSheet(
                "background:#dcfce7; color:#15803d; border-radius:12px; padding:4px 12px;"
            )
            expire = state.get("expire_date") or "永久"
            days = state.get("days_left")
            remaining = "永久使用" if days is None or days < 0 else f"剩余 {days} 天"
            self._license_summary.setText(
                f"授权对象：{state.get('recipient') or '未填写'}    到期日期：{expire}    {remaining}"
            )
            self._license_summary.setStyleSheet("color:#15803d; font-size:13px;")
        else:
            self._status_badge.setText("未授权")
            self._status_badge.setStyleSheet(
                "background:#fee2e2; color:#dc2626; border-radius:12px; padding:4px 12px;"
            )
            self._license_summary.setText(state.get("message") or "当前尚未激活，请粘贴授权码激活。")
            self._license_summary.setStyleSheet("color:#dc2626; font-size:13px;")

    def _activate(self):
        code = self._activation_input.text().strip()
        if not code:
            QMessageBox.information(self, "请输入授权码", "请先粘贴由授权管理工具生成的激活码。")
            return
        result = activate_license(code)
        if result.get("ok"):
            QMessageBox.information(self, "激活成功", result.get("message"))
            self._activation_input.clear()
            self.refresh_data()
        else:
            QMessageBox.warning(self, "激活失败", result.get("message"))

    def _revoke_local(self):
        state = get_active_license_state()
        if not state.get("valid"):
            QMessageBox.information(self, "无需操作", "当前本机尚未授权。")
            return
        reply = QMessageBox.question(
            self,
            "解除本机授权",
            "解除后，若已启用强制授权验证，软件将需要重新激活。是否继续？",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            revoke_local_license()
            self.refresh_data()
            QMessageBox.information(self, "已解除", "本机授权已解除。")
