import unittest
from unittest.mock import PropertyMock, patch

from src.ai_service import AIService
from src.official_source_discovery import (
    build_official_source_queries,
    canonical_source_url,
    discover_official_sources,
)


class _Response:
    def __init__(self, url, body, status_code=200, content_type="text/html; charset=utf-8"):
        self.url = url
        self.status_code = status_code
        self.headers = {"Content-Type": content_type}
        self.encoding = "utf-8"
        self._body = body.encode("utf-8")

    def iter_content(self, chunk_size=32768):
        yield self._body

    def close(self):
        pass


class OfficialSourceDiscoveryTest(unittest.TestCase):
    def test_queries_follow_city_and_province_cost_authorities(self):
        queries = build_official_source_queries("成都", province="四川")
        text = "\n".join(queries)
        self.assertIn("住房和城乡建设局", text)
        self.assertIn("工程造价管理站", text)
        self.assertIn("标准定额站", text)
        self.assertIn("四川", text)
        self.assertIn("住房和城乡建设厅", text)

    def test_search_retains_only_verified_official_price_evidence(self):
        def fake_search(query, limit=6):
            return [
                {
                    "query": query,
                    "title": "示例市建设工程材料信息价",
                    "url": "https://zjj.example.gov.cn/cost/price",
                    "snippet": "建设工程造价信息价查询",
                    "engine": "test",
                },
                {
                    "query": query,
                    "title": "非官方网站",
                    "url": "https://example.com/price",
                    "snippet": "信息价",
                    "engine": "test",
                },
            ]

        def fake_get(url, **_kwargs):
            return _Response(
                url,
                '<html><body>建设工程材料信息价<a href="/api/price/list">查询</a></body></html>',
            )

        result = discover_official_sources(
            "示例市",
            search_fn=fake_search,
            request_get=fake_get,
        )
        self.assertEqual(len(result["sources"]), 1)
        self.assertTrue(result["sources"][0]["verified"])
        self.assertEqual(result["sources"][0]["evidence_id"], "E1")
        self.assertIn("/api/price/list", result["sources"][0]["api_candidates"][0])
        self.assertTrue(any("非官方网站" not in item.get("reason", "") for item in result["rejected"]))

    def test_ai_can_only_classify_supplied_evidence_url(self):
        evidence = [{
            "evidence_id": "E1",
            "name": "官方材料信息价",
            "url": "https://zjj.example.gov.cn/cost",
            "source_kind": "web",
            "verified": True,
            "http_status": 200,
        }]
        ai = AIService()
        ai_result = {
            "sources": [{
                "evidence_id": "E1",
                "url": "https://invented.example.com/api",
                "recommended": True,
                "name": "审核后的名称",
                "source_kind": "api",
                "confidence": 88,
                "description": "页面含接口线索",
            }],
            "search_note": "完成",
        }
        with (
            patch.object(AIService, "is_available", new_callable=PropertyMock, return_value=True),
            patch.object(ai, "_call_json", return_value=ai_result),
        ):
            result = ai.search_official_sources("示例市", research_evidence=evidence)
        self.assertEqual(result["sources"][0]["url"], evidence[0]["url"])
        self.assertEqual(result["sources"][0]["source_kind"], "api")

    def test_canonical_url_drops_tracking_but_keeps_functional_query(self):
        left = canonical_source_url(
            "https://ZJJ.Example.Gov.Cn/cost/?period=2026-07&utm_source=test"
        )
        right = canonical_source_url(
            "https://zjj.example.gov.cn/cost?period=2026-07"
        )
        self.assertEqual(left, right)


if __name__ == "__main__":
    unittest.main()
