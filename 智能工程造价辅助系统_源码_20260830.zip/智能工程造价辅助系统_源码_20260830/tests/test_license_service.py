import unittest

from src.license_service import (
    _b58decode,
    _b58encode,
    activate_license,
    generate_license_code,
    verify_license_code,
)


class LicenseServiceTests(unittest.TestCase):
    def test_base58_roundtrip(self):
        raw = b'{"mc":"0123456789ABCDEF","exp":"20261231","sig":"ABCDEF"}'
        self.assertEqual(_b58decode(_b58encode(raw)), raw)

    def test_generate_and_verify_roundtrip(self):
        for days in (0, 1, 7, 30):
            with self.subTest(days=days):
                code = generate_license_code("0123456789ABCDEF", days)
                result = verify_license_code(code)
                self.assertTrue(result["valid"])
                self.assertEqual(result["machine_code"], "0123456789ABCDEF")
                if days == 0:
                    self.assertLess(result["days_left"], 0)
                else:
                    self.assertGreaterEqual(result["days_left"], days - 1)

    def test_rejects_tampered_signature(self):
        code = generate_license_code("0123456789ABCDEF", 7)
        tampered = code[:-1] + ("A" if code[-1] != "A" else "B")
        result = verify_license_code(tampered)
        self.assertFalse(result["valid"])

    def test_activation_rejects_machine_code_mismatch(self):
        code = generate_license_code("0123456789ABCDEF", 1)
        result = activate_license(code)
        self.assertFalse(result["ok"])
        self.assertIn("机器码", result["message"])


if __name__ == "__main__":
    unittest.main()
