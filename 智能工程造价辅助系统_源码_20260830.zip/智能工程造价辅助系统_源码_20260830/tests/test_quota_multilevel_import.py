import unittest

from src.db import get_session
from src.models import QuotaComposition, QuotaItem
from src.ui.quota_match import QuotaMatchTab
from src.quota_service import build_quota_match_index


class FakeWorksheet:
    name = "F.1.1 分部分项工程清单计价表"

    def __init__(self, rows):
        self.rows = rows


class QuotaMultilevelImportTest(unittest.TestCase):
    def test_mechanical_components_are_in_match_index(self):
        session = get_session()
        try:
            item = QuotaItem(
                source_key="test-mechanical-index",
                major="测试",
                code="TEST-MACHINE",
                name="机械挖土方",
                unit="m3",
            )
            item.compositions.append(
                QuotaComposition(
                    category="机械费",
                    code="MACHINE-1",
                    name="挖掘机挖土",
                    unit="m3",
                    qty=1,
                    no_tax_price=8,
                    tax_price=8.24,
                )
            )
            session.add(item)
            session.flush()
            index = build_quota_match_index(session, "测试")
            entry = next(value for value in index if value["item"].id == item.id)
            self.assertIn("机械费", entry["raw_logic_text"])
            self.assertEqual(entry["components"][0][0], "挖掘机挖土")
        finally:
            session.rollback()
            session.close()

    def test_merged_control_price_headers_preserve_prices(self):
        worksheet = FakeWorksheet([
            ["序号", "项目编码", "", "项目名称", "项目特征描述", "计量单位", "工程量", "金额（元）", "", "", "", ""],
            ["", "", "", "", "", "", "", "综合单价", "合价", "其中", "", ""],
            ["", "", "", "", "", "", "", "", "", "定额人工费", "定额机械费", "暂估价"],
            [1, "010101002001", "", "挖一般土方", "土方类别：综合", "m3", 472.96, 12.06, 5703.90, 2227.64, 2166.16, ""],
            [2, "010101002002", "", "空白价格清单", "按设计", "m3", 1, "", "", "", "", ""],
        ])

        items = QuotaMatchTab._extract_generic_items(
            [worksheet],
            lambda sheet: (tuple(row) for row in sheet.rows),
        )

        self.assertEqual(len(items), 2)
        self.assertEqual(items[0]["quantity"], "472.96")
        self.assertEqual(items[0]["comprehensive_price"], "12.06")
        self.assertEqual(items[0]["total_price"], "5703.9")
        self.assertEqual(items[0]["labor"], "2227.64")
        self.assertEqual(items[0]["machinery"], "2166.16")
        self.assertEqual(items[1]["comprehensive_price"], "")
        self.assertEqual(items[1]["total_price"], "")

    def test_generic_cost_columns_survive_row_conversion(self):
        row = QuotaMatchTab._row_from_import_item(
            {
                "seq": 1,
                "name": "挖一般土方",
                "feature": "土方类别：综合",
                "unit": "m3",
                "quantity": 2,
                "comprehensive_price": 12.06,
                "total_price": 24.12,
                "labor": 4.5,
                "material": 1.2,
                "machinery": 3.4,
            },
            1,
        )

        self.assertEqual(row["labor"], "4.5")
        self.assertEqual(row["material"], "1.2")
        self.assertEqual(row["machinery"], "3.4")
        self.assertEqual(row["source_total_price"], "24.12")

    def test_generic_import_blocks_code_only_and_non_quantity_rows(self):
        worksheet = FakeWorksheet([
            ["序号", "项目编码", "工程名称", "项目特征及工作内容", "单位", "工程量"],
            [1, "010101002001", "挖一般土方", "土方类别：综合", "m3", 12.5],
            [2, "粤011701008001", "粤011701008001", "粤011701008001", "m2", 2844.8],
            [3, "010101002002", "回填方", "密实度满足设计要求", "m3", 0],
            [4, "", "分部分项工程合计", "", "元", 1],
        ])

        items = QuotaMatchTab._extract_generic_items(
            [worksheet],
            lambda sheet: (tuple(row) for row in sheet.rows),
        )

        self.assertEqual([item["name"] for item in items], ["挖一般土方"])
        self.assertEqual(sum(QuotaMatchTab._last_generic_rejections.values()), 3)


if __name__ == "__main__":
    unittest.main()
