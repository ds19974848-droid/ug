import unittest

from src.ui.quota_match import QuotaMatchTab


class MatchingVersionCacheTests(unittest.TestCase):
    def test_old_cache_entry_is_not_read(self):
        row = {
            "ai_result_cache": {
                "fallback": {
                    "old-key": {
                        "schema": "ai-cache-v2",
                        "algorithm_version": "old",
                        "prompt_version": "old",
                        "result": {"valid": True},
                    }
                }
            }
        }
        self.assertIsNone(QuotaMatchTab._cached_ai_result(row, "fallback", "old-key"))

    def test_current_cache_entry_is_read(self):
        row = {"ai_result_cache": {}}
        result = {
            "valid": True,
            "actionable": True,
            "decision": "generate",
            "generated_quota": {"components": []},
        }
        QuotaMatchTab._save_cached_ai_result(row, "fallback", "key", result)
        self.assertEqual(
            QuotaMatchTab._cached_ai_result(row, "fallback", "key"),
            result,
        )

    def test_stale_entries_are_purged_without_touching_current_entries(self):
        row = {"ai_result_cache": {}}
        current = {
            "valid": True,
            "actionable": True,
            "decision": "generate",
            "generated_quota": {"components": []},
        }
        QuotaMatchTab._save_cached_ai_result(row, "fallback", "current", current)
        row["ai_result_cache"]["fallback"]["old"] = {
            "schema": "ai-cache-v2",
            "algorithm_version": "old",
            "prompt_version": "old",
            "result": {"valid": True},
        }
        QuotaMatchTab._purge_stale_ai_cache(row)
        self.assertIn("current", row["ai_result_cache"]["fallback"])
        self.assertNotIn("old", row["ai_result_cache"]["fallback"])

    def test_row_result_version_is_required_for_persisted_match(self):
        stale = {
            "quota_ids": [12],
            "row_result_algorithm_version": "quota-match-old",
            "row_result_schema": QuotaMatchTab.ROW_RESULT_SCHEMA,
        }
        current = {
            "quota_ids": [12],
            "row_result_algorithm_version": QuotaMatchTab.MATCHING_ALGORITHM_VERSION,
            "row_result_schema": QuotaMatchTab.ROW_RESULT_SCHEMA,
        }
        self.assertFalse(QuotaMatchTab._row_result_is_current(stale))
        self.assertTrue(QuotaMatchTab._row_result_is_current(current))
        self.assertFalse(QuotaMatchTab._row_is_matched(stale))
        self.assertTrue(QuotaMatchTab._row_is_matched(current))

    def test_worker_metadata_is_not_persisted_inside_restartable_cache(self):
        row = {"ai_result_cache": {}}
        result = {
            "valid": True,
            "actionable": True,
            "decision": "generate",
            "generated_quota": {"components": []},
            "_match_generation": 8,
            "_row_input_key": "live-worker-only",
            "_project_id": 99,
        }
        QuotaMatchTab._save_cached_ai_result(row, "fallback", "restart", result)
        cached = QuotaMatchTab._cached_ai_result(row, "fallback", "restart")
        self.assertIsNotNone(cached)
        self.assertNotIn("_match_generation", cached)
        self.assertNotIn("_row_input_key", cached)
        self.assertNotIn("_project_id", cached)


if __name__ == "__main__":
    unittest.main()
