import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from openpyxl import Workbook, load_workbook

from src.price_comparison import compare_tables, export_comparison, export_database_comparison, load_comparison_table


class PriceComparisonTest(unittest.TestCase):
    def _write_table(self, path: Path, rows: list[list[object]]) -> None:
        workbook = Workbook()
        worksheet = workbook.active
        for row in rows:
            worksheet.append(row)
        workbook.save(path)

    def test_compare_and_export_table_3_1_layout(self):
        headers = ["序号", "定额编号", "单项名称", "单位", "工程量", "综合单价", "合计"]
        with TemporaryDirectory() as directory:
            root = Path(directory)
            self._write_table(root / "table-a.xlsx", [
                headers,
                [1, "A-1", "土方", "m3", 10, 20, 200],
                [2, "A-2", "回填", "m3", 5, 30, 150],
            ])
            self._write_table(root / "table-b.xlsx", [
                headers,
                [1, "A-1", "土方", "m3", 12, 20, 240],
                [2, "A-2", "回填", "m3", 5, 35, 175],
            ])

            result = compare_tables(
                load_comparison_table(root / "table-a.xlsx"),
                load_comparison_table(root / "table-b.xlsx"),
            )
            self.assertEqual(result.equal_rows, 1)
            self.assertEqual(result.different_rows, 2)
            self.assertEqual(result.diff_cells, 4)
            self.assertEqual(result.rows[1].numeric_diffs["工程量"], 2.0)
            self.assertEqual(result.rows[1].numeric_diffs["合计"], 40.0)

            output = root / "comparison.xlsx"
            export_comparison(result, output)
            workbook = load_workbook(output, data_only=True)
            worksheet = workbook.active
            self.assertEqual(worksheet.max_column, 21)
            self.assertIn("A1:G3", worksheet["A4"].value)
            self.assertIn("原表B - 原表A", worksheet["A4"].value)
            self.assertEqual(worksheet["B7"].value, "A_序号")
            self.assertEqual(worksheet["I7"].value, "B_序号")
            self.assertEqual(worksheet["R9"].value, 2)
            self.assertEqual(worksheet["T9"].value, 40)
            workbook.close()

    def test_export_database_comparison_layout(self):
        with TemporaryDirectory() as directory:
            output = Path(directory) / "database-comparison.xlsx"
            export_database_comparison(
                [{
                    "seq_no": 1,
                    "item_code": "A-1",
                    "item_name": "土方",
                    "spec": "",
                    "unit": "m3",
                    "quantity": 10,
                    "old_price": 20,
                    "new_price": 22,
                    "price_diff": 2,
                    "change_rate": 0.1,
                    "estimated_change": 20,
                    "source": "地方官方 / 郑州 / 2026-08",
                    "confidence": 0.98,
                    "status": "已匹配",
                    "note": "本地区匹配",
                }],
                output,
                title="价格库对比",
                region="郑州",
                period="2026-08",
                source_name="当前项目清单",
            )
            workbook = load_workbook(output, data_only=True)
            worksheet = workbook.active
            self.assertEqual(worksheet.max_column, 15)
            self.assertEqual(worksheet["A6"].value, 1)
            self.assertEqual(worksheet["I6"].value, 2)
            self.assertEqual(worksheet["K6"].value, 20)
            workbook.close()


if __name__ == "__main__":
    unittest.main()
