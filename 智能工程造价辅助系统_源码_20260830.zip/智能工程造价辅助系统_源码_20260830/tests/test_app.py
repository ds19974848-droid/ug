import os
import sqlite3
import tempfile
import unittest
from contextlib import closing
from io import BytesIO
from pathlib import Path
from unittest.mock import Mock, PropertyMock, patch
from zipfile import ZipFile


TEST_ROOT = Path(tempfile.mkdtemp(prefix="dashuo-tests-"))
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["DASHUO_DATA_DIR"] = str(TEST_ROOT)
os.environ["DATABASE_URL"] = f"sqlite:///{(TEST_ROOT / 'test.db').as_posix()}"
os.environ["DEEPSEEK_API_KEY"] = ""

from openpyxl import Workbook, load_workbook
from PySide6.QtCore import QEvent, QItemSelectionModel, QPointF, QThread, SIGNAL, Qt
from PySide6.QtGui import QMouseEvent
from PySide6.QtWidgets import (
    QApplication, QDialog, QFileDialog, QInputDialog, QMessageBox, QPushButton,
    QTableWidgetItem,
)

from src.db import get_db_stats, get_session, get_setting, init_db, set_settings
from src.api_fetcher import _extract_period, has_api_handler
from src.api_sniffer import sanitize_post_data
from src.config import config
from src.models import (
    CostItem,
    Material,
    MaterialPrice,
    OfficialSource,
    Project,
    ProjectItem,
    ProjectQuotaMatch,
    QuotaComposition,
    QuotaItem,
    Region,
    SourceDocument,
    SubscriptionTask,
)
from src.subscription import SubscriptionEngine, confirm_pending_prices
from src.utils import is_official_domain
from src.ui.base_database import BaseDatabasePage
from src.ui.data_records import DataRecordsPage
from src.ui.home_page import HomePage
from src.ui.main_window import MainWindow, NAV_STRUCTURE
from src.ui.price_info import AISourceSearchWorker, ApiSnifferWorker, PriceInfoPage, SubscriptionWorker
from src.ui.project_workspace import (
    AIValidateWorker,
    AISuggestWorker,
    OfficialPriceUpdateWorker,
    ProjectWorkspacePage,
)
from src.ui.project_info import ProjectInfoPage, ProjectEditDialog
from src.ui.quota_library import QuotaLibraryPage
from src.ui.system_settings import AIConnectionWorker, SystemSettingsPage


def make_workbook(rows):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.append(["材料名称", "规格型号", "单位", "信息价"])
    for row in rows:
        worksheet.append(row)
    stream = BytesIO()
    workbook.save(stream)
    return stream.getvalue()


class FakeResponse:
    def __init__(self, text="", content=b"", content_type="text/html; charset=utf-8"):
        self._text = text
        self.content = content or text.encode("utf-8")
        self.headers = {"Content-Type": content_type}
        self.encoding = "utf-8"
        self.apparent_encoding = "utf-8"
        self.status_code = 200

    @property
    def text(self):
        return self._text or self.content.decode("utf-8")

    def raise_for_status(self):
        return None


class DashuoAppTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        set_settings({"auto_subscription_enabled": "false"})
        cls.app = QApplication.instance() or QApplication([])

    def test_01_builtin_cost_items_are_seeded_once(self):
        self.assertEqual(get_db_stats()["cost_items"], 4453)
        init_db()
        self.assertEqual(get_db_stats()["cost_items"], 4453)
        session = get_session()
        try:
            counts = {
                source: session.query(CostItem).filter(CostItem.data_source == source).count()
                for source in ("旧改", "新建", "装修", "测试数据")
            }
            self.assertEqual(counts, {"旧改": 1221, "新建": 683, "装修": 1630, "测试数据": 919})
        finally:
            session.close()

    def test_01b_builtin_quota_library_is_seeded_once(self):
        self.assertEqual(get_db_stats()["quota_items"], 227)
        session = get_session()
        try:
            self.assertEqual(session.query(QuotaComposition).count(), 668)
        finally:
            session.close()

    def test_02_subscription_crawls_pages_and_all_attachments(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="测试官方源",
                url="https://cost.example.gov.cn/info/index.html",
                is_official=True,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
            region_id = shanghai.id
        finally:
            session.close()

        root_url = "https://cost.example.gov.cn/info/index.html"
        page_url = "https://cost.example.gov.cn/info/month.html"
        first_url = "https://cost.example.gov.cn/files/a.xlsx"
        second_url = "https://cost.example.gov.cn/files/b.xlsx"
        responses = {
            root_url: FakeResponse(f'<a href="{first_url}">上海材料信息价附件一</a><a href="{page_url}">造价信息栏目</a>'),
            page_url: FakeResponse(f'<a href="{second_url}">材料价格附件二</a>'),
            first_url: FakeResponse(
                content=make_workbook([
                    ["预拌混凝土", "C30", "m3", 410],
                    ["预拌混凝土", "C35", "m3", 425],
                ]),
                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ),
            second_url: FakeResponse(
                content=make_workbook([
                    ["螺纹钢", "HRB400E Φ20", "t", 3800],
                    ["中砂", "河砂", "m3", 155],
                ]),
                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ),
        }

        def fake_get(url, **kwargs):
            return responses[url]

        progress_events = []
        with patch("src.subscription.requests.get", side_effect=fake_get):
            with SubscriptionEngine(progress_callback=progress_events.append) as engine:
                result = engine.run_single_source(source_id)

        self.assertTrue(result["success"], result)
        self.assertEqual(result["new_prices"], 4)
        self.assertEqual(progress_events[-1]["percent"], 100)
        self.assertGreaterEqual(max(event["documents"] for event in progress_events), 2)
        session = get_session()
        try:
            prices = session.query(MaterialPrice).join(Material).filter(
                MaterialPrice.region_id == region_id,
                Material.name.in_(["预拌混凝土", "螺纹钢", "中砂"]),
            ).all()
            self.assertEqual(len(prices), 4)
            concrete_specs = {price.spec for price in prices if price.material.name == "预拌混凝土"}
            self.assertEqual(concrete_specs, {"C30", "C35"})
            self.assertTrue(all(price.is_confirmed for price in prices))
            self.assertEqual(session.query(SourceDocument).filter(SourceDocument.source_id == source_id).count(), 4)
            task = session.query(SubscriptionTask).filter(SubscriptionTask.source_id == source_id).one()
            self.assertEqual((task.status, task.result_count), ("success", 4))
        finally:
            session.close()

    def test_03_subscription_prices_are_directly_confirmed(self):
        session = get_session()
        try:
            price = session.query(MaterialPrice).filter(MaterialPrice.is_confirmed.is_(True)).first()
            self.assertIsNotNone(price)
            price_id = price.id
        finally:
            session.close()
        result = confirm_pending_prices([price_id])
        self.assertEqual(result, {"success": True, "confirmed": 0})
        session = get_session()
        try:
            self.assertTrue(session.query(MaterialPrice).filter(MaterialPrice.id == price_id).one().is_confirmed)
        finally:
            session.close()

    def test_04_fixed_library_can_drive_batch_quote(self):
        page = ProjectWorkspacePage()
        quote = page._quote_tab
        quote._pricing_source_combo.setCurrentIndex(quote._pricing_source_combo.findData("fixed_only"))
        quote._table.setItem(0, 2, quote._table.item(0, 2).__class__("平整场地"))
        session = get_session()
        try:
            reference = quote._lookup_reference(session, 0)
        finally:
            session.close()
        self.assertIsNotNone(reference)
        self.assertEqual(reference["source_type"], "fixed")
        quote._apply_reference(0, reference)
        self.assertIn("固定清单库", quote._table.item(0, quote.COL_SOURCE).text())

    def test_04b_project_quote_navigation_fee_linkage_and_scrollbars(self):
        self.assertEqual([group[0] for group in NAV_STRUCTURE[:4]], ["首页", "项目信息", "造价工作台", "AI智能"])
        self.assertEqual(sum(group[0] == "造价工作台" for group in NAV_STRUCTURE), 1)
        self.assertEqual(
            NAV_STRUCTURE[2][2],
            ["匹配定额库", "匹配信息价与基础信息库", "造价变化联动"],
        )
        page = ProjectWorkspacePage()
        quote = page._quote_tab
        quote._management_base_combo.setCurrentIndex(quote._management_base_combo.findData("direct"))
        quote._profit_base_combo.setCurrentIndex(quote._profit_base_combo.findData("direct_management"))
        quote._management_rate.setValue(5)
        quote._profit_rate.setValue(7)
        quote._tax_rate.setValue(9)
        quote._updating_table = True
        try:
            values = {
                quote.COL_QUANTITY: "2",
                quote.COL_LABOR: "100",
                quote.COL_MATERIAL: "200",
                quote.COL_MACHINERY: "50",
                quote.COL_UNALLOCATED: "0",
            }
            for column, value in values.items():
                quote._table.setItem(0, column, quote._table.item(0, column).__class__(value))
        finally:
            quote._updating_table = False
        quote._recalculate_all_rows()
        self.assertAlmostEqual(quote._number_at(0, quote.COL_MANAGEMENT), 17.5, places=4)
        self.assertAlmostEqual(quote._number_at(0, quote.COL_PROFIT), 25.725, places=4)
        self.assertAlmostEqual(quote._number_at(0, quote.COL_UNIT_PRICE), 393.225, places=4)
        self.assertFalse(quote._table.item(0, quote.COL_UNIT_PRICE).flags() & Qt.ItemIsEditable)
        self.assertEqual(quote._table.horizontalScrollBarPolicy(), Qt.ScrollBarAlwaysOn)
        self.assertEqual(quote._table.verticalScrollBarPolicy(), Qt.ScrollBarAlwaysOn)
        quote._table_select_all()
        self.assertTrue(quote._table.selectionModel().selectedRows())
        quote._table_clear_selection()
        self.assertFalse(quote._table.selectionModel().selectedRows())

    def test_04ba_unselected_project_hint_navigates_to_project_info(self):
        original = get_setting("active_project_id", "")
        set_settings({"active_project_id": ""})
        try:
            page = ProjectWorkspacePage()
            routes = []
            page.navigate_requested.connect(routes.append)
            self.assertIn("点击此处", page._project_context.text())
            page._project_context.click()
            self.assertEqual(routes, ["project_info"])
            self.assertGreater(page._quota_match_tab.receivers(SIGNAL("navigate_requested(QString)")), 0)
        finally:
            set_settings({"active_project_id": original})

    def test_04c_project_quote_import_preserves_limited_custom_headers(self):
        page = ProjectWorkspacePage()
        quote = page._quote_tab
        with tempfile.TemporaryDirectory(prefix="dashuo-quote-import-") as directory:
            path = Path(directory) / "quote.xlsx"
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.append([
                "清单编号", "清单名称", "单位", "工程量", "人工费", "材料费", "机械费",
                "综合单价", "施工部位", "责任班组",
            ])
            worksheet.append(["A-1", "测试清单", "m2", 2, 10, 20, 5, 40, "一层", "一班"])
            workbook.save(path)
            workbook.close()
            with (
                patch.object(QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
            ):
                quote._on_import_excel()
            wide_path = Path(directory) / "too-wide.xlsx"
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.append([f"字段{index}" for index in range(31)])
            worksheet.append(list(range(31)))
            workbook.save(wide_path)
            workbook.close()
            with (
                patch.object(QFileDialog, "getOpenFileName", return_value=(str(wide_path), "")),
                patch.object(QMessageBox, "warning", return_value=QMessageBox.Ok) as warning,
            ):
                quote._on_import_excel()
            self.assertIn("最多允许 30 个", warning.call_args.args[2])
        self.assertEqual(quote._custom_headers, ["施工部位", "责任班组"])
        self.assertEqual(quote._table.columnCount(), len(quote.CORE_HEADERS) + 2)
        self.assertEqual(quote._table.horizontalHeaderItem(len(quote.CORE_HEADERS)).text(), "施工部位")
        self.assertEqual(quote._table.item(0, len(quote.CORE_HEADERS)).text(), "一层")
        self.assertAlmostEqual(quote._number_at(0, quote.COL_UNIT_PRICE), 40.0, places=3)

    def test_04ca_project_quote_import_preserves_blank_numeric_cells(self):
        page = ProjectWorkspacePage()
        quote = page._quote_tab
        with tempfile.TemporaryDirectory(prefix="dashuo-quote-blank-import-") as directory:
            path = Path(directory) / "blank-quote.xlsx"
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.append([
                "序号", "清单编号", "清单名称", "单位", "工程量", "人工费", "材料费", "机械费",
                "未拆分费", "管理费", "利润", "综合单价", "合价",
            ])
            worksheet.append([
                1, "A-1", "空值测试", "项", None, None, None, None,
                None, None, None, None, None,
            ])
            worksheet.append([
                2, "A-2", "目标价测试", "项", None, None, None, None,
                None, None, None, 50, None,
            ])
            workbook.save(path)
            workbook.close()
            with (
                patch.object(QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
            ):
                quote._on_import_excel()

        for column in (
            quote.COL_LABOR,
            quote.COL_MATERIAL,
            quote.COL_MACHINERY,
            quote.COL_UNALLOCATED,
            quote.COL_MANAGEMENT,
            quote.COL_PROFIT,
            quote.COL_UNIT_PRICE,
            quote.COL_TOTAL,
        ):
            self.assertEqual(quote._text_at(0, column), "")
        self.assertGreater(quote._number_at(1, quote.COL_UNIT_PRICE), 0)

    def test_04cb_single_material_query_applies_confirmed_price(self):
        from src.ui.project_workspace import ProjectQuoteTab

        region_name = "单材料测试地区"
        material_name = "单材料测试混凝土"
        period = "2099-08"
        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == region_name).first()
            if region is None:
                region = Region(name=region_name)
                session.add(region)
                session.flush()
            material = session.query(Material).filter(Material.name == material_name).first()
            if material is None:
                material = Material(name=material_name, default_unit="m3", spec_template="C99")
                session.add(material)
                session.flush()
            price = MaterialPrice(
                material_id=material.id,
                region_id=region.id,
                period=period,
                price=123.45,
                unit="m3",
                spec="C99",
                trust_level="official",
                source_type="official",
                price_basis="tax_exclusive",
                is_confirmed=True,
            )
            session.add(price)
            session.commit()
        finally:
            session.close()

        page = ProjectQuoteTab()
        page._material_keyword_input.setText(material_name)
        page._material_spec_input.setText("C99")
        page._material_unit_input.setText("m3")
        page._material_region_input.setText(region_name)
        page._material_period_input.setText(period)
        page._on_query_material_price()
        self.assertTrue(page._material_lookup_rows)
        self.assertEqual(page._material_lookup_rows[0]["price"], 123.45)
        self.assertEqual(page._material_lookup_table.rowCount(), 1)

        page._table.setCurrentCell(0, page.COL_NAME)
        page._material_lookup_table.selectRow(0)
        page._on_apply_material_lookup()
        self.assertEqual(page._text_at(0, page.COL_MATERIAL), "123.4500")
        self.assertIn(region_name, page._text_at(0, page.COL_SOURCE))

    def test_04cc_network_query_fetches_direct_sources_and_reminds_login(self):
        from src.ui.project_workspace import ProjectQuoteTab

        page = ProjectQuoteTab()
        page._material_keyword_input.setText("不存在测试材料XYZ")
        page._material_region_input.setText("测试城市")
        page._material_period_input.setText("2099-09")
        fake_worker = Mock()
        fake_worker.progress_changed = Mock()
        fake_worker.progress_changed.connect = Mock()
        fake_worker.completed = Mock()
        fake_worker.completed.connect = Mock()
        fake_worker.start = Mock()
        with (
            patch.object(
                ProjectQuoteTab,
                "_official_source_plan",
                return_value={
                    "status": "working",
                    "direct_source_ids": [999],
                    "source_names": ["测试官方来源"],
                    "login_required": False,
                    "note": "",
                },
            ),
            patch("src.ui.project_workspace.OfficialPriceUpdateWorker", return_value=fake_worker),
        ):
            page._on_query_material_price()
        fake_worker.start.assert_called_once()

        page._material_fetch_worker = None
        routes = []
        page.navigate_requested.connect(routes.append)
        with (
            patch.object(
                ProjectQuoteTab,
                "_official_source_plan",
                return_value={
                    "status": "login_required",
                    "direct_source_ids": [],
                    "source_names": [],
                    "login_required": True,
                    "note": "",
                },
            ),
            patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
        ):
            page._on_query_material_price()
        self.assertEqual(routes[-1], "subscription")

    def test_04cc_price_linkage_applies_matched_price_to_current_quote(self):
        region_name = "价格联动测试地区"
        material_name = "价格联动测试混凝土"
        period = "2099-08"
        session = get_session()
        try:
            region = session.query(Region).filter(Region.name == region_name).first()
            if region is None:
                region = Region(name=region_name)
                session.add(region)
                session.flush()
            material = session.query(Material).filter(Material.name == material_name).first()
            if material is None:
                material = Material(name=material_name, default_unit="m3", spec_template="LC-01")
                session.add(material)
                session.flush()
            price = MaterialPrice(
                material_id=material.id,
                region_id=region.id,
                period=period,
                price=158.8,
                unit="m3",
                spec="LC-01",
                trust_level="official",
                source_type="official",
                price_basis="tax_exclusive",
                is_confirmed=True,
            )
            session.add(price)
            session.commit()
        finally:
            session.close()

        page = ProjectWorkspacePage()
        quote = page._quote_tab
        linkage = page._linkage_tab
        quote._updating_table = True
        try:
            for column, value in {
                quote.COL_NAME: material_name,
                quote.COL_SPEC: "LC-01",
                quote.COL_UNIT: "m3",
                quote.COL_QUANTITY: "10",
                quote.COL_MATERIAL: "120.0000",
            }.items():
                quote._table.setItem(0, column, QTableWidgetItem(value))
        finally:
            quote._updating_table = False
        quote._region_input.setText(region_name)
        quote._period_input.setText(period)
        linkage._db_region_input.setText(region_name)
        linkage._db_period_input.setText(period)
        linkage._on_compare_current_project()
        self.assertEqual(linkage._database_rows[0]["status"], "已匹配")
        self.assertEqual(linkage._database_rows[0]["new_price"], 158.8)

        with (
            patch.object(QMessageBox, "question", return_value=QMessageBox.Yes),
            patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
        ):
            linkage._on_apply_linkage()
        self.assertEqual(quote._text_at(0, quote.COL_MATERIAL), "158.8000")
        self.assertIn("造价变化联动", quote._text_at(0, quote.COL_SOURCE))
        self.assertEqual(linkage._database_rows[0]["status"], "已应用")

    def test_04cd_linkage_uses_selected_project_rows(self):
        page = ProjectWorkspacePage()
        quote = page._quote_tab
        linkage = page._linkage_tab
        quote._table.selectRow(0)
        linkage._on_compare_current_project()
        self.assertEqual(len(linkage._database_rows), 1)
        self.assertIn("选中 1 行", linkage._database_source_label.text())

    def test_04ce_linkage_switches_to_file_compare_mode(self):
        page = ProjectWorkspacePage()
        linkage = page._linkage_tab
        page.show_route("price_linkage")
        page.show()
        self.app.processEvents()
        linkage._mode_combo.setCurrentIndex(linkage._mode_combo.findData("file"))
        self.assertFalse(linkage._database_controls.isVisible())
        self.assertTrue(linkage._file_controls.isVisible())
        self.assertEqual(linkage._mode_combo.currentData(), "file")
        self.assertFalse(linkage._apply_linkage_button.isEnabled())

    def test_04cf_linkage_prefers_quota_match_rows(self):
        page = ProjectWorkspacePage()
        linkage = page._linkage_tab
        page._quota_match_tab._rows = [{
            "seq": "1",
            "code": "Q-1",
            "name": "已套定额清单",
            "feature": "测试特征",
            "unit": "m2",
            "quantity": "10",
            "material": "88.8",
            "comprehensive_price": "120.5",
            "compositions": [],
            "quota_matches": [],
        }]
        linkage._on_compare_current_project()
        self.assertEqual(len(linkage._database_rows), 1)
        self.assertEqual(linkage._database_rows[0]["item_name"], "已套定额清单")
        self.assertIn("匹配定额库结果", linkage._database_source_label.text())

    def test_04d_project_quote_duplicates_rows_and_remembers_visible_columns(self):
        page = ProjectWorkspacePage()
        quote = page._quote_tab
        original_count = quote._table.rowCount()
        original_name = quote._text_at(0, quote.COL_NAME)
        quote._table.selectRow(0)

        quote._on_duplicate_selected_rows()

        self.assertEqual(quote._table.rowCount(), original_count + 1)
        self.assertEqual(quote._text_at(original_count, quote.COL_NAME), original_name)
        self.assertEqual(quote._text_at(original_count, quote.COL_SEQ), str(original_count + 1))
        self.assertFalse(
            quote._table.item(original_count, quote.COL_UNIT_PRICE).flags() & Qt.ItemIsEditable
        )

        quote._set_column_visible("备注", False)
        self.assertTrue(quote._table.isColumnHidden(quote.COL_NOTES))
        quote._show_all_columns()
        self.assertFalse(any(
            quote._table.isColumnHidden(column)
            for column in range(quote._table.columnCount())
        ))

    def test_04e_fixed_library_uses_primary_category_filter(self):
        page = BaseDatabasePage()
        fixed = page._fixed_items
        category_labels = [fixed._category.itemText(index) for index in range(fixed._category.count())]
        self.assertLessEqual(fixed._category.count(), 6)
        self.assertEqual(category_labels[:5], ["全部分类", "新建", "装修", "旧改", "测试数据"])
        fixed._category.setCurrentIndex(fixed._category.findData("新建"))
        session = get_session()
        try:
            items = fixed._query(session).limit(50).all()
        finally:
            session.close()
        self.assertTrue(items)
        self.assertTrue(all(item.full_category == "新建" or item.full_category.startswith("新建 /") for item in items))

    def test_04f_ai_service_uses_compact_http_client(self):
        from src.ai_service import AIService

        response = Mock()
        response.ok = True
        response.status_code = 200
        response.json.return_value = {
            "choices": [{"message": {"content": "测试回答"}}],
        }
        session = Mock()
        session.post.return_value = response
        with (
            patch.object(config, "DEEPSEEK_API_KEY", "test-key"),
            patch.object(config, "DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
            patch.object(config, "DEEPSEEK_MODEL", "deepseek-chat"),
            patch("src.ai_service.requests.Session", return_value=session),
        ):
            service = AIService()
            service._available = None
            service._session = None
            service.reload()
            success, content = service.chat([{"role": "user", "content": "你好"}])

        self.assertTrue(success)
        self.assertEqual(content, "测试回答")
        endpoint = session.post.call_args.args[0]
        payload = session.post.call_args.kwargs["json"]
        self.assertEqual(endpoint, "https://api.deepseek.com/chat/completions")
        self.assertEqual(payload["model"], "deepseek-chat")
        self.assertEqual(payload["messages"][0]["content"], "你好")
        headers = session.headers.update.call_args.args[0]
        headers["User-Agent"].encode("ascii")
        service._available = None
        service._session = None

    def test_04fa_ai_web_search_parses_bing_results(self):
        from src.ai_research import search_web

        html = """
        <ol>
          <li class="b_algo">
            <h2><a href="https://cost.example.gov.cn/prices.html">官方信息价</a></h2>
            <div class="b_caption"><p>D400 球墨铸铁检查井盖 660 元/套</p></div>
          </li>
          <li class="b_algo">
            <h2><a href="https://example.com/docs">技术说明</a></h2>
            <div class="b_caption"><p>材质、安装要求</p></div>
          </li>
        </ol>
        """
        with patch("src.ai_research.requests.get", return_value=FakeResponse(html)):
            results = search_web("检查井盖 信息价")

        self.assertEqual(len(results), 2)
        self.assertTrue(results[0]["official"])
        self.assertIn("660", results[0]["snippet"])
        self.assertFalse(results[1]["official"])

    def test_04fb_ai_research_quota_filters_unverified_urls(self):
        from src.ai_service import AIService

        service = AIService()
        old_available = service._available
        old_session = service._session
        service._available = True
        service._session = Mock()
        try:
            with patch.object(service, "_call_json", return_value={
                "decision": "generate",
                "summary": "已检索到对应人材机",
                "generated_quota": {
                    "name": "球墨铸铁检查井盖",
                    "feature": "φ700 D400",
                    "unit": "套",
                    "confidence": 0.72,
                    "components": [{
                        "cat": "主材费",
                        "name": "球墨铸铁检查井盖",
                        "feature": "φ700 D400",
                        "unit": "套",
                        "qty": 1,
                        "loss": 0,
                        "noTaxPrice": 660,
                        "taxRate": 13,
                        "taxPrice": 745.8,
                        "calculation_basis": "公开检索价格",
                        "source_urls": [
                            "https://cost.example.gov.cn/prices.html",
                            "https://invalid.example/fake",
                        ],
                    }],
                },
            }):
                result = service.research_quota({
                    "name": "铸铁井盖",
                    "feature": "φ700球墨铸铁检查井盖座,等级D400",
                    "unit": "套",
                }, {
                    "project": {},
                    "work_items": ["安装球墨铸铁检查井盖"],
                }, [{
                    "query": "检查井盖 信息价",
                    "title": "官方信息价",
                    "url": "https://cost.example.gov.cn/prices.html",
                    "snippet": "D400 球墨铸铁检查井盖 660 元/套",
                    "excerpt": "价格 660",
                    "official": True,
                }])

        finally:
            service._available = old_available
            service._session = old_session

        self.assertEqual(result["decision"], "generate")
        generated = result["generated_quota"]
        self.assertEqual(generated["source_type"], "ai_web_research")
        self.assertEqual(
            generated["components"][0]["source_urls"],
            ["https://cost.example.gov.cn/prices.html"],
        )
        self.assertIn("cost.example.gov.cn", generated["components"][0]["calculation_basis"])

    def test_04fc_ai_audit_quota_composition_flags_logic_issues(self):
        from src.ai_service import AIService

        service = AIService()
        old_available = service._available
        old_session = service._session
        service._available = True
        service._session = Mock()
        try:
            with patch.object(service, "_call_json", return_value={
                "findings": [{
                    "severity": "high",
                    "type": "对象错误",
                    "message": "清单是检查井盖，当前组成不是井盖",
                    "affected_component": "主材",
                }],
                "needs_correction": True,
                "reason": "对象不匹配",
                "summary": "需要重新检索人材机",
            }):
                result = service.audit_quota_composition(
                    {
                        "name": "铸铁井盖",
                        "feature": "φ700 D400",
                        "unit": "套",
                    },
                    {
                        "project": {},
                        "work_items": ["安装检查井盖"],
                        "candidates": [],
                    },
                    {
                        "quota_matches": [{
                            "role": "主体",
                            "quota_id": 999,
                            "quota_code": "TEST",
                            "quota_name": "错误定额",
                            "score": 0.4,
                            "evidence_level": "red",
                        }],
                        "compositions": [{
                            "cat": "主材费",
                            "name": "错误材料",
                            "unit": "套",
                            "qty": 1,
                        }],
                    },
                )
        finally:
            service._available = old_available
            service._session = old_session

        self.assertTrue(result["success"])
        self.assertTrue(result["needs_correction"])
        self.assertEqual(len(result["findings"]), 1)
        self.assertEqual(result["findings"][0]["severity"], "high")

    def test_04fd_fixed_quota_audit_rules_cover_missing_duplicate_logic_and_calculation(self):
        from src.quota_service import build_quota_audit_report

        component = {
            "included": True,
            "cat": "主材费",
            "code": "MAT-C25",
            "name": "预拌混凝土C25",
            "unit": "m3",
            "qty": 0.2,
            "loss": 0,
            "noTaxPrice": 400,
            "taxRate": 9,
            "taxPrice": 436,
            "noTaxTotal": 80,
            "taxTotal": 87.2,
            "quotaRole": "主体",
            "quotaName": "混凝土面层",
        }
        report = build_quota_audit_report(
            {
                "name": "水泥混凝土路面",
                "feature": "1、20cm厚C25混凝土面层\n2、钢筋Φ12\n3、锯缝机切缝5cm",
                "unit": "m2",
            },
            {
                "quota_matches": [{
                    "role": "主体",
                    "quota_id": 123,
                    "quota_code": "WRONG",
                    "quota_name": "吸音铝板墙面",
                    "score": 0.4,
                    "evidence_level": "red",
                    "matched_source_clauses": ["20cm厚C25混凝土面层"],
                }],
                "compositions": [
                    dict(component),
                    dict(component),
                    {
                        "included": True,
                        "cat": "人工费",
                        "name": "混凝土面层人工",
                        "unit": "m2",
                        "qty": 1,
                        "loss": 0,
                        "noTaxPrice": 10,
                        "taxRate": 9,
                        "taxPrice": 10.9,
                        "noTaxTotal": 10,
                        "taxTotal": 10.9,
                    },
                ],
                "management": 5,
                "profit": 3,
                "comprehensive_price": 88,
                "evidence_level": "red",
            },
        )

        categories = {issue.get("category") for issue in report["issues"]}
        self.assertTrue({"人材机遗漏", "重复匹配", "乱匹配", "计算错误"}.issubset(categories))
        self.assertTrue(report["needs_correction"])
        self.assertIn("钢筋", str(report["coverage"]["missing_materials"]))
        self.assertEqual(len(report["duplicate_components"]), 1)

    def test_04fe_quota_matching_deduplicates_covered_rebar(self):
        from src.quota_service import _quota_covers_clause, normalize_quota_row_matches

        session = get_session()
        try:
            main = QuotaItem(
                source_key="test-covered-rebar-quota",
                major="测试",
                name="钢筋混凝土构件钢筋",
                unit="t",
            )
            session.add(main)
            session.flush()
            session.add(QuotaComposition(
                quota_item_id=main.id,
                category="主材费",
                code="CLF-TEST-REBAR",
                name="钢筋",
                unit="t",
                qty=1,
                loss_rate=2,
                no_tax_price=3800,
                tax_rate=13,
                tax_price=4294,
                no_tax_total=3876,
                tax_total=4379.88,
            ))
            session.commit()
            session.refresh(main)
            self.assertTrue(_quota_covers_clause(
                main,
                "普通钢筋制作、安装 带肋钢筋",
            ))
            session.delete(main)
            session.commit()
        finally:
            session.close()

        row = {
            "quota_id": 309,
            "quota_ids": [309, 288],
            "quota_matches": [
                {
                    "quota_id": 309,
                    "quota_name": "钢筋混凝土构件钢筋",
                    "role": "主体",
                    "component_only": False,
                },
                {
                    "quota_id": 288,
                    "quota_name": "灌注桩钢筋制作",
                    "role": "补充材料（低相似度）",
                    "component_only": True,
                },
            ],
            "compositions": [
                {
                    "quotaId": 309,
                    "cat": "主材费",
                    "name": "钢筋",
                    "unit": "t",
                    "qty": 1,
                    "loss": "2%",
                    "noTaxPrice": 3800,
                    "taxRate": "13%",
                    "taxPrice": 4294,
                },
                {
                    "quotaId": 288,
                    "cat": "主材费",
                    "name": "钢筋",
                    "unit": "t",
                    "qty": 1,
                    "loss": "2%",
                    "noTaxPrice": 3800,
                    "taxRate": "13%",
                    "taxPrice": 4294,
                },
            ],
        }
        normalize_quota_row_matches(row)
        self.assertEqual(len(row["compositions"]), 1)
        self.assertEqual(row["quota_ids"], [309])
        self.assertEqual(len(row["quota_matches"]), 1)

    def test_04ff_audit_worker_reuses_identical_patterns(self):
        from src.ui.quota_match import QuotaAuditWorker

        boq = {
            "name": "现浇构件钢筋",
            "feature": "普通钢筋制作、安装 带肋钢筋",
            "unit": "t",
        }
        current = {
            "quota_matches": [{
                "quota_id": 309,
                "quota_code": "",
                "quota_name": "钢筋混凝土构件钢筋",
                "role": "主体",
                "score": 0.55,
                "source_type": "",
            }],
            "compositions": [{
                "cat": "主材费",
                "code": "CLF",
                "name": "钢筋",
                "unit": "t",
                "qty": 1,
                "loss": "2%",
                "noTaxPrice": 3800,
                "taxRate": "13%",
                "taxPrice": 4294,
            }],
            "evidence_level": "yellow",
        }
        same = dict(current)
        same["evidence_level"] = "red"
        self.assertEqual(
            QuotaAuditWorker._pattern_key(boq, current),
            QuotaAuditWorker._pattern_key(dict(boq, seq=22), same),
        )
        different = dict(boq, feature="拉杆钢筋")
        self.assertNotEqual(
            QuotaAuditWorker._pattern_key(boq, current),
            QuotaAuditWorker._pattern_key(different, current),
        )

    def test_04g_quota_reference_matches_quota_library(self):
        from src.quota_service import find_quota_reference, quota_reference_dict

        session = get_session()
        try:
            match = find_quota_reference(session, "地砖地面（正铺）", "正铺", "m2")
            self.assertIsNotNone(match)
            self.assertIn("地砖", match[0].name)
            reference = quota_reference_dict(match[0])
            self.assertGreater(reference["price"], 0)
            self.assertEqual(reference["source_type"], "quota")
        finally:
            session.close()

    def test_04gb_base_fallback_uses_fixed_and_info_price_evidence(self):
        from src.quota_service import build_base_data_fallback, quota_reference_dict

        session = get_session()
        try:
            duplicate = QuotaItem(
                source_key="test-base-fallback-duplicate",
                major="测试",
                code="TEST-DUP",
                name="防水粘结层测试",
                unit="m2",
            )
            session.add(duplicate)
            session.flush()
            for category, code, name in (
                ("机械费", "JXF-TEST", "测试机械费"),
                ("机械费", "JXF-TEST", "测试机械费"),
                ("主材费", "CLF-TEST", "测试碎石"),
            ):
                session.add(QuotaComposition(
                    quota_item_id=duplicate.id,
                    category=category,
                    code=code,
                    name=name,
                    unit="m2" if category == "机械费" else "m3",
                    qty=1.0,
                    no_tax_price=1.456 if category == "机械费" else 79.646,
                    tax_price=1.5 if category == "机械费" else 90.0,
                ))
            session.commit()
            session.refresh(duplicate)
            reference = quota_reference_dict(duplicate)
            self.assertEqual(
                [component["cat"] for component in reference["compositions"]].count("机械费"),
                1,
            )

            fixed = build_base_data_fallback(session, {
                "name": "塑料检查井",
                "feature": "名称:塑料排水检查井 规格:φ630 井盖样式:配套树脂井盖 安装部位:室外绿化带 H=1.8m",
                "unit": "座",
            })
            self.assertIsNotNone(fixed)
            self.assertEqual(fixed["source_type"], "base_fixed")
            self.assertTrue(fixed["auto_apply"])
            self.assertEqual(fixed["evidence_level"], "green")

            mismatched = build_base_data_fallback(session, {
                "name": "塑料检查井",
                "feature": "小方井φ450 塑料检查井φ450 井筒φ450 具体详见图纸",
                "unit": "座",
            }, include_unconfirmed=True)
            self.assertIsNotNone(mismatched)
            self.assertFalse(mismatched["auto_apply"])
            self.assertEqual(mismatched["evidence_level"], "red")

            region = session.query(Region).order_by(Region.id).first()
            material = Material(
                name="测试铸铁井盖",
                category="市政材料",
                default_unit="套",
                spec_template="φ700 D400",
            )
            session.add(material)
            session.flush()
            session.add(MaterialPrice(
                material_id=material.id,
                region_id=region.id,
                period="2026-08",
                price=660,
                unit="套",
                spec="φ700 D400",
                source_key="test-cast-iron-cover",
                source_type="manual",
                price_basis="tax_inclusive",
                is_confirmed=False,
            ))
            session.commit()
            price_fallback = build_base_data_fallback(session, {
                "name": "铸铁井盖",
                "feature": "φ700球墨铸铁检查井盖座,等级D400",
                "unit": "套",
            }, include_unconfirmed=True)
            self.assertIsNotNone(price_fallback)
            self.assertEqual(price_fallback["source_type"], "base_material")
            self.assertFalse(price_fallback["auto_apply"])
            self.assertEqual(price_fallback["evidence_level"], "red")

            for price in material.prices:
                session.delete(price)
            session.delete(material)
            session.delete(duplicate)
            session.commit()
        finally:
            session.close()

    def test_04ga_quota_match_has_four_threshold_levels(self):
        from src.ui.quota_match import QuotaMatchTab

        page = QuotaMatchTab()
        self.assertEqual(
            [page._match_level.itemData(index) for index in range(page._match_level.count())],
            [40, 50, 60, 70],
        )
        self.assertEqual(page._match_level.currentData(), 60)
        page._match_level.setCurrentIndex(3)
        self.assertIn("主体≥70%", page._match_rule_label.text())
        self.assertIn("补充工序≥78%", page._match_rule_label.text())

    def test_04h_quota_library_cells_are_compact_and_editable(self):
        page = QuotaLibraryPage()
        self.assertFalse(hasattr(page, "_cell_preview"))
        self.assertFalse(page._upper_table.wordWrap())
        self.assertEqual(page._upper_table.textElideMode(), Qt.ElideRight)
        self.assertEqual(page._upper_table.verticalHeader().defaultSectionSize(), 27)
        self.assertEqual(page._upper_table.receivers(SIGNAL("cellClicked(int,int)")), 0)
        self.assertGreater(page._upper_table.receivers(SIGNAL("cellDoubleClicked(int,int)")), 0)
        self.assertEqual(page._lower_table.receivers(SIGNAL("cellClicked(int,int)")), 0)
        self.assertGreater(page._lower_table.receivers(SIGNAL("cellDoubleClicked(int,int)")), 0)
        cell = page._upper_table.item(0, 1)
        quota_id = cell.data(Qt.UserRole)
        original = cell.text()
        try:
            page._save_cell_value(page._upper_table, 0, 1, "code", f"{original}-测试")
            session = get_session()
            try:
                quota = session.query(QuotaItem).filter(QuotaItem.id == quota_id).one()
                self.assertEqual(quota.code, f"{original}-测试")
            finally:
                session.close()

        finally:
            session = get_session()
            try:
                quota = session.query(QuotaItem).filter(QuotaItem.id == quota_id).one()
                quota.code = original
                session.commit()
            finally:
                session.close()

    def test_04h2_quota_library_shows_only_requested_detail_columns(self):
        from src.quota_service import QUOTA_DETAIL_CATEGORIES, export_quota_excel

        page = QuotaLibraryPage()
        self.assertEqual(page.UPPER_HEADERS, [
            "类别", "定额编码", "定额名称", "单位", "除税单价", "含税单价",
        ])
        self.assertGreater(page._upper_table.columnCount(), 0)
        self.assertTrue(all(
            page._upper_table.item(row, 0).text() in QUOTA_DETAIL_CATEGORIES
            for row in range(page._upper_table.rowCount())
        ))
        with tempfile.TemporaryDirectory(prefix="quota-detail-export-") as directory:
            path = Path(directory) / "定额明细.xlsx"
            export_quota_excel(page._items[:2], path)
            workbook = load_workbook(path, read_only=True, data_only=True)
            worksheet = workbook.active
            self.assertEqual(tuple(next(worksheet.iter_rows(values_only=True))), tuple(page.UPPER_HEADERS))
            self.assertTrue(all(
                row[0] in QUOTA_DETAIL_CATEGORIES
                for row in worksheet.iter_rows(min_row=2, values_only=True)
            ))
            self.assertTrue(all(
                len(row) == len(page.UPPER_HEADERS)
                for row in worksheet.iter_rows(min_row=2, values_only=True)
            ))
            workbook.close()

    def test_04hb_long_cell_tooltip_uses_extended_duration(self):
        from src.ui.quota_match import QuotaMatchTab

        page = QuotaMatchTab()
        page._table.setRowCount(1)
        page._table.setItem(0, 1, QTableWidgetItem("很长的项目名称 " * 80))
        with patch("src.ui.quota_match.QToolTip.showText") as show_text:
            page._table.cellEntered.emit(0, 1)
        show_text.assert_called_once()
        self.assertEqual(
            show_text.call_args.args[4],
            page.TOOLTIP_DURATION_MS,
        )
        self.assertGreater(page._table.receivers(SIGNAL("cellDoubleClicked(int,int)")), 0)

    def test_04hc_long_cell_tooltip_filter_is_installed_on_project_quote_table(self):
        from src.ui.project_workspace import ProjectQuoteTab

        page = ProjectQuoteTab()
        self.assertIsNotNone(getattr(page._table, "_long_text_tooltip_filter", None))
        self.assertTrue(page._table.viewport().hasMouseTracking())
        page._table.setRowCount(1)
        page._table.setItem(0, page.COL_NAME, QTableWidgetItem("很长的清单名称 " * 80))
        point = page._table.visualItemRect(page._table.item(0, page.COL_NAME)).center()
        event = QMouseEvent(
            QEvent.MouseMove,
            QPointF(point),
            Qt.NoButton,
            Qt.NoButton,
            Qt.NoModifier,
        )
        with patch("src.ui.widgets.QToolTip.showText") as show_text:
            QApplication.sendEvent(page._table.viewport(), event)
        show_text.assert_called_once()
        self.assertEqual(show_text.call_args.args[4], 30000)

    def test_04i_quota_match_imports_old_xls_with_late_header(self):
        from src.ui.quota_match import QuotaMatchTab

        class FakeCell:
            def __init__(self, value):
                self.value = value

        class FakeSheet:
            def __init__(self, rows):
                self._rows = rows
                self.nrows = len(rows)

            def row(self, index):
                return [FakeCell(value) for value in self._rows[index]]

        class FakeWorkbook:
            def __init__(self):
                self.released = False
                self._sheets = [
                    FakeSheet([["汇总表"], ["项目名称", "金额"]]),
                    FakeSheet([
                        ["工程施工费预算表", "", "", ""],
                        ["项目名称：测试项目", "", "", ""],
                        ["序号", "定额编号", "单项名称", "单位", "工程量"],
                        ["", "(1)", "(2)", "(3)"],
                        [1, "A-1", "地砖地面", "m2", 1],
                    ]),
                ]

            def sheets(self):
                return self._sheets

            def release_resources(self):
                self.released = True

        page = QuotaMatchTab()
        workbook = FakeWorkbook()
        with (
            patch.object(QFileDialog, "getOpenFileName", return_value=("fixture.xls", "")),
            patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
            patch.object(QMessageBox, "warning", return_value=QMessageBox.Ok) as warning,
            patch("xlrd.open_workbook", return_value=workbook),
        ):
            page._import_excel()
        warning.assert_not_called()
        self.assertTrue(workbook.released)
        self.assertEqual(len(page._rows), 1)
        self.assertEqual(page._rows[0]["name"], "地砖地面")
        self.assertEqual(page._rows[0]["unit"], "m2")

    def test_04j_quota_match_preserves_twelve_column_boq(self):
        from src.ui.quota_match import QuotaMatchTab

        with tempfile.TemporaryDirectory(prefix="quota-match-xlsx-") as directory:
            path = Path(directory) / "清单.xlsx"
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.append([
                "序号", "工程名称", "项目特征及工作内容", "单位", "工程量", "综合单价分析",
                "综合单价", "人工费", "材料费", "机械费", "管理费", "利润", "备注",
            ])
            worksheet.append([1, "地砖地面（正铺）", "正铺\n具体详见图纸", "m2", 1, None, None, None, None, None, None, None, None])
            worksheet.append([2, "测试空特征", None, "项", 1, None, None, None, None, None, None, None, "原备注"])
            workbook.save(path)

            page = QuotaMatchTab()
            with (
                patch.object(QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
                patch.object(QMessageBox, "warning", return_value=QMessageBox.Ok) as warning,
            ):
                page._import_excel()
            warning.assert_not_called()
            self.assertEqual(page.HEADERS, [
                "序号", "工程名称", "项目特征及工作内容", "单位", "工程量", "综合单价分析",
                "综合单价", "人工费", "材料费", "机械费", "管理费", "利润", "备注",
            ])
            self.assertEqual(len(page._rows), 2)
            self.assertEqual(page._rows[0]["feature"], "正铺\n具体详见图纸")
            self.assertEqual(page._rows[1]["feature"], "测试空特征")
            self.assertIn("使用工程名称作为匹配依据", page._rows[1]["note"])
            self.assertIn("原备注", page._rows[1]["note"])
            self.assertIn("使用工程名称作为匹配依据", page._rows[1]["note"])
            for field in ("analysis", "comprehensive_price", "labor", "material", "machinery", "management", "profit"):
                self.assertEqual(page._rows[0][field], "")

            with patch.object(QMessageBox, "information", return_value=QMessageBox.Ok):
                page._batch_match()
            self.assertTrue(page._rows[0]["analysis"])
            self.assertTrue(page._rows[0]["comprehensive_price"])
            direct_base = (
                float(page._rows[0]["labor"] or 0)
                + float(page._rows[0]["material"] or 0)
                + float(page._rows[0]["machinery"] or 0)
            )
            self.assertAlmostEqual(
                page._rows[0]["management"],
                direct_base * page._management_rate.value() / 100,
                places=4,
            )
            self.assertAlmostEqual(
                page._rows[0]["profit"],
                (direct_base + page._rows[0]["management"]) * page._profit_rate.value() / 100,
                places=4,
            )
            self.assertEqual(page._rows[0]["note"], "")
            self.assertEqual(page._rows[1]["analysis"], "")
            self.assertEqual(page._rows[1]["comprehensive_price"], "")

            export_path = Path(directory) / "匹配结果.xlsx"
            with (
                patch.object(QFileDialog, "getSaveFileName", return_value=(str(export_path), "")),
                patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
            ):
                page._export_excel()
            exported = load_workbook(export_path, read_only=True, data_only=True)
            try:
                self.assertEqual(exported.sheetnames, [
                    "定额匹配结果", "费用分类汇总", "分量计算明细", "计价参数",
                ])
                self.assertGreater(exported["分量计算明细"].max_row, 1)
                hierarchy = exported["定额匹配结果"]
                self.assertGreater(hierarchy.max_row, 3)
                self.assertEqual(hierarchy["A2"].value, "清单")
                self.assertIn(hierarchy["A3"].value, page.EXPENSE_CATEGORIES)
            finally:
                exported.close()

    def test_04jd_quota_match_imports_glodon_f1_format(self):
        from src.ui.quota_match import QuotaMatchTab

        with tempfile.TemporaryDirectory(prefix="quota-glodon-") as directory:
            path = Path(directory) / "广联达清单.xlsx"
            workbook = Workbook()
            bill = workbook.active
            bill.title = "F.1 分部分项工程和单价措施项目清单与计价表"
            bill.append(["序号", "项目编码", "项目名称", "", "项目特征", "单位", "工程量", "综合单价"])
            bill.append([1, "010101001001", "平整场地", "", "土壤类别：综合考虑", "m2", 12.5, 1.35])
            analysis = workbook.create_sheet("F.2 综合单价分析表")
            analysis.append(["项目编码", "(1) 010101001001"])
            subtotal = [None] * 16
            subtotal[0] = "小     计"
            subtotal[10], subtotal[12], subtotal[13], subtotal[14], subtotal[15] = (0.66, 2.5, 0.52, 0.05, 0.12)
            analysis.append(subtotal)
            workbook.save(path)

            page = QuotaMatchTab()
            with (
                patch.object(QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
                patch.object(QMessageBox, "warning", return_value=QMessageBox.Ok) as warning,
            ):
                page._import_excel()

        warning.assert_not_called()
        self.assertEqual(page._source_format, "广联达 F.1/F.2")
        self.assertEqual(len(page._rows), 1)
        self.assertEqual(page._rows[0]["code"], "010101001001")
        self.assertEqual(page._rows[0]["feature"], "土壤类别：综合考虑")
        self.assertEqual(page._rows[0]["quantity"], "12.5")
        self.assertEqual(page._rows[0]["labor"], "0.66")
        self.assertEqual(page._rows[0]["material"], "2.5")

    def test_04je_quota_match_persists_imported_rows_immediately(self):
        from src.ui.quota_match import QuotaMatchTab

        session = get_session()
        try:
            project = session.query(Project).order_by(Project.id).first()
            project_id = project.id
            session.query(ProjectQuotaMatch).filter(
                ProjectQuotaMatch.project_id == project_id
            ).delete()
            session.commit()
        finally:
            session.close()
        set_settings({"active_project_id": str(project_id)})

        page = QuotaMatchTab()
        page._source_file = "清单导入测试.xlsx"
        page._source_format = "测试格式"
        page._rows = [{
            "seq": "1", "code": "A-001", "name": "测试工程", "feature": "测试工作内容",
            "unit": "m2", "quantity": "12", "analysis": "", "comprehensive_price": "",
            "labor": "", "material": "", "machinery": "", "management": "", "profit": "",
            "note": "", "quota_id": None, "quota_ids": [], "quota_matches": [], "score": 0,
            "match_reasons": [], "compositions": [],
        }]
        self.assertTrue(page._persist_after_import())

        restored = QuotaMatchTab()
        restored.refresh_data()
        self.assertEqual(len(restored._rows), 1)
        self.assertEqual(restored._rows[0]["feature"], "测试工作内容")
        self.assertEqual(restored._source_format, "测试格式")

    def test_04jf_quota_match_filters_and_batches_unmatched_visible_rows(self):
        from src.ui.quota_match import QuotaMatchTab

        page = QuotaMatchTab()
        page._rows = [
            {
                "seq": "1", "name": "已匹配清单", "feature": "测试", "unit": "m2",
                "quota_id": 1, "quota_ids": [1], "quota_matches": [],
                "ai_generated": False,
            },
            {
                "seq": "2", "name": "未匹配清单", "feature": "测试", "unit": "m2",
                "quota_id": None, "quota_ids": [], "quota_matches": [],
                "ai_generated": False,
            },
            {
                "seq": "3", "name": "AI补充清单", "feature": "测试", "unit": "m2",
                "quota_id": None, "quota_ids": [], "quota_matches": [],
                "ai_generated": True,
            },
        ]
        page._render_table()

        index = page._status_filter.findData("unmatched")
        self.assertGreaterEqual(index, 0)
        page._status_filter.setCurrentIndex(index)
        self.assertEqual(page._visible_row_indexes(), [1])
        page._select_unmatched()
        self.assertEqual(
            [model_index.row() for model_index in page._table.selectionModel().selectedRows()],
            [1],
        )

        with patch.object(page, "_batch_match_indexes") as matcher:
            page._batch_match_filtered()
        matcher.assert_called_once_with([1])

        page._status_filter.setCurrentIndex(page._status_filter.findData("all"))
        selection_model = page._table.selectionModel()
        selection_model.clearSelection()
        selection_model.select(
            page._table.model().index(0, 0),
            QItemSelectionModel.Select | QItemSelectionModel.Rows,
        )
        selection_model.select(
            page._table.model().index(2, 0),
            QItemSelectionModel.Select | QItemSelectionModel.Rows,
        )
        with patch.object(page, "_batch_match_indexes") as matcher:
            page._batch_match_selected()
        matcher.assert_called_once_with([0, 2])

        selection_model.clearSelection()
        selection_model.select(
            page._table.model().index(1, 0),
            QItemSelectionModel.Select | QItemSelectionModel.Rows,
        )
        with patch.object(page, "_batch_match_indexes") as matcher:
            page._batch_match_selected()
        matcher.assert_called_once_with([1])

        page._status_filter.setCurrentIndex(page._status_filter.findData("ai"))
        self.assertEqual(page._visible_row_indexes(), [2])

    def test_04jfa_quota_match_applies_section_fee_settings(self):
        from src.ui.quota_match import QuotaMatchTab

        page = QuotaMatchTab()
        page._fee_settings = {
            "default": {
                "management_base": "direct",
                "management_rate": 5,
                "profit_base": "direct_management",
                "profit_rate": 7,
            },
            "groups": {
                "施工技术措施项目": {
                    "management_base": "labor_machine",
                    "management_rate": 12.5,
                    "profit_base": "labor",
                    "profit_rate": 8,
                },
            },
        }
        row = {
            "seq": "1",
            "code": "041101001001",
            "name": "施工措施测试项",
            "feature": "测试工作内容",
            "unit": "m2",
            "quantity": "1",
            "source_tab": "0_2_表10_2_2-16 施工技术措施项目清单与计价表",
            "score": 1.0,
            "quota_ids": [],
            "quota_matches": [],
            "compositions": [
                {"cat": "人工费", "included": True, "qty": 1, "noTaxPrice": 100},
                {"cat": "材料费", "included": True, "qty": 1, "noTaxPrice": 200},
                {"cat": "机械费", "included": True, "qty": 1, "noTaxPrice": 50},
            ],
        }

        page._calculate_row_from_compositions(row)

        self.assertEqual(row["fee_group"], "施工技术措施项目")
        self.assertAlmostEqual(row["management"], (100 + 50) * 0.125, places=4)
        self.assertAlmostEqual(row["profit"], 100 * 0.08, places=4)
        self.assertAlmostEqual(
            row["comprehensive_price"],
            100 + 200 + 50 + 18.75 + 8,
            places=4,
        )
        self.assertEqual(
            row["applied_fee_settings"]["management_base"],
            "labor_machine",
        )

    def test_04jfb_fee_settings_dialog_restores_default_and_clears_groups(self):
        from src.ui.quota_match import FeeSettingsDialog

        dialog = FeeSettingsDialog(
            {
                "default": {
                    "management_base": "direct",
                    "management_rate": 5,
                    "profit_base": "direct_management",
                    "profit_rate": 7,
                },
                "groups": {
                    "施工技术措施项目": {
                        "management_base": "labor_machine",
                        "management_rate": 12.5,
                        "profit_base": "labor",
                        "profit_rate": 8,
                    },
                },
            },
            ["施工技术措施项目"],
        )

        self.assertEqual(
            dialog.values()["groups"]["施工技术措施项目"]["management_rate"],
            12.5,
        )
        dialog._restore_defaults()
        restored = dialog.values()
        self.assertEqual(restored["default"]["management_rate"], 5)
        self.assertEqual(restored["groups"], {})
        dialog.deleteLater()

    def test_04jfc_quota_match_payload_round_trips_fee_settings(self):
        from src.ui.quota_match import QuotaMatchTab

        settings = {
            "default": {
                "management_base": "direct",
                "management_rate": 5,
                "profit_base": "direct_management",
                "profit_rate": 7,
            },
            "groups": {
                "分部分项工程": {
                    "management_base": "labor_material",
                    "management_rate": 9.5,
                    "profit_base": "labor_machine",
                    "profit_rate": 6.5,
                },
            },
        }
        page = QuotaMatchTab()
        page._fee_settings = page._normalize_fee_settings(settings)
        payload = page._payload()

        restored = QuotaMatchTab()
        restored._apply_saved_payload({"rows": [], "fee_settings": payload["fee_settings"]})
        self.assertEqual(
            restored._fee_settings["groups"]["分部分项工程"]["management_base"],
            "labor_material",
        )
        self.assertAlmostEqual(
            restored._fee_settings["groups"]["分部分项工程"]["profit_rate"],
            6.5,
            places=4,
        )
        self.assertAlmostEqual(restored._profit_rate.value(), 7, places=4)

    def test_04jfd_quota_match_export_includes_engineering_totals(self):
        from src.ui.quota_match import QuotaMatchTab

        page = QuotaMatchTab()
        page._rows = [{
            "seq": "1",
            "code": "A-001",
            "name": "测试清单",
            "feature": "测试特征",
            "unit": "m2",
            "quantity": "10",
            "comprehensive_price": "122",
            "compositions": [
                {
                    "cat": "人工费",
                    "included": True,
                    "qty": 1,
                    "noTaxPrice": 100,
                    "taxRate": 9,
                    "taxPrice": 109,
                },
                {
                    "cat": "材料费",
                    "included": True,
                    "qty": 0.2,
                    "noTaxPrice": 10,
                    "taxRate": 9,
                    "taxPrice": 10.9,
                },
            ],
            "fee_details": [{
                "calculatedFee": True,
                "included": True,
                "quotaRole": "取费",
                "quotaCode": "计价参数",
                "quotaName": "管理费",
                "cat": "管理费",
                "name": "管理费",
                "unit": "m2",
                "sourceQty": 1,
                "qty": 1,
                "quotaFactor": 1,
                "loss": 0,
                "effectiveQty": 1,
                "noTaxPrice": 10,
                "unitNoTaxTotal": 10,
                "engineeringQuantity": 10,
                "engineeringNoTaxTotal": 100,
                "taxRate": 0,
                "taxPrice": 10,
                "unitTaxTotal": 10,
                "engineeringTaxTotal": 100,
            }],
        }]

        with tempfile.TemporaryDirectory(prefix="quota-export-totals-") as directory:
            export_path = Path(directory) / "定额匹配结果.xlsx"
            with (
                patch.object(QFileDialog, "getSaveFileName", return_value=(str(export_path), "")),
                patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
            ):
                page._export_excel()
            exported = load_workbook(export_path, read_only=True, data_only=True)
            try:
                hierarchy = exported["定额匹配结果"]
                self.assertEqual(hierarchy["G1"].value, "清单工程量")
                self.assertEqual(hierarchy["N1"].value, "除税工程合价")
                self.assertEqual(hierarchy["O1"].value, "含税工程合价")
                self.assertAlmostEqual(hierarchy["N2"].value, 1220, places=4)
                self.assertAlmostEqual(hierarchy["O2"].value, 1211.8, places=4)
                self.assertAlmostEqual(hierarchy["N3"].value, 1000, places=4)
                self.assertAlmostEqual(hierarchy["O3"].value, 1090, places=4)
                self.assertAlmostEqual(hierarchy["N6"].value, 1220, places=4)
                self.assertAlmostEqual(hierarchy["O6"].value, 1211.8, places=4)
            finally:
                exported.close()

    def test_04jfe_quota_match_adjusts_manual_fee_group(self):
        from src.ui.quota_match import QuotaMatchTab

        page = QuotaMatchTab()
        row = {
            "seq": "1",
            "code": "A-001",
            "name": "测试清单",
            "feature": "测试特征",
            "unit": "m2",
            "quantity": "10",
            "source_tab": "F.1 分部分项工程和单价措施项目清单与计价表",
            "quota_id": None,
            "quota_ids": [],
            "quota_matches": [],
            "compositions": [],
        }
        page._rows = [row]
        page._render_table()
        page._table.setCurrentCell(0, 0)

        with (
            patch.object(QInputDialog, "getItem", return_value=("施工技术措施项目", True)),
            patch.object(page, "_save_results", return_value=True),
            patch.object(page, "_save_pending_draft", return_value=True),
            patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
        ):
            page._adjust_row_fee_group()
        self.assertEqual(row["fee_group"], "施工技术措施项目")
        self.assertEqual(page._row_fee_group(row), "施工技术措施项目")

        with (
            patch.object(QInputDialog, "getItem", return_value=("自动识别（按来源表）", True)),
            patch.object(page, "_save_results", return_value=True),
            patch.object(page, "_save_pending_draft", return_value=True),
            patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
        ):
            page._adjust_row_fee_group()
        self.assertNotIn("fee_group", row)
        self.assertEqual(page._row_fee_group(row), "分部分项工程")

    def test_04jg_quota_match_import_shows_supported_source_types(self):
        from src.ui.quota_match import QuotaMatchTab

        with tempfile.TemporaryDirectory(prefix="quota-import-hint-") as directory:
            path = Path(directory) / "清单.xlsx"
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.append(["序号", "工程名称", "项目特征及工作内容", "单位"])
            worksheet.append([1, "测试清单", "测试特征", "项"])
            workbook.save(path)

            page = QuotaMatchTab()
            with (
                patch.object(QFileDialog, "getOpenFileName", return_value=(str(path), "")),
                patch.object(QMessageBox, "information", return_value=QMessageBox.Ok) as information,
                patch.object(QMessageBox, "warning", return_value=QMessageBox.Ok),
            ):
                page._import_excel()

        information.assert_called()
        first_call = information.call_args_list[0].args
        self.assertEqual(first_call[0], page)
        self.assertEqual(first_call[1], "清单 Excel 导入")
        self.assertIn("工程量清单", first_call[2])
        self.assertIn("结算文件", first_call[2])
        self.assertIn("自动生成需要套定额的清单", first_call[2])

    def test_04ja_quota_component_calculation_keeps_full_audit_chain(self):
        from src.quota_service import composition_cost_breakdown

        detail = {
            "sourceQty": 0.02,
            "qty": 0.03,
            "quotaFactor": 1.5,
            "loss": "3%",
            "noTaxPrice": 100,
            "taxPrice": 113,
        }
        result = composition_cost_breakdown(detail, 200)
        self.assertAlmostEqual(result["baseQty"], 0.02)
        self.assertAlmostEqual(result["adjustedQty"], 0.03)
        self.assertAlmostEqual(result["factoredQty"], 0.045)
        self.assertAlmostEqual(result["effectiveQty"], 0.04635)
        self.assertAlmostEqual(result["unitNoTaxTotal"], 4.635)
        self.assertAlmostEqual(result["engineeringNoTaxTotal"], 927.0)
        self.assertAlmostEqual(result["engineeringTaxTotal"], 1047.51)

    def test_04jb_quota_match_splits_independent_work_content(self):
        from src.quota_service import split_boq_work_items

        clauses = split_boq_work_items(
            "人行道块料铺设",
            "1、15cm厚C25混凝土基层\n2、锯缝机切缝缝深5cm\n3、具体详见设计图纸",
        )
        self.assertIn("人行道块料铺设", clauses)
        self.assertTrue(any("混凝土基层" in clause for clause in clauses))
        self.assertTrue(any("切缝" in clause for clause in clauses))
        self.assertFalse(any("详见设计图纸" in clause for clause in clauses))

    def test_04jb2_quota_match_covers_every_feature_with_component_substitutes(self):
        from src.quota_service import (
            boq_cost_clauses,
            build_quota_match_index,
            find_quota_composition_matches,
            material_coverage_gaps,
            quota_reference_dict,
            uncovered_cost_clauses,
        )

        feature = (
            "混凝土路面：\n"
            "1、20cm厚C35水泥混凝土面层\n"
            "2、锯缝机切缝缝深(cm)5\n"
            "3、路面防滑条\n"
            "4、塑料膜养护\n"
            "5、混凝土缩缝，缝宽0.4cm，缝深5cm，伸缝沥青玛蹄脂\n"
            "6、人工填灌缝塑料油膏缝深(cm)5\n"
            "具体详见设计图纸"
        )
        major = "测试多特征匹配"
        primary = QuotaItem(
            source_key="test-multi-feature-primary",
            major=major,
            code="TEST-ROAD-001",
            name="人工铺筑混凝土道路",
            feature="1.混凝土强度等级:C35，抗折4.5MPa\n2.厚度:20cm\n3.养护、切缝",
            unit="m2",
            no_tax_price=30,
            tax_price=32.7,
            compositions=[
                QuotaComposition(
                    category="人工费", name="混凝土道路（人工浇筑）",
                    feature="20cm厚混凝土道路，养护、切缝", unit="m2",
                    qty=1, no_tax_price=17, tax_price=18.7,
                ),
                QuotaComposition(
                    category="主材费", name="普通商品混凝土", feature="C35",
                    unit="m3", qty=0.2, no_tax_price=265, tax_price=300,
                ),
                QuotaComposition(
                    category="人工费", name="路面刻纹", feature="综合",
                    unit="m2", qty=1, no_tax_price=1.4, tax_price=1.5,
                ),
                QuotaComposition(
                    category="人工费", name="路面切缝", feature="水泥混凝土路面切缝",
                    unit="m", qty=0.16, no_tax_price=7, tax_price=7.5,
                ),
            ],
        )
        film = QuotaItem(
            source_key="test-multi-feature-film",
            major=major,
            code="TEST-FILM-001",
            name="塑料薄膜坡面铺设",
            feature="铺设塑料薄膜",
            unit="m2",
            compositions=[QuotaComposition(
                category="主材费", name="塑料薄膜", feature="综合",
                unit="m2", qty=1, no_tax_price=0.265, tax_price=0.3,
            )],
        )
        seal = QuotaItem(
            source_key="test-multi-feature-seal",
            major=major,
            code="TEST-SEAL-001",
            name="混凝土桩头防水",
            feature="密封膏嵌缝",
            unit="个",
            compositions=[QuotaComposition(
                category="辅材费", name="密封膏", feature="双组份聚氨酯",
                unit="kg", qty=0.05, no_tax_price=23.628, tax_price=26.7,
            )],
        )
        session = get_session()
        session.add_all([primary, film, seal])
        session.commit()
        try:
            matches = find_quota_composition_matches(
                session,
                "水泥混凝土",
                feature,
                "m2",
                major=major,
                candidate_index=build_quota_match_index(session, major),
            )
            clauses = boq_cost_clauses("水泥混凝土", feature)
            primary_index_entry = next(
                entry for entry in build_quota_match_index(session, major)
                if entry["item"].name == "人工铺筑混凝土道路"
            )
            self.assertNotIn("抗折4.5MPa", primary_index_entry["raw_logic_text"])
            self.assertNotIn("20cm厚混凝土道路", primary_index_entry["raw_logic_text"])
            sources = [
                source
                for match in matches
                for source in match.get("matched_source_clauses") or []
            ]
            self.assertEqual(len(clauses), 6)
            self.assertTrue(all(any(clause in source for source in sources) for clause in clauses))
            self.assertEqual(
                [match["item"].name for match in matches],
                ["人工铺筑混凝土道路", "塑料薄膜坡面铺设", "混凝土桩头防水"],
            )
            seal_match = next(match for match in matches if match["item"].name == "混凝土桩头防水")
            self.assertTrue(seal_match["component_only"])
            self.assertEqual(
                [value["name"] for value in seal_match["components"]],
                ["玛蹄脂（以密封膏替补）", "油膏（以密封膏替补）"],
            )
            self.assertFalse(any("陶粒" in value["name"] for value in seal_match["components"]))
            details = []
            for match in matches:
                if match.get("component_only"):
                    details.extend(match.get("components") or [])
                else:
                    details.extend(quota_reference_dict(match["item"])["compositions"])
            self.assertEqual(uncovered_cost_clauses("水泥混凝土", feature, details, sources), [])
            self.assertEqual(material_coverage_gaps("水泥混凝土", feature, details), [])
        finally:
            session.query(QuotaItem).filter(
                QuotaItem.source_key.in_([
                    "test-multi-feature-primary",
                    "test-multi-feature-film",
                    "test-multi-feature-seal",
                ])
            ).delete(synchronize_session=False)
            session.commit()
            session.close()

    def test_04jc_quota_match_saves_separately_from_project_quote(self):
        from src.ui.quota_match import QuotaMatchTab

        session = get_session()
        try:
            project = session.query(Project).order_by(Project.id).first()
            project_id = project.id
            quote_item_count = session.query(ProjectItem).filter(ProjectItem.project_id == project_id).count()
            session.query(ProjectQuotaMatch).filter(ProjectQuotaMatch.project_id == project_id).delete()
            session.commit()
        finally:
            session.close()
        set_settings({"active_project_id": str(project_id)})
        page = QuotaMatchTab()
        page._rows = [{
            "seq": "1", "code": "", "name": "测试清单", "feature": "测试工作内容",
            "unit": "m2", "quantity": "10", "analysis": "", "comprehensive_price": 12.5,
            "labor": 5.0, "material": 5.0, "machinery": "", "management": 0.5,
            "profit": 2.0, "note": "", "quota_id": 1, "quota_ids": [1],
            "quota_matches": [], "score": 1.0, "match_reasons": [], "compositions": [],
        }]
        self.assertTrue(page._save_results(show_message=False))
        session = get_session()
        try:
            self.assertEqual(
                session.query(ProjectItem).filter(ProjectItem.project_id == project_id).count(),
                quote_item_count,
            )
            saved = session.query(ProjectQuotaMatch).filter(ProjectQuotaMatch.project_id == project_id).one()
            self.assertEqual(saved.total_rows, 1)
            self.assertEqual(saved.quota_count, 1)
        finally:
            session.close()
        restored = QuotaMatchTab()
        restored.refresh_data()
        self.assertEqual(len(restored._rows), 1)
        self.assertEqual(restored._rows[0]["name"], "测试清单")

    def test_04k_quota_matching_rejects_cost_logic_conflicts(self):
        from src.quota_service import _candidate_logic

        self.assertFalse(_candidate_logic("墙面瓷砖铺贴", "地砖楼地面铺贴", "m2", "m2")[0])
        self.assertFalse(_candidate_logic("墙面拆除", "墙面抹灰新建", "m2", "m2")[0])
        self.assertFalse(_candidate_logic("混凝土体积", "混凝土地面", "m3", "m2")[0])
        self.assertFalse(_candidate_logic("水泥混凝土路面", "细粒式沥青混凝土路面", "m2", "m2")[0])
        self.assertFalse(_candidate_logic("C20混凝土基础", "片石混凝土洞门基础", "m3", "m3")[0])
        ok, bonus, reasons = _candidate_logic(
            "地砖地面铺贴",
            "地砖楼地面铺贴，含地砖和砂浆",
            "m2",
            "m2",
        )
        self.assertTrue(ok)
        self.assertGreater(bonus, 0)
        self.assertTrue(any("单位一致" in reason for reason in reasons))

    def test_04ka_quota_matching_rejects_explicit_size_conflicts(self):
        from src.quota_service import _candidate_logic

        result = _candidate_logic(
            "600x600地砖地面正铺",
            "1000x1000地砖地面正铺",
            "m2",
            "m2",
        )
        self.assertFalse(result[0])
        self.assertIn("规格冲突", result[2][0])
        self.assertTrue(_candidate_logic(
            "600x600地砖地面正铺",
            "地砖地面正铺",
            "m2",
            "m2",
        )[0])

    def test_04ka2_quota_matching_requires_roadbed_and_rolling_keywords(self):
        from src.quota_service import _candidate_logic, extract_quota_key_terms

        feature = "路床整形碾压，密实度达到设计和规范要求，具体详见设计图纸"
        terms = extract_quota_key_terms("路床整形碾压", feature)
        self.assertIn("碾压", terms["crafts"])
        self.assertIn("整形", terms["crafts"])
        self.assertIn("路床", terms["road_scope_groups"])

        self.assertFalse(_candidate_logic(feature, "道路标线", "m2", "m2")[0])
        self.assertTrue(_candidate_logic(feature, "路床整形碾压", "m2", "m2")[0])

    def test_04kb_ai_generated_quota_keeps_missing_details_and_converted_unit_actionable(self):
        from src.quota_service import validate_ai_generated_quota

        generated = {
            "major": "市政",
            "code": "AI-001",
            "name": "人行道混凝土基层浇筑",
            "feature": "C25混凝土基层浇筑",
            "unit": "m2",
            "confidence": 0.8,
            "components": [{
                "cat": "材料费", "name": "预拌混凝土C25", "feature": "C25混凝土基层浇筑",
                "unit": "m3", "qty": 0.15, "loss": 2, "noTaxPrice": 400,
                "taxRate": 13, "taxPrice": 452, "calculation_basis": "当地同期市场询价估算",
                "source_evidence_ids": [],
            }],
        }
        missing_feature = validate_ai_generated_quota(
            {"name": "人行道混凝土基层", "feature": "", "unit": "m2"}, generated, [],
        )
        self.assertTrue(missing_feature["valid"], missing_feature)
        self.assertTrue(missing_feature["actionable"])
        self.assertEqual(missing_feature["status"], "accepted_with_warning")
        self.assertIn("每1m2", missing_feature["quota"]["components"][0]["unitConversion"])
        self.assertTrue(any("项目特征" in value for value in missing_feature["warnings"]))
        self.assertEqual(missing_feature["evidence_level"], "red")

        wrong_unit = dict(
            generated,
            unit="m3",
            feature="15cm厚C25混凝土基层浇筑",
        )
        invalid = validate_ai_generated_quota(
            {"name": "人行道混凝土基层", "feature": "15cm厚C25混凝土基层浇筑", "unit": "m2"},
            wrong_unit,
            [],
        )
        self.assertTrue(invalid["valid"])
        self.assertTrue(invalid["actionable"])
        self.assertTrue(any("单位" in value for value in invalid["warnings"]))

    def test_04kb2_ai_generated_quota_keeps_water_grate_estimate_actionable(self):
        from src.quota_service import validate_ai_generated_quota

        generated = {
            "major": "市政", "code": "AI-GRATE-001", "name": "球墨铸铁水篦板安装",
            "feature": "250x500球墨铸铁水篦板安装", "unit": "块",
            "unit_conversion": "每块清单按1块主材计量，安装人工按块数换算",
            "assumptions": ["厚度按市政常用40mm假设", "单块重量按市场常见规格假设"],
            "confidence": 0.58,
            "components": [
                {
                    "cat": "主材费", "name": "球墨铸铁水篦板", "feature": "250x500球墨铸铁水篦板",
                    "unit": "块", "qty": 1, "loss": 0, "noTaxPrice": 100,
                    "taxRate": 13, "taxPrice": 113,
                    "calculation_basis": "市场模型估算：本地市政常用球墨铸铁水篦板价格",
                    "source_evidence_ids": [],
                },
                {
                    "cat": "人工费", "name": "水篦板安装人工", "feature": "水篦板安装",
                    "unit": "工日", "qty": 0.08, "loss": 0, "noTaxPrice": 300,
                    "taxRate": 0, "taxPrice": 300,
                    "calculation_basis": "市场模型估算：按每块安装耗时和市政人工费估算",
                    "source_evidence_ids": [],
                },
            ],
        }
        result = validate_ai_generated_quota(
            {
                "name": "球墨铸铁水篦板 250x500",
                "feature": "",
                "unit": "块",
            },
            generated,
            [],
        )
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["actionable"])
        self.assertEqual(len(result["quota"]["components"]), 2)
        self.assertIn("项目特征", "；".join(result["warnings"]))
        self.assertIn("assumptions", result["quota"])
        self.assertEqual(result["evidence_level"], "red")

    def test_04kb3_ai_quota_prompt_uses_repair_and_respects_candidate_logic(self):
        from src.ai_service import AIService

        service = AIService()
        service._available = True
        service._session = object()
        context = {
            "project": {},
            "work_items": ["球墨铸铁水篦板安装", "250x500"],
            "candidates": [
                {
                    "quota_id": 1, "logic_allowed": False,
                    "name": "旧铸铁井盖安装", "components": [],
                },
                {
                    "quota_id": 2, "logic_allowed": True,
                    "name": "水篦板安装", "components": [],
                },
            ],
            "market_prices": [],
        }
        fake_result = {
            "decision": "existing",
            "matches": [
                {"quota_id": 1, "confidence": 0.9},
                {"quota_id": 2, "confidence": 0.8},
            ],
            "summary": "测试",
        }
        with patch.object(service, "_call_json", return_value=fake_result) as call:
            result = service.match_or_generate_quota(
                {"name": "球墨铸铁水篦板", "feature": "", "unit": "块"},
                context,
            )
        self.assertEqual([value["quota_id"] for value in result["matches"]], [2])
        prompt = call.call_args.args[1]
        self.assertIn("unit_conversion", prompt)
        self.assertIn("不要返回 none", prompt)
        self.assertIn("assumptions", prompt)
        self.assertIn("required_terms", prompt)
        self.assertEqual(call.call_args.kwargs["max_tokens"], 8192)
        self.assertEqual(call.call_args.kwargs["response_format"], {"type": "json_object"})

        with patch.object(service, "_call_json", return_value=fake_result) as repair_call:
            service.match_or_generate_quota(
                {"name": "球墨铸铁水篦板", "feature": "", "unit": "块"},
                context,
                repair_hints=["必须保留水篦板对象核心词"],
            )
        self.assertIn("必须保留水篦板对象核心词", repair_call.call_args.args[1])

    def test_04kc_ai_generated_quota_rejects_invented_material_and_spec(self):
        from src.quota_service import validate_ai_generated_quota

        generated = {
            "major": "装修", "code": "AI-002", "name": "地砖地面铺贴",
            "feature": "600x600地砖正铺", "unit": "m2", "confidence": 0.75,
            "components": [{
                "cat": "主材费", "name": "HRB400钢筋", "feature": "HRB400钢筋安装",
                "unit": "kg", "qty": 5, "loss": 2, "noTaxPrice": 4.5,
                "taxRate": 13, "taxPrice": 5.085, "calculation_basis": "模型市场估算，无本地确认来源",
                "source_evidence_ids": [],
            }],
        }
        result = validate_ai_generated_quota(
            {"name": "地砖地面铺贴", "feature": "600x600地砖正铺，水泥砂浆结合层", "unit": "m2"},
            generated,
            [],
        )
        self.assertFalse(result["valid"])
        self.assertTrue(any("主材" in value or "等级" in value for value in result["errors"]))

    def test_04kc2_ai_generated_quota_rejects_object_replacement(self):
        from src.quota_service import validate_ai_generated_quota

        generated = {
            "major": "市政", "code": "AI-WRONG-001", "name": "电缆桥架安装",
            "feature": "钢制电缆桥架安装", "unit": "m", "confidence": 0.8,
            "components": [{
                "cat": "主材费", "name": "钢制电缆桥架", "feature": "桥架安装",
                "unit": "m", "qty": 1, "loss": 2, "noTaxPrice": 80,
                "taxRate": 13, "taxPrice": 90.4,
                "calculation_basis": "市场模型估算：常规电缆桥架价格",
                "source_evidence_ids": [],
            }],
        }
        result = validate_ai_generated_quota(
            {"name": "球墨铸铁水篦板 250×500", "feature": "", "unit": "块"},
            generated,
            [],
        )
        self.assertFalse(result["valid"])
        self.assertTrue(any("对象" in value for value in result["errors"]))

    def test_04kc3_ai_generated_quota_rejects_missing_required_craft(self):
        from src.quota_service import validate_ai_generated_quota

        generated = {
            "major": "市政",
            "code": "AI-ROAD-MARK",
            "name": "道路标线",
            "feature": "道路标线施划",
            "unit": "m2",
            "confidence": 0.85,
            "components": [{
                "cat": "人工费",
                "name": "道路标线施划人工",
                "feature": "道路标线施划",
                "unit": "m2",
                "qty": 1,
                "loss": 0,
                "noTaxPrice": 10,
                "taxRate": 9,
                "taxPrice": 10.9,
                "calculation_basis": "市场模型估算，无本地已确认价格来源",
                "source_evidence_ids": [],
            }],
        }
        result = validate_ai_generated_quota(
            {
                "name": "路床整形碾压",
                "feature": "路床整形碾压，密实度达到设计和规范要求，具体详见设计图纸",
                "unit": "m2",
            },
            generated,
            [],
        )
        self.assertFalse(result["valid"])
        self.assertTrue(any("核心工艺" in value for value in result["errors"]))

    def test_04kd_ai_market_estimate_recalculates_totals_and_evidence_color(self):
        from src.quota_service import validate_ai_generated_quota

        boq = {"name": "C25混凝土基层", "feature": "15cm厚C25混凝土基层浇筑", "unit": "m2"}
        generated = {
            "major": "市政", "code": "AI-003", "name": "C25混凝土基层",
            "feature": "15cm厚C25混凝土基层浇筑", "unit": "m2", "confidence": 0.9,
            "components": [{
                "cat": "材料费", "name": "预拌混凝土C25", "feature": "C25混凝土基层浇筑",
                "unit": "m3", "qty": 0.15, "loss": 2, "noTaxPrice": 400,
                "taxRate": 13, "taxPrice": 999, "noTaxTotal": 9999, "taxTotal": 9999,
                "calculation_basis": "郑州2026-08已确认信息价除税口径", "source_evidence_ids": [99],
            }],
        }
        evidence = [{
            "price_id": 99, "material_name": "预拌混凝土C25", "spec": "C25",
            "unit": "m3", "price": 400, "period": "2026-08", "region": "郑州",
            "price_basis": "tax_exclusive", "region_match": "exact", "period_match": "exact",
        }]
        result = validate_ai_generated_quota(boq, generated, evidence)
        self.assertTrue(result["valid"], result)
        component = result["quota"]["components"][0]
        self.assertAlmostEqual(component["taxPrice"], 452)
        self.assertAlmostEqual(component["noTaxTotal"], 61.2)
        self.assertEqual(component["evidenceLevel"], "green")
        self.assertEqual(result["evidence_level"], "green")

        no_source = validate_ai_generated_quota(boq, generated, [])
        self.assertTrue(no_source["valid"], no_source)
        self.assertEqual(no_source["evidence_level"], "red")
        self.assertEqual(no_source["quota"]["components"][0]["sourceEvidenceIds"], [])

    def test_04ke_project_ai_supplement_counts_without_official_quota_id(self):
        from src.ui.quota_match import QuotaMatchTab

        row = {"quota_ids": [], "quota_id": None, "generated_quota": {"code": "AI-004"}}
        self.assertEqual(QuotaMatchTab._row_quota_count(row), 1)
        self.assertTrue(QuotaMatchTab._row_is_matched(row))

    def test_05_all_routes_and_buttons_are_wired(self):
        window = MainWindow()
        home = HomePage()
        project_info = ProjectInfoPage()
        price_info = PriceInfoPage()
        project = ProjectWorkspacePage()
        base = BaseDatabasePage()
        records = DataRecordsPage()
        settings = SystemSettingsPage()
        quota_library = QuotaLibraryPage()
        pages = [home, project_info, price_info, project, base, records, settings, quota_library]
        route_groups = {
            project_info: ["project_info"],
            price_info: ["subscription", "source_config", "source_docs"],
            project: ["project_quote", "price_linkage", "project_snapshot", "quota_match"],
            base: ["price_library", "bq_library", "market_library", "material_library"],
            records: ["history", "audit_logs", "backup_restore", "audit_export"],
            settings: ["deepseek_config", "sub_rules", "anomaly_threshold", "db_management"],
            quota_library: ["quota_library"],
        }
        for page, routes in route_groups.items():
            for route in routes:
                page.show_route(route)
                self.app.processEvents()
        dead_buttons = []
        for owner in [window, *pages]:
            for button in owner.findChildren(QPushButton):
                if button.receivers(SIGNAL("clicked()")) == 0:
                    dead_buttons.append((owner.__class__.__name__, button.text()))
        self.assertEqual(dead_buttons, [])

    def test_06_every_button_can_be_clicked_without_crashing(self):
        window = MainWindow()
        pages = [
            HomePage(), ProjectInfoPage(), PriceInfoPage(), ProjectWorkspacePage(),
            BaseDatabasePage(), DataRecordsPage(), SystemSettingsPage(), QuotaLibraryPage(),
        ]
        buttons = []
        for owner in [window, *pages]:
            buttons.extend(owner.findChildren(QPushButton))
        with (
            patch.object(QMessageBox, "information", return_value=QMessageBox.Ok),
            patch.object(QMessageBox, "warning", return_value=QMessageBox.Ok),
            patch.object(QMessageBox, "critical", return_value=QMessageBox.Ok),
            patch.object(QMessageBox, "question", return_value=QMessageBox.No),
            patch.object(QFileDialog, "getOpenFileName", return_value=("", "")),
            patch.object(QFileDialog, "getSaveFileName", return_value=("", "")),
            patch.object(QFileDialog, "getExistingDirectory", return_value=""),
            patch.object(QInputDialog, "getItem", return_value=("", False)),
            patch("src.ui.system_settings.QDesktopServices.openUrl", return_value=True),
            patch.object(QDialog, "exec", return_value=QDialog.Rejected),
            patch.object(AISourceSearchWorker, "start", return_value=None),
            patch.object(ApiSnifferWorker, "start", return_value=None),
            patch.object(SubscriptionWorker, "start", return_value=None),
            patch.object(AIConnectionWorker, "start", return_value=None),
            patch.object(AISuggestWorker, "start", return_value=None),
            patch.object(AIValidateWorker, "start", return_value=None),
            patch.object(OfficialPriceUpdateWorker, "start", return_value=None),
            patch.object(QThread, "start", return_value=None),
            patch("src.ai_service.AIService.is_available", new_callable=PropertyMock, return_value=False),
        ):
            for button in buttons:
                button.click()
                self.app.processEvents()
        self.assertGreaterEqual(len(buttons), 80)

    def test_07_source_credentials_use_windows_encryption(self):
        from src.source_credentials import protect_text, unprotect_text
        encrypted = protect_text("member-cookie-value")
        self.assertNotIn("member-cookie-value", encrypted)
        self.assertEqual(unprotect_text(encrypted), "member-cookie-value")

    def test_07b_data_directory_switch_copies_local_data(self):
        with tempfile.TemporaryDirectory(prefix="dashuo-data-source-") as source_dir, \
             tempfile.TemporaryDirectory(prefix="dashuo-data-target-") as target_dir, \
             tempfile.TemporaryDirectory(prefix="dashuo-data-location-") as location_dir:
            source = Path(source_dir)
            target = Path(target_dir)
            current_db = source / "dashuo_cost_cloud.db"
            with closing(sqlite3.connect(current_db)) as connection:
                connection.execute("CREATE TABLE marker (value TEXT)")
                connection.execute("INSERT INTO marker VALUES ('source')")
                connection.commit()
            (source / "source_files").mkdir()
            (source / "source_files" / "official.xlsx").write_bytes(b"source-file")
            (source / "backups").mkdir()
            (source / "backups" / "backup.db").write_bytes(b"backup-file")

            config_type = type(config)
            with patch.object(config_type, "USER_DATA_DIR", source), \
                 patch.object(config_type, "DATABASE_URL", f"sqlite:///{current_db.as_posix()}"), \
                 patch.object(config_type, "DATA_LOCATION_FILE", Path(location_dir) / "data_location.txt"):
                success, message = config.configure_data_directory(target)

            self.assertTrue(success, message)
            self.assertTrue((target / "dashuo_cost_cloud.db").exists())
            self.assertEqual((target / "source_files" / "official.xlsx").read_bytes(), b"source-file")
            self.assertEqual((target / "backups" / "backup.db").read_bytes(), b"backup-file")
            self.assertEqual(
                (Path(location_dir) / "data_location.txt").read_text(encoding="utf-8"),
                str(target.resolve()),
            )
            with closing(sqlite3.connect(target / "dashuo_cost_cloud.db")) as connection:
                self.assertEqual(connection.execute("SELECT value FROM marker").fetchone()[0], "source")

    def test_08_bulk_zip_and_pagination_use_document_period(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="上海批量官网源",
                url="https://cost.example.gov.cn/zaojia/index.html",
                is_official=True,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
            region_id = shanghai.id
        finally:
            session.close()

        workbook_data = make_workbook([
            [f"市政材料{index:04d}", f"规格{index}", "m3", 100 + index]
            for index in range(120)
        ])
        zip_stream = BytesIO()
        with ZipFile(zip_stream, "w") as archive:
            archive.writestr("桥梁工程2026年06月.xlsx", workbook_data)

        root_url = "https://cost.example.gov.cn/zaojia/index.html"
        list_url = "https://cost.example.gov.cn/zaojia/list.html"
        next_url = "https://cost.example.gov.cn/zaojia/list_2.html"
        zip_url = "https://cost.example.gov.cn/files/上海市政信息价2026-06.zip"
        responses = {
            root_url: FakeResponse(f'<a href="{list_url}">工程造价信息栏目</a>'),
            list_url: FakeResponse(f'<a href="{next_url}">下一页</a>'),
            next_url: FakeResponse(f'<a href="{zip_url}">下载信息价附件</a>'),
            zip_url: FakeResponse(content=zip_stream.getvalue(), content_type="application/zip"),
        }

        with patch("src.subscription.requests.get", side_effect=lambda url, **kwargs: responses[url]):
            with SubscriptionEngine(period="2026-05", specialty="市政工程") as engine:
                result = engine.run_single_source(source_id)

        self.assertTrue(result["success"], result)
        self.assertEqual(result["new_prices"], 120)
        session = get_session()
        try:
            prices = session.query(MaterialPrice).filter(MaterialPrice.region_id == region_id).all()
            bulk_prices = [price for price in prices if price.material.name.startswith("市政材料")]
            self.assertEqual(len(bulk_prices), 120)
            self.assertEqual({price.period for price in bulk_prices}, {"2026-06"})
        finally:
            session.close()

    def test_09_global_price_search_and_strict_official_domain(self):
        self.assertTrue(is_official_domain("https://zjw.sh.gov.cn/info"))
        self.assertFalse(is_official_domain("https://example.com/path/.gov.cn"))
        base = BaseDatabasePage()
        base.set_search_query("上海 2026年6月 C30混凝土")
        self.assertEqual(base._official_prices._region.currentText(), "上海")
        self.assertEqual(base._official_prices._period.text(), "2026-06")
        self.assertEqual(base._official_prices._keyword.text(), "C30 混凝土")

    def test_10_duplicate_rows_do_not_rollback_source(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="重复行测试源",
                url="https://duplicate.example.gov.cn/2026-07/prices.xlsx",
                is_official=True,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
            region_id = shanghai.id
        finally:
            session.close()

        response = FakeResponse(
            content=make_workbook([
                ["重复测试材料", "规格A", "t", 51301],
                ["重复测试材料", "规格A", "t", 51301],
                ["重复测试材料", "规格B", "t", 52000],
            ]),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        with patch("src.subscription.requests.get", return_value=response):
            with SubscriptionEngine(period="2026-07") as engine:
                first = engine.run_single_source(source_id)
                second = engine.run_single_source(source_id)

        self.assertTrue(first["success"], first)
        self.assertEqual(first["new_prices"], 2)
        self.assertTrue(second["success"], second)
        self.assertEqual(second["new_prices"], 0)
        session = get_session()
        try:
            rows = session.query(MaterialPrice).join(Material).filter(
                MaterialPrice.region_id == region_id,
                Material.name == "重复测试材料",
                MaterialPrice.period == "2026-07",
            ).all()
            self.assertEqual({row.spec for row in rows}, {"规格A", "规格B"})
        finally:
            session.close()

    def test_11_home_dashboard_uses_real_database_data(self):
        home = HomePage()
        home.resize(900, 660)
        home.refresh_data()
        self.app.processEvents()
        self.assertEqual(home._metric_values["quota"].text(), "227")
        self.assertGreaterEqual(len(home._trend_chart._points), 2)
        self.assertGreater(home._category_layout.count(), 0)
        self.assertGreaterEqual(home._task_table.rowCount(), 1)

    def test_11b_project_info_page_uses_project_archive_fields(self):
        page = ProjectInfoPage()
        self.assertEqual(page._table.columnCount(), len(ProjectInfoPage.HEADERS))
        self.assertIn("项目所在地", ProjectInfoPage.HEADERS)
        self.assertIn("计价阶段", ProjectInfoPage.HEADERS)
        self.assertIn("造价专业", ProjectInfoPage.HEADERS)
        self.assertIn("更新时间", ProjectInfoPage.HEADERS)
        self.assertGreaterEqual(page._table.rowCount(), 1)
        from src.ui.project_info import _effective_status
        self.assertEqual(_effective_status(Mock(status="draft"), True), "进行中")
        self.assertEqual(_effective_status(Mock(status="locked"), False), "已锁定")
        self.assertEqual(_effective_status(Mock(status="draft"), False), "未开始")

    def test_12_non_price_documents_are_rejected(self):
        with SubscriptionEngine(period="2026-07") as engine:
            self.assertFalse(engine._is_plausible_price_record(
                "10《建筑电气制图标准》GB/", "", "T", 2012,
            ))
            self.assertFalse(engine._is_plausible_price_record(
                "本页面点击上传申请表文件", "", "件", 20,
            ))
            self.assertTrue(engine._is_plausible_price_record(
                "预拌混凝土", "C30", "m3", 410,
            ))
            parsed = engine._parse_grid(
                [
                    ["标准名称", "标准编号", "年份"],
                    ["建筑电气制图标准", "GB/T", "2012"],
                ],
                None,
                None,
                None,
            )
            self.assertEqual(parsed, 0)
            attachments, _ = engine._discover_links(
                '<div>工程造价信息</div>'
                '<a href="/files/manual.pdf">操作手册</a>'
                '<a href="/files/prices.xlsx">材料信息价附件</a>',
                "https://cost.example.gov.cn/info/index.html",
                "https://cost.example.gov.cn/info/index.html",
                True,
            )
            self.assertEqual(
                attachments,
                ["https://cost.example.gov.cn/files/prices.xlsx"],
            )

    def test_13_dynamic_official_page_uses_browser_json_capture(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="动态官网测试源",
                url="https://dynamic.example.gov.cn/pc/#/price-list",
                is_official=True,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
            region_id = shanghai.id
        finally:
            session.close()

        shell = '<html><body><div id="app"></div><script src="static/js/app.js"></script></body></html>'
        captured_json = '''{
            "data": {
                "records": [
                    {"materialName": "动态预拌混凝土", "specification": "C40", "unit": "m3", "informationPrice": 455.5},
                    {"materialName": "动态螺纹钢", "specification": "HRB400E", "unit": "t", "informationPrice": 3820}
                ]
            }
        }'''
        capture_result = {
            "success": True,
            "browser": "msedge.exe",
            "url": "https://dynamic.example.gov.cn/pc/#/price-list",
            "html": shell,
            "resources": [{
                "url": "https://dynamic.example.gov.cn/api/material-price/list",
                "mime_type": "application/json",
                "status": 200,
                "body": captured_json,
                "base64_encoded": False,
            }],
        }
        with (
            patch("src.subscription.requests.get", return_value=FakeResponse(shell)),
            patch("src.browser_capture.capture_dynamic_page", return_value=capture_result) as browser_capture,
        ):
            with SubscriptionEngine(period="2026-07") as engine:
                result = engine.run_single_source(source_id)

        self.assertTrue(result["success"], result)
        self.assertEqual(result["new_prices"], 2)
        browser_capture.assert_called_once()
        session = get_session()
        try:
            prices = session.query(MaterialPrice).join(Material).filter(
                MaterialPrice.region_id == region_id,
                Material.name.in_(["动态预拌混凝土", "动态螺纹钢"]),
            ).all()
            self.assertEqual(len(prices), 2)
            self.assertTrue(all(price.trust_level == "official" for price in prices))
            documents = session.query(SourceDocument).filter(SourceDocument.source_id == source_id).all()
            self.assertTrue(any(document.file_type == "json" for document in documents))
        finally:
            session.close()

    def test_14_reposted_official_source_stays_in_market_reference_tier(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="转载信息价测试源",
                url="https://reference.example.com/prices.xlsx",
                is_official=False,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
        finally:
            session.close()

        response = FakeResponse(
            content=make_workbook([["转载混凝土", "C30", "m3", 420]]),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        with patch("src.subscription.requests.get", return_value=response):
            with SubscriptionEngine(period="2026-07") as engine:
                result = engine.run_single_source(source_id)

        self.assertTrue(result["success"], result)
        self.assertEqual(result["new_prices"], 1)
        session = get_session()
        try:
            price = session.query(MaterialPrice).join(Material).filter(Material.name == "转载混凝土").one()
            self.assertEqual(price.trust_level, "market_reference")
        finally:
            session.close()

    def test_15_api_sniffer_redacts_credentials_and_shanghai_is_default(self):
        import inspect
        from src.api_fetcher import shanghai_gov_fetch, shenzhen_gov_fetch

        self.assertEqual(_extract_period("2026年07月信息价", "2026-07-20"), "2026-07")
        sanitized = sanitize_post_data("bmCode=003002&token=private-token&password=123456")
        self.assertIn("bmCode=003002", sanitized)
        self.assertNotIn("private-token", sanitized)
        self.assertNotIn("123456", sanitized)
        page = PriceInfoPage()
        self.assertEqual(page._subscription_tab._city_combo.currentText(), "上海")
        self.assertEqual(page._source_tab._sniff_btn.text(), "API嗅探（排错）")
        self.assertEqual(page._source_tab._update_all_btn.text(), "一键更新全部")
        self.assertTrue(has_api_handler("https://ciac.zjw.sh.gov.cn/JGBXMGCZJInterWeb/pc/"))
        self.assertTrue(has_api_handler("https://zjj.sz.gov.cn/szzjxx/web/pc/index"))
        self.assertTrue(has_api_handler("https://www.xjzj.com/"))
        self.assertFalse(has_api_handler("https://example.gov.cn/cost/"))
        self.assertIn("source_id", inspect.signature(shanghai_gov_fetch).parameters)
        self.assertIn("source_id", inspect.signature(shenzhen_gov_fetch).parameters)
        strategy_cities, status_cities = page._subscription_tab._strategy_city_map()
        self.assertEqual(
            strategy_cities["api"],
            ["上海", "乌鲁木齐", "佛山", "北京", "呼和浩特", "大连", "天津", "宁波", "广州", "徐州", "昆明", "杭州", "深圳", "珠海", "石家庄", "绵阳", "连云港", "郑州", "重庆", "长春", "长沙", "青岛"],
        )
        self.assertIn("成都", strategy_cities["browser_login"])
        self.assertIn("佛山", status_cities["working"])

    def test_16_api_source_import_is_traceable_and_idempotent(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="上海API幂等测试源",
                url="https://ciac.zjw.sh.gov.cn/test-api-source",
                source_type="api",
                is_official=True,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
            region_id = shanghai.id
        finally:
            session.close()

        api_result = {
            "count": 2,
            "period": "2026-07",
            "prices": [
                {"name": "API测试水泥", "spec": "P.O 42.5", "unit": "t", "price": 420, "category": "建筑"},
                {"name": "API测试水泥", "spec": "P.O 52.5", "unit": "t", "price": 465, "category": "建筑"},
            ],
            "document": {
                "file_name": "2026-07_上海信息价.xls",
                "url": "https://ciac.zjw.sh.gov.cn/download?id=test",
                "content": b"official-xls-fixture",
            },
        }
        with patch("src.subscription.fetch_api_source", return_value=api_result):
            with SubscriptionEngine(period="2026-07") as engine:
                first = engine.run_single_source(source_id)
            with SubscriptionEngine(period="2026-07") as engine:
                second = engine.run_single_source(source_id)

        self.assertTrue(first["success"], first)
        self.assertEqual(first["new_prices"], 2)
        self.assertTrue(second["success"], second)
        self.assertEqual(second["new_prices"], 0)
        session = get_session()
        try:
            prices = session.query(MaterialPrice).join(Material).filter(
                MaterialPrice.region_id == region_id,
                Material.name == "API测试水泥",
            ).all()
            self.assertEqual(len(prices), 2)
            self.assertTrue(all(price.period == "2026-07" and price.source_doc_id for price in prices))
            documents = session.query(SourceDocument).filter(SourceDocument.source_id == source_id).all()
            self.assertEqual(len(documents), 2)
            self.assertTrue(all(document.is_parsed for document in documents))
        finally:
            session.close()



    def test_17_api_rows_with_same_material_spec_keep_distinct_prices(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="上海同规格不同价格测试源",
                url="https://ciac.zjw.sh.gov.cn/test-duplicate-api-source",
                source_type="api",
                is_official=True,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
            region_id = shanghai.id
        finally:
            session.close()

        api_result = {
            "count": 2,
            "period": "2026-07",
            "prices": [
                {"code": "DUP-001", "name": "同规格材料", "spec": "标准", "unit": "t", "price": 100, "category": "建筑"},
                {"code": "DUP-001", "name": "同规格材料", "spec": "标准", "unit": "t", "price": 120, "category": "建筑"},
            ],
            "document": {"file_name": "duplicate.xls", "url": "https://ciac.zjw.sh.gov.cn/duplicate.xls", "content": b"fixture"},
        }
        with patch("src.subscription.fetch_api_source", return_value=api_result):
            with SubscriptionEngine(period="2026-07") as engine:
                first = engine.run_single_source(source_id)
            with SubscriptionEngine(period="2026-07") as engine:
                second = engine.run_single_source(source_id)

        self.assertTrue(first["success"], first)
        self.assertEqual(first["new_prices"], 2)
        self.assertTrue(second["success"], second)
        self.assertEqual(second["new_prices"], 0)
        session = get_session()
        try:
            prices = session.query(MaterialPrice).join(Material).filter(
                MaterialPrice.region_id == region_id,
                Material.name == "同规格材料",
            ).all()
            self.assertEqual({price.price for price in prices}, {100.0, 120.0})
            self.assertEqual(len(prices), 2)
        finally:
            session.close()

    def test_18_shenzhen_adapter_parses_official_prices(self):
        from src.api_fetcher import shenzhen_gov_fetch

        class FakeJsonResponse:
            def __init__(self, payload):
                self._payload = payload

            @property
            def text(self):
                import json as jsonlib
                return jsonlib.dumps(self._payload, ensure_ascii=False)

            def json(self):
                return self._payload

        def fake_post(url, **kwargs):
            if url.endswith("/currentyear"):
                return FakeJsonResponse([
                    {"id": "p202607", "yearMonth": "202607", "periodName": "2026年7月价格信息"},
                    {"id": "p202606", "yearMonth": "202606", "periodName": "2026年6月价格信息"},
                ])
            if url.endswith("/getcategorytreelist"):
                return FakeJsonResponse([
                    {"id": "top1", "name": "建筑材料", "children": [
                        {"id": "2082650634552750080", "name": "1.黑色及有色金属", "children": []},
                    ]},
                ])
            if url.endswith("/all"):
                return FakeJsonResponse({
                    "total": 3,
                    "rows": [
                        {"mc": "热轧光圆钢筋 HPB300", "gg": "φ6盘卷", "dw": "t", "djSq": "3688.0", "categoryid": 2082650634552750080, "jgCode": "010101"},
                        {"mc": "热轧带肋钢筋 HRB400E", "gg": "φ8 盘卷", "dw": "t", "djSq": "3565.0", "categoryid": 2082650634552750080, "jgCode": "010102"},
                        {"mc": "区间价材料", "gg": "φ10", "dw": "t", "djSq": "3500-3600", "categoryid": 2082650634552750080, "jgCode": "010103"},
                    ],
                })
            raise AssertionError(f"unexpected url {url}")

        with patch("src.api_fetcher.requests.post", side_effect=fake_post):
            result = shenzhen_gov_fetch("https://zjj.sz.gov.cn/szzjxx/web/pc/index", None)

        self.assertNotIn("error", result, result)
        self.assertEqual(result["count"], 3)
        self.assertEqual(result["period"], "2026-07")
        self.assertEqual(result["prices"][0]["name"], "热轧光圆钢筋 HPB300")
        self.assertEqual(result["prices"][0]["category"], "1.黑色及有色金属")
        self.assertEqual(result["prices"][2]["price"], 3550.0)
        self.assertTrue(result["document"]["content"])

        session = get_session()
        try:
            region = session.query(Region).filter(Region.code == "440300").first()
            self.assertIsNotNone(region)
            primary = session.query(OfficialSource).filter(
                OfficialSource.region_id == region.id,
                OfficialSource.url == "https://zjj.sz.gov.cn/szzjxx/web/pc/index",
            ).first()
            self.assertIsNotNone(primary)
            self.assertTrue(primary.is_active)
            self.assertEqual(primary.source_type, "api")
        finally:
            session.close()

    def test_18_sichuan_adapter_reports_restricted_prices(self):
        from src.api_fetcher import sichuan_gov_fetch

        class FakeJsonResponse:
            def __init__(self, payload):
                self._payload = payload

            def raise_for_status(self):
                return None

            def json(self):
                return self._payload

        def fake_request(method, url, **kwargs):
            params = kwargs.get("params") or {}
            if params.get("Type") == "HQCLJGNFXX":
                return FakeJsonResponse([{"id": 2015, "text": "2015年"}])
            if params.get("Type") == "BDJGXX":
                return FakeJsonResponse({
                    "total": "2",
                    "html": (
                        "<tr><td>170370</td><td>电</td><td></td><td>度</td>"
                        "<td>会员查看</td><td>201508</td><td>成都市</td></tr>"
                        "<tr><td>170308</td><td>水</td><td></td><td>m3</td>"
                        "<td>会员查看</td><td>201507</td><td>成都市</td></tr>"
                    ),
                })
            raise AssertionError(f"unexpected request {method} {url} {params}")

        with patch("src.api_fetcher.requests.request", side_effect=fake_request):
            result = sichuan_gov_fetch(
                "http://202.61.90.35:8037/jgxx.htm?code=5101",
                None,
            )

        self.assertNotIn("error", result, result)
        self.assertTrue(result["access_restricted"])
        self.assertEqual(result["catalog_count"], 2)
        self.assertEqual(result["period"], "2015-08")
        self.assertEqual(result["count"], 0)
        self.assertIn("会员查看", result["message"])
        self.assertTrue(result["document"]["content"])
        self.assertTrue(is_official_domain("http://202.61.90.35:8037/"))

        session = get_session()
        try:
            region = session.query(Region).filter(Region.code == "510100").first()
            source = session.query(OfficialSource).filter(
                OfficialSource.region_id == region.id,
                OfficialSource.url == "http://202.61.90.35:8037/jgxx.htm?code=5101",
            ).first()
            self.assertIsNotNone(source)
            self.assertTrue(source.is_official)
            self.assertTrue(source.is_active)
            self.assertEqual(source.source_type, "api")
        finally:
            session.close()

    def test_19_sichuan_adapter_parses_authorized_prices(self):
        from src.api_fetcher import sichuan_gov_fetch

        class FakeJsonResponse:
            def __init__(self, payload):
                self._payload = payload

            def raise_for_status(self):
                return None

            def json(self):
                return self._payload

        def fake_request(method, url, **kwargs):
            params = kwargs.get("params") or {}
            if params.get("Type") == "HQCLJGNFXX":
                return FakeJsonResponse([{"id": 2015, "text": "2015年"}])
            if params.get("Type") == "BDJGXX":
                return FakeJsonResponse({
                    "total": "2",
                    "html": (
                        "<tr><td>165285</td><td>柴油</td><td>#0</td><td>kg</td>"
                        "<td>7.65</td><td>201508</td><td>成都市</td></tr>"
                        "<tr><td>165256</td><td>汽油</td><td>#93</td><td>kg</td>"
                        "<td>8.12</td><td>201508</td><td>成都市</td></tr>"
                    ),
                })
            raise AssertionError(f"unexpected request {method} {url} {params}")

        with patch("src.api_fetcher.requests.request", side_effect=fake_request):
            result = sichuan_gov_fetch(
                "http://202.61.90.35:8037/jgxx.htm?code=5101",
                None,
                period_filter="2015-08",
            )

        self.assertNotIn("error", result, result)
        self.assertEqual(result["period"], "2015-08")
        self.assertEqual(result["count"], 2)
        self.assertEqual(result["prices"][0]["name"], "柴油")
        self.assertEqual(result["prices"][0]["price"], 7.65)
        self.assertEqual(result["prices"][1]["category"], "四川材料信息价/成都市")

    def test_20_urumqi_adapter_discovers_and_parses_official_xlsx(self):
        from io import BytesIO
        from openpyxl import Workbook
        from src.api_fetcher import fetch_api_source

        workbook = Workbook()
        sheet = workbook.active
        sheet.append(["附件", "", "", "", ""])
        sheet.append(["乌鲁木齐市2026年5月份建设工程综合价格信息", "", "", "", ""])
        sheet.append(["序号", "材料名称及规格型号", "单位", "除税综合\n信息价", "含税综合\n信息价"])
        sheet.append(["钢材", "", "", "", ""])
        sheet.append(["1", "低碳热轧盘条 HPB300 Φ6", "t", 3285.03, 3703.88])
        sheet.append(["2", "热轧带肋钢筋 HRB400E Φ8", "t", 3565.0, 4028.45])
        output = BytesIO()
        workbook.save(output)
        workbook.close()
        xlsx_content = output.getvalue()

        class FakeResponse:
            def __init__(self, *, text="", content=b""):
                self.text = text
                self.content = content
                self.encoding = "utf-8"
                self.apparent_encoding = "utf-8"

            def raise_for_status(self):
                return None

        def fake_get(url, **kwargs):
            if url == "https://www.xjzj.com/":
                return FakeResponse(text=(
                    '<a href="/Home/PoliciesDetail/6806">'
                    "乌鲁木齐市2026年5月份建设工程综合价格信息</a>"
                ))
            if url.endswith("/Home/PoliciesDetail/6806"):
                return FakeResponse(text=(
                    "<a href=\"javascript:LookFile('/Upload/File/test/"
                    "乌鲁木齐市2026年5月份建设工程综合价格信息.xlsx')\">下载</a>"
                ))
            if "/Upload/File/test/" in url:
                return FakeResponse(content=xlsx_content)
            raise AssertionError(f"unexpected url {url}")

        with patch("src.api_fetcher.requests.get", side_effect=fake_get):
            result = fetch_api_source(
                "https://www.xjzj.com/",
                None,
                source_id=108,
                period_filter="2026-05",
            )

        self.assertNotIn("error", result, result)
        self.assertEqual(result["count"], 2)
        self.assertEqual(result["period"], "2026-05")
        self.assertEqual(result["prices"][0]["name"], "低碳热轧盘条 HPB300 Φ6")
        self.assertEqual(result["prices"][0]["price"], 3285.03)
        self.assertEqual(result["prices"][0]["category"], "钢材")
        self.assertTrue(result["document"]["content"])
    def test_21_public_pdf_adapters_parse_structured_prices(self):
        from src.api_fetcher import _parse_qingdao_pdf, _parse_shijiazhuang_pdf

        class FakePage:
            def __init__(self, tables, text=""):
                self._tables = tables
                self._text = text

            def extract_tables(self):
                return self._tables

            def extract_text(self):
                return self._text

        class FakePdf:
            def __init__(self, pages):
                self.pages = pages

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return None

        shijiazhuang_pdf = FakePdf([FakePage([[
            ["一尧 钢 材", None, None, None, None, None],
            ["序号", "材料名称", "规格品种", "单位", "价格", "不含税价"],
            ["1", "线材", "HPB300", "t", "4050", "3584.07"],
            ["2", None, "HPB400", "t", "3850", "3407.08"],
        ]])])
        qingdao_pdf = FakePdf([FakePage([[
            ["序号", "名称", "规格型号", "单位", "含税价"],
            ["1", "预拌混凝土", "C30", "m3", "424.50"],
        ]], "预拌混凝土")])

        with patch("src.api_fetcher.pdfplumber.open", side_effect=[shijiazhuang_pdf, qingdao_pdf]):
            shijiazhuang = _parse_shijiazhuang_pdf(b"pdf", "2026-06")
            qingdao = _parse_qingdao_pdf(b"pdf", "2026-06")

        self.assertEqual(len(shijiazhuang), 2)
        self.assertEqual(shijiazhuang[1]["name"], "线材")
        self.assertEqual(shijiazhuang[0]["category"], "一、 钢 材")
        self.assertEqual(shijiazhuang[0]["price"], 4050.0)
        self.assertEqual(qingdao[0]["name"], "预拌混凝土")
        self.assertEqual(qingdao[0]["price"], 424.5)

    def test_22_changchun_zip_and_mianyang_xls_parsers(self):
        from src.api_fetcher import _parse_changchun_zip, _parse_mianyang_xls

        workbook = Workbook()
        worksheet = workbook.active
        worksheet.append(["二、材料价格信息", None, None, None, None, None])
        worksheet.append(["序号", "材料名称", "规格", "单位", "除税价", "含税价"])
        worksheet.append([1, "热轧带肋钢筋", "HRB400E", "t", 3500, 3955])
        xlsx_stream = BytesIO()
        workbook.save(xlsx_stream)
        workbook.close()
        zip_stream = BytesIO()
        with ZipFile(zip_stream, "w") as archive:
            archive.writestr("长春市2026年第二季度建设工程价格信息.xlsx", xlsx_stream.getvalue())

        changchun = _parse_changchun_zip(zip_stream.getvalue(), "2026-Q2")
        self.assertEqual(len(changchun), 1)
        self.assertEqual(changchun[0]["price"], 3955.0)
        self.assertEqual(changchun[0]["category"], "二、材料价格信息")

        class FakeSheet:
            name = "Sheet1"
            rows = [
                ["序号", "材料名称", "规格型号", "单位", "不含税信息价(元)", "Guid"],
                [1, "普通商品砼", "C30", "m3", "410", ""],
            ]
            nrows = len(rows)

            def row_values(self, index):
                return self.rows[index]

        class FakeWorkbook:
            def sheets(self):
                return [FakeSheet()]

        with patch("src.api_fetcher.xlrd.open_workbook", return_value=FakeWorkbook()):
            mianyang = _parse_mianyang_xls(b"xls", "2026-06")
        self.assertEqual(len(mianyang), 1)
        self.assertEqual(mianyang[0]["name"], "普通商品砼")
        self.assertEqual(mianyang[0]["price"], 410.0)

    def test_23_new_public_sources_are_enabled_only_after_data_validation(self):
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES

        urls = {
            "石家庄": "https://zjj.sjz.gov.cn/columns/38884fcc-b2c6-46a2-83e5-e9a2a178d559/index.html",
            "长春": "http://xxgk.jl.gov.cn/zcbm/fgw_98022/xxgkmlqy/",
            "青岛": "http://sjw.qingdao.gov.cn/cxjsj13/cxjs_95/cxjsj_gczjxx13/",
            "绵阳": "https://zjw.my.gov.cn/myszjj/c101133/list.shtml",
            "郑州": "https://zzjsj.zhengzhou.gov.cn/zjxx/index.jhtml",
            "佛山": "http://fszj.foshan.gov.cn/ywxt/jsgczjfwzx/zwzt_1110045/jjyjgl/jgxx/scjg/index.html",
            "呼和浩特": "http://zfcxjsj.huhhot.gov.cn/bsfw_91/xzzx/zjxx/",
            "天津": "https://zfcxjs.tj.gov.cn/ztzl_70/jjjgcjjjyth/jjjgx/glgczjxx/",
            "大连": "https://fwpt.zjt.ln.gov.cn/gczj/gczj/oldJgk/api/search.xhtml?selType=dz",
            "昆明": "https://www.ynbzde.com/catlist.html?catid=32",
            "宁波": "https://www.nbzj.net/Book/ElectronicJournalList.aspx?CategoryId=194",
            "重庆": "http://www.cqsgczjxx.org/Pages/CQZJW/index.aspx",
            "长沙": "http://zjt.hunan.gov.cn/zjt/hnweb/xzzx/zlxx/",
        }
        for city, url in urls.items():
            self.assertEqual(CITY_AUDIT_STATUS[city]["status"], "working")
            self.assertTrue(has_api_handler(url))
            self.assertTrue(any(source.get("data_status") == "working" for source in CITY_SOURCES[city]))

        self.assertEqual(CITY_AUDIT_STATUS["杭州"]["status"], "working")
        self.assertEqual(CITY_AUDIT_STATUS["太原"]["status"], "public_scanned_document")

    def test_23b_zhuhai_monthly_pdf_source_is_working(self):
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES

        self.assertEqual(CITY_AUDIT_STATUS["珠海"]["status"], "working")
        self.assertTrue(any(
            source.get("strategy") == "api"
            and source.get("data_status") == "working"
            and "hygl/zzxx" in source.get("url", "")
            for source in CITY_SOURCES["珠海"]
        ))

    def test_24_zhengzhou_and_foshan_pdf_parsers(self):
        from src.api_fetcher import _parse_foshan_green_pdf, _parse_zhengzhou_pdf

        class FakePage:
            def __init__(self, table):
                self._table = table

            def extract_tables(self):
                return [self._table]

        class FakePdf:
            def __init__(self, pages):
                self.pages = pages

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        zhengzhou_pdf = FakePdf([FakePage([
            ["序号", "材料名称", "规格型号", "单位", "含税单价", "不含税单价"],
            ["1", "预应力钢筋", "φ10mm以内", "t", "4200.00", "3716.81"],
        ])])
        foshan_pdf = FakePdf([FakePage([
            ["代码", "材料名称", "规格", "单位", "税前价", None, None, None, "备注"],
            [None, None, None, None, "4月", "5月", "6月", "季度价", None],
            ["", "仿石类保温装饰一体板", "1220*2440", "㎡", "103.00～110.00",
             "103.00～110.00", "103.00～110.00", "103.00～110.00", ""],
            ["", None, "600*800", "㎡", "101.00～108.00", "101.00～108.00",
             "101.00～108.00", "101.00～108.00", ""],
        ])])

        with patch("src.api_fetcher.pdfplumber.open", side_effect=[zhengzhou_pdf, foshan_pdf]):
            zhengzhou = _parse_zhengzhou_pdf(b"pdf", "2026-06")
            foshan = _parse_foshan_green_pdf(b"pdf", "2026-Q2")

        self.assertEqual(zhengzhou[0]["price"], 4200.0)
        self.assertEqual(zhengzhou[0]["period"], "2026-06")
        self.assertEqual(len(foshan), 2)
        self.assertEqual(foshan[0]["price"], 106.5)
        self.assertEqual(foshan[0]["raw_price"], "103.00～110.00")
        self.assertEqual(foshan[1]["name"], "仿石类保温装饰一体板")
        self.assertEqual(foshan[1]["period"], "2026-Q2")

    def test_25_hohhot_pdf_parser_deduplicates_material_rows(self):
        from src.api_fetcher import _hohhot_period, _parse_hohhot_pdf

        class FakePage:
            def extract_tables(self):
                return [[
                    ["一、通用及建筑装饰材料", None, None, None, None, None, None],
                    ["材料编码", "材料名称及规格型号", "计量单位", "含税价格", "除税价格", "平均税率", "备注"],
                    ["01010001", "钢筋HPB300(高线) Φ6", "t", "3570.00", "3167.98", "12.69", ""],
                    ["01010001", "钢筋HPB300(高线) Φ6", "t", "3570.00", "3167.98", "12.69", ""],
                    ["序号", "工种", "日工资", "备注"],
                    ["1", "建筑工程普工", "220", ""],
                ]]

        class FakePdf:
            pages = [FakePage()]

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        with patch("src.api_fetcher.pdfplumber.open", return_value=FakePdf()):
            prices = _parse_hohhot_pdf(b"pdf", "2026-06")

        self.assertEqual(_hohhot_period("2026年第3期（5-6月份）"), "2026-06")
        self.assertEqual(len(prices), 1)
        self.assertEqual(prices[0]["name"], "钢筋")
        self.assertEqual(prices[0]["spec"], "HPB300(高线) Φ6")
        self.assertEqual(prices[0]["price"], 3570.0)

    def test_26_kunming_price_html_parser_requires_city_price_fields(self):
        from src.api_fetcher import _parse_kunming_price_html

        html = """
        <div class="header_price_table"><div>名称</div><div>规格型号</div><div>单位</div></div>
        <div class="body">
          <div><span class="titlename">普通硅酸盐水泥（散装）</span></div>
          <div><span>P·O42.5</span></div><div><span>t</span></div>
          <div><span>303.00</span></div><div><span>2026-06</span></div><div><span>昆明市</span></div>
        </div>
        <div class="body">
          <div><span>外地材料</span></div><div><span>综合</span></div><div><span>t</span></div>
          <div><span>999.00</span></div><div><span>2026-06</span></div><div><span>曲靖市</span></div>
        </div>
        <div class="body">
          <div><span>无价格</span></div><div><span>综合</span></div><div><span>t</span></div>
          <div><span>-</span></div><div><span>2026-06</span></div><div><span>昆明市</span></div>
        </div>
        """

        prices = _parse_kunming_price_html(html, "2026-06")

        self.assertEqual(len(prices), 1)
        self.assertEqual(prices[0]["name"], "普通硅酸盐水泥（散装）")
        self.assertEqual(prices[0]["spec"], "P·O42.5")
        self.assertEqual(prices[0]["unit"], "t")
        self.assertEqual(prices[0]["price"], 303.0)
        self.assertEqual(prices[0]["period"], "2026-06")

    def test_27_guangzhou_pdf_parser_handles_columns_ranges_and_merged_cells(self):
        from src.api_fetcher import _parse_guangzhou_pdf

        class FakePage:
            def __init__(self, tables, text):
                self._tables = tables
                self._text = text

            def extract_tables(self):
                return self._tables

            def extract_text(self):
                return self._text

        class FakePdf:
            def __init__(self, pages):
                self.pages = pages

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        steel_page = FakePage(
            [[
                ["\u4e00\u3001\u9ed1\u8272\u53ca\u6709\u8272\u91d1\u5c5e\u7a0e\u524d\u7efc\u5408\u4ef7\u683c", None, None, None, None, None, None, None, None, None, None, None],
                ["\u6750\u6599\u7f16\u7801", "\u6750\u6599\u540d\u79f0", "\u89c4\u683c", "\u5355\u4f4d", "\u7a0e\u524d\u7efc\u5408\u4ef7\u683c\uff08\u5143\uff09", None, "\u6750\u6599\u7f16\u7801", "\u6750\u6599\u540d\u79f0", "\u89c4\u683c", "\u5355\u4f4d", "\u7a0e\u524d\u7efc\u5408\u4ef7\u683c\uff08\u5143\uff09", None],
                ["010100360020390001", "\u5706 \u94a2", "\u03a610\u5185 HPB300", "t", "3122\uff5e3343", "3232", "012901310650090001", "\u70ed\u8f67\u8584\u94a2\u677f", "1.6--1.8", "t", "3384.16", None],
                ["010100360070390001", None, "\u03a610\u5916 HPB300", "t", "3088\uff5e3320", "3204", "012901310670090001", None, "2.0--2.5", "t", "3296.18", None],
            ]],
            "2026\u5e746\u6708\u5e7f\u5dde\u5730\u533a\u5efa\u8bbe\u5de5\u7a0b\u5e38\u7528\u6750\u6599\u7a0e\u524d\u7efc\u5408\u4ef7\u683c",
        )
        pipe_page = FakePage(
            [[
                ["\u94a2\u7b4b\u6df7\u51dd\u571f\u7ba1\u7a0e\u524d\u7efc\u5408\u4ef7\u683c", None, None, None, None, None, None, None, None],
                ["\u6750\u6599\u7f16\u7801", "\u6750\u6599\u540d\u79f0", "\u89c4\u683c", "\u7a0e\u524d\u7efc\u5408\u4ef7\u683c\uff08\u5143/m\uff09", None, "\u6750\u6599\u7f16\u7801", "\u6750\u6599\u540d\u79f0", "\u89c4\u683c", "\u7a0e\u524d\u7efc\u5408\u4ef7\u683c\uff08\u5143/m\uff09"],
                ["172902310000011602", "I\u7ea7\u94a2\u7b4b\u6df7\u51dd\u571f\u6392\u6c34\u7ba1", "\u03a6200\uff08\u58c1\u539a30\uff09", "32.13", None, "172902660000011222", "\u2161\u7ea7F\u578b\u94a2\u7b4b\u6df7\u51dd\u571f\u9876\u7ba1", "\u03a6800\uff08\u58c1\u539a80\uff09", "555.43"],
                ["172902310000009232", None, "\u03a6250\uff08\u58c1\u539a30\uff09", "39.80", None, "172902660000009712", None, "\u03a6900\uff08\u58c1\u539a90\uff09", "700.09"],
            ]],
            "\u94a2\u7b4b\u6df7\u51dd\u571f\u7ba1\u7a0e\u524d\u7efc\u5408\u4ef7\u683c\uff08\u5143/m\uff09",
        )
        merged_page = FakePage(
            [[
                ["\u4e94\u3001\u95e8\u7a97\u5236\u54c1", None, None, None, None, None, None, None, None, None, None],
                ["\u6750\u6599\u7f16\u7801", "\u6750\u6599\u540d\u79f0", "\u89c4\u683c", "\u5355\u4f4d", "\u7a0e\u524d\u7efc\u5408\u4ef7\u683c", "\u6750\u6599\u7f16\u7801", "\u6750\u6599\u540d\u79f0", None, "\u89c4\u683c", "\u5355\u4f4d", "\u7a0e\u524d\u7efc\u5408\u4ef7\u683c"],
                ["090502870000080001", "\u6c1f\u78b3\u55b7\u6d82\u94dd\u5355\u677f", "2.5mm", None, None, None, None, None, "m2", "295.87", None],
            ]],
            "\u4e94\u3001\u95e8\u7a97\u5236\u54c1",
        )

        with patch(
            "src.api_fetcher.pdfplumber.open",
            return_value=FakePdf([steel_page, pipe_page, merged_page]),
        ):
            prices = _parse_guangzhou_pdf(b"pdf", "2026-06")

        self.assertEqual(len(prices), 9)
        steel = next(price for price in prices if price["code"] == "010100360020390001")
        self.assertEqual(steel["name"], "\u5706 \u94a2")
        self.assertEqual(steel["price"], 3232.0)
        self.assertEqual(steel["unit"], "t")
        inherited = next(price for price in prices if price["code"] == "010100360070390001")
        self.assertEqual(inherited["name"], "\u5706 \u94a2")
        pipe = next(price for price in prices if price["code"] == "172902310000011602")
        self.assertEqual(pipe["unit"], "m")
        self.assertEqual(pipe["price"], 32.13)
        merged = next(price for price in prices if price["code"] == "090502870000080001")
        self.assertEqual(merged["unit"], "m2")
        self.assertEqual(merged["price"], 295.87)

    def test_28_jiangsu_parsers_and_source_statuses(self):
        from src.api_fetcher import _parse_jiangsu_lianyungang_pdf, _parse_jiangsu_xuzhou_xls
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES, get_city_source_config

        class FakeSheet:
            name = "Sheet1"
            rows = [
                ["序号", "材料编码", "名称", "规格", "计量单位", "含税单价", "除税单价", "增值税率"],
                ["1.0", "", "", "黑色及有色金属类", "", "", "", ""],
                ["2.0", "01010212", "螺纹钢", "Φ10 HRB335", "t", "3741.99", "3319.94", "0.13"],
            ]
            nrows = len(rows)

            def row_values(self, index):
                return self.rows[index]

        class FakeWorkbook:
            def sheets(self):
                return [FakeSheet()]

        with patch("src.api_fetcher.xlrd.open_workbook", return_value=FakeWorkbook()):
            xuzhou = _parse_jiangsu_xuzhou_xls(b"xls", "2026-06")
        self.assertEqual(len(xuzhou), 1)
        self.assertEqual(xuzhou[0]["code"], "01010212")
        self.assertEqual(xuzhou[0]["name"], "螺纹钢")
        self.assertEqual(xuzhou[0]["spec"], "Φ10 HRB335")
        self.assertEqual(xuzhou[0]["unit"], "t")
        self.assertEqual(xuzhou[0]["price"], 3741.99)
        self.assertEqual(xuzhou[0]["category"], "黑色及有色金属类")

        class FakePage:
            def __init__(self, tables):
                self._tables = tables

            def extract_tables(self):
                return self._tables

        class FakePdf:
            pages = [FakePage([[
                ["材料编码", "材料名称", "单位", "规格型号", "含税单价", "备注"],
                ["一、建筑材料", "", "", "", "", ""],
                ["4030105", "细砂", "t", "", "115", "111.72"],
            ]])]

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        with patch("src.api_fetcher.pdfplumber.open", return_value=FakePdf()):
            lianyungang = _parse_jiangsu_lianyungang_pdf(b"pdf", "2026-06")
        self.assertEqual(len(lianyungang), 1)
        self.assertEqual(lianyungang[0]["name"], "细砂")
        self.assertEqual(lianyungang[0]["unit"], "t")
        self.assertEqual(lianyungang[0]["price"], 115.0)

        xuzhou_sources = CITY_SOURCES["徐州"]
        lianyungang_sources = CITY_SOURCES["连云港"]
        self.assertTrue(xuzhou_sources[0]["url"].endswith("secondPageThird.html"))
        self.assertTrue(lianyungang_sources[0]["url"].endswith("secondPageThird.html"))
        self.assertTrue(xuzhou_sources[0]["is_official"])
        self.assertTrue(lianyungang_sources[0]["is_official"])
        self.assertEqual(xuzhou_sources[1]["data_status"], "membership_required")
        self.assertEqual(lianyungang_sources[1]["data_status"], "membership_required")
        self.assertEqual(CITY_AUDIT_STATUS["徐州"]["status"], "working")
        self.assertEqual(CITY_AUDIT_STATUS["连云港"]["status"], "working")
        nanjing = get_city_source_config("南京", "https://www.costku.com/nanjing/")
        self.assertIsNotNone(nanjing)
        self.assertFalse(nanjing["is_official"])
        self.assertEqual(nanjing["data_status"], "membership_required")

    def test_29_ningbo_parser_and_source_status(self):
        import fitz
        from src.api_fetcher import _latest_ningbo_journal, _parse_ningbo_pdf
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES, get_city_source_config

        pdf = fitz.open()
        page = pdf.new_page()
        page.insert_text((72, 72), "Test Steel")
        page.insert_text((220, 72), "HG6/C")
        page.insert_text((350, 72), "Phi6")
        page.insert_text((430, 72), "t")
        page.insert_text((470, 72), "6018")
        page.insert_text((72, 92), "Composite Beam")
        page.insert_text((220, 92), "-")
        page.insert_text((350, 92), "-")
        page.insert_text((430, 92), "m3")
        page.insert_text((470, 92), "2515")
        content = pdf.tobytes()
        pdf.close()
        prices = _parse_ningbo_pdf(content, "2026-07")
        self.assertEqual(len(prices), 2)
        steel = next(price for price in prices if price["unit"] == "t")
        self.assertEqual(steel["name"], "Test Steel")
        self.assertEqual(steel["price"], 6018.0)

        journal = _latest_ningbo_journal(
            '<a href="ElectronicJournalView.aspx?ContentId=9824"><img alt="2026年7月刊建材商情版"></a>',
            "https://www.nbzj.net/Book/ElectronicJournalList.aspx?CategoryId=194",
            "商情版",
            "2026-07",
        )
        self.assertIsNotNone(journal)
        self.assertEqual(journal[0], "2026-07")
        self.assertIn("ContentId=9824", journal[2])

        self.assertEqual(CITY_AUDIT_STATUS["宁波"]["status"], "working")
        ningbo = get_city_source_config(
            "宁波",
            "https://www.nbzj.net/Book/ElectronicJournalList.aspx?CategoryId=194",
        )
        self.assertIsNotNone(ningbo)
        self.assertEqual(ningbo["data_status"], "working")
        self.assertEqual(CITY_SOURCES["宁波"][1]["data_status"], "no_public_source")

    def test_30_chongqing_parser_and_source_status(self):
        from unittest.mock import patch

        from src.api_fetcher import _latest_chongqing_journal, _parse_chongqing_pdf
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES, get_city_source_config

        class FakePage:
            def __init__(self, text, table):
                self._text = text
                self._table = table

            def extract_text(self):
                return self._text

            def extract_tables(self):
                return [self._table]

        class FakePdf:
            def __init__(self, pages):
                self.pages = pages

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        page_text = (
            "价格信息 综合价格信息 重庆工程造价 / 2026年第7期\n"
            "长寿区\n"
            "序号 材料名称 规格及型号 单位 不含税价（元）"
        )
        table = [
            ["序号", "材料名称", "规格及型号", "单位", "不含税价（元）"],
            ["1", "工 设 水泥 建", "级（袋装） M 32.5", "t", "总 价 330"],
            ["2", "", "级（袋装） P·O 42.5", "t", "造 346"],
        ]
        fake_pdf = FakePdf([FakePage(page_text, table)])
        with patch("src.api_fetcher.pdfplumber.open", return_value=fake_pdf):
            prices = _parse_chongqing_pdf(b"pdf", "2026-07")
        self.assertEqual(len(prices), 2)
        self.assertEqual(prices[0]["name"], "水泥")
        self.assertEqual(prices[0]["spec"], "级（袋装） M 32.5")
        self.assertEqual(prices[0]["unit"], "t")
        self.assertEqual(prices[0]["price"], 330.0)
        self.assertEqual(prices[1]["name"], "水泥")
        self.assertEqual(prices[1]["price"], 346.0)
        self.assertIn("长寿区", prices[0]["category"])

        journal = _latest_chongqing_journal(
            '<div><h3>重庆工程造价信息</h3>'
            '<a href="http://manage.cqsgczjxx.org/_UploadFile/d4ca187c-ed78-4417-ad64-026a9bd5ce79.pdf">'
            '2026年第七期 总第416期</a></div>',
            "http://www.cqsgczjxx.org/Pages/CQZJW/index.aspx",
            "2026-07",
        )
        self.assertIsNotNone(journal)
        self.assertEqual(journal[0], "2026-07")
        self.assertIn("_UploadFile", journal[2])

        self.assertEqual(CITY_AUDIT_STATUS["重庆"]["status"], "working")
        chongqing = get_city_source_config(
            "重庆",
            "http://www.cqsgczjxx.org/Pages/CQZJW/index.aspx",
        )
        self.assertIsNotNone(chongqing)
        self.assertEqual(chongqing["data_status"], "working")
        self.assertEqual(CITY_SOURCES["重庆"][0]["strategy"], "api")

    def test_31_tianjin_parser_and_source_status(self):
        from unittest.mock import patch

        from src.api_fetcher import _latest_tianjin_journal, _parse_tianjin_pdf
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES, get_city_source_config

        class FakePage:
            def __init__(self, table):
                self._table = table

            def extract_tables(self):
                return [self._table]

        class FakePdf:
            def __init__(self, pages):
                self.pages = pages

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        table = [
            ["", "材料编码", "材料名称", "规格型号", "单位", "北京市", "天津市", "河北省"],
            ["1", "0101030002", "热轧带肋钢筋", "HRB400E φ10", "t", "3850.00", "3113.65", "--"],
        ]
        fake_pdf = FakePdf([FakePage(table)])
        with patch("src.api_fetcher.pdfplumber.open", return_value=fake_pdf):
            prices = _parse_tianjin_pdf(b"pdf", "2026-05")
        self.assertEqual(len(prices), 1)
        self.assertEqual(prices[0]["name"], "热轧带肋钢筋")
        self.assertEqual(prices[0]["unit"], "t")
        self.assertEqual(prices[0]["price"], 3113.65)
        self.assertIn("天津", prices[0]["category"])

        journal = _latest_tianjin_journal(
            '<a href="https://zfcxjs.tj.gov.cn/ztzl_70/jjjgcjjjyth/jjjgx/glgczjxx/202607/t20260708_7332089.html">'
            '2026年5月京津冀城市地下综合管廊工程造价信息</a>',
            "https://zfcxjs.tj.gov.cn/ztzl_70/jjjgcjjjyth/jjjgx/glgczjxx/",
            "2026-05",
        )
        self.assertIsNotNone(journal)
        self.assertEqual(journal[0], "2026-05")
        self.assertIn("t20260708_7332089.html", journal[2])

        self.assertEqual(CITY_AUDIT_STATUS["天津"]["status"], "working")
        tianjin = get_city_source_config(
            "天津",
            "https://zfcxjs.tj.gov.cn/ztzl_70/jjjgcjjjyth/jjjgx/glgczjxx/",
        )
        self.assertIsNotNone(tianjin)
        self.assertEqual(tianjin["data_status"], "working")
        self.assertEqual(CITY_SOURCES["天津"][0]["strategy"], "api")

    def test_32_liaoning_dalian_parser_and_source_status(self):
        from src.api_fetcher import _liaoning_dalian_latest_date, _parse_liaoning_dalian_html
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES, get_city_source_config

        html = """
        <table id="jmesa">
          <tr><td>材料号</td><td>材料名称</td><td>规格型号</td><td>计量单位</td>
              <td>单价（元）</td><td>备注</td><td>地区</td><td>发布日期</td><td>材料类别</td></tr>
          <tr><td>01001</td><td>低碳钢热轧圆盘条</td><td>6.5</td><td>t</td><td>3460.00</td>
              <td></td><td>大连市</td><td>2026年6月</td><td>黑色及有色金属</td></tr>
        </table>
        """
        prices = _parse_liaoning_dalian_html(html, "2026-06")
        self.assertEqual(len(prices), 1)
        self.assertEqual(prices[0]["code"], "01001")
        self.assertEqual(prices[0]["name"], "低碳钢热轧圆盘条")
        self.assertEqual(prices[0]["unit"], "t")
        self.assertEqual(prices[0]["price"], 3460.0)
        self.assertIn("大连", prices[0]["category"])

        date_info = _liaoning_dalian_latest_date(
            '<select id="dateSelect"><option value="2026-06-01 00:00:00">2026年6月</option></select>',
            "2026-06",
        )
        self.assertIsNotNone(date_info)
        self.assertEqual(date_info[0], "2026-06")
        self.assertIn("2026-06-01", date_info[1])

        self.assertEqual(CITY_AUDIT_STATUS["大连"]["status"], "working")
        dalian = get_city_source_config(
            "大连",
            "https://fwpt.zjt.ln.gov.cn/gczj/gczj/oldJgk/api/search.xhtml?selType=dz",
        )
        self.assertIsNotNone(dalian)
        self.assertEqual(dalian["data_status"], "working")
        self.assertEqual(CITY_SOURCES["大连"][0]["strategy"], "api")

    def test_33_hunan_changsha_parser_and_source_status(self):
        from unittest.mock import patch

        from src.api_fetcher import _hunan_changsha_period, _parse_hunan_changsha_pdf
        from src.official_sources_config import CITY_AUDIT_STATUS, CITY_SOURCES, get_city_source_config

        class FakePage:
            def __init__(self, table):
                self._table = table

            def extract_tables(self):
                return [self._table]

        class FakePdf:
            def __init__(self, pages):
                self.pages = pages

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        table = [
            ["序号", "编码", "名称", "规格", "单位", "长沙", None, "株洲", None],
            [None, None, None, None, None, "3月", "4月", "3月", "4月"],
            ["1", "RVYPTNP3810087DKG0", "热轧圆盘条（高线）", "HPB300 Φ8-Φ10", "kg", "3.260", "3.219", "3.160", "3.080"],
        ]
        fake_pdf = FakePdf([FakePage(table)])
        with patch("src.api_fetcher.pdfplumber.open", return_value=fake_pdf):
            prices = _parse_hunan_changsha_pdf(b"pdf", "2026-03/04")
        self.assertEqual(len(prices), 2)
        self.assertEqual(prices[0]["period"], "2026-03")
        self.assertEqual(prices[0]["price"], 3.260)
        self.assertEqual(prices[1]["period"], "2026-04")
        self.assertEqual(prices[1]["price"], 3.219)

        self.assertEqual(
            _hunan_changsha_period("2026年第二期（3-4月份）湖南省建设工程材料价格行情资讯"),
            "2026-03/04",
        )
        self.assertEqual(CITY_AUDIT_STATUS["长沙"]["status"], "working")
        changsha = get_city_source_config(
            "长沙",
            "http://zjt.hunan.gov.cn/zjt/hnweb/xzzx/zlxx/",
        )
        self.assertIsNotNone(changsha)
        self.assertEqual(changsha["data_status"], "working")
        self.assertEqual(CITY_SOURCES["长沙"][0]["strategy"], "api")

    def test_34_material_identity_reuses_standard_name_and_alias(self):
        from src.material_service import find_or_create_material
        from src.models import MaterialAlias

        session = get_session()
        try:
            material, created = find_or_create_material(
                session,
                "Identity Test Material C 30",
                unit="m3",
            )
            session.commit()
            same_material, alias_created = find_or_create_material(
                session,
                "IdentityTestMaterialC30",
                unit="m3",
            )
            session.commit()
            self.assertTrue(created)
            self.assertFalse(alias_created)
            self.assertEqual(material.id, same_material.id)
            self.assertEqual(
                session.query(MaterialAlias).filter(MaterialAlias.material_id == material.id).count(),
                1,
            )
        finally:
            session.close()

    def test_14b_user_url_source_is_separate_and_pending_confirmation(self):
        session = get_session()
        try:
            shanghai = session.query(Region).filter(Region.code == "310000").first()
            source = OfficialSource(
                region_id=shanghai.id,
                name="用户网址测试源",
                url="https://user.example.com/prices.xlsx",
                source_type="user_url",
                is_official=False,
                is_active=True,
            )
            session.add(source)
            session.commit()
            source_id = source.id
            region_id = shanghai.id
        finally:
            session.close()

        response = FakeResponse(
            content=make_workbook([["用户网址混凝土", "C30", "m3", 421]]),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        with patch("src.subscription.requests.get", return_value=response):
            with SubscriptionEngine(period="2026-07") as engine:
                result = engine.run_single_source(source_id)

        self.assertTrue(result["success"], result)
        self.assertEqual(result["new_prices"], 1)
        session = get_session()
        try:
            price = session.query(MaterialPrice).join(Material).filter(
                MaterialPrice.region_id == region_id,
                Material.name == "用户网址混凝土",
            ).one()
            self.assertEqual(price.source_type, "user_url")
            self.assertEqual(price.trust_level, "market_reference")
            self.assertTrue(price.is_confirmed)
        finally:
            session.close()

    def test_35_excel_import_accepts_common_headers_and_price_metadata(self):
        from src.utils import import_prices_from_excel

        session = get_session()
        try:
            region = session.query(Region).filter(Region.code == "310000").first()
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.append(["名称", "城市", "月份", "含税信息价", "规格型号", "计量单位", "数据来源"])
            worksheet.append(["Import Material C 30", region.name, "2026-08", 1200, "C30", "m3", "官方信息价"])
            worksheet.append(["ImportMaterialC30", region.name, "2026-08", 1210, "C30", "m3", "官方信息价"])
            path = TEST_ROOT / "flexible-price-import.xlsx"
            workbook.save(path)

            result = import_prices_from_excel(str(path), session)
            self.assertTrue(result["success"], result)
            self.assertEqual(result["imported"], 2)
            material_rows = session.query(Material).filter(
                Material.name == "Import Material C 30",
            ).all()
            self.assertEqual(len(material_rows), 1)
            price = session.query(MaterialPrice).filter(
                MaterialPrice.material_id == material_rows[0].id,
                MaterialPrice.region_id == region.id,
                MaterialPrice.period == "2026-08",
                MaterialPrice.spec == "C30",
            ).one()
            self.assertEqual(price.price, 1210)
            self.assertEqual(price.source_type, "official")
            self.assertEqual(price.price_basis, "tax_inclusive")
        finally:
            session.close()

if __name__ == "__main__":
    unittest.main(verbosity=2)
