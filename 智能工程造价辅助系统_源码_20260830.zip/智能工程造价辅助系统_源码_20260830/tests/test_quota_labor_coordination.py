import uuid
import unittest

from src.db import get_session
from src.models import QuotaComposition, QuotaItem
from src.quota_service import (
    build_quota_match_index,
    find_quota_composition_matches,
    labor_coordination_evidence,
)


class QuotaLaborCoordinationTests(unittest.TestCase):
    def test_machine_quota_with_manual_coordination_does_not_add_full_manual_excavation(self):
        session = get_session()
        token = uuid.uuid4().hex
        machine = QuotaItem(
            source_key=f"test-machine-labor-cover-{token}",
            major="测试人工配合",
            code="TEST-MACHINE-EXCAVATION",
            name="机械挖土方",
            feature="机械开挖、清底、人工修整边坡，综合考虑机械和人工配合",
            unit="m3",
        )
        manual = QuotaItem(
            source_key=f"test-manual-excavation-{token}",
            major="测试人工配合",
            code="TEST-MANUAL-EXCAVATION",
            name="人工挖土方",
            feature="人工挖土、就近堆放",
            unit="m3",
        )
        session.add_all([machine, manual])
        session.flush()
        session.add_all([
            QuotaComposition(
                quota_item_id=machine.id, category="机械费", code="TEST-MACHINE",
                name="机械挖土方", unit="m3", qty=1, no_tax_price=9.7,
            ),
            QuotaComposition(
                quota_item_id=manual.id, category="人工费", code="TEST-LABOR",
                name="人工挖土方", unit="m3", qty=1, no_tax_price=22.3,
            ),
        ])
        session.commit()
        try:
            self.assertIn("人工配合", labor_coordination_evidence(machine.name, machine.feature))
            matches = find_quota_composition_matches(
                session,
                "挖一般土方",
                "基坑开挖，人工捡底等费用综合考虑",
                "m3",
                major="测试人工配合",
                candidate_index=build_quota_match_index(session, "测试人工配合"),
                minimum_score=40,
                source_costs={"labor": 4.7, "machinery": 9.7},
            )
            self.assertIn(machine.id, [match["item"].id for match in matches])
            self.assertNotIn(manual.id, [match["item"].id for match in matches])
        finally:
            session.delete(machine)
            session.delete(manual)
            session.commit()
            session.close()


if __name__ == "__main__":
    unittest.main()
