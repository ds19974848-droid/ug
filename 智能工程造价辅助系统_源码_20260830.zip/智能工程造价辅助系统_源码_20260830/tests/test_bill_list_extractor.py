import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook

from src.bill_list_extractor import extract_specialized_bill_list


class BillListExtractorTest(unittest.TestCase):
    def test_format_a_extracts_features_quantity_and_f2_costs(self):
        with tempfile.TemporaryDirectory(prefix="bill-format-a-") as directory:
            path = Path(directory) / "format-a.xlsx"
            workbook = Workbook()
            bill = workbook.active
            bill.title = "F.1 分部分项工程和单价措施项目清单与计价表"
            bill.append(["序号", "项目编码", "项目名称", "", "项目特征", "单位", "工程量", "综合单价"])
            bill.append([1, "010101001001", "平整场地", "", "土壤类别：综合考虑", "m2", 12.5, 1.35])

            analysis = workbook.create_sheet("F.2 综合单价分析表")
            analysis.append(["项目编码", "(1) 010101001001"])
            subtotal = [None] * 16
            subtotal[0] = "小     计"
            subtotal[10], subtotal[12], subtotal[13], subtotal[14], subtotal[15] = (
                0.66, 2.5, 0.52, 0.05, 0.12
            )
            analysis.append(subtotal)
            workbook.save(path)

            result = extract_specialized_bill_list(str(path))

        self.assertEqual(result["format"], "广联达 F.1/F.2")
        self.assertEqual(len(result["items"]), 1)
        item = result["items"][0]
        self.assertEqual(item["code"], "010101001001")
        self.assertEqual(item["feature"], "土壤类别：综合考虑")
        self.assertEqual(item["quantity"], "12.5")
        self.assertEqual(item["costs"], (0.66, 2.5, 0.52, 0.05, 0.12))

    def test_format_b_extracts_calculation_sheet_costs(self):
        with tempfile.TemporaryDirectory(prefix="bill-format-b-") as directory:
            path = Path(directory) / "format-b.xlsx"
            workbook = Workbook()
            bill = workbook.active
            bill.title = "1_表10.2.2-16 分部分项工程清单与计价表"
            bill.append(["序号", "项目编码", "项目名称", "项目特征", "单位", "工程量", "合价", "综合单价"])
            bill.append([1, "040501001001", "混凝土基础", "C30，泵送", "m3", 8, 0, 125.0])

            analysis = workbook.create_sheet("1_表10.2.2-17 综合单价计算表")
            analysis.append(["序号", "项目编码", "项目名称", "项目特征", "单位", "人工费", "材料费", "机械费", "管理费", "利润"])
            analysis.append([1, "040501001001", "混凝土基础", "C30", "m3", 10, 20, 30, 4, 5])
            workbook.save(path)

            result = extract_specialized_bill_list(str(path))

        self.assertEqual(result["format"], "广联达表10.2.2-16/17")
        self.assertEqual(len(result["items"]), 1)
        item = result["items"][0]
        self.assertEqual(item["name"], "混凝土基础")
        self.assertEqual(item["feature"], "C30，泵送")
        self.assertEqual(item["costs"], (10, 20, 30, 4, 5))

    def test_generic_workbook_uses_existing_importer(self):
        with tempfile.TemporaryDirectory(prefix="bill-generic-") as directory:
            path = Path(directory) / "generic.xlsx"
            workbook = Workbook()
            worksheet = workbook.active
            worksheet.append(["序号", "工程名称", "单位"])
            worksheet.append([1, "普通清单", "项"])
            workbook.save(path)

            self.assertIsNone(extract_specialized_bill_list(str(path)))


if __name__ == "__main__":
    unittest.main()
