import unittest

from src.quota_service import (
    _candidate_logic,
    _declared_conversion_quantity,
    _earthwork_logic_conflict,
    _earthwork_profile,
    _material_match_allowed,
    mechanical_dedup_keys,
    _technical_specs,
    apply_explicit_unit_conversion,
    apply_specification_quantity_conversion,
    canonical_quota_major,
    composition_cost_breakdown,
    specification_relation,
    validate_ai_generated_quota,
)


class QuotaSpecificationConstraintTests(unittest.TestCase):
    def test_quota_major_alias_maps_ui_term_to_library_term(self):
        self.assertEqual(canonical_quota_major("土建"), "建筑")
        self.assertEqual(canonical_quota_major("建筑工程"), "建筑")
        self.assertEqual(canonical_quota_major("装修"), "装饰")
        self.assertEqual(canonical_quota_major("装饰"), "装饰")
        self.assertEqual(canonical_quota_major("市政"), "市政")

    def test_earthwork_profile_recognizes_soil_excavation_loading_and_scope(self):
        profile = _earthwork_profile("挖掘机挖装槽坑土方 四类土")
        self.assertEqual(profile["material"], "土方")
        self.assertTrue(profile["excavation"])
        self.assertTrue(profile["loading"])
        self.assertEqual(profile["scope"], "槽坑")

    def test_soil_excavation_cannot_match_rock_excavation(self):
        reason = _earthwork_logic_conflict(
            "挖掘机挖装槽坑土方 四类土",
            "挖掘机挖石渣",
        )
        self.assertIn("土石方对象冲突", reason)
        allowed, _, reasons = _candidate_logic(
            "挖掘机挖装槽坑土方 四类土",
            "挖掘机挖石渣",
            "m3",
            "m3",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("土石方对象冲突" in value for value in reasons))

    def test_excavation_cannot_match_transport_only_quota(self):
        allowed, _, reasons = _candidate_logic(
            "挖掘机挖装槽坑土方 四类土",
            "土方运输 10km",
            "m3",
            "m3",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("仅为土方运输" in value for value in reasons))

    def test_soil_slot_excavation_can_match_soil_loading_quota(self):
        allowed, _, reasons = _candidate_logic(
            "挖掘机挖装槽坑土方 四类土",
            "挖掘机挖装土",
            "m3",
            "m3",
        )
        self.assertTrue(allowed)
        self.assertTrue(any("单位一致" in value for value in reasons))

    def test_ai_conversion_parser_accepts_common_quantity_bases(self):
        self.assertAlmostEqual(
            _declared_conversion_quantity(
                "\u6bcf\u7c73\u7ba1\u9053\u542b\u7ba1\u4ef60.3\u4e2a",
                "m",
                "\u4e2a",
            ),
            0.3,
        )
        self.assertAlmostEqual(
            _declared_conversion_quantity(
                "\u6bcf\u516c\u91cc\u7535\u6746\u6570\u91cf=1000m/50m\u6863\u8ddd=20\u6839",
                "km",
                "\u6839",
            ),
            20,
        )
        self.assertAlmostEqual(
            _declared_conversion_quantity(
                "\u6bcf\u6839\u7535\u6746\u4e00\u5957\uff0c1km 25\u6839",
                "km",
                "\u5957",
            ),
            25,
        )
        self.assertAlmostEqual(
            _declared_conversion_quantity(
                "1km / 40m/\u6839 = 25\u6839/km",
                "km",
                "\u6839",
            ),
            25,
        )

    def test_concrete_grade_is_canonical_and_supports_chinese_form(self):
        self.assertIn("concrete_grade:C25", _technical_specs("混凝土强度等级：C 25"))
        self.assertIn("concrete_grade:C25", _technical_specs("混凝土强度等级：25"))

    def test_thickness_units_are_normalized(self):
        self.assertEqual(
            _technical_specs("20cm厚 C25 混凝土"),
            {"concrete_grade:C25", "thickness:T200MM"},
        )
        self.assertIn("thickness:T200MM", _technical_specs("厚度 200mm"))

    def test_concrete_can_use_constituent_material_components(self):
        allowed, reason = _material_match_allowed("C25混凝土面层", "水泥")
        self.assertTrue(allowed)
        self.assertIn("混凝土", reason)

    def test_concrete_alias_tong_matches_ready_mix_concrete(self):
        allowed, reason = _material_match_allowed("C25砼底板", "预拌混凝土C25")
        self.assertTrue(allowed, reason)
        allowed, reason, reasons = _candidate_logic(
            "C25砼底板", "C25混凝土底板浇筑", "m3", "m3",
        )
        self.assertTrue(allowed, reasons)

    def test_concrete_cannot_use_asphalt_concrete_component(self):
        allowed, reason = _material_match_allowed("C25混凝土面层", "沥青混凝土")
        self.assertFalse(allowed)
        self.assertIn("材料体系", reason)

    def test_mechanical_dedup_keeps_different_earthwork_scopes(self):
        slot = mechanical_dedup_keys("槽坑土方开挖", "挖装")
        general = mechanical_dedup_keys("一般土方开挖", "挖装")
        self.assertTrue(slot)
        self.assertTrue(general)
        self.assertTrue(slot.isdisjoint(general))

    def test_c25_cannot_match_c30(self):
        allowed, _, reasons = _candidate_logic(
            "混凝土面层 C25",
            "现浇混凝土面层 C30",
            "m2",
            "m2",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("冲突" in value for value in reasons))

    def test_explicit_grade_cannot_match_unqualified_candidate(self):
        allowed, _, reasons = _candidate_logic(
            "混凝土面层 C25",
            "现浇混凝土面层",
            "m2",
            "m2",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("缺少" in value for value in reasons))

    def test_explicit_material_cannot_match_different_material(self):
        allowed, _, reasons = _candidate_logic(
            "DN100 PVC排水管",
            "DN100镀锌钢管",
            "m",
            "m",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("材料" in value for value in reasons))

    def test_aluminium_landscape_wall_cannot_match_marble_wall(self):
        allowed, _, reasons = _candidate_logic(
            "铝板景墙",
            "干挂大理石复合板墙面",
            "m2",
            "m2",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("核心工程对象" in value for value in reasons))

    def test_matching_aluminium_wall_keeps_core_object_evidence(self):
        allowed, bonus, reasons = _candidate_logic(
            "铝板景墙 3厚铝板",
            "铝板景墙安装 3厚铝板",
            "m2",
            "m2",
        )
        self.assertTrue(allowed)
        self.assertGreater(bonus, 20)
        self.assertTrue(any("核心对象/材料体系一致" in value for value in reasons))

    def test_one_matching_family_cannot_hide_another_conflict(self):
        allowed, _, reasons = _candidate_logic(
            "20cm厚 C25混凝土面层",
            "20cm厚 C30混凝土面层",
            "m2",
            "m2",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("强度等级" in value for value in reasons))

    def test_thickness_difference_creates_auditable_material_conversion(self):
        relation = specification_relation(
            "20cm厚 C25混凝土面层",
            "10cm厚 C25混凝土面层",
        )
        self.assertTrue(relation["compatible"])
        self.assertAlmostEqual(relation["conversions"][0]["ratio"], 2.0)

        material = apply_specification_quantity_conversion(
            {
                "cat": "主材费",
                "name": "C25混凝土",
                "unit": "m3",
                "qty": 1,
                "noTaxPrice": 100,
                "taxPrice": 113,
            },
            "20cm厚 C25混凝土面层",
            "10cm厚 C25混凝土面层",
        )
        labor = apply_specification_quantity_conversion(
            {
                "cat": "人工费",
                "name": "混凝土浇筑人工",
                "unit": "工日",
                "qty": 1,
                "noTaxPrice": 100,
                "taxPrice": 113,
            },
            "20cm厚 C25混凝土面层",
            "10cm厚 C25混凝土面层",
        )
        self.assertEqual(material["specConversionFactor"], 2.0)
        self.assertEqual(labor["specConversionFactor"], 1.0)
        calculated = composition_cost_breakdown({**material, "boqUnit": "m2"})
        self.assertAlmostEqual(calculated["unitNoTaxTotal"], 200.0)

    def test_mix_ratio_is_a_specification_family(self):
        self.assertIn("mix_ratio:R1:3", _technical_specs("30厚1:3干硬性水泥砂浆"))
        allowed, _, reasons = _candidate_logic(
            "30厚1:3干硬性水泥砂浆找平层",
            "30厚1:2干硬性水泥砂浆找平层",
            "m2",
            "m2",
        )
        self.assertFalse(allowed)
        self.assertTrue(any("配合比" in value for value in reasons))

    def test_ai_keeps_positive_material_consumption_without_prose_formula_actionable(self):
        result = validate_ai_generated_quota(
            {"name": "人行道混凝土基层", "feature": "", "unit": "m2"},
            {
                "name": "人行道混凝土基层浇筑",
                "feature": "C25混凝土基层浇筑",
                "unit": "m2",
                "components": [{
                    "cat": "材料费",
                    "name": "预拌混凝土C25",
                    "unit": "m3",
                    "qty": 0.15,
                    "noTaxPrice": 400,
                    "taxRate": 13,
                    "taxPrice": 452,
                    "calculation_basis": "当地市场估算",
                }],
            },
            [],
        )
        self.assertTrue(result["valid"], result)
        self.assertEqual(result["status"], "accepted_with_warning")
        component = result["quota"]["components"][0]
        self.assertTrue(component["included"])
        self.assertAlmostEqual(component["qty"], 0.15)
        self.assertIn("每1m2", component["unitConversion"])

    def test_ai_derives_area_volume_quantity_from_explicit_thickness(self):
        result = validate_ai_generated_quota(
            {
                "name": "人行道混凝土基层",
                "feature": "15cm厚C25混凝土基层浇筑",
                "unit": "m2",
            },
            {
                "name": "人行道混凝土基层浇筑",
                "feature": "15cm厚C25混凝土基层浇筑",
                "unit": "m3",
                "components": [{
                    "cat": "材料费",
                    "name": "预拌混凝土C25",
                    "feature": "15cm厚C25混凝土基层浇筑",
                    "unit": "m3",
                    "qty": 1,
                    "noTaxPrice": 400,
                    "taxRate": 13,
                    "taxPrice": 452,
                    "calculation_basis": "按清单明确厚度计算",
                }],
            },
            [],
        )
        self.assertTrue(result["valid"], result)
        component = result["quota"]["components"][0]
        self.assertAlmostEqual(component["qty"], 0.15)
        self.assertIn("1m2", component["unitConversion"])

    def test_local_quota_material_quantity_is_converted_before_costing(self):
        detail = apply_explicit_unit_conversion(
            {
                "cat": "材料费",
                "name": "预拌混凝土C25",
                "unit": "m3",
                "qty": 1,
                "noTaxPrice": 400,
                "taxPrice": 452,
            },
            "15cm厚C25混凝土基层浇筑",
            "m2",
            strict=True,
        )
        self.assertAlmostEqual(detail["qty"], 0.15)
        self.assertIn("1m2", detail["unitConversion"])
        calculated = composition_cost_breakdown({**detail, "boqUnit": "m2"})
        self.assertFalse(calculated["conversionRequired"])
        self.assertAlmostEqual(calculated["unitNoTaxTotal"], 60.0)

    def test_missing_quantity_cannot_reuse_stale_source_total(self):
        calculated = composition_cost_breakdown({
            "cat": "材料费",
            "name": "测试材料",
            "unit": "m2",
            "qty": 0,
            "noTaxPrice": 20,
            "taxPrice": 22.6,
            "noTaxTotal": 999,
            "taxTotal": 1128.87,
            "boqUnit": "m2",
        }, 10)
        self.assertFalse(calculated["quantityValid"])
        self.assertTrue(calculated["blockedByQuantity"])
        self.assertIsNone(calculated["unitNoTaxTotal"])
        self.assertIsNone(calculated["engineeringNoTaxTotal"])

    def test_ai_fills_missing_area_volume_quantity_from_explicit_thickness(self):
        result = validate_ai_generated_quota(
            {
                "name": "道路混凝土基层",
                "feature": "15cm厚C25混凝土",
                "unit": "m2",
            },
            {
                "name": "道路混凝土基层",
                "feature": "15cm厚C25混凝土",
                "unit": "m2",
                "components": [{
                    "cat": "材料费",
                    "name": "C25混凝土",
                    "unit": "m3",
                    "qty": 0,
                    "noTaxPrice": 400,
                    "taxRate": 13,
                    "taxPrice": 452,
                    "calculation_basis": "按清单明确厚度计算",
                }],
            },
            [],
        )
        self.assertTrue(result["valid"], result)
        self.assertAlmostEqual(result["quota"]["components"][0]["qty"], 0.15)


if __name__ == "__main__":
    unittest.main()
