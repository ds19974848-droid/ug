import uuid
import unittest

from src.db import get_session
from src.models import QuotaItem
from src.quota_service import preserve_imported_cost_references


class ImportedCostReferenceTests(unittest.TestCase):
    def test_extracts_priced_human_material_machine_rows_into_quota_library(self):
        session = get_session()
        source_file = f"TEST:imported-cost-{uuid.uuid4().hex}"
        try:
            result = preserve_imported_cost_references(
                session,
                [{
                    "name": "测试导入人材机清单",
                    "feature": "混凝土浇筑",
                    "unit": "m3",
                    "quantity": "2",
                    "seq": "1",
                    "code": "TEST-001",
                    "source_tab": "分部分项",
                    "imported_labor": "100",
                    "imported_material": "200",
                    "imported_machinery": "50",
                    "imported_comprehensive_price": "180",
                }],
                source_file=source_file,
                major="测试导入",
            )
            session.commit()

            self.assertEqual(result["imported"], 1)
            self.assertEqual(result["components"], 3)
            self.assertEqual(
                result["categories"],
                {"人工费": 1, "材料费": 1, "机械费": 1},
            )
            item = session.query(QuotaItem).filter(QuotaItem.source == source_file).one()
            self.assertEqual(item.major, "测试导入")
            categories = {
                composition.category: composition.no_tax_price
                for composition in item.compositions
            }
            self.assertEqual(categories["人工费"], 50)
            self.assertEqual(categories["材料费"], 100)
            self.assertEqual(categories["机械费"], 25)
        finally:
            session.query(QuotaItem).filter(
                QuotaItem.source == source_file
            ).delete(synchronize_session=False)
            session.commit()
            session.close()


if __name__ == "__main__":
    unittest.main()
