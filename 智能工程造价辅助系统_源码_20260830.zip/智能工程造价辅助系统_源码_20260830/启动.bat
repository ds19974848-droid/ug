@echo off
title Intelligent Engineering Cost Assistant
cd /d "%~dp0"

echo.
echo ================================
echo   Intelligent Engineering Cost Assistant v0.1
echo ================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.12+
    echo Download: https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)
echo [OK] Python detected

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo [SETUP] Creating virtual environment...
    python -m venv .venv
    echo [OK] Virtual environment created
    echo.
    echo [SETUP] Installing dependencies (3-5 min, first time only)...
    .\.venv\Scripts\python.exe -m pip install -r requirements.txt
    echo [OK] Dependencies installed
) else (
    echo [OK] Environment ready
)

echo.
echo [LAUNCH] Starting Intelligent Engineering Cost Assistant...
.\.venv\Scripts\python.exe src/main.py

echo.
pause
