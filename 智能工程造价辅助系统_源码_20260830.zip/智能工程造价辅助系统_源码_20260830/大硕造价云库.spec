﻿# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['src\\main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('assets\\工程价格数据库_4453条.xlsx', 'assets'),
        ('assets\\信息价数据库.xlsx', 'assets'),
        ('assets\\定额库.xlsx', 'assets'),
        ('assets\\intelligent-cost-logo.svg', 'assets'),
        ('assets\\装饰成本定额.xlsx', 'assets'),
        ('assets\\内蒙古区域企业工程高频项目参考定额8.25(1).xlsx', 'assets'),
        ('使用说明.md', '.'),
    ],
    hiddenimports=[
        'websocket', 'fitz', 'python_calamine', 'xlrd', 'rapidocr_onnxruntime',
        'onnxruntime', 'cv2', 'numpy',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'pandas', 'alembic', 'apscheduler', 'openai', 'pydantic',
        'PySide6.QtQml', 'PySide6.QtQuick', 'PySide6.QtPdf',
        'PySide6.QtVirtualKeyboard',
    ],
    noarchive=False,
    optimize=0,
)

# PySide's hook collects optional Addons DLLs even though this Widgets-only app
# does not import their Python modules. Pillow similarly bundles AVIF support,
# while the app only uses Pillow indirectly for PDF parsing.
unused_binary_names = {
    'qt6quick.dll',
    'qt6qml.dll',
    'qt6qmlmodels.dll',
    'qt6qmlmeta.dll',
    'qt6qmlworkerscript.dll',
    'qt6pdf.dll',
    'qt6virtualkeyboard.dll',
}
a.binaries = [
    item for item in a.binaries
    if item[0].replace('\\', '/').rsplit('/', 1)[-1].lower() not in unused_binary_names
    and not item[0].replace('\\', '/').rsplit('/', 1)[-1].lower().startswith('_avif.')
]

# No QTranslator is installed by the application, so bundled Qt .qm files are
# unreachable at runtime.
a.datas = [
    item for item in a.datas
    if not item[0].replace('\\', '/').lower().startswith('pyside6/translations/')
]
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    name='智能工程造价辅助系统',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    exclude_binaries=True,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='智能工程造价辅助系统',
)
